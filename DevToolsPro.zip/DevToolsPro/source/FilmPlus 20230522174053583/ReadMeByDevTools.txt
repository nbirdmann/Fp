Has filtered some open source or sdk package, include:
1. androidx
https://developer.android.com/topic/libraries/architecture/index

2. android.support
https://developer.android.com/topic/libraries/support-library/

3. butterknife
https://github.com/JakeWharton/butterknife

4. com.amazon.device.ads
https://developer.amazon.com/docs/mobile-ads/mb-quick-start.html

5. com.bumptech.glide
https://github.com/bumptech/glide

6. com.google.android.exoplayer2
https://github.com/google/ExoPlayer

7. com.google.android.gms
https://developers.google.com/android/guides/setup

8. com.google.android.material
https://material.io/develop/android/docs/getting-started/

9. com.google.firebase
https://firebase.google.com/support/guides/firebase-android

10. kotlin
https://kotlinlang.org/

11. org.greenrobot.eventbus
https://github.com/greenrobot/EventBus

12. okhttp3
https://github.com/square/okhttp

