package a.b.a.a;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface a extends IInterface {

    public static class a implements a {
        public IBinder asBinder() {
            return null;
        }

        public void g4(int i, Bundle bundle) throws RemoteException {
        }
    }

    public static abstract class b extends Binder implements a {
        private static final String e = "android.support.v4.os.IResultReceiver";
        static final int f = 1;

        private static class a implements a {
            public static a e;
            private IBinder f;

            a(IBinder iBinder) {
                this.f = iBinder;
            }

            public String X1() {
                return b.e;
            }

            public IBinder asBinder() {
                return this.f;
            }

            public void g4(int i, Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(b.e);
                    obtain.writeInt(i);
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (this.f.transact(1, obtain, null, 1) || b.j4() == null) {
                        obtain.recycle();
                    } else {
                        b.j4().g4(i, bundle);
                    }
                } finally {
                    obtain.recycle();
                }
            }
        }

        public b() {
            attachInterface(this, e);
        }

        public static a X1(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface(e);
            return (queryLocalInterface == null || !(queryLocalInterface instanceof a)) ? new a(iBinder) : (a) queryLocalInterface;
        }

        public static a j4() {
            return a.e;
        }

        public static boolean k4(a aVar) {
            if (a.e != null || aVar == null) {
                return false;
            }
            a.e = aVar;
            return true;
        }

        public IBinder asBinder() {
            return this;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            String str = e;
            if (i == 1) {
                parcel.enforceInterface(str);
                g4(parcel.readInt(), parcel.readInt() != 0 ? (Bundle) Bundle.CREATOR.createFromParcel(parcel) : null);
                return true;
            } else if (i != 1598968902) {
                return super.onTransact(i, parcel, parcel2, i2);
            } else {
                parcel2.writeString(str);
                return true;
            }
        }
    }

    void g4(int i, Bundle bundle) throws RemoteException;
}
