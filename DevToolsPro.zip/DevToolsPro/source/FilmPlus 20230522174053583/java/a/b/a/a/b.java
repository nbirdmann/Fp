package a.b.a.a;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import androidx.annotation.r0;

@SuppressLint({"BanParcelableUsage"})
@r0({androidx.annotation.r0.a.c})
public class b implements Parcelable {
    public static final Creator<b> CREATOR = new a();
    final boolean a;
    final Handler b;
    a c;

    class a implements Creator<b> {
        a() {
        }

        /* renamed from: a */
        public b createFromParcel(Parcel parcel) {
            return new b(parcel);
        }

        /* renamed from: b */
        public b[] newArray(int i) {
            return new b[i];
        }
    }

    class b extends a.b.a.a.a.b {
        b() {
        }

        public void g4(int i, Bundle bundle) {
            b bVar = b.this;
            Handler handler = bVar.b;
            if (handler != null) {
                handler.post(new c(i, bundle));
            } else {
                bVar.a(i, bundle);
            }
        }
    }

    class c implements Runnable {
        final int a;
        final Bundle b;

        c(int i, Bundle bundle) {
            this.a = i;
            this.b = bundle;
        }

        public void run() {
            b.this.a(this.a, this.b);
        }
    }

    public b(Handler handler) {
        this.a = true;
        this.b = handler;
    }

    b(Parcel parcel) {
        this.a = false;
        this.b = null;
        this.c = a.b.a.a.a.b.X1(parcel.readStrongBinder());
    }

    protected void a(int i, Bundle bundle) {
    }

    public void b(int i, Bundle bundle) {
        if (this.a) {
            Handler handler = this.b;
            if (handler != null) {
                handler.post(new c(i, bundle));
            } else {
                a(i, bundle);
            }
            return;
        }
        a aVar = this.c;
        if (aVar != null) {
            try {
                aVar.g4(i, bundle);
            } catch (RemoteException unused) {
            }
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        synchronized (this) {
            if (this.c == null) {
                this.c = new b();
            }
            parcel.writeStrongBinder(this.c.asBinder());
        }
    }
}
