package b.b.a.b;

import androidx.annotation.j0;
import androidx.annotation.r0;
import androidx.annotation.r0.a;

@r0({a.b})
public abstract class c {
    public abstract void a(@j0 Runnable runnable);

    public void b(@j0 Runnable runnable) {
        if (c()) {
            runnable.run();
        } else {
            d(runnable);
        }
    }

    public abstract boolean c();

    public abstract void d(@j0 Runnable runnable);
}
