package b.b.a.b;

import androidx.annotation.j0;
import androidx.annotation.k0;
import androidx.annotation.r0;
import java.util.concurrent.Executor;

@r0({androidx.annotation.r0.a.b})
public class a extends c {
    private static volatile a a;
    @j0
    private static final Executor b = new a();
    @j0
    private static final Executor c = new b();
    @j0
    private c d;
    @j0
    private c e;

    static class a implements Executor {
        a() {
        }

        public void execute(Runnable runnable) {
            a.f().d(runnable);
        }
    }

    static class b implements Executor {
        b() {
        }

        public void execute(Runnable runnable) {
            a.f().a(runnable);
        }
    }

    private a() {
        c bVar = new b();
        this.e = bVar;
        this.d = bVar;
    }

    @j0
    public static Executor e() {
        return c;
    }

    @j0
    public static a f() {
        if (a != null) {
            return a;
        }
        synchronized (a.class) {
            if (a == null) {
                a = new a();
            }
        }
        return a;
    }

    @j0
    public static Executor g() {
        return b;
    }

    public void a(Runnable runnable) {
        this.d.a(runnable);
    }

    public boolean c() {
        return this.d.c();
    }

    public void d(Runnable runnable) {
        this.d.d(runnable);
    }

    public void h(@k0 c cVar) {
        if (cVar == null) {
            cVar = this.e;
        }
        this.d = cVar;
    }
}
