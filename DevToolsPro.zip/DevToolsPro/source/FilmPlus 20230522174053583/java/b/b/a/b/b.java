package b.b.a.b;

import android.os.Handler;
import android.os.Looper;
import androidx.annotation.k0;
import androidx.annotation.r0;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

@r0({androidx.annotation.r0.a.b})
public class b extends c {
    private final Object a = new Object();
    private final ExecutorService b = Executors.newFixedThreadPool(2, new a());
    @k0
    private volatile Handler c;

    class a implements ThreadFactory {
        private static final String a = "arch_disk_io_%d";
        private final AtomicInteger b = new AtomicInteger(0);

        a() {
        }

        public Thread newThread(Runnable runnable) {
            Thread thread = new Thread(runnable);
            thread.setName(String.format(a, new Object[]{Integer.valueOf(this.b.getAndIncrement())}));
            return thread;
        }
    }

    public void a(Runnable runnable) {
        this.b.execute(runnable);
    }

    public boolean c() {
        return Looper.getMainLooper().getThread() == Thread.currentThread();
    }

    public void d(Runnable runnable) {
        if (this.c == null) {
            synchronized (this.a) {
                if (this.c == null) {
                    this.c = new Handler(Looper.getMainLooper());
                }
            }
        }
        this.c.post(runnable);
    }
}
