package b.b.a.c;

import androidx.annotation.j0;
import androidx.annotation.r0;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.WeakHashMap;

@r0({androidx.annotation.r0.a.b})
public class b<K, V> implements Iterable<Entry<K, V>> {
    c<K, V> a;
    private c<K, V> b;
    private WeakHashMap<f<K, V>, Boolean> c = new WeakHashMap();
    private int d = 0;

    interface f<K, V> {
        void a(@j0 c<K, V> cVar);
    }

    private static abstract class e<K, V> implements Iterator<Entry<K, V>>, f<K, V> {
        c<K, V> a;
        c<K, V> b;

        e(c<K, V> cVar, c<K, V> cVar2) {
            this.a = cVar2;
            this.b = cVar;
        }

        private c<K, V> f() {
            c cVar = this.b;
            c cVar2 = this.a;
            return (cVar == cVar2 || cVar2 == null) ? null : d(cVar);
        }

        public void a(@j0 c<K, V> cVar) {
            if (this.a == cVar && cVar == this.b) {
                this.b = null;
                this.a = null;
            }
            c<K, V> cVar2 = this.a;
            if (cVar2 == cVar) {
                this.a = c(cVar2);
            }
            if (this.b == cVar) {
                this.b = f();
            }
        }

        abstract c<K, V> c(c<K, V> cVar);

        abstract c<K, V> d(c<K, V> cVar);

        /* renamed from: e */
        public Entry<K, V> next() {
            Entry entry = this.b;
            this.b = f();
            return entry;
        }

        public boolean hasNext() {
            return this.b != null;
        }
    }

    static class a<K, V> extends e<K, V> {
        a(c<K, V> cVar, c<K, V> cVar2) {
            super(cVar, cVar2);
        }

        c<K, V> c(c<K, V> cVar) {
            return cVar.d;
        }

        c<K, V> d(c<K, V> cVar) {
            return cVar.c;
        }
    }

    private static class b<K, V> extends e<K, V> {
        b(c<K, V> cVar, c<K, V> cVar2) {
            super(cVar, cVar2);
        }

        c<K, V> c(c<K, V> cVar) {
            return cVar.c;
        }

        c<K, V> d(c<K, V> cVar) {
            return cVar.d;
        }
    }

    static class c<K, V> implements Entry<K, V> {
        @j0
        final K a;
        @j0
        final V b;
        c<K, V> c;
        c<K, V> d;

        c(@j0 K k, @j0 V v) {
            this.a = k;
            this.b = v;
        }

        public boolean equals(Object obj) {
            boolean z = true;
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof c)) {
                return false;
            }
            c cVar = (c) obj;
            if (!(this.a.equals(cVar.a) && this.b.equals(cVar.b))) {
                z = false;
            }
            return z;
        }

        @j0
        public K getKey() {
            return this.a;
        }

        @j0
        public V getValue() {
            return this.b;
        }

        public int hashCode() {
            return this.a.hashCode() ^ this.b.hashCode();
        }

        public V setValue(V v) {
            throw new UnsupportedOperationException("An entry modification is not supported");
        }

        public String toString() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.a);
            stringBuilder.append("=");
            stringBuilder.append(this.b);
            return stringBuilder.toString();
        }
    }

    private class d implements Iterator<Entry<K, V>>, f<K, V> {
        private c<K, V> a;
        private boolean b = true;

        d() {
        }

        public void a(@j0 c<K, V> cVar) {
            c<K, V> cVar2 = this.a;
            if (cVar == cVar2) {
                c cVar3 = cVar2.d;
                this.a = cVar3;
                this.b = cVar3 == null;
            }
        }

        /* renamed from: c */
        public Entry<K, V> next() {
            if (this.b) {
                this.b = false;
                this.a = b.this.a;
            } else {
                c cVar = this.a;
                this.a = cVar != null ? cVar.c : null;
            }
            return this.a;
        }

        public boolean hasNext() {
            boolean z = true;
            if (this.b) {
                if (b.this.a == null) {
                    z = false;
                }
                return z;
            }
            c cVar = this.a;
            if (cVar == null || cVar.c == null) {
                z = false;
            }
            return z;
        }
    }

    public Entry<K, V> a() {
        return this.a;
    }

    protected c<K, V> b(K k) {
        c<K, V> cVar = this.a;
        while (cVar != null && !cVar.a.equals(k)) {
            cVar = cVar.c;
        }
        return cVar;
    }

    public d c() {
        d dVar = new d();
        this.c.put(dVar, Boolean.FALSE);
        return dVar;
    }

    public Iterator<Entry<K, V>> descendingIterator() {
        Iterator bVar = new b(this.b, this.a);
        this.c.put(bVar, Boolean.FALSE);
        return bVar;
    }

    public Entry<K, V> e() {
        return this.b;
    }

    public boolean equals(Object obj) {
        boolean z = true;
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof b)) {
            return false;
        }
        b bVar = (b) obj;
        if (size() != bVar.size()) {
            return false;
        }
        Iterator it = iterator();
        Iterator it2 = bVar.iterator();
        while (it.hasNext() && it2.hasNext()) {
            Entry entry = (Entry) it.next();
            Object next = it2.next();
            if ((entry == null && next != null) || (entry != null && !entry.equals(next))) {
                return false;
            }
        }
        if (it.hasNext() || it2.hasNext()) {
            z = false;
        }
        return z;
    }

    protected c<K, V> f(@j0 K k, @j0 V v) {
        c<K, V> cVar = new c(k, v);
        this.d++;
        c cVar2 = this.b;
        if (cVar2 == null) {
            this.a = cVar;
            this.b = cVar;
            return cVar;
        }
        cVar2.c = cVar;
        cVar.d = cVar2;
        this.b = cVar;
        return cVar;
    }

    public int hashCode() {
        Iterator it = iterator();
        int i = 0;
        while (it.hasNext()) {
            i += ((Entry) it.next()).hashCode();
        }
        return i;
    }

    public V i(@j0 K k, @j0 V v) {
        c b = b(k);
        if (b != null) {
            return b.b;
        }
        f(k, v);
        return null;
    }

    @j0
    public Iterator<Entry<K, V>> iterator() {
        Iterator aVar = new a(this.a, this.b);
        this.c.put(aVar, Boolean.FALSE);
        return aVar;
    }

    public V j(@j0 K k) {
        c b = b(k);
        if (b == null) {
            return null;
        }
        this.d--;
        if (!this.c.isEmpty()) {
            for (f a : this.c.keySet()) {
                a.a(b);
            }
        }
        c cVar = b.d;
        if (cVar != null) {
            cVar.c = b.c;
        } else {
            this.a = b.c;
        }
        c cVar2 = b.c;
        if (cVar2 != null) {
            cVar2.d = cVar;
        } else {
            this.b = cVar;
        }
        b.c = null;
        b.d = null;
        return b.b;
    }

    public int size() {
        return this.d;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("[");
        Iterator it = iterator();
        while (it.hasNext()) {
            stringBuilder.append(((Entry) it.next()).toString());
            if (it.hasNext()) {
                stringBuilder.append(", ");
            }
        }
        stringBuilder.append("]");
        return stringBuilder.toString();
    }
}
