package b.b.a.d;

public interface a<I, O> {
    O apply(I i);
}
