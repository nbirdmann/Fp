package b.b.a.c;

import androidx.annotation.j0;
import androidx.annotation.r0;
import java.util.HashMap;
import java.util.Map.Entry;

@r0({androidx.annotation.r0.a.b})
public class a<K, V> extends b<K, V> {
    private HashMap<K, c<K, V>> f = new HashMap();

    protected c<K, V> b(K k) {
        return (c) this.f.get(k);
    }

    public boolean contains(K k) {
        return this.f.containsKey(k);
    }

    public V i(@j0 K k, @j0 V v) {
        c b = b(k);
        if (b != null) {
            return b.b;
        }
        this.f.put(k, f(k, v));
        return null;
    }

    public V j(@j0 K k) {
        V j = super.j(k);
        this.f.remove(k);
        return j;
    }

    public Entry<K, V> k(K k) {
        return contains(k) ? ((c) this.f.get(k)).d : null;
    }
}
