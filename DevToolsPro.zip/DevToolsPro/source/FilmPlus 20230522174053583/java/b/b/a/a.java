package b.b.a;

public final class a {
    private a() {
    }
}
