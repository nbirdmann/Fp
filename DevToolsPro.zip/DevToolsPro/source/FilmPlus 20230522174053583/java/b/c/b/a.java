package b.c.b;

import android.content.Context;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.e0;
import androidx.annotation.j0;
import androidx.annotation.k0;
import androidx.annotation.y0;
import java.util.Objects;
import java.util.concurrent.ArrayBlockingQueue;

public final class a {
    private static final String a = "AsyncLayoutInflater";
    LayoutInflater b;
    Handler c;
    d d;
    private Callback e = new a();

    class a implements Callback {
        a() {
        }

        public boolean handleMessage(Message message) {
            c cVar = (c) message.obj;
            if (cVar.d == null) {
                cVar.d = a.this.b.inflate(cVar.c, cVar.b, false);
            }
            cVar.e.a(cVar.d, cVar.c, cVar.b);
            a.this.d.d(cVar);
            return true;
        }
    }

    private static class b extends LayoutInflater {
        private static final String[] a = new String[]{"android.widget.", "android.webkit.", "android.app."};

        b(Context context) {
            super(context);
        }

        public LayoutInflater cloneInContext(Context context) {
            return new b(context);
        }

        /* DevToolsApp WARNING: Missing block: B:12:0x000f, code:
            continue;
     */
        protected android.view.View onCreateView(java.lang.String r5, android.util.AttributeSet r6) throws java.lang.ClassNotFoundException {
            /*
            r4 = this;
            r0 = a;
            r1 = r0.length;
            r2 = 0;
        L_0x0004:
            if (r2 >= r1) goto L_0x0012;
        L_0x0006:
            r3 = r0[r2];
            r3 = r4.createView(r5, r3, r6);	 Catch:{ ClassNotFoundException -> 0x000f }
            if (r3 == 0) goto L_0x000f;
        L_0x000e:
            return r3;
        L_0x000f:
            r2 = r2 + 1;
            goto L_0x0004;
        L_0x0012:
            r5 = super.onCreateView(r5, r6);
            return r5;
            */
            throw new UnsupportedOperationException("Method not decompiled: b.c.b.a.b.onCreateView(java.lang.String, android.util.AttributeSet):android.view.View");
        }
    }

    private static class c {
        a a;
        ViewGroup b;
        int c;
        View d;
        e e;

        c() {
        }
    }

    private static class d extends Thread {
        private static final d a;
        private ArrayBlockingQueue<c> b = new ArrayBlockingQueue(10);
        private b.h.n.h.c<c> c = new b.h.n.h.c(10);

        static {
            Thread dVar = new d();
            a = dVar;
            dVar.start();
        }

        private d() {
        }

        public static d b() {
            return a;
        }

        public void a(c cVar) {
            try {
                this.b.put(cVar);
            } catch (Throwable e) {
                throw new RuntimeException("Failed to enqueue async inflate request", e);
            }
        }

        public c c() {
            c cVar = (c) this.c.a();
            return cVar == null ? new c() : cVar;
        }

        public void d(c cVar) {
            cVar.e = null;
            cVar.a = null;
            cVar.b = null;
            cVar.c = 0;
            cVar.d = null;
            this.c.b(cVar);
        }

        public void e() {
            String str = a.a;
            try {
                c cVar = (c) this.b.take();
                try {
                    cVar.d = cVar.a.b.inflate(cVar.c, cVar.b, false);
                } catch (Throwable e) {
                    Log.w(str, "Failed to inflate resource in the background! Retrying on the UI thread", e);
                }
                Message.obtain(cVar.a.c, 0, cVar).sendToTarget();
            } catch (Throwable e2) {
                Log.w(str, e2);
            }
        }

        public void run() {
            while (true) {
                e();
            }
        }
    }

    public interface e {
        void a(@j0 View view, @e0 int i, @k0 ViewGroup viewGroup);
    }

    public a(@j0 Context context) {
        this.b = new b(context);
        this.c = new Handler(this.e);
        this.d = d.b();
    }

    @y0
    public void a(@e0 int i, @k0 ViewGroup viewGroup, @j0 e eVar) {
        Objects.requireNonNull(eVar, "callback argument may not be null!");
        c c = this.d.c();
        c.a = this;
        c.c = i;
        c.b = viewGroup;
        c.e = eVar;
        this.d.a(c);
    }
}
