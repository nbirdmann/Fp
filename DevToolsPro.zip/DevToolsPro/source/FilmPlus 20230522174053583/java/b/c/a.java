package b.c;

import com.guideplus.co.R;

public final class a {

    public static final class a {
        public static final int a = 2130968617;
        public static final int b = 2130968850;
        public static final int c = 2130968852;
        public static final int d = 2130968853;
        public static final int e = 2130968854;
        public static final int f = 2130968855;
        public static final int g = 2130968856;
        public static final int h = 2130968857;
        public static final int i = 2130968858;
        public static final int j = 2130968859;
        public static final int k = 2130968860;
        public static final int l = 2130969215;

        private a() {
        }
    }

    public static final class b {
        public static final int a = 2131099809;
        public static final int b = 2131099810;
        public static final int c = 2131099824;
        public static final int d = 2131099826;

        private b() {
        }
    }

    public static final class c {
        public static final int a = 2131165299;
        public static final int b = 2131165300;
        public static final int c = 2131165301;
        public static final int d = 2131165302;
        public static final int e = 2131165303;
        public static final int f = 2131165304;
        public static final int g = 2131165305;
        public static final int h = 2131165457;
        public static final int i = 2131165458;
        public static final int j = 2131165459;
        public static final int k = 2131165460;
        public static final int l = 2131165461;
        public static final int m = 2131165462;
        public static final int n = 2131165463;
        public static final int o = 2131165464;
        public static final int p = 2131165465;
        public static final int q = 2131165466;
        public static final int r = 2131165467;
        public static final int s = 2131165468;
        public static final int t = 2131165469;
        public static final int u = 2131165470;
        public static final int v = 2131165471;

        private c() {
        }
    }

    public static final class d {
        public static final int a = 2131231271;
        public static final int b = 2131231272;
        public static final int c = 2131231273;
        public static final int d = 2131231274;
        public static final int e = 2131231275;
        public static final int f = 2131231276;
        public static final int g = 2131231277;
        public static final int h = 2131231278;
        public static final int i = 2131231279;
        public static final int j = 2131231280;
        public static final int k = 2131231281;
        public static final int l = 2131231282;

        private d() {
        }
    }

    public static final class e {
        public static final int A = 2131362290;
        public static final int B = 2131362294;
        public static final int a = 2131361840;
        public static final int b = 2131361842;
        public static final int c = 2131361843;
        public static final int d = 2131361849;
        public static final int e = 2131361851;
        public static final int f = 2131361868;
        public static final int g = 2131361877;
        public static final int h = 2131361926;
        public static final int i = 2131362038;
        public static final int j = 2131362048;
        public static final int k = 2131362050;
        public static final int l = 2131362087;
        public static final int m = 2131362090;
        public static final int n = 2131362099;
        public static final int o = 2131362100;
        public static final int p = 2131362179;
        public static final int q = 2131362180;
        public static final int r = 2131362182;
        public static final int s = 2131362183;
        public static final int t = 2131362204;
        public static final int u = 2131362205;
        public static final int v = 2131362275;
        public static final int w = 2131362276;
        public static final int x = 2131362277;
        public static final int y = 2131362278;
        public static final int z = 2131362279;

        private e() {
        }
    }

    public static final class f {
        public static final int a = 2131427353;

        private f() {
        }
    }

    public static final class g {
        public static final int a = 2131558534;
        public static final int b = 2131558535;
        public static final int c = 2131558544;
        public static final int d = 2131558545;
        public static final int e = 2131558549;
        public static final int f = 2131558550;

        private g() {
        }
    }

    public static final class h {
        public static final int a = 2131886385;

        private h() {
        }
    }

    public static final class i {
        public static final int a = 2131951949;
        public static final int b = 2131951950;
        public static final int c = 2131951952;
        public static final int d = 2131951955;
        public static final int e = 2131951957;
        public static final int f = 2131952138;
        public static final int g = 2131952139;

        private i() {
        }
    }

    public static final class j {
        public static final int A = 3;
        public static final int B = 4;
        public static final int C = 5;
        public static final int D = 6;
        public static final int E = 7;
        public static final int F = 8;
        public static final int G = 9;
        public static final int H = 10;
        public static final int I = 11;
        public static final int[] J = new int[]{16843173, 16844052};
        public static final int K = 0;
        public static final int L = 1;
        public static final int[] a = new int[]{16843173, 16843551, R.attr.alpha};
        public static final int b = 0;
        public static final int c = 1;
        public static final int d = 2;
        public static final int[] e = new int[]{R.attr.fontProviderAuthority, R.attr.fontProviderCerts, R.attr.fontProviderFetchStrategy, R.attr.fontProviderFetchTimeout, R.attr.fontProviderPackage, R.attr.fontProviderQuery};
        public static final int f = 0;
        public static final int g = 1;
        public static final int h = 2;
        public static final int i = 3;
        public static final int j = 4;
        public static final int k = 5;
        public static final int[] l = new int[]{16844082, 16844083, 16844095, 16844143, 16844144, R.attr.font, R.attr.fontStyle, R.attr.fontVariationSettings, R.attr.fontWeight, R.attr.ttcIndex};
        public static final int m = 0;
        public static final int n = 1;
        public static final int o = 2;
        public static final int p = 3;
        public static final int q = 4;
        public static final int r = 5;
        public static final int s = 6;
        public static final int t = 7;
        public static final int u = 8;
        public static final int v = 9;
        public static final int[] w = new int[]{16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051};
        public static final int x = 0;
        public static final int y = 1;
        public static final int z = 2;

        private j() {
        }
    }

    private a() {
    }
}
