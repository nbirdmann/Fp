package b.e;

import androidx.annotation.j0;
import androidx.annotation.k0;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

public class g<K, V> {
    private final LinkedHashMap<K, V> a;
    private int b;
    private int c;
    private int d;
    private int e;
    private int f;
    private int g;
    private int h;

    public g(int i) {
        if (i > 0) {
            this.c = i;
            this.a = new LinkedHashMap(0, 0.75f, true);
            return;
        }
        throw new IllegalArgumentException("maxSize <= 0");
    }

    private int n(K k, V v) {
        int p = p(k, v);
        if (p >= 0) {
            return p;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Negative size: ");
        stringBuilder.append(k);
        stringBuilder.append("=");
        stringBuilder.append(v);
        throw new IllegalStateException(stringBuilder.toString());
    }

    @k0
    protected V a(@j0 K k) {
        return null;
    }

    public final synchronized int b() {
        return this.e;
    }

    protected void c(boolean z, @j0 K k, @j0 V v, @k0 V v2) {
    }

    public final void d() {
        r(-1);
    }

    public final synchronized int e() {
        return this.f;
    }

    /* DevToolsApp WARNING: Missing block: B:10:0x001d, code:
            r0 = a(r5);
     */
    /* DevToolsApp WARNING: Missing block: B:11:0x0021, code:
            if (r0 != null) goto L_0x0025;
     */
    /* DevToolsApp WARNING: Missing block: B:13:0x0024, code:
            return null;
     */
    /* DevToolsApp WARNING: Missing block: B:14:0x0025, code:
            monitor-enter(r4);
     */
    /* DevToolsApp WARNING: Missing block: B:16:?, code:
            r4.e++;
            r1 = r4.a.put(r5, r0);
     */
    /* DevToolsApp WARNING: Missing block: B:17:0x0032, code:
            if (r1 == null) goto L_0x003a;
     */
    /* DevToolsApp WARNING: Missing block: B:18:0x0034, code:
            r4.a.put(r5, r1);
     */
    /* DevToolsApp WARNING: Missing block: B:19:0x003a, code:
            r4.b += n(r5, r0);
     */
    /* DevToolsApp WARNING: Missing block: B:20:0x0043, code:
            monitor-exit(r4);
     */
    /* DevToolsApp WARNING: Missing block: B:21:0x0044, code:
            if (r1 == null) goto L_0x004b;
     */
    /* DevToolsApp WARNING: Missing block: B:22:0x0046, code:
            c(false, r5, r0, r1);
     */
    /* DevToolsApp WARNING: Missing block: B:23:0x004a, code:
            return r1;
     */
    /* DevToolsApp WARNING: Missing block: B:24:0x004b, code:
            r(r4.c);
     */
    /* DevToolsApp WARNING: Missing block: B:25:0x0050, code:
            return r0;
     */
    @androidx.annotation.k0
    public final V f(@androidx.annotation.j0 K r5) {
        /*
        r4 = this;
        r0 = "key == null";
        java.util.Objects.requireNonNull(r5, r0);
        monitor-enter(r4);
        r0 = r4.a;	 Catch:{ all -> 0x0054 }
        r0 = r0.get(r5);	 Catch:{ all -> 0x0054 }
        if (r0 == 0) goto L_0x0016;
    L_0x000e:
        r5 = r4.g;	 Catch:{ all -> 0x0054 }
        r5 = r5 + 1;
        r4.g = r5;	 Catch:{ all -> 0x0054 }
        monitor-exit(r4);	 Catch:{ all -> 0x0054 }
        return r0;
    L_0x0016:
        r0 = r4.h;	 Catch:{ all -> 0x0054 }
        r0 = r0 + 1;
        r4.h = r0;	 Catch:{ all -> 0x0054 }
        monitor-exit(r4);	 Catch:{ all -> 0x0054 }
        r0 = r4.a(r5);
        if (r0 != 0) goto L_0x0025;
    L_0x0023:
        r5 = 0;
        return r5;
    L_0x0025:
        monitor-enter(r4);
        r1 = r4.e;	 Catch:{ all -> 0x0051 }
        r1 = r1 + 1;
        r4.e = r1;	 Catch:{ all -> 0x0051 }
        r1 = r4.a;	 Catch:{ all -> 0x0051 }
        r1 = r1.put(r5, r0);	 Catch:{ all -> 0x0051 }
        if (r1 == 0) goto L_0x003a;
    L_0x0034:
        r2 = r4.a;	 Catch:{ all -> 0x0051 }
        r2.put(r5, r1);	 Catch:{ all -> 0x0051 }
        goto L_0x0043;
    L_0x003a:
        r2 = r4.b;	 Catch:{ all -> 0x0051 }
        r3 = r4.n(r5, r0);	 Catch:{ all -> 0x0051 }
        r2 = r2 + r3;
        r4.b = r2;	 Catch:{ all -> 0x0051 }
    L_0x0043:
        monitor-exit(r4);	 Catch:{ all -> 0x0051 }
        if (r1 == 0) goto L_0x004b;
    L_0x0046:
        r2 = 0;
        r4.c(r2, r5, r0, r1);
        return r1;
    L_0x004b:
        r5 = r4.c;
        r4.r(r5);
        return r0;
    L_0x0051:
        r5 = move-exception;
        monitor-exit(r4);	 Catch:{ all -> 0x0051 }
        throw r5;
    L_0x0054:
        r5 = move-exception;
        monitor-exit(r4);	 Catch:{ all -> 0x0054 }
        throw r5;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.e.g.f(java.lang.Object):V");
    }

    public final synchronized int g() {
        return this.g;
    }

    public final synchronized int h() {
        return this.c;
    }

    public final synchronized int i() {
        return this.h;
    }

    @k0
    public final V j(@j0 K k, @j0 V v) {
        if (k == null || v == null) {
            throw new NullPointerException("key == null || value == null");
        }
        V put;
        synchronized (this) {
            this.d++;
            this.b += n(k, v);
            put = this.a.put(k, v);
            if (put != null) {
                this.b -= n(k, put);
            }
        }
        if (put != null) {
            c(false, k, put, v);
        }
        r(this.c);
        return put;
    }

    public final synchronized int k() {
        return this.d;
    }

    @k0
    public final V l(@j0 K k) {
        V remove;
        Objects.requireNonNull(k, "key == null");
        synchronized (this) {
            remove = this.a.remove(k);
            if (remove != null) {
                this.b -= n(k, remove);
            }
        }
        if (remove != null) {
            c(false, k, remove, null);
        }
        return remove;
    }

    public void m(int i) {
        if (i > 0) {
            synchronized (this) {
                this.c = i;
            }
            r(i);
            return;
        }
        throw new IllegalArgumentException("maxSize <= 0");
    }

    public final synchronized int o() {
        return this.b;
    }

    protected int p(@j0 K k, @j0 V v) {
        return 1;
    }

    public final synchronized Map<K, V> q() {
        return new LinkedHashMap(this.a);
    }

    /* DevToolsApp WARNING: Missing block: B:17:0x0051, code:
            return;
     */
    public void r(int r5) {
        /*
        r4 = this;
    L_0x0000:
        monitor-enter(r4);
        r0 = r4.b;	 Catch:{ all -> 0x0071 }
        if (r0 < 0) goto L_0x0052;
    L_0x0005:
        r0 = r4.a;	 Catch:{ all -> 0x0071 }
        r0 = r0.isEmpty();	 Catch:{ all -> 0x0071 }
        if (r0 == 0) goto L_0x0011;
    L_0x000d:
        r0 = r4.b;	 Catch:{ all -> 0x0071 }
        if (r0 != 0) goto L_0x0052;
    L_0x0011:
        r0 = r4.b;	 Catch:{ all -> 0x0071 }
        if (r0 <= r5) goto L_0x0050;
    L_0x0015:
        r0 = r4.a;	 Catch:{ all -> 0x0071 }
        r0 = r0.isEmpty();	 Catch:{ all -> 0x0071 }
        if (r0 == 0) goto L_0x001e;
    L_0x001d:
        goto L_0x0050;
    L_0x001e:
        r0 = r4.a;	 Catch:{ all -> 0x0071 }
        r0 = r0.entrySet();	 Catch:{ all -> 0x0071 }
        r0 = r0.iterator();	 Catch:{ all -> 0x0071 }
        r0 = r0.next();	 Catch:{ all -> 0x0071 }
        r0 = (java.util.Map.Entry) r0;	 Catch:{ all -> 0x0071 }
        r1 = r0.getKey();	 Catch:{ all -> 0x0071 }
        r0 = r0.getValue();	 Catch:{ all -> 0x0071 }
        r2 = r4.a;	 Catch:{ all -> 0x0071 }
        r2.remove(r1);	 Catch:{ all -> 0x0071 }
        r2 = r4.b;	 Catch:{ all -> 0x0071 }
        r3 = r4.n(r1, r0);	 Catch:{ all -> 0x0071 }
        r2 = r2 - r3;
        r4.b = r2;	 Catch:{ all -> 0x0071 }
        r2 = r4.f;	 Catch:{ all -> 0x0071 }
        r3 = 1;
        r2 = r2 + r3;
        r4.f = r2;	 Catch:{ all -> 0x0071 }
        monitor-exit(r4);	 Catch:{ all -> 0x0071 }
        r2 = 0;
        r4.c(r3, r1, r0, r2);
        goto L_0x0000;
    L_0x0050:
        monitor-exit(r4);	 Catch:{ all -> 0x0071 }
        return;
    L_0x0052:
        r5 = new java.lang.IllegalStateException;	 Catch:{ all -> 0x0071 }
        r0 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0071 }
        r0.<init>();	 Catch:{ all -> 0x0071 }
        r1 = r4.getClass();	 Catch:{ all -> 0x0071 }
        r1 = r1.getName();	 Catch:{ all -> 0x0071 }
        r0.append(r1);	 Catch:{ all -> 0x0071 }
        r1 = ".sizeOf() is reporting inconsistent results!";
        r0.append(r1);	 Catch:{ all -> 0x0071 }
        r0 = r0.toString();	 Catch:{ all -> 0x0071 }
        r5.<init>(r0);	 Catch:{ all -> 0x0071 }
        throw r5;	 Catch:{ all -> 0x0071 }
    L_0x0071:
        r5 = move-exception;
        monitor-exit(r4);	 Catch:{ all -> 0x0071 }
        goto L_0x0075;
    L_0x0074:
        throw r5;
    L_0x0075:
        goto L_0x0074;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.e.g.r(int):void");
    }

    public final synchronized String toString() {
        int i;
        i = this.g;
        int i2 = this.h + i;
        i = i2 != 0 ? (i * 100) / i2 : 0;
        return String.format(Locale.US, "LruCache[maxSize=%d,hits=%d,misses=%d,hitRate=%d%%]", new Object[]{Integer.valueOf(this.c), Integer.valueOf(this.g), Integer.valueOf(this.h), Integer.valueOf(i)});
    }
}
