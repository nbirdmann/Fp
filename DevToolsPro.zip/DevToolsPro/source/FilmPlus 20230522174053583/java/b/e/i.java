package b.e;

import androidx.annotation.j0;
import androidx.annotation.k0;
import java.util.ConcurrentModificationException;

public class i<K, V> {
    private static final boolean a = false;
    private static final String b = "ArrayMap";
    private static final boolean c = true;
    private static final int d = 4;
    private static final int f = 10;
    static int q0;
    @k0
    static Object[] r0;
    @k0
    static Object[] s;
    static int s0;
    int[] t0;
    Object[] u0;
    int v0;

    public i() {
        this.t0 = e.a;
        this.u0 = e.c;
        this.v0 = 0;
    }

    public i(int i) {
        if (i == 0) {
            this.t0 = e.a;
            this.u0 = e.c;
        } else {
            a(i);
        }
        this.v0 = 0;
    }

    public i(i<K, V> iVar) {
        this();
        if (iVar != null) {
            l(iVar);
        }
    }

    private void a(int i) {
        Class cls = i.class;
        Object[] objArr;
        if (i == 8) {
            synchronized (cls) {
                objArr = r0;
                if (objArr != null) {
                    this.u0 = objArr;
                    r0 = (Object[]) objArr[0];
                    this.t0 = (int[]) objArr[1];
                    objArr[1] = null;
                    objArr[0] = null;
                    s0--;
                    return;
                }
            }
        } else if (i == 4) {
            synchronized (cls) {
                objArr = s;
                if (objArr != null) {
                    this.u0 = objArr;
                    s = (Object[]) objArr[0];
                    this.t0 = (int[]) objArr[1];
                    objArr[1] = null;
                    objArr[0] = null;
                    q0--;
                    return;
                }
            }
        }
        this.t0 = new int[i];
        this.u0 = new Object[(i << 1)];
    }

    private static int b(int[] iArr, int i, int i2) {
        try {
            return e.a(iArr, i, i2);
        } catch (ArrayIndexOutOfBoundsException unused) {
            throw new ConcurrentModificationException();
        }
    }

    private static void d(int[] iArr, Object[] objArr, int i) {
        Class cls = i.class;
        int i2;
        if (iArr.length == 8) {
            synchronized (cls) {
                if (s0 < 10) {
                    objArr[0] = r0;
                    objArr[1] = iArr;
                    for (i2 = (i << 1) - 1; i2 >= 2; i2--) {
                        objArr[i2] = null;
                    }
                    r0 = objArr;
                    s0++;
                }
            }
        } else if (iArr.length == 4) {
            synchronized (cls) {
                if (q0 < 10) {
                    objArr[0] = s;
                    objArr[1] = iArr;
                    for (i2 = (i << 1) - 1; i2 >= 2; i2--) {
                        objArr[i2] = null;
                    }
                    s = objArr;
                    q0++;
                }
            }
        }
    }

    public void c(int i) {
        int i2 = this.v0;
        Object obj = this.t0;
        if (obj.length < i) {
            Object obj2 = this.u0;
            a(i);
            if (this.v0 > 0) {
                System.arraycopy(obj, 0, this.t0, 0, i2);
                System.arraycopy(obj2, 0, this.u0, 0, i2 << 1);
            }
            d(obj, obj2, i2);
        }
        if (this.v0 != i2) {
            throw new ConcurrentModificationException();
        }
    }

    public void clear() {
        int i = this.v0;
        if (i > 0) {
            int[] iArr = this.t0;
            Object[] objArr = this.u0;
            this.t0 = e.a;
            this.u0 = e.c;
            this.v0 = 0;
            d(iArr, objArr, i);
        }
        if (this.v0 > 0) {
            throw new ConcurrentModificationException();
        }
    }

    public boolean containsKey(@k0 Object obj) {
        return f(obj) >= 0;
    }

    public boolean containsValue(Object obj) {
        return h(obj) >= 0;
    }

    int e(Object obj, int i) {
        int i2 = this.v0;
        if (i2 == 0) {
            return -1;
        }
        int b = b(this.t0, i2, i);
        if (b < 0 || obj.equals(this.u0[b << 1])) {
            return b;
        }
        int i3 = b + 1;
        while (i3 < i2 && this.t0[i3] == i) {
            if (obj.equals(this.u0[i3 << 1])) {
                return i3;
            }
            i3++;
        }
        b--;
        while (b >= 0 && this.t0[b] == i) {
            if (obj.equals(this.u0[b << 1])) {
                return b;
            }
            b--;
        }
        return i3 ^ -1;
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:23:0x003d A:{RETURN, ExcHandler: java.lang.NullPointerException (unused java.lang.NullPointerException), Splitter: B:9:0x0017} */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:44:0x0076 A:{RETURN, ExcHandler: java.lang.NullPointerException (unused java.lang.NullPointerException), Splitter: B:30:0x0050} */
    /* DevToolsApp WARNING: Missing block: B:23:0x003d, code:
            return false;
     */
    /* DevToolsApp WARNING: Missing block: B:44:0x0076, code:
            return false;
     */
    public boolean equals(java.lang.Object r7) {
        /*
        r6 = this;
        r0 = 1;
        if (r6 != r7) goto L_0x0004;
    L_0x0003:
        return r0;
    L_0x0004:
        r1 = r7 instanceof b.e.i;
        r2 = 0;
        if (r1 == 0) goto L_0x003e;
    L_0x0009:
        r7 = (b.e.i) r7;
        r1 = r6.size();
        r3 = r7.size();
        if (r1 == r3) goto L_0x0016;
    L_0x0015:
        return r2;
    L_0x0016:
        r1 = 0;
    L_0x0017:
        r3 = r6.v0;	 Catch:{ NullPointerException -> 0x003d, NullPointerException -> 0x003d }
        if (r1 >= r3) goto L_0x003c;
    L_0x001b:
        r3 = r6.i(r1);	 Catch:{ NullPointerException -> 0x003d, NullPointerException -> 0x003d }
        r4 = r6.p(r1);	 Catch:{ NullPointerException -> 0x003d, NullPointerException -> 0x003d }
        r5 = r7.get(r3);	 Catch:{ NullPointerException -> 0x003d, NullPointerException -> 0x003d }
        if (r4 != 0) goto L_0x0032;
    L_0x0029:
        if (r5 != 0) goto L_0x0031;
    L_0x002b:
        r3 = r7.containsKey(r3);	 Catch:{ NullPointerException -> 0x003d, NullPointerException -> 0x003d }
        if (r3 != 0) goto L_0x0039;
    L_0x0031:
        return r2;
    L_0x0032:
        r3 = r4.equals(r5);	 Catch:{ NullPointerException -> 0x003d, NullPointerException -> 0x003d }
        if (r3 != 0) goto L_0x0039;
    L_0x0038:
        return r2;
    L_0x0039:
        r1 = r1 + 1;
        goto L_0x0017;
    L_0x003c:
        return r0;
    L_0x003d:
        return r2;
    L_0x003e:
        r1 = r7 instanceof java.util.Map;
        if (r1 == 0) goto L_0x0076;
    L_0x0042:
        r7 = (java.util.Map) r7;
        r1 = r6.size();
        r3 = r7.size();
        if (r1 == r3) goto L_0x004f;
    L_0x004e:
        return r2;
    L_0x004f:
        r1 = 0;
    L_0x0050:
        r3 = r6.v0;	 Catch:{ NullPointerException -> 0x0076, NullPointerException -> 0x0076 }
        if (r1 >= r3) goto L_0x0075;
    L_0x0054:
        r3 = r6.i(r1);	 Catch:{ NullPointerException -> 0x0076, NullPointerException -> 0x0076 }
        r4 = r6.p(r1);	 Catch:{ NullPointerException -> 0x0076, NullPointerException -> 0x0076 }
        r5 = r7.get(r3);	 Catch:{ NullPointerException -> 0x0076, NullPointerException -> 0x0076 }
        if (r4 != 0) goto L_0x006b;
    L_0x0062:
        if (r5 != 0) goto L_0x006a;
    L_0x0064:
        r3 = r7.containsKey(r3);	 Catch:{ NullPointerException -> 0x0076, NullPointerException -> 0x0076 }
        if (r3 != 0) goto L_0x0072;
    L_0x006a:
        return r2;
    L_0x006b:
        r3 = r4.equals(r5);	 Catch:{ NullPointerException -> 0x0076, NullPointerException -> 0x0076 }
        if (r3 != 0) goto L_0x0072;
    L_0x0071:
        return r2;
    L_0x0072:
        r1 = r1 + 1;
        goto L_0x0050;
    L_0x0075:
        return r0;
    L_0x0076:
        return r2;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.e.i.equals(java.lang.Object):boolean");
    }

    public int f(@k0 Object obj) {
        return obj == null ? g() : e(obj, obj.hashCode());
    }

    int g() {
        int i = this.v0;
        if (i == 0) {
            return -1;
        }
        int b = b(this.t0, i, 0);
        if (b < 0 || this.u0[b << 1] == null) {
            return b;
        }
        int i2 = b + 1;
        while (i2 < i && this.t0[i2] == 0) {
            if (this.u0[i2 << 1] == null) {
                return i2;
            }
            i2++;
        }
        b--;
        while (b >= 0 && this.t0[b] == 0) {
            if (this.u0[b << 1] == null) {
                return b;
            }
            b--;
        }
        return i2 ^ -1;
    }

    @k0
    public V get(Object obj) {
        return getOrDefault(obj, null);
    }

    public V getOrDefault(Object obj, V v) {
        int f = f(obj);
        return f >= 0 ? this.u0[(f << 1) + 1] : v;
    }

    int h(Object obj) {
        int i = this.v0 * 2;
        Object[] objArr = this.u0;
        if (obj == null) {
            for (int i2 = 1; i2 < i; i2 += 2) {
                if (objArr[i2] == null) {
                    return i2 >> 1;
                }
            }
        } else {
            for (int i3 = 1; i3 < i; i3 += 2) {
                if (obj.equals(objArr[i3])) {
                    return i3 >> 1;
                }
            }
        }
        return -1;
    }

    public int hashCode() {
        int[] iArr = this.t0;
        Object[] objArr = this.u0;
        int i = this.v0;
        int i2 = 1;
        int i3 = 0;
        int i4 = 0;
        while (i3 < i) {
            Object obj = objArr[i2];
            i4 += (obj == null ? 0 : obj.hashCode()) ^ iArr[i3];
            i3++;
            i2 += 2;
        }
        return i4;
    }

    public K i(int i) {
        return this.u0[i << 1];
    }

    public boolean isEmpty() {
        return this.v0 <= 0;
    }

    public void l(@j0 i<? extends K, ? extends V> iVar) {
        int i = iVar.v0;
        c(this.v0 + i);
        int i2 = 0;
        if (this.v0 != 0) {
            while (i2 < i) {
                put(iVar.i(i2), iVar.p(i2));
                i2++;
            }
        } else if (i > 0) {
            System.arraycopy(iVar.t0, 0, this.t0, 0, i);
            System.arraycopy(iVar.u0, 0, this.u0, 0, i << 1);
            this.v0 = i;
        }
    }

    public V m(int i) {
        Object obj = this.u0;
        int i2 = i << 1;
        V v = obj[i2 + 1];
        int i3 = this.v0;
        int i4 = 0;
        if (i3 <= 1) {
            d(this.t0, obj, i3);
            this.t0 = e.a;
            this.u0 = e.c;
        } else {
            int i5 = i3 - 1;
            Object obj2 = this.t0;
            int i6 = 8;
            if (obj2.length <= 8 || i3 >= obj2.length / 3) {
                int i7;
                if (i < i5) {
                    i7 = i + 1;
                    i4 = i5 - i;
                    System.arraycopy(obj2, i7, obj2, i, i4);
                    Object obj3 = this.u0;
                    System.arraycopy(obj3, i7 << 1, obj3, i2, i4 << 1);
                }
                Object[] objArr = this.u0;
                i7 = i5 << 1;
                objArr[i7] = null;
                objArr[i7 + 1] = null;
            } else {
                if (i3 > 8) {
                    i6 = i3 + (i3 >> 1);
                }
                a(i6);
                if (i3 == this.v0) {
                    if (i > 0) {
                        System.arraycopy(obj2, 0, this.t0, 0, i);
                        System.arraycopy(obj, 0, this.u0, 0, i2);
                    }
                    if (i < i5) {
                        i4 = i + 1;
                        i6 = i5 - i;
                        System.arraycopy(obj2, i4, this.t0, i, i6);
                        System.arraycopy(obj, i4 << 1, this.u0, i2, i6 << 1);
                    }
                } else {
                    throw new ConcurrentModificationException();
                }
            }
            i4 = i5;
        }
        if (i3 == this.v0) {
            this.v0 = i4;
            return v;
        }
        throw new ConcurrentModificationException();
    }

    public V n(int i, V v) {
        i = (i << 1) + 1;
        Object[] objArr = this.u0;
        V v2 = objArr[i];
        objArr[i] = v;
        return v2;
    }

    public V p(int i) {
        return this.u0[(i << 1) + 1];
    }

    @k0
    public V put(K k, V v) {
        int g;
        int i;
        int i2 = this.v0;
        if (k == null) {
            g = g();
            i = 0;
        } else {
            g = k.hashCode();
            i = g;
            g = e(k, g);
        }
        Object[] objArr;
        if (g >= 0) {
            int i3 = (g << 1) + 1;
            objArr = this.u0;
            V v2 = objArr[i3];
            objArr[i3] = v;
            return v2;
        }
        g ^= -1;
        Object obj = this.t0;
        if (i2 >= obj.length) {
            int i4 = 4;
            if (i2 >= 8) {
                i4 = (i2 >> 1) + i2;
            } else if (i2 >= 4) {
                i4 = 8;
            }
            Object obj2 = this.u0;
            a(i4);
            if (i2 == this.v0) {
                Object obj3 = this.t0;
                if (obj3.length > 0) {
                    System.arraycopy(obj, 0, obj3, 0, obj.length);
                    System.arraycopy(obj2, 0, this.u0, 0, obj2.length);
                }
                d(obj, obj2, i2);
            } else {
                throw new ConcurrentModificationException();
            }
        }
        if (g < i2) {
            Object obj4 = this.t0;
            int i5 = g + 1;
            System.arraycopy(obj4, g, obj4, i5, i2 - g);
            obj4 = this.u0;
            System.arraycopy(obj4, g << 1, obj4, i5 << 1, (this.v0 - g) << 1);
        }
        int i6 = this.v0;
        if (i2 == i6) {
            int[] iArr = this.t0;
            if (g < iArr.length) {
                iArr[g] = i;
                objArr = this.u0;
                g <<= 1;
                objArr[g] = k;
                objArr[g + 1] = v;
                this.v0 = i6 + 1;
                return null;
            }
        }
        throw new ConcurrentModificationException();
    }

    @k0
    public V putIfAbsent(K k, V v) {
        V v2 = get(k);
        return v2 == null ? put(k, v) : v2;
    }

    @k0
    public V remove(Object obj) {
        int f = f(obj);
        return f >= 0 ? m(f) : null;
    }

    public boolean remove(Object obj, Object obj2) {
        int f = f(obj);
        if (f >= 0) {
            Object p = p(f);
            if (obj2 == p || (obj2 != null && obj2.equals(p))) {
                m(f);
                return true;
            }
        }
        return false;
    }

    @k0
    public V replace(K k, V v) {
        int f = f(k);
        return f >= 0 ? n(f, v) : null;
    }

    public boolean replace(K k, V v, V v2) {
        int f = f(k);
        if (f >= 0) {
            V p = p(f);
            if (p == v || (v != null && v.equals(p))) {
                n(f, v2);
                return true;
            }
        }
        return false;
    }

    public int size() {
        return this.v0;
    }

    public String toString() {
        if (isEmpty()) {
            return "{}";
        }
        StringBuilder stringBuilder = new StringBuilder(this.v0 * 28);
        stringBuilder.append('{');
        for (int i = 0; i < this.v0; i++) {
            if (i > 0) {
                stringBuilder.append(", ");
            }
            i i2 = i(i);
            String str = "(this Map)";
            if (i2 != this) {
                stringBuilder.append(i2);
            } else {
                stringBuilder.append(str);
            }
            stringBuilder.append('=');
            i2 = p(i);
            if (i2 != this) {
                stringBuilder.append(i2);
            } else {
                stringBuilder.append(str);
            }
        }
        stringBuilder.append('}');
        return stringBuilder.toString();
    }
}
