package b.e;

import androidx.annotation.j0;
import androidx.annotation.k0;

public class j<E> implements Cloneable {
    private static final Object a = new Object();
    private boolean b;
    private int[] c;
    private Object[] d;
    private int f;

    public j() {
        this(10);
    }

    public j(int i) {
        this.b = false;
        if (i == 0) {
            this.c = e.a;
            this.d = e.c;
            return;
        }
        i = e.e(i);
        this.c = new int[i];
        this.d = new Object[i];
    }

    private void g() {
        int i = this.f;
        int[] iArr = this.c;
        Object[] objArr = this.d;
        int i2 = 0;
        for (int i3 = 0; i3 < i; i3++) {
            Object obj = objArr[i3];
            if (obj != a) {
                if (i3 != i2) {
                    iArr[i2] = iArr[i3];
                    objArr[i2] = obj;
                    objArr[i3] = null;
                }
                i2++;
            }
        }
        this.b = false;
        this.f = i2;
    }

    public int A() {
        if (this.b) {
            g();
        }
        return this.f;
    }

    public E B(int i) {
        if (this.b) {
            g();
        }
        return this.d[i];
    }

    public void a(int i, E e) {
        int i2 = this.f;
        if (i2 == 0 || i > this.c[i2 - 1]) {
            if (this.b && i2 >= this.c.length) {
                g();
            }
            i2 = this.f;
            if (i2 >= this.c.length) {
                int e2 = e.e(i2 + 1);
                Object obj = new int[e2];
                Object obj2 = new Object[e2];
                Object obj3 = this.c;
                System.arraycopy(obj3, 0, obj, 0, obj3.length);
                obj3 = this.d;
                System.arraycopy(obj3, 0, obj2, 0, obj3.length);
                this.c = obj;
                this.d = obj2;
            }
            this.c[i2] = i;
            this.d[i2] = e;
            this.f = i2 + 1;
            return;
        }
        q(i, e);
    }

    public void b() {
        int i = this.f;
        Object[] objArr = this.d;
        for (int i2 = 0; i2 < i; i2++) {
            objArr[i2] = null;
        }
        this.f = 0;
        this.b = false;
    }

    /* renamed from: c */
    public j<E> clone() {
        try {
            j<E> jVar = (j) super.clone();
            jVar.c = (int[]) this.c.clone();
            jVar.d = (Object[]) this.d.clone();
            return jVar;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError(e);
        }
    }

    public boolean d(int i) {
        return j(i) >= 0;
    }

    public boolean e(E e) {
        return k(e) >= 0;
    }

    @Deprecated
    public void f(int i) {
        t(i);
    }

    @k0
    public E h(int i) {
        return i(i, null);
    }

    public E i(int i, E e) {
        i = e.a(this.c, this.f, i);
        if (i >= 0) {
            Object[] objArr = this.d;
            if (objArr[i] != a) {
                return objArr[i];
            }
        }
        return e;
    }

    public int j(int i) {
        if (this.b) {
            g();
        }
        return e.a(this.c, this.f, i);
    }

    public int k(E e) {
        if (this.b) {
            g();
        }
        for (int i = 0; i < this.f; i++) {
            if (this.d[i] == e) {
                return i;
            }
        }
        return -1;
    }

    public boolean o() {
        return A() == 0;
    }

    public int p(int i) {
        if (this.b) {
            g();
        }
        return this.c[i];
    }

    public void q(int i, E e) {
        int a = e.a(this.c, this.f, i);
        if (a >= 0) {
            this.d[a] = e;
        } else {
            Object obj;
            Object obj2;
            a ^= -1;
            int i2 = this.f;
            if (a < i2) {
                Object[] objArr = this.d;
                if (objArr[a] == a) {
                    this.c[a] = i;
                    objArr[a] = e;
                    return;
                }
            }
            if (this.b && i2 >= this.c.length) {
                g();
                a = e.a(this.c, this.f, i) ^ -1;
            }
            i2 = this.f;
            if (i2 >= this.c.length) {
                i2 = e.e(i2 + 1);
                obj = new int[i2];
                obj2 = new Object[i2];
                Object obj3 = this.c;
                System.arraycopy(obj3, 0, obj, 0, obj3.length);
                obj3 = this.d;
                System.arraycopy(obj3, 0, obj2, 0, obj3.length);
                this.c = obj;
                this.d = obj2;
            }
            i2 = this.f;
            if (i2 - a != 0) {
                obj = this.c;
                int i3 = a + 1;
                System.arraycopy(obj, a, obj, i3, i2 - a);
                obj2 = this.d;
                System.arraycopy(obj2, a, obj2, i3, this.f - a);
            }
            this.c[a] = i;
            this.d[a] = e;
            this.f++;
        }
    }

    public void r(@j0 j<? extends E> jVar) {
        int A = jVar.A();
        for (int i = 0; i < A; i++) {
            q(jVar.p(i), jVar.B(i));
        }
    }

    @k0
    public E s(int i, E e) {
        E h = h(i);
        if (h == null) {
            q(i, e);
        }
        return h;
    }

    public void t(int i) {
        i = e.a(this.c, this.f, i);
        if (i >= 0) {
            Object[] objArr = this.d;
            Object obj = objArr[i];
            Object obj2 = a;
            if (obj != obj2) {
                objArr[i] = obj2;
                this.b = true;
            }
        }
    }

    public String toString() {
        if (A() <= 0) {
            return "{}";
        }
        StringBuilder stringBuilder = new StringBuilder(this.f * 28);
        stringBuilder.append('{');
        for (int i = 0; i < this.f; i++) {
            if (i > 0) {
                stringBuilder.append(", ");
            }
            stringBuilder.append(p(i));
            stringBuilder.append('=');
            j B = B(i);
            if (B != this) {
                stringBuilder.append(B);
            } else {
                stringBuilder.append("(this Map)");
            }
        }
        stringBuilder.append('}');
        return stringBuilder.toString();
    }

    public boolean u(int i, Object obj) {
        i = j(i);
        if (i >= 0) {
            Object B = B(i);
            if (obj == B || (obj != null && obj.equals(B))) {
                v(i);
                return true;
            }
        }
        return false;
    }

    public void v(int i) {
        Object[] objArr = this.d;
        Object obj = objArr[i];
        Object obj2 = a;
        if (obj != obj2) {
            objArr[i] = obj2;
            this.b = true;
        }
    }

    public void w(int i, int i2) {
        i2 = Math.min(this.f, i2 + i);
        while (i < i2) {
            v(i);
            i++;
        }
    }

    @k0
    public E x(int i, E e) {
        i = j(i);
        if (i < 0) {
            return null;
        }
        Object[] objArr = this.d;
        E e2 = objArr[i];
        objArr[i] = e;
        return e2;
    }

    public boolean y(int i, E e, E e2) {
        i = j(i);
        if (i >= 0) {
            E e3 = this.d[i];
            if (e3 == e || (e != null && e.equals(e3))) {
                this.d[i] = e2;
                return true;
            }
        }
        return false;
    }

    public void z(int i, E e) {
        if (this.b) {
            g();
        }
        this.d[i] = e;
    }
}
