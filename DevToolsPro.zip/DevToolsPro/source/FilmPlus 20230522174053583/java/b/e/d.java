package b.e;

public final class d {
    private int[] a;
    private int b;
    private int c;
    private int d;

    public d() {
        this(8);
    }

    public d(int i) {
        if (i < 1) {
            throw new IllegalArgumentException("capacity must be >= 1");
        } else if (i <= 1073741824) {
            if (Integer.bitCount(i) != 1) {
                i = Integer.highestOneBit(i - 1) << 1;
            }
            this.d = i - 1;
            this.a = new int[i];
        } else {
            throw new IllegalArgumentException("capacity must be <= 2^30");
        }
    }

    private void d() {
        Object obj = this.a;
        int length = obj.length;
        int i = this.b;
        int i2 = length - i;
        int i3 = length << 1;
        if (i3 >= 0) {
            Object obj2 = new int[i3];
            System.arraycopy(obj, i, obj2, 0, i2);
            System.arraycopy(this.a, 0, obj2, i2, this.b);
            this.a = obj2;
            this.b = 0;
            this.c = length;
            this.d = i3 - 1;
            return;
        }
        throw new RuntimeException("Max array capacity exceeded");
    }

    public void a(int i) {
        int i2 = (this.b - 1) & this.d;
        this.b = i2;
        this.a[i2] = i;
        if (i2 == this.c) {
            d();
        }
    }

    public void b(int i) {
        int[] iArr = this.a;
        int i2 = this.c;
        iArr[i2] = i;
        i = this.d & (i2 + 1);
        this.c = i;
        if (i == this.b) {
            d();
        }
    }

    public void c() {
        this.c = this.b;
    }

    public int e(int i) {
        if (i < 0 || i >= m()) {
            throw new ArrayIndexOutOfBoundsException();
        }
        return this.a[this.d & (this.b + i)];
    }

    public int f() {
        int i = this.b;
        if (i != this.c) {
            return this.a[i];
        }
        throw new ArrayIndexOutOfBoundsException();
    }

    public int g() {
        int i = this.b;
        int i2 = this.c;
        if (i != i2) {
            return this.a[(i2 - 1) & this.d];
        }
        throw new ArrayIndexOutOfBoundsException();
    }

    public boolean h() {
        return this.b == this.c;
    }

    public int i() {
        int i = this.b;
        if (i != this.c) {
            int i2 = this.a[i];
            this.b = (i + 1) & this.d;
            return i2;
        }
        throw new ArrayIndexOutOfBoundsException();
    }

    public int j() {
        int i = this.b;
        int i2 = this.c;
        if (i != i2) {
            i = this.d & (i2 - 1);
            i2 = this.a[i];
            this.c = i;
            return i2;
        }
        throw new ArrayIndexOutOfBoundsException();
    }

    public void k(int i) {
        if (i > 0) {
            if (i <= m()) {
                this.c = this.d & (this.c - i);
                return;
            }
            throw new ArrayIndexOutOfBoundsException();
        }
    }

    public void l(int i) {
        if (i > 0) {
            if (i <= m()) {
                this.b = this.d & (this.b + i);
                return;
            }
            throw new ArrayIndexOutOfBoundsException();
        }
    }

    public int m() {
        return (this.c - this.b) & this.d;
    }
}
