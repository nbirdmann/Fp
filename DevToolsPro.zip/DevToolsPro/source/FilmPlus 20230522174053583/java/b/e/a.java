package b.e;

import androidx.annotation.j0;
import androidx.annotation.k0;
import java.util.Collection;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class a<K, V> extends i<K, V> implements Map<K, V> {
    @k0
    h<K, V> w0;

    class a extends h<K, V> {
        a() {
        }

        protected void a() {
            a.this.clear();
        }

        protected Object b(int i, int i2) {
            return a.this.u0[(i << 1) + i2];
        }

        protected Map<K, V> c() {
            return a.this;
        }

        protected int d() {
            return a.this.v0;
        }

        protected int e(Object obj) {
            return a.this.f(obj);
        }

        protected int f(Object obj) {
            return a.this.h(obj);
        }

        protected void g(K k, V v) {
            a.this.put(k, v);
        }

        protected void h(int i) {
            a.this.m(i);
        }

        protected V i(int i, V v) {
            return a.this.n(i, v);
        }
    }

    public a(int i) {
        super(i);
    }

    public a(i iVar) {
        super(iVar);
    }

    private h<K, V> r() {
        if (this.w0 == null) {
            this.w0 = new a();
        }
        return this.w0;
    }

    public Set<Entry<K, V>> entrySet() {
        return r().l();
    }

    public Set<K> keySet() {
        return r().m();
    }

    public void putAll(Map<? extends K, ? extends V> map) {
        c(this.v0 + map.size());
        for (Entry entry : map.entrySet()) {
            put(entry.getKey(), entry.getValue());
        }
    }

    public boolean q(@j0 Collection<?> collection) {
        return h.j(this, collection);
    }

    public boolean s(@j0 Collection<?> collection) {
        return h.o(this, collection);
    }

    public boolean t(@j0 Collection<?> collection) {
        return h.p(this, collection);
    }

    public Collection<V> values() {
        return r().n();
    }
}
