package b.e;

import androidx.annotation.j0;
import androidx.annotation.k0;
import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public final class b<E> implements Collection<E>, Set<E> {
    private static final boolean a = false;
    private static final String b = "ArraySet";
    private static final int[] c = new int[0];
    private static final Object[] d = new Object[0];
    private static final int f = 4;
    @k0
    private static Object[] q0 = null;
    private static int r0 = 0;
    private static final int s = 10;
    @k0
    private static Object[] s0;
    private static int t0;
    private int[] u0;
    Object[] v0;
    int w0;
    private h<E, E> x0;

    class a extends h<E, E> {
        a() {
        }

        protected void a() {
            b.this.clear();
        }

        protected Object b(int i, int i2) {
            return b.this.v0[i];
        }

        protected Map<E, E> c() {
            throw new UnsupportedOperationException("not a map");
        }

        protected int d() {
            return b.this.w0;
        }

        protected int e(Object obj) {
            return b.this.indexOf(obj);
        }

        protected int f(Object obj) {
            return b.this.indexOf(obj);
        }

        protected void g(E e, E e2) {
            b.this.add(e);
        }

        protected void h(int i) {
            b.this.l(i);
        }

        protected E i(int i, E e) {
            throw new UnsupportedOperationException("not a map");
        }
    }

    public b() {
        this(0);
    }

    public b(int i) {
        if (i == 0) {
            this.u0 = c;
            this.v0 = d;
        } else {
            b(i);
        }
        this.w0 = 0;
    }

    public b(@k0 b<E> bVar) {
        this();
        if (bVar != null) {
            a(bVar);
        }
    }

    public b(@k0 Collection<E> collection) {
        this();
        if (collection != null) {
            addAll(collection);
        }
    }

    private void b(int i) {
        Object[] objArr;
        if (i == 8) {
            synchronized (b.class) {
                objArr = s0;
                if (objArr != null) {
                    this.v0 = objArr;
                    s0 = (Object[]) objArr[0];
                    this.u0 = (int[]) objArr[1];
                    objArr[1] = null;
                    objArr[0] = null;
                    t0--;
                    return;
                }
            }
        } else if (i == 4) {
            synchronized (b.class) {
                objArr = q0;
                if (objArr != null) {
                    this.v0 = objArr;
                    q0 = (Object[]) objArr[0];
                    this.u0 = (int[]) objArr[1];
                    objArr[1] = null;
                    objArr[0] = null;
                    r0--;
                    return;
                }
            }
        }
        this.u0 = new int[i];
        this.v0 = new Object[i];
    }

    private static void e(int[] iArr, Object[] objArr, int i) {
        if (iArr.length == 8) {
            synchronized (b.class) {
                if (t0 < 10) {
                    objArr[0] = s0;
                    objArr[1] = iArr;
                    for (i--; i >= 2; i--) {
                        objArr[i] = null;
                    }
                    s0 = objArr;
                    t0++;
                }
            }
        } else if (iArr.length == 4) {
            synchronized (b.class) {
                if (r0 < 10) {
                    objArr[0] = q0;
                    objArr[1] = iArr;
                    for (i--; i >= 2; i--) {
                        objArr[i] = null;
                    }
                    q0 = objArr;
                    r0++;
                }
            }
        }
    }

    private h<E, E> f() {
        if (this.x0 == null) {
            this.x0 = new a();
        }
        return this.x0;
    }

    private int i(Object obj, int i) {
        int i2 = this.w0;
        if (i2 == 0) {
            return -1;
        }
        int a = e.a(this.u0, i2, i);
        if (a < 0 || obj.equals(this.v0[a])) {
            return a;
        }
        int i3 = a + 1;
        while (i3 < i2 && this.u0[i3] == i) {
            if (obj.equals(this.v0[i3])) {
                return i3;
            }
            i3++;
        }
        a--;
        while (a >= 0 && this.u0[a] == i) {
            if (obj.equals(this.v0[a])) {
                return a;
            }
            a--;
        }
        return i3 ^ -1;
    }

    private int j() {
        int i = this.w0;
        if (i == 0) {
            return -1;
        }
        int a = e.a(this.u0, i, 0);
        if (a < 0 || this.v0[a] == null) {
            return a;
        }
        int i2 = a + 1;
        while (i2 < i && this.u0[i2] == 0) {
            if (this.v0[i2] == null) {
                return i2;
            }
            i2++;
        }
        a--;
        while (a >= 0 && this.u0[a] == 0) {
            if (this.v0[a] == null) {
                return a;
            }
            a--;
        }
        return i2 ^ -1;
    }

    public void a(@j0 b<? extends E> bVar) {
        int i = bVar.w0;
        c(this.w0 + i);
        int i2 = 0;
        if (this.w0 != 0) {
            while (i2 < i) {
                add(bVar.m(i2));
                i2++;
            }
        } else if (i > 0) {
            System.arraycopy(bVar.u0, 0, this.u0, 0, i);
            System.arraycopy(bVar.v0, 0, this.v0, 0, i);
            this.w0 = i;
        }
    }

    public boolean add(@k0 E e) {
        int j;
        int i;
        if (e == null) {
            j = j();
            i = 0;
        } else {
            j = e.hashCode();
            i = j;
            j = i(e, j);
        }
        if (j >= 0) {
            return false;
        }
        Object obj;
        j ^= -1;
        int i2 = this.w0;
        Object obj2 = this.u0;
        if (i2 >= obj2.length) {
            int i3 = 4;
            if (i2 >= 8) {
                i3 = (i2 >> 1) + i2;
            } else if (i2 >= 4) {
                i3 = 8;
            }
            obj = this.v0;
            b(i3);
            Object obj3 = this.u0;
            if (obj3.length > 0) {
                System.arraycopy(obj2, 0, obj3, 0, obj2.length);
                System.arraycopy(obj, 0, this.v0, 0, obj.length);
            }
            e(obj2, obj, this.w0);
        }
        int i4 = this.w0;
        if (j < i4) {
            obj = this.u0;
            int i5 = j + 1;
            System.arraycopy(obj, j, obj, i5, i4 - j);
            Object obj4 = this.v0;
            System.arraycopy(obj4, j, obj4, i5, this.w0 - j);
        }
        this.u0[j] = i;
        this.v0[j] = e;
        this.w0++;
        return true;
    }

    public boolean addAll(@j0 Collection<? extends E> collection) {
        c(this.w0 + collection.size());
        boolean z = false;
        for (Object add : collection) {
            z |= add(add);
        }
        return z;
    }

    public void c(int i) {
        Object obj = this.u0;
        if (obj.length < i) {
            Object obj2 = this.v0;
            b(i);
            i = this.w0;
            if (i > 0) {
                System.arraycopy(obj, 0, this.u0, 0, i);
                System.arraycopy(obj2, 0, this.v0, 0, this.w0);
            }
            e(obj, obj2, this.w0);
        }
    }

    public void clear() {
        int i = this.w0;
        if (i != 0) {
            e(this.u0, this.v0, i);
            this.u0 = c;
            this.v0 = d;
            this.w0 = 0;
        }
    }

    public boolean contains(@k0 Object obj) {
        return indexOf(obj) >= 0;
    }

    public boolean containsAll(@j0 Collection<?> collection) {
        for (Object contains : collection) {
            if (!contains(contains)) {
                return false;
            }
        }
        return true;
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:17:0x002a A:{RETURN, ExcHandler: java.lang.NullPointerException (unused java.lang.NullPointerException), Splitter: B:9:0x0017} */
    /* DevToolsApp WARNING: Missing block: B:17:0x002a, code:
            return false;
     */
    public boolean equals(java.lang.Object r5) {
        /*
        r4 = this;
        r0 = 1;
        if (r4 != r5) goto L_0x0004;
    L_0x0003:
        return r0;
    L_0x0004:
        r1 = r5 instanceof java.util.Set;
        r2 = 0;
        if (r1 == 0) goto L_0x002a;
    L_0x0009:
        r5 = (java.util.Set) r5;
        r1 = r4.size();
        r3 = r5.size();
        if (r1 == r3) goto L_0x0016;
    L_0x0015:
        return r2;
    L_0x0016:
        r1 = 0;
    L_0x0017:
        r3 = r4.w0;	 Catch:{ NullPointerException -> 0x002a, NullPointerException -> 0x002a }
        if (r1 >= r3) goto L_0x0029;
    L_0x001b:
        r3 = r4.m(r1);	 Catch:{ NullPointerException -> 0x002a, NullPointerException -> 0x002a }
        r3 = r5.contains(r3);	 Catch:{ NullPointerException -> 0x002a, NullPointerException -> 0x002a }
        if (r3 != 0) goto L_0x0026;
    L_0x0025:
        return r2;
    L_0x0026:
        r1 = r1 + 1;
        goto L_0x0017;
    L_0x0029:
        return r0;
    L_0x002a:
        return r2;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.e.b.equals(java.lang.Object):boolean");
    }

    public int hashCode() {
        int[] iArr = this.u0;
        int i = 0;
        for (int i2 = 0; i2 < this.w0; i2++) {
            i += iArr[i2];
        }
        return i;
    }

    public int indexOf(@k0 Object obj) {
        return obj == null ? j() : i(obj, obj.hashCode());
    }

    public boolean isEmpty() {
        return this.w0 <= 0;
    }

    public Iterator<E> iterator() {
        return f().m().iterator();
    }

    public boolean k(@j0 b<? extends E> bVar) {
        int i = bVar.w0;
        int i2 = this.w0;
        for (int i3 = 0; i3 < i; i3++) {
            remove(bVar.m(i3));
        }
        return i2 != this.w0;
    }

    public E l(int i) {
        Object obj = this.v0;
        E e = obj[i];
        int i2 = this.w0;
        if (i2 <= 1) {
            e(this.u0, obj, i2);
            this.u0 = c;
            this.v0 = d;
            this.w0 = 0;
        } else {
            Object obj2 = this.u0;
            int i3 = 8;
            if (obj2.length <= 8 || i2 >= obj2.length / 3) {
                i2--;
                this.w0 = i2;
                if (i < i2) {
                    int i4 = i + 1;
                    System.arraycopy(obj2, i4, obj2, i, i2 - i);
                    Object obj3 = this.v0;
                    System.arraycopy(obj3, i4, obj3, i, this.w0 - i);
                }
                this.v0[this.w0] = null;
            } else {
                if (i2 > 8) {
                    i3 = i2 + (i2 >> 1);
                }
                b(i3);
                this.w0--;
                if (i > 0) {
                    System.arraycopy(obj2, 0, this.u0, 0, i);
                    System.arraycopy(obj, 0, this.v0, 0, i);
                }
                i2 = this.w0;
                if (i < i2) {
                    int i5 = i + 1;
                    System.arraycopy(obj2, i5, this.u0, i, i2 - i);
                    System.arraycopy(obj, i5, this.v0, i, this.w0 - i);
                }
            }
        }
        return e;
    }

    @k0
    public E m(int i) {
        return this.v0[i];
    }

    public boolean remove(@k0 Object obj) {
        int indexOf = indexOf(obj);
        if (indexOf < 0) {
            return false;
        }
        l(indexOf);
        return true;
    }

    public boolean removeAll(@j0 Collection<?> collection) {
        boolean z = false;
        for (Object remove : collection) {
            z |= remove(remove);
        }
        return z;
    }

    public boolean retainAll(@j0 Collection<?> collection) {
        boolean z = false;
        for (int i = this.w0 - 1; i >= 0; i--) {
            if (!collection.contains(this.v0[i])) {
                l(i);
                z = true;
            }
        }
        return z;
    }

    public int size() {
        return this.w0;
    }

    @j0
    public Object[] toArray() {
        int i = this.w0;
        Object obj = new Object[i];
        System.arraycopy(this.v0, 0, obj, 0, i);
        return obj;
    }

    @j0
    public <T> T[] toArray(@j0 T[] tArr) {
        Object tArr2;
        if (tArr2.length < this.w0) {
            tArr2 = (Object[]) Array.newInstance(tArr2.getClass().getComponentType(), this.w0);
        }
        System.arraycopy(this.v0, 0, tArr2, 0, this.w0);
        int length = tArr2.length;
        int i = this.w0;
        if (length > i) {
            tArr2[i] = null;
        }
        return tArr2;
    }

    public String toString() {
        if (isEmpty()) {
            return "{}";
        }
        StringBuilder stringBuilder = new StringBuilder(this.w0 * 14);
        stringBuilder.append('{');
        for (int i = 0; i < this.w0; i++) {
            if (i > 0) {
                stringBuilder.append(", ");
            }
            b m = m(i);
            if (m != this) {
                stringBuilder.append(m);
            } else {
                stringBuilder.append("(this Set)");
            }
        }
        stringBuilder.append('}');
        return stringBuilder.toString();
    }
}
