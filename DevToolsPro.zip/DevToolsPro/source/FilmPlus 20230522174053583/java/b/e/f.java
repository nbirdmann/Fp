package b.e;

import androidx.annotation.j0;
import androidx.annotation.k0;

public class f<E> implements Cloneable {
    private static final Object a = new Object();
    private boolean b;
    private long[] c;
    private Object[] d;
    private int f;

    public f() {
        this(10);
    }

    public f(int i) {
        this.b = false;
        if (i == 0) {
            this.c = e.b;
            this.d = e.c;
            return;
        }
        i = e.f(i);
        this.c = new long[i];
        this.d = new Object[i];
    }

    private void g() {
        int i = this.f;
        long[] jArr = this.c;
        Object[] objArr = this.d;
        int i2 = 0;
        for (int i3 = 0; i3 < i; i3++) {
            Object obj = objArr[i3];
            if (obj != a) {
                if (i3 != i2) {
                    jArr[i2] = jArr[i3];
                    objArr[i2] = obj;
                    objArr[i3] = null;
                }
                i2++;
            }
        }
        this.b = false;
        this.f = i2;
    }

    public E A(int i) {
        if (this.b) {
            g();
        }
        return this.d[i];
    }

    public void a(long j, E e) {
        int i = this.f;
        if (i == 0 || j > this.c[i - 1]) {
            if (this.b && i >= this.c.length) {
                g();
            }
            i = this.f;
            if (i >= this.c.length) {
                int f = e.f(i + 1);
                Object obj = new long[f];
                Object obj2 = new Object[f];
                Object obj3 = this.c;
                System.arraycopy(obj3, 0, obj, 0, obj3.length);
                obj3 = this.d;
                System.arraycopy(obj3, 0, obj2, 0, obj3.length);
                this.c = obj;
                this.d = obj2;
            }
            this.c[i] = j;
            this.d[i] = e;
            this.f = i + 1;
            return;
        }
        q(j, e);
    }

    public void b() {
        int i = this.f;
        Object[] objArr = this.d;
        for (int i2 = 0; i2 < i; i2++) {
            objArr[i2] = null;
        }
        this.f = 0;
        this.b = false;
    }

    /* renamed from: c */
    public f<E> clone() {
        try {
            f<E> fVar = (f) super.clone();
            fVar.c = (long[]) this.c.clone();
            fVar.d = (Object[]) this.d.clone();
            return fVar;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError(e);
        }
    }

    public boolean d(long j) {
        return j(j) >= 0;
    }

    public boolean e(E e) {
        return k(e) >= 0;
    }

    @Deprecated
    public void f(long j) {
        t(j);
    }

    @k0
    public E h(long j) {
        return i(j, null);
    }

    public E i(long j, E e) {
        int b = e.b(this.c, this.f, j);
        if (b >= 0) {
            Object[] objArr = this.d;
            if (objArr[b] != a) {
                return objArr[b];
            }
        }
        return e;
    }

    public int j(long j) {
        if (this.b) {
            g();
        }
        return e.b(this.c, this.f, j);
    }

    public int k(E e) {
        if (this.b) {
            g();
        }
        for (int i = 0; i < this.f; i++) {
            if (this.d[i] == e) {
                return i;
            }
        }
        return -1;
    }

    public boolean o() {
        return z() == 0;
    }

    public long p(int i) {
        if (this.b) {
            g();
        }
        return this.c[i];
    }

    public void q(long j, E e) {
        int b = e.b(this.c, this.f, j);
        if (b >= 0) {
            this.d[b] = e;
        } else {
            Object obj;
            Object obj2;
            b ^= -1;
            int i = this.f;
            if (b < i) {
                Object[] objArr = this.d;
                if (objArr[b] == a) {
                    this.c[b] = j;
                    objArr[b] = e;
                    return;
                }
            }
            if (this.b && i >= this.c.length) {
                g();
                b = e.b(this.c, this.f, j) ^ -1;
            }
            i = this.f;
            if (i >= this.c.length) {
                i = e.f(i + 1);
                obj = new long[i];
                obj2 = new Object[i];
                Object obj3 = this.c;
                System.arraycopy(obj3, 0, obj, 0, obj3.length);
                obj3 = this.d;
                System.arraycopy(obj3, 0, obj2, 0, obj3.length);
                this.c = obj;
                this.d = obj2;
            }
            i = this.f;
            if (i - b != 0) {
                obj = this.c;
                int i2 = b + 1;
                System.arraycopy(obj, b, obj, i2, i - b);
                obj2 = this.d;
                System.arraycopy(obj2, b, obj2, i2, this.f - b);
            }
            this.c[b] = j;
            this.d[b] = e;
            this.f++;
        }
    }

    public void r(@j0 f<? extends E> fVar) {
        int z = fVar.z();
        for (int i = 0; i < z; i++) {
            q(fVar.p(i), fVar.A(i));
        }
    }

    @k0
    public E s(long j, E e) {
        E h = h(j);
        if (h == null) {
            q(j, e);
        }
        return h;
    }

    public void t(long j) {
        int b = e.b(this.c, this.f, j);
        if (b >= 0) {
            Object[] objArr = this.d;
            Object obj = objArr[b];
            Object obj2 = a;
            if (obj != obj2) {
                objArr[b] = obj2;
                this.b = true;
            }
        }
    }

    public String toString() {
        if (z() <= 0) {
            return "{}";
        }
        StringBuilder stringBuilder = new StringBuilder(this.f * 28);
        stringBuilder.append('{');
        for (int i = 0; i < this.f; i++) {
            if (i > 0) {
                stringBuilder.append(", ");
            }
            stringBuilder.append(p(i));
            stringBuilder.append('=');
            f A = A(i);
            if (A != this) {
                stringBuilder.append(A);
            } else {
                stringBuilder.append("(this Map)");
            }
        }
        stringBuilder.append('}');
        return stringBuilder.toString();
    }

    public boolean u(long j, Object obj) {
        int j2 = j(j);
        if (j2 >= 0) {
            Object A = A(j2);
            if (obj == A || (obj != null && obj.equals(A))) {
                v(j2);
                return true;
            }
        }
        return false;
    }

    public void v(int i) {
        Object[] objArr = this.d;
        Object obj = objArr[i];
        Object obj2 = a;
        if (obj != obj2) {
            objArr[i] = obj2;
            this.b = true;
        }
    }

    @k0
    public E w(long j, E e) {
        int j2 = j(j);
        if (j2 < 0) {
            return null;
        }
        Object[] objArr = this.d;
        E e2 = objArr[j2];
        objArr[j2] = e;
        return e2;
    }

    public boolean x(long j, E e, E e2) {
        int j2 = j(j);
        if (j2 >= 0) {
            E e3 = this.d[j2];
            if (e3 == e || (e != null && e.equals(e3))) {
                this.d[j2] = e2;
                return true;
            }
        }
        return false;
    }

    public void y(int i, E e) {
        if (this.b) {
            g();
        }
        this.d[i] = e;
    }

    public int z() {
        if (this.b) {
            g();
        }
        return this.f;
    }
}
