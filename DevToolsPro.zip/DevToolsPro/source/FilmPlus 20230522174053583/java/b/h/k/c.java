package b.h.k;

import android.os.Handler;
import android.os.Handler.Callback;
import android.os.HandlerThread;
import android.os.Message;
import androidx.annotation.r0;
import androidx.annotation.w;
import androidx.annotation.z0;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

@r0({androidx.annotation.r0.a.c})
public class c {
    private static final int a = 1;
    private static final int b = 0;
    private final Object c = new Object();
    @w("mLock")
    private HandlerThread d;
    @w("mLock")
    private Handler e;
    @w("mLock")
    private int f;
    private Callback g = new a();
    private final int h;
    private final int i;
    private final String j;

    public interface d<T> {
        void a(T t);
    }

    class a implements Callback {
        a() {
        }

        public boolean handleMessage(Message message) {
            int i = message.what;
            if (i == 0) {
                c.this.c();
                return true;
            } else if (i != 1) {
                return true;
            } else {
                c.this.d((Runnable) message.obj);
                return true;
            }
        }
    }

    class b implements Runnable {
        final /* synthetic */ Callable a;
        final /* synthetic */ Handler b;
        final /* synthetic */ d c;

        class a implements Runnable {
            final /* synthetic */ Object a;

            a(Object obj) {
                this.a = obj;
            }

            public void run() {
                b.this.c.a(this.a);
            }
        }

        b(Callable callable, Handler handler, d dVar) {
            this.a = callable;
            this.b = handler;
            this.c = dVar;
        }

        public void run() {
            Object call;
            try {
                call = this.a.call();
            } catch (Exception unused) {
                call = null;
            }
            this.b.post(new a(call));
        }
    }

    class c implements Runnable {
        final /* synthetic */ AtomicReference a;
        final /* synthetic */ Callable b;
        final /* synthetic */ ReentrantLock c;
        final /* synthetic */ AtomicBoolean d;
        final /* synthetic */ Condition f;

        c(AtomicReference atomicReference, Callable callable, ReentrantLock reentrantLock, AtomicBoolean atomicBoolean, Condition condition) {
            this.a = atomicReference;
            this.b = callable;
            this.c = reentrantLock;
            this.d = atomicBoolean;
            this.f = condition;
        }

        public void run() {
            try {
                this.a.set(this.b.call());
            } catch (Exception unused) {
                this.c.lock();
                this.d.set(false);
                this.f.signal();
            } finally {
                this.c.unlock();
            }
        }
    }

    public c(String str, int i, int i2) {
        this.j = str;
        this.i = i;
        this.h = i2;
        this.f = 0;
    }

    private void e(Runnable runnable) {
        synchronized (this.c) {
            if (this.d == null) {
                HandlerThread handlerThread = new HandlerThread(this.j, this.i);
                this.d = handlerThread;
                handlerThread.start();
                this.e = new Handler(this.d.getLooper(), this.g);
                this.f++;
            }
            this.e.removeMessages(0);
            Handler handler = this.e;
            handler.sendMessage(handler.obtainMessage(1, runnable));
        }
    }

    @z0
    public int a() {
        int i;
        synchronized (this.c) {
            i = this.f;
        }
        return i;
    }

    @z0
    public boolean b() {
        boolean z;
        synchronized (this.c) {
            z = this.d != null;
        }
        return z;
    }

    void c() {
        synchronized (this.c) {
            if (this.e.hasMessages(1)) {
                return;
            }
            this.d.quit();
            this.d = null;
            this.e = null;
        }
    }

    void d(Runnable runnable) {
        runnable.run();
        synchronized (this.c) {
            this.e.removeMessages(0);
            Handler handler = this.e;
            handler.sendMessageDelayed(handler.obtainMessage(0), (long) this.h);
        }
    }

    public <T> void f(Callable<T> callable, d<T> dVar) {
        e(new b(callable, new Handler(), dVar));
    }

    public <T> T g(Callable<T> callable, int i) throws InterruptedException {
        ReentrantLock reentrantLock = new ReentrantLock();
        Condition newCondition = reentrantLock.newCondition();
        AtomicReference atomicReference = new AtomicReference();
        AtomicBoolean atomicBoolean = new AtomicBoolean(true);
        e(new c(atomicReference, callable, reentrantLock, atomicBoolean, newCondition));
        reentrantLock.lock();
        long toNanos;
        T t;
        try {
            if (atomicBoolean.get()) {
                toNanos = TimeUnit.MILLISECONDS.toNanos((long) i);
                while (true) {
                    toNanos = newCondition.awaitNanos(toNanos);
                }
                return t;
            }
            t = atomicReference.get();
            return t;
        } catch (InterruptedException unused) {
            if (!atomicBoolean.get()) {
                t = atomicReference.get();
                break;
            } else if (toNanos <= 0) {
                throw new InterruptedException("timeout");
            }
        } finally {
            reentrantLock.unlock();
        }
    }
}
