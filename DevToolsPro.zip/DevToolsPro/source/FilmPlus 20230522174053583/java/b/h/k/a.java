package b.h.k;

import android.util.Base64;
import androidx.annotation.e;
import androidx.annotation.j0;
import androidx.annotation.k0;
import androidx.annotation.r0;
import b.h.n.i;
import java.util.List;

public final class a {
    private final String a;
    private final String b;
    private final String c;
    private final List<List<byte[]>> d;
    private final int e;
    private final String f;

    public a(@j0 String str, @j0 String str2, @j0 String str3, @e int i) {
        str = (String) i.f(str);
        this.a = str;
        str2 = (String) i.f(str2);
        this.b = str2;
        str3 = (String) i.f(str3);
        this.c = str3;
        this.d = null;
        i.a(i != 0);
        this.e = i;
        StringBuilder stringBuilder = new StringBuilder(str);
        str = com.guideplus.co.download_manager.download.a.p;
        stringBuilder.append(str);
        stringBuilder.append(str2);
        stringBuilder.append(str);
        stringBuilder.append(str3);
        this.f = stringBuilder.toString();
    }

    public a(@j0 String str, @j0 String str2, @j0 String str3, @j0 List<List<byte[]>> list) {
        str = (String) i.f(str);
        this.a = str;
        str2 = (String) i.f(str2);
        this.b = str2;
        str3 = (String) i.f(str3);
        this.c = str3;
        this.d = (List) i.f(list);
        this.e = 0;
        StringBuilder stringBuilder = new StringBuilder(str);
        str = com.guideplus.co.download_manager.download.a.p;
        stringBuilder.append(str);
        stringBuilder.append(str2);
        stringBuilder.append(str);
        stringBuilder.append(str3);
        this.f = stringBuilder.toString();
    }

    @k0
    public List<List<byte[]>> a() {
        return this.d;
    }

    @e
    public int b() {
        return this.e;
    }

    @r0({androidx.annotation.r0.a.c})
    public String c() {
        return this.f;
    }

    @j0
    public String d() {
        return this.a;
    }

    @j0
    public String e() {
        return this.b;
    }

    @j0
    public String f() {
        return this.c;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("FontRequest {mProviderAuthority: ");
        stringBuilder2.append(this.a);
        stringBuilder2.append(", mProviderPackage: ");
        stringBuilder2.append(this.b);
        stringBuilder2.append(", mQuery: ");
        stringBuilder2.append(this.c);
        stringBuilder2.append(", mCertificates:");
        stringBuilder.append(stringBuilder2.toString());
        for (int i = 0; i < this.d.size(); i++) {
            stringBuilder.append(" [");
            List list = (List) this.d.get(i);
            for (int i2 = 0; i2 < list.size(); i2++) {
                stringBuilder.append(" \"");
                stringBuilder.append(Base64.encodeToString((byte[]) list.get(i2), 0));
                stringBuilder.append("\"");
            }
            stringBuilder.append(" ]");
        }
        stringBuilder.append("}");
        stringBuilder2 = new StringBuilder();
        stringBuilder2.append("mCertificatesArray: ");
        stringBuilder2.append(this.e);
        stringBuilder.append(stringBuilder2.toString());
        return stringBuilder.toString();
    }
}
