package b.h.k;

import android.content.ContentUris;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.ProviderInfo;
import android.content.pm.Signature;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Typeface;
import android.net.Uri;
import android.net.Uri.Builder;
import android.os.Build.VERSION;
import android.os.CancellationSignal;
import android.os.Handler;
import android.provider.BaseColumns;
import androidx.annotation.b0;
import androidx.annotation.j0;
import androidx.annotation.k0;
import androidx.annotation.o0;
import androidx.annotation.r0;
import androidx.annotation.w;
import androidx.annotation.z0;
import b.h.d.k;
import b.h.d.r;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;

public class b {
    @r0({androidx.annotation.r0.a.c})
    public static final String a = "font_results";
    @r0({androidx.annotation.r0.a.c})
    static final int b = -1;
    @r0({androidx.annotation.r0.a.c})
    static final int c = -2;
    static final b.e.g<String, Typeface> d = new b.e.g(16);
    private static final int e = 10000;
    private static final c f = new c("fonts", 10, 10000);
    static final Object g = new Object();
    @w("sLock")
    static final b.e.i<String, ArrayList<b.h.k.c.d<j>>> h = new b.e.i();
    private static final Comparator<byte[]> i = new e();

    class a implements Callable<j> {
        final /* synthetic */ Context a;
        final /* synthetic */ a b;
        final /* synthetic */ int c;
        final /* synthetic */ String d;

        a(Context context, a aVar, int i, String str) {
            this.a = context;
            this.b = aVar;
            this.c = i;
            this.d = str;
        }

        /* renamed from: a */
        public j call() throws Exception {
            j g = b.g(this.a, this.b, this.c);
            Typeface typeface = g.a;
            if (typeface != null) {
                b.d.j(this.d, typeface);
            }
            return g;
        }
    }

    class b implements b.h.k.c.d<j> {
        final /* synthetic */ androidx.core.content.i.g.a a;
        final /* synthetic */ Handler b;

        b(androidx.core.content.i.g.a aVar, Handler handler) {
            this.a = aVar;
            this.b = handler;
        }

        /* renamed from: b */
        public void a(j jVar) {
            if (jVar == null) {
                this.a.a(1, this.b);
                return;
            }
            int i = jVar.b;
            if (i == 0) {
                this.a.b(jVar.a, this.b);
            } else {
                this.a.a(i, this.b);
            }
        }
    }

    class c implements b.h.k.c.d<j> {
        final /* synthetic */ String a;

        c(String str) {
            this.a = str;
        }

        /* DevToolsApp WARNING: Missing block: B:9:0x0017, code:
            r0 = 0;
     */
        /* DevToolsApp WARNING: Missing block: B:11:0x001c, code:
            if (r0 >= r2.size()) goto L_0x002a;
     */
        /* DevToolsApp WARNING: Missing block: B:12:0x001e, code:
            ((b.h.k.c.d) r2.get(r0)).a(r5);
            r0 = r0 + 1;
     */
        /* DevToolsApp WARNING: Missing block: B:13:0x002a, code:
            return;
     */
        /* renamed from: b */
        public void a(b.h.k.b.j r5) {
            /*
            r4 = this;
            r0 = b.h.k.b.g;
            monitor-enter(r0);
            r1 = b.h.k.b.h;	 Catch:{ all -> 0x002b }
            r2 = r4.a;	 Catch:{ all -> 0x002b }
            r2 = r1.get(r2);	 Catch:{ all -> 0x002b }
            r2 = (java.util.ArrayList) r2;	 Catch:{ all -> 0x002b }
            if (r2 != 0) goto L_0x0011;
        L_0x000f:
            monitor-exit(r0);	 Catch:{ all -> 0x002b }
            return;
        L_0x0011:
            r3 = r4.a;	 Catch:{ all -> 0x002b }
            r1.remove(r3);	 Catch:{ all -> 0x002b }
            monitor-exit(r0);	 Catch:{ all -> 0x002b }
            r0 = 0;
        L_0x0018:
            r1 = r2.size();
            if (r0 >= r1) goto L_0x002a;
        L_0x001e:
            r1 = r2.get(r0);
            r1 = (b.h.k.c.d) r1;
            r1.a(r5);
            r0 = r0 + 1;
            goto L_0x0018;
        L_0x002a:
            return;
        L_0x002b:
            r5 = move-exception;
            monitor-exit(r0);	 Catch:{ all -> 0x002b }
            goto L_0x002f;
        L_0x002e:
            throw r5;
        L_0x002f:
            goto L_0x002e;
            */
            throw new UnsupportedOperationException("Method not decompiled: b.h.k.b.c.b(b.h.k.b$j):void");
        }
    }

    class d implements Runnable {
        final /* synthetic */ Context a;
        final /* synthetic */ a b;
        final /* synthetic */ Handler c;
        final /* synthetic */ i d;

        class a implements Runnable {
            a() {
            }

            public void run() {
                d.this.d.a(-1);
            }
        }

        class b implements Runnable {
            b() {
            }

            public void run() {
                d.this.d.a(-2);
            }
        }

        class c implements Runnable {
            c() {
            }

            public void run() {
                d.this.d.a(-3);
            }
        }

        class d implements Runnable {
            d() {
            }

            public void run() {
                d.this.d.a(-3);
            }
        }

        class e implements Runnable {
            e() {
            }

            public void run() {
                d.this.d.a(1);
            }
        }

        class f implements Runnable {
            f() {
            }

            public void run() {
                d.this.d.a(-3);
            }
        }

        class g implements Runnable {
            final /* synthetic */ int a;

            g(int i) {
                this.a = i;
            }

            public void run() {
                d.this.d.a(this.a);
            }
        }

        class h implements Runnable {
            h() {
            }

            public void run() {
                d.this.d.a(-3);
            }
        }

        class i implements Runnable {
            final /* synthetic */ Typeface a;

            i(Typeface typeface) {
                this.a = typeface;
            }

            public void run() {
                d.this.d.b(this.a);
            }
        }

        d(Context context, a aVar, Handler handler, i iVar) {
            this.a = context;
            this.b = aVar;
            this.c = handler;
            this.d = iVar;
        }

        public void run() {
            try {
                g d = b.d(this.a, null, this.b);
                int b;
                if (d.b() != 0) {
                    b = d.b();
                    if (b == 1) {
                        this.c.post(new b());
                        return;
                    } else if (b != 2) {
                        this.c.post(new d());
                        return;
                    } else {
                        this.c.post(new c());
                        return;
                    }
                }
                h[] a = d.a();
                if (a == null || a.length == 0) {
                    this.c.post(new e());
                    return;
                }
                for (h hVar : a) {
                    if (hVar.a() != 0) {
                        b = hVar.a();
                        if (b < 0) {
                            this.c.post(new f());
                        } else {
                            this.c.post(new g(b));
                        }
                        return;
                    }
                }
                Typeface a2 = b.a(this.a, null, a);
                if (a2 == null) {
                    this.c.post(new h());
                } else {
                    this.c.post(new i(a2));
                }
            } catch (NameNotFoundException unused) {
                this.c.post(new a());
            }
        }
    }

    class e implements Comparator<byte[]> {
        e() {
        }

        /* renamed from: a */
        public int compare(byte[] bArr, byte[] bArr2) {
            int length;
            int length2;
            if (bArr.length != bArr2.length) {
                length = bArr.length;
                length2 = bArr2.length;
            } else {
                int i = 0;
                while (i < bArr.length) {
                    if (bArr[i] != bArr2[i]) {
                        length = bArr[i];
                        length2 = bArr2[i];
                    } else {
                        i++;
                    }
                }
                return 0;
            }
            return length - length2;
        }
    }

    public static final class f implements BaseColumns {
        public static final String a = "file_id";
        public static final String b = "font_ttc_index";
        public static final String c = "font_variation_settings";
        public static final String d = "font_weight";
        public static final String e = "font_italic";
        public static final String f = "result_code";
        public static final int g = 0;
        public static final int h = 1;
        public static final int i = 2;
        public static final int j = 3;
    }

    public static class g {
        public static final int a = 0;
        public static final int b = 1;
        public static final int c = 2;
        private final int d;
        private final h[] e;

        @r0({androidx.annotation.r0.a.c})
        public g(int i, @k0 h[] hVarArr) {
            this.d = i;
            this.e = hVarArr;
        }

        public h[] a() {
            return this.e;
        }

        public int b() {
            return this.d;
        }
    }

    public static class h {
        private final Uri a;
        private final int b;
        private final int c;
        private final boolean d;
        private final int e;

        @r0({androidx.annotation.r0.a.c})
        public h(@j0 Uri uri, @b0(from = 0) int i, @b0(from = 1, to = 1000) int i2, boolean z, int i3) {
            this.a = (Uri) b.h.n.i.f(uri);
            this.b = i;
            this.c = i2;
            this.d = z;
            this.e = i3;
        }

        public int a() {
            return this.e;
        }

        @b0(from = 0)
        public int b() {
            return this.b;
        }

        @j0
        public Uri c() {
            return this.a;
        }

        @b0(from = 1, to = 1000)
        public int d() {
            return this.c;
        }

        public boolean e() {
            return this.d;
        }
    }

    public static class i {
        @r0({androidx.annotation.r0.a.c})
        public static final int a = 0;
        public static final int b = -1;
        public static final int c = -2;
        public static final int d = -3;
        public static final int e = -4;
        public static final int f = 1;
        public static final int g = 2;
        public static final int h = 3;

        @r0({androidx.annotation.r0.a.c})
        @Retention(RetentionPolicy.SOURCE)
        public @interface a {
        }

        public void a(int i) {
        }

        public void b(Typeface typeface) {
        }
    }

    private static final class j {
        final Typeface a;
        final int b;

        j(@k0 Typeface typeface, int i) {
            this.a = typeface;
            this.b = i;
        }
    }

    private b() {
    }

    @k0
    public static Typeface a(@j0 Context context, @k0 CancellationSignal cancellationSignal, @j0 h[] hVarArr) {
        return k.b(context, cancellationSignal, hVarArr, 0);
    }

    private static List<byte[]> b(Signature[] signatureArr) {
        List<byte[]> arrayList = new ArrayList();
        for (Signature toByteArray : signatureArr) {
            arrayList.add(toByteArray.toByteArray());
        }
        return arrayList;
    }

    private static boolean c(List<byte[]> list, List<byte[]> list2) {
        if (list.size() != list2.size()) {
            return false;
        }
        for (int i = 0; i < list.size(); i++) {
            if (!Arrays.equals((byte[]) list.get(i), (byte[]) list2.get(i))) {
                return false;
            }
        }
        return true;
    }

    @j0
    public static g d(@j0 Context context, @k0 CancellationSignal cancellationSignal, @j0 a aVar) throws NameNotFoundException {
        ProviderInfo i = i(context.getPackageManager(), aVar, context.getResources());
        return i == null ? new g(1, null) : new g(0, f(context, aVar, i.authority, cancellationSignal));
    }

    private static List<List<byte[]>> e(a aVar, Resources resources) {
        return aVar.a() != null ? aVar.a() : androidx.core.content.i.d.c(resources, aVar.b());
    }

    @j0
    @z0
    static h[] f(Context context, a aVar, String str, CancellationSignal cancellationSignal) {
        String str2 = str;
        ArrayList arrayList = new ArrayList();
        Builder builder = new Builder();
        String str3 = com.google.firebase.analytics.FirebaseAnalytics.d.P;
        Uri build = builder.scheme(str3).authority(str2).build();
        Uri build2 = new Builder().scheme(str3).authority(str2).appendPath("file").build();
        Cursor cursor = null;
        try {
            cursor = VERSION.SDK_INT > 16 ? context.getContentResolver().query(build, new String[]{"_id", f.a, f.b, f.c, f.d, f.e, f.f}, "query = ?", new String[]{aVar.f()}, null, cancellationSignal) : context.getContentResolver().query(build, new String[]{"_id", f.a, f.b, f.c, f.d, f.e, f.f}, "query = ?", new String[]{aVar.f()}, null);
            if (cursor != null && cursor.getCount() > 0) {
                int columnIndex = cursor.getColumnIndex(f.f);
                ArrayList arrayList2 = new ArrayList();
                int columnIndex2 = cursor.getColumnIndex("_id");
                int columnIndex3 = cursor.getColumnIndex(f.a);
                int columnIndex4 = cursor.getColumnIndex(f.b);
                int columnIndex5 = cursor.getColumnIndex(f.d);
                int columnIndex6 = cursor.getColumnIndex(f.e);
                while (cursor.moveToNext()) {
                    int i = columnIndex != -1 ? cursor.getInt(columnIndex) : 0;
                    int i2 = columnIndex4 != -1 ? cursor.getInt(columnIndex4) : 0;
                    Uri withAppendedId = columnIndex3 == -1 ? ContentUris.withAppendedId(build, cursor.getLong(columnIndex2)) : ContentUris.withAppendedId(build2, cursor.getLong(columnIndex3));
                    int i3 = columnIndex5 != -1 ? cursor.getInt(columnIndex5) : com.guideplus.co.download_manager.download.f.Z;
                    boolean z = columnIndex6 != -1 && cursor.getInt(columnIndex6) == 1;
                    arrayList2.add(new h(withAppendedId, i2, i3, z, i));
                }
                arrayList = arrayList2;
            }
            if (cursor != null) {
                cursor.close();
            }
            return (h[]) arrayList.toArray(new h[0]);
        } catch (Throwable th) {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    @j0
    static j g(Context context, a aVar, int i) {
        try {
            g d = d(context, null, aVar);
            int i2 = -3;
            if (d.b() == 0) {
                Typeface b = k.b(context, null, d.a(), i);
                if (b != null) {
                    i2 = 0;
                }
                return new j(b, i2);
            }
            if (d.b() == 1) {
                i2 = -2;
            }
            return new j(null, i2);
        } catch (NameNotFoundException unused) {
            return new j(null, -1);
        }
    }

    /* DevToolsApp WARNING: Missing block: B:32:0x0072, code:
            return r2;
     */
    /* DevToolsApp WARNING: Missing block: B:36:0x0081, code:
            f.f(r1, new b.h.k.b.c(r0));
     */
    /* DevToolsApp WARNING: Missing block: B:37:0x008b, code:
            return r2;
     */
    @androidx.annotation.r0({androidx.annotation.r0.a.c})
    public static android.graphics.Typeface h(android.content.Context r2, b.h.k.a r3, @androidx.annotation.k0 androidx.core.content.i.g.a r4, @androidx.annotation.k0 android.os.Handler r5, boolean r6, int r7, int r8) {
        /*
        r0 = new java.lang.StringBuilder;
        r0.<init>();
        r1 = r3.c();
        r0.append(r1);
        r1 = "-";
        r0.append(r1);
        r0.append(r8);
        r0 = r0.toString();
        r1 = d;
        r1 = r1.f(r0);
        r1 = (android.graphics.Typeface) r1;
        if (r1 == 0) goto L_0x0028;
    L_0x0022:
        if (r4 == 0) goto L_0x0027;
    L_0x0024:
        r4.d(r1);
    L_0x0027:
        return r1;
    L_0x0028:
        if (r6 == 0) goto L_0x0043;
    L_0x002a:
        r1 = -1;
        if (r7 != r1) goto L_0x0043;
    L_0x002d:
        r2 = g(r2, r3, r8);
        if (r4 == 0) goto L_0x0040;
    L_0x0033:
        r3 = r2.b;
        if (r3 != 0) goto L_0x003d;
    L_0x0037:
        r3 = r2.a;
        r4.b(r3, r5);
        goto L_0x0040;
    L_0x003d:
        r4.a(r3, r5);
    L_0x0040:
        r2 = r2.a;
        return r2;
    L_0x0043:
        r1 = new b.h.k.b$a;
        r1.<init>(r2, r3, r8, r0);
        r2 = 0;
        if (r6 == 0) goto L_0x0056;
    L_0x004b:
        r3 = f;	 Catch:{ InterruptedException -> 0x0055 }
        r3 = r3.g(r1, r7);	 Catch:{ InterruptedException -> 0x0055 }
        r3 = (b.h.k.b.j) r3;	 Catch:{ InterruptedException -> 0x0055 }
        r2 = r3.a;	 Catch:{ InterruptedException -> 0x0055 }
    L_0x0055:
        return r2;
    L_0x0056:
        if (r4 != 0) goto L_0x005a;
    L_0x0058:
        r3 = r2;
        goto L_0x005f;
    L_0x005a:
        r3 = new b.h.k.b$b;
        r3.<init>(r4, r5);
    L_0x005f:
        r4 = g;
        monitor-enter(r4);
        r5 = h;	 Catch:{ all -> 0x008c }
        r6 = r5.get(r0);	 Catch:{ all -> 0x008c }
        r6 = (java.util.ArrayList) r6;	 Catch:{ all -> 0x008c }
        if (r6 == 0) goto L_0x0073;
    L_0x006c:
        if (r3 == 0) goto L_0x0071;
    L_0x006e:
        r6.add(r3);	 Catch:{ all -> 0x008c }
    L_0x0071:
        monitor-exit(r4);	 Catch:{ all -> 0x008c }
        return r2;
    L_0x0073:
        if (r3 == 0) goto L_0x0080;
    L_0x0075:
        r6 = new java.util.ArrayList;	 Catch:{ all -> 0x008c }
        r6.<init>();	 Catch:{ all -> 0x008c }
        r6.add(r3);	 Catch:{ all -> 0x008c }
        r5.put(r0, r6);	 Catch:{ all -> 0x008c }
    L_0x0080:
        monitor-exit(r4);	 Catch:{ all -> 0x008c }
        r3 = f;
        r4 = new b.h.k.b$c;
        r4.<init>(r0);
        r3.f(r1, r4);
        return r2;
    L_0x008c:
        r2 = move-exception;
        monitor-exit(r4);	 Catch:{ all -> 0x008c }
        throw r2;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.k.b.h(android.content.Context, b.h.k.a, androidx.core.content.i.g$a, android.os.Handler, boolean, int, int):android.graphics.Typeface");
    }

    @r0({androidx.annotation.r0.a.c})
    @z0
    @k0
    public static ProviderInfo i(@j0 PackageManager packageManager, @j0 a aVar, @k0 Resources resources) throws NameNotFoundException {
        String d = aVar.d();
        int i = 0;
        ProviderInfo resolveContentProvider = packageManager.resolveContentProvider(d, 0);
        if (resolveContentProvider == null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("No package found for authority: ");
            stringBuilder.append(d);
            throw new NameNotFoundException(stringBuilder.toString());
        } else if (resolveContentProvider.packageName.equals(aVar.e())) {
            List b = b(packageManager.getPackageInfo(resolveContentProvider.packageName, 64).signatures);
            Collections.sort(b, i);
            List e = e(aVar, resources);
            while (i < e.size()) {
                List arrayList = new ArrayList((Collection) e.get(i));
                Collections.sort(arrayList, i);
                if (c(b, arrayList)) {
                    return resolveContentProvider;
                }
                i++;
            }
            return null;
        } else {
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("Found content provider ");
            stringBuilder2.append(d);
            stringBuilder2.append(", but package was not ");
            stringBuilder2.append(aVar.e());
            throw new NameNotFoundException(stringBuilder2.toString());
        }
    }

    @o0(19)
    @r0({androidx.annotation.r0.a.c})
    public static Map<Uri, ByteBuffer> j(Context context, h[] hVarArr, CancellationSignal cancellationSignal) {
        Map hashMap = new HashMap();
        for (h hVar : hVarArr) {
            if (hVar.a() == 0) {
                Uri c = hVar.c();
                if (!hashMap.containsKey(c)) {
                    hashMap.put(c, r.f(context, cancellationSignal, c));
                }
            }
        }
        return Collections.unmodifiableMap(hashMap);
    }

    public static void k(@j0 Context context, @j0 a aVar, @j0 i iVar, @j0 Handler handler) {
        l(context.getApplicationContext(), aVar, iVar, handler);
    }

    private static void l(@j0 Context context, @j0 a aVar, @j0 i iVar, @j0 Handler handler) {
        handler.post(new d(context, aVar, new Handler(), iVar));
    }

    @r0({androidx.annotation.r0.a.c})
    public static void m() {
        d.d();
    }
}
