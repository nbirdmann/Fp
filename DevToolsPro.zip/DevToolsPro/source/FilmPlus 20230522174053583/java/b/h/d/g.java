package b.h.d;

import android.graphics.BlendMode;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.Xfermode;
import android.os.Build.VERSION;
import androidx.annotation.j0;
import androidx.annotation.k0;
import b.h.n.f;

public final class g {
    private static final String a = "󟿽";
    private static final String b = "m";
    private static final ThreadLocal<f<Rect, Rect>> c = new ThreadLocal();

    private g() {
    }

    public static boolean a(@j0 Paint paint, @j0 String str) {
        if (VERSION.SDK_INT >= 23) {
            return paint.hasGlyph(str);
        }
        int length = str.length();
        if (length == 1 && Character.isWhitespace(str.charAt(0))) {
            return true;
        }
        String str2 = a;
        float measureText = paint.measureText(str2);
        float measureText2 = paint.measureText(b);
        float measureText3 = paint.measureText(str);
        float f = 0.0f;
        if (measureText3 == 0.0f) {
            return false;
        }
        if (str.codePointCount(0, str.length()) > 1) {
            if (measureText3 > measureText2 * 2.0f) {
                return false;
            }
            int i = 0;
            while (i < length) {
                int charCount = Character.charCount(str.codePointAt(i)) + i;
                f += paint.measureText(str, i, charCount);
                i = charCount;
            }
            if (measureText3 >= f) {
                return false;
            }
        }
        if (measureText3 != measureText) {
            return true;
        }
        f b = b();
        paint.getTextBounds(str2, 0, 2, (Rect) b.a);
        paint.getTextBounds(str, 0, length, (Rect) b.b);
        return ((Rect) b.a).equals(b.b) ^ true;
    }

    private static f<Rect, Rect> b() {
        ThreadLocal threadLocal = c;
        f<Rect, Rect> fVar = (f) threadLocal.get();
        if (fVar == null) {
            fVar = new f(new Rect(), new Rect());
            threadLocal.set(fVar);
            return fVar;
        }
        ((Rect) fVar.a).setEmpty();
        ((Rect) fVar.b).setEmpty();
        return fVar;
    }

    public static boolean c(@j0 Paint paint, @k0 c cVar) {
        boolean z = true;
        Xfermode xfermode = null;
        if (VERSION.SDK_INT >= 29) {
            BlendMode a;
            if (cVar != null) {
                a = d.a(cVar);
            }
            paint.setBlendMode(a);
            return true;
        } else if (cVar != null) {
            Mode b = d.b(cVar);
            if (b != null) {
                xfermode = new PorterDuffXfermode(b);
            }
            paint.setXfermode(xfermode);
            if (b == null) {
                z = false;
            }
            return z;
        } else {
            paint.setXfermode(null);
            return true;
        }
    }
}
