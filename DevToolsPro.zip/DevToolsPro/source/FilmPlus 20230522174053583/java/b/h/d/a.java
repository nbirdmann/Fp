package b.h.d;

import android.graphics.Bitmap;
import android.os.Build.VERSION;
import androidx.annotation.j0;

public final class a {
    private a() {
    }

    public static int a(@j0 Bitmap bitmap) {
        return VERSION.SDK_INT >= 19 ? bitmap.getAllocationByteCount() : bitmap.getByteCount();
    }

    public static boolean b(@j0 Bitmap bitmap) {
        return VERSION.SDK_INT >= 18 ? bitmap.hasMipMap() : false;
    }

    public static void c(@j0 Bitmap bitmap, boolean z) {
        if (VERSION.SDK_INT >= 18) {
            bitmap.setHasMipMap(z);
        }
    }
}
