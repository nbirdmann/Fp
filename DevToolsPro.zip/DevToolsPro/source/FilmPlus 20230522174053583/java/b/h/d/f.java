package b.h.d;

import android.graphics.Insets;
import android.graphics.Rect;
import androidx.annotation.j0;
import androidx.annotation.o0;
import androidx.annotation.r0;
import androidx.annotation.r0.a;

public final class f {
    @j0
    public static final f a = new f(0, 0, 0, 0);
    public final int b;
    public final int c;
    public final int d;
    public final int e;

    private f(int i, int i2, int i3, int i4) {
        this.b = i;
        this.c = i2;
        this.d = i3;
        this.e = i4;
    }

    @j0
    public static f a(int i, int i2, int i3, int i4) {
        return (i == 0 && i2 == 0 && i3 == 0 && i4 == 0) ? a : new f(i, i2, i3, i4);
    }

    @j0
    public static f b(@j0 Rect rect) {
        return a(rect.left, rect.top, rect.right, rect.bottom);
    }

    @o0(api = 29)
    @j0
    public static f c(@j0 Insets insets) {
        return a(insets.left, insets.top, insets.right, insets.bottom);
    }

    @o0(api = 29)
    @j0
    @r0({a.c})
    @Deprecated
    public static f e(@j0 Insets insets) {
        return c(insets);
    }

    @o0(api = 29)
    @j0
    public Insets d() {
        return Insets.of(this.b, this.c, this.d, this.e);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || f.class != obj.getClass()) {
            return false;
        }
        f fVar = (f) obj;
        return this.e == fVar.e && this.b == fVar.b && this.d == fVar.d && this.c == fVar.c;
    }

    public int hashCode() {
        return (((((this.b * 31) + this.c) * 31) + this.d) * 31) + this.e;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Insets{left=");
        stringBuilder.append(this.b);
        stringBuilder.append(", top=");
        stringBuilder.append(this.c);
        stringBuilder.append(", right=");
        stringBuilder.append(this.d);
        stringBuilder.append(", bottom=");
        stringBuilder.append(this.e);
        stringBuilder.append('}');
        return stringBuilder.toString();
    }
}
