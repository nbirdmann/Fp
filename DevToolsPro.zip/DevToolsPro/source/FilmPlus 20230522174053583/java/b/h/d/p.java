package b.h.d;

import android.content.ContentResolver;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.Typeface.CustomFallbackBuilder;
import android.graphics.fonts.Font;
import android.graphics.fonts.FontFamily.Builder;
import android.graphics.fonts.FontStyle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import androidx.annotation.j0;
import androidx.annotation.k0;
import androidx.annotation.o0;
import androidx.annotation.r0;
import androidx.annotation.r0.a;
import androidx.core.content.i.d.c;
import androidx.core.content.i.d.d;
import b.h.k.b.h;
import com.guideplus.co.download_manager.download.f;
import java.io.IOException;
import java.io.InputStream;

@o0(29)
@r0({a.b})
public class p extends q {
    @k0
    public Typeface b(Context context, c cVar, Resources resources, int i) {
        d[] a = cVar.a();
        int length = a.length;
        int i2 = 0;
        Builder builder = null;
        int i3 = 0;
        while (true) {
            int i4 = 1;
            if (i3 >= length) {
                break;
            }
            d dVar = a[i3];
            try {
                Font.Builder weight = new Font.Builder(resources, dVar.b()).setWeight(dVar.e());
                if (!dVar.f()) {
                    i4 = 0;
                }
                Font build = weight.setSlant(i4).setTtcIndex(dVar.c()).setFontVariationSettings(dVar.d()).build();
                if (builder == null) {
                    builder = new Builder(build);
                } else {
                    builder.addFont(build);
                }
            } catch (IOException unused) {
                i3++;
            }
        }
        if (builder == null) {
            return null;
        }
        length = (i & 1) != 0 ? 700 : f.Z;
        if ((i & 2) != 0) {
            i2 = 1;
        }
        return new CustomFallbackBuilder(builder.build()).setStyle(new FontStyle(length, i2)).build();
    }

    @k0
    public Typeface c(Context context, @k0 CancellationSignal cancellationSignal, @j0 h[] hVarArr, int i) {
        ContentResolver contentResolver = context.getContentResolver();
        int length = hVarArr.length;
        int i2 = 0;
        Builder builder = null;
        int i3 = 0;
        while (true) {
            int i4 = 1;
            if (i3 < length) {
                h hVar = hVarArr[i3];
                ParcelFileDescriptor openFileDescriptor;
                try {
                    openFileDescriptor = contentResolver.openFileDescriptor(hVar.c(), "r", cancellationSignal);
                    if (openFileDescriptor != null) {
                        Font.Builder weight = new Font.Builder(openFileDescriptor).setWeight(hVar.d());
                        if (!hVar.e()) {
                            i4 = 0;
                        }
                        Font build = weight.setSlant(i4).setTtcIndex(hVar.b()).build();
                        if (builder == null) {
                            builder = new Builder(build);
                        } else {
                            builder.addFont(build);
                        }
                    } else if (openFileDescriptor == null) {
                    }
                    openFileDescriptor.close();
                } catch (IOException unused) {
                    i3++;
                } catch (Throwable th) {
                    continue;
                    th.addSuppressed(th);
                    break;
                }
            } else if (builder == null) {
                return null;
            } else {
                int i5 = (i & 1) != 0 ? 700 : f.Z;
                if ((i & 2) != 0) {
                    i2 = 1;
                }
                return new CustomFallbackBuilder(builder.build()).setStyle(new FontStyle(i5, i2)).build();
            }
        }
    }

    protected Typeface d(Context context, InputStream inputStream) {
        throw new RuntimeException("Do not use this function in API 29 or later.");
    }

    @k0
    public Typeface e(Context context, Resources resources, int i, String str, int i2) {
        try {
            return new CustomFallbackBuilder(new Builder(new Font.Builder(resources, i).build()).build()).setStyle(new FontStyle((i2 & 1) != 0 ? 700 : f.Z, (i2 & 2) != 0 ? 1 : 0)).build();
        } catch (IOException unused) {
            return null;
        }
    }

    protected h h(h[] hVarArr, int i) {
        throw new RuntimeException("Do not use this function in API 29 or later.");
    }
}
