package b.h.d;

import android.graphics.PointF;
import androidx.annotation.j0;

public final class i {
    private final PointF a;
    private final float b;
    private final PointF c;
    private final float d;

    public i(@j0 PointF pointF, float f, @j0 PointF pointF2, float f2) {
        this.a = (PointF) b.h.n.i.g(pointF, "start == null");
        this.b = f;
        this.c = (PointF) b.h.n.i.g(pointF2, "end == null");
        this.d = f2;
    }

    @j0
    public PointF a() {
        return this.c;
    }

    public float b() {
        return this.d;
    }

    @j0
    public PointF c() {
        return this.a;
    }

    public float d() {
        return this.b;
    }

    public boolean equals(Object obj) {
        boolean z = true;
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof i)) {
            return false;
        }
        i iVar = (i) obj;
        if (!(Float.compare(this.b, iVar.b) == 0 && Float.compare(this.d, iVar.d) == 0 && this.a.equals(iVar.a) && this.c.equals(iVar.c))) {
            z = false;
        }
        return z;
    }

    public int hashCode() {
        int hashCode = this.a.hashCode() * 31;
        float f = this.b;
        int i = 0;
        hashCode = (((hashCode + (f != 0.0f ? Float.floatToIntBits(f) : 0)) * 31) + this.c.hashCode()) * 31;
        f = this.d;
        if (f != 0.0f) {
            i = Float.floatToIntBits(f);
        }
        return hashCode + i;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("PathSegment{start=");
        stringBuilder.append(this.a);
        stringBuilder.append(", startFraction=");
        stringBuilder.append(this.b);
        stringBuilder.append(", end=");
        stringBuilder.append(this.c);
        stringBuilder.append(", endFraction=");
        stringBuilder.append(this.d);
        stringBuilder.append('}');
        return stringBuilder.toString();
    }
}
