package b.h.d;

import android.graphics.BlendMode;
import android.graphics.PorterDuff.Mode;
import androidx.annotation.j0;
import androidx.annotation.k0;
import androidx.annotation.o0;

class d {

    static /* synthetic */ class a {
        static final /* synthetic */ int[] a;

        /* DevToolsApp WARNING: Failed to process nested try/catch */
        /* DevToolsApp WARNING: Missing block: B:58:?, code:
            a[b.h.d.c.LUMINOSITY.ordinal()] = 29;
     */
        static {
            /*
            r0 = b.h.d.c.values();
            r0 = r0.length;
            r0 = new int[r0];
            a = r0;
            r1 = b.h.d.c.CLEAR;	 Catch:{ NoSuchFieldError -> 0x0012 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0012 }
            r2 = 1;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0012 }
        L_0x0012:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x001d }
            r1 = b.h.d.c.SRC;	 Catch:{ NoSuchFieldError -> 0x001d }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x001d }
            r2 = 2;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x001d }
        L_0x001d:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x0028 }
            r1 = b.h.d.c.DST;	 Catch:{ NoSuchFieldError -> 0x0028 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0028 }
            r2 = 3;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0028 }
        L_0x0028:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x0033 }
            r1 = b.h.d.c.SRC_OVER;	 Catch:{ NoSuchFieldError -> 0x0033 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0033 }
            r2 = 4;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0033 }
        L_0x0033:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x003e }
            r1 = b.h.d.c.DST_OVER;	 Catch:{ NoSuchFieldError -> 0x003e }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x003e }
            r2 = 5;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x003e }
        L_0x003e:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x0049 }
            r1 = b.h.d.c.SRC_IN;	 Catch:{ NoSuchFieldError -> 0x0049 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0049 }
            r2 = 6;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0049 }
        L_0x0049:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x0054 }
            r1 = b.h.d.c.DST_IN;	 Catch:{ NoSuchFieldError -> 0x0054 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0054 }
            r2 = 7;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0054 }
        L_0x0054:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x0060 }
            r1 = b.h.d.c.SRC_OUT;	 Catch:{ NoSuchFieldError -> 0x0060 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0060 }
            r2 = 8;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0060 }
        L_0x0060:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x006c }
            r1 = b.h.d.c.DST_OUT;	 Catch:{ NoSuchFieldError -> 0x006c }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x006c }
            r2 = 9;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x006c }
        L_0x006c:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x0078 }
            r1 = b.h.d.c.SRC_ATOP;	 Catch:{ NoSuchFieldError -> 0x0078 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0078 }
            r2 = 10;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0078 }
        L_0x0078:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x0084 }
            r1 = b.h.d.c.DST_ATOP;	 Catch:{ NoSuchFieldError -> 0x0084 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0084 }
            r2 = 11;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0084 }
        L_0x0084:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x0090 }
            r1 = b.h.d.c.XOR;	 Catch:{ NoSuchFieldError -> 0x0090 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0090 }
            r2 = 12;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0090 }
        L_0x0090:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x009c }
            r1 = b.h.d.c.PLUS;	 Catch:{ NoSuchFieldError -> 0x009c }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x009c }
            r2 = 13;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x009c }
        L_0x009c:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x00a8 }
            r1 = b.h.d.c.MODULATE;	 Catch:{ NoSuchFieldError -> 0x00a8 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x00a8 }
            r2 = 14;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x00a8 }
        L_0x00a8:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x00b4 }
            r1 = b.h.d.c.SCREEN;	 Catch:{ NoSuchFieldError -> 0x00b4 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x00b4 }
            r2 = 15;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x00b4 }
        L_0x00b4:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x00c0 }
            r1 = b.h.d.c.OVERLAY;	 Catch:{ NoSuchFieldError -> 0x00c0 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x00c0 }
            r2 = 16;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x00c0 }
        L_0x00c0:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x00cc }
            r1 = b.h.d.c.DARKEN;	 Catch:{ NoSuchFieldError -> 0x00cc }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x00cc }
            r2 = 17;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x00cc }
        L_0x00cc:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x00d8 }
            r1 = b.h.d.c.LIGHTEN;	 Catch:{ NoSuchFieldError -> 0x00d8 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x00d8 }
            r2 = 18;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x00d8 }
        L_0x00d8:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x00e4 }
            r1 = b.h.d.c.COLOR_DODGE;	 Catch:{ NoSuchFieldError -> 0x00e4 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x00e4 }
            r2 = 19;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x00e4 }
        L_0x00e4:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x00f0 }
            r1 = b.h.d.c.COLOR_BURN;	 Catch:{ NoSuchFieldError -> 0x00f0 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x00f0 }
            r2 = 20;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x00f0 }
        L_0x00f0:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x00fc }
            r1 = b.h.d.c.HARD_LIGHT;	 Catch:{ NoSuchFieldError -> 0x00fc }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x00fc }
            r2 = 21;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x00fc }
        L_0x00fc:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x0108 }
            r1 = b.h.d.c.SOFT_LIGHT;	 Catch:{ NoSuchFieldError -> 0x0108 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0108 }
            r2 = 22;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0108 }
        L_0x0108:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x0114 }
            r1 = b.h.d.c.DIFFERENCE;	 Catch:{ NoSuchFieldError -> 0x0114 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0114 }
            r2 = 23;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0114 }
        L_0x0114:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x0120 }
            r1 = b.h.d.c.EXCLUSION;	 Catch:{ NoSuchFieldError -> 0x0120 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0120 }
            r2 = 24;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0120 }
        L_0x0120:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x012c }
            r1 = b.h.d.c.MULTIPLY;	 Catch:{ NoSuchFieldError -> 0x012c }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x012c }
            r2 = 25;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x012c }
        L_0x012c:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x0138 }
            r1 = b.h.d.c.HUE;	 Catch:{ NoSuchFieldError -> 0x0138 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0138 }
            r2 = 26;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0138 }
        L_0x0138:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x0144 }
            r1 = b.h.d.c.SATURATION;	 Catch:{ NoSuchFieldError -> 0x0144 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0144 }
            r2 = 27;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0144 }
        L_0x0144:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x0150 }
            r1 = b.h.d.c.COLOR;	 Catch:{ NoSuchFieldError -> 0x0150 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0150 }
            r2 = 28;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0150 }
        L_0x0150:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x015c }
            r1 = b.h.d.c.LUMINOSITY;	 Catch:{ NoSuchFieldError -> 0x015c }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x015c }
            r2 = 29;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x015c }
        L_0x015c:
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: b.h.d.d.a.<clinit>():void");
        }
    }

    private d() {
    }

    @k0
    @o0(29)
    static BlendMode a(@j0 c cVar) {
        switch (a.a[cVar.ordinal()]) {
            case 1:
                return BlendMode.CLEAR;
            case 2:
                return BlendMode.SRC;
            case 3:
                return BlendMode.DST;
            case 4:
                return BlendMode.SRC_OVER;
            case 5:
                return BlendMode.DST_OVER;
            case 6:
                return BlendMode.SRC_IN;
            case 7:
                return BlendMode.DST_IN;
            case 8:
                return BlendMode.SRC_OUT;
            case 9:
                return BlendMode.DST_OUT;
            case 10:
                return BlendMode.SRC_ATOP;
            case 11:
                return BlendMode.DST_ATOP;
            case 12:
                return BlendMode.XOR;
            case 13:
                return BlendMode.PLUS;
            case 14:
                return BlendMode.MODULATE;
            case 15:
                return BlendMode.SCREEN;
            case 16:
                return BlendMode.OVERLAY;
            case 17:
                return BlendMode.DARKEN;
            case 18:
                return BlendMode.LIGHTEN;
            case 19:
                return BlendMode.COLOR_DODGE;
            case 20:
                return BlendMode.COLOR_BURN;
            case 21:
                return BlendMode.HARD_LIGHT;
            case 22:
                return BlendMode.SOFT_LIGHT;
            case 23:
                return BlendMode.DIFFERENCE;
            case 24:
                return BlendMode.EXCLUSION;
            case 25:
                return BlendMode.MULTIPLY;
            case 26:
                return BlendMode.HUE;
            case 27:
                return BlendMode.SATURATION;
            case 28:
                return BlendMode.COLOR;
            case 29:
                return BlendMode.LUMINOSITY;
            default:
                return null;
        }
    }

    @k0
    static Mode b(@k0 c cVar) {
        if (cVar == null) {
            return null;
        }
        switch (a.a[cVar.ordinal()]) {
            case 1:
                return Mode.CLEAR;
            case 2:
                return Mode.SRC;
            case 3:
                return Mode.DST;
            case 4:
                return Mode.SRC_OVER;
            case 5:
                return Mode.DST_OVER;
            case 6:
                return Mode.SRC_IN;
            case 7:
                return Mode.DST_IN;
            case 8:
                return Mode.SRC_OUT;
            case 9:
                return Mode.DST_OUT;
            case 10:
                return Mode.SRC_ATOP;
            case 11:
                return Mode.DST_ATOP;
            case 12:
                return Mode.XOR;
            case 13:
                return Mode.ADD;
            case 14:
                return Mode.MULTIPLY;
            case 15:
                return Mode.SCREEN;
            case 16:
                return Mode.OVERLAY;
            case 17:
                return Mode.DARKEN;
            case 18:
                return Mode.LIGHTEN;
            default:
                return null;
        }
    }
}
