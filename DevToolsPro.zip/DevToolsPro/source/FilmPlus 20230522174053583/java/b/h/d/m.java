package b.h.d;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.CancellationSignal;
import android.util.Log;
import androidx.annotation.j0;
import androidx.annotation.k0;
import androidx.annotation.o0;
import androidx.annotation.r0;
import androidx.annotation.r0.a;
import androidx.core.content.i.d.c;
import androidx.core.content.i.d.d;
import b.e.i;
import b.h.k.b.h;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.List;

@o0(24)
@r0({a.c})
class m extends q {
    private static final String d = "TypefaceCompatApi24Impl";
    private static final String e = "android.graphics.FontFamily";
    private static final String f = "addFontWeightStyle";
    private static final String g = "createFromFamiliesWithDefault";
    private static final Class<?> h;
    private static final Constructor<?> i;
    private static final Method j;
    private static final Method k;

    static {
        Class cls;
        Method method;
        Method method2;
        Throwable e;
        Constructor constructor = null;
        try {
            cls = Class.forName(e);
            Constructor constructor2 = cls.getConstructor(new Class[0]);
            String str = f;
            r5 = new Class[5];
            Class cls2 = Integer.TYPE;
            r5[1] = cls2;
            r5[2] = List.class;
            r5[3] = cls2;
            r5[4] = Boolean.TYPE;
            method = cls.getMethod(str, r5);
            Object newInstance = Array.newInstance(cls, 1);
            constructor = Typeface.class.getMethod(g, new Class[]{newInstance.getClass()});
            method2 = constructor;
            constructor = constructor2;
        } catch (ClassNotFoundException e2) {
            e = e2;
            Log.e(d, e.getClass().getName(), e);
            cls = constructor;
            method2 = cls;
            method = method2;
            i = constructor;
            h = cls;
            j = method;
            k = method2;
        } catch (NoSuchMethodException e3) {
            e = e3;
            Log.e(d, e.getClass().getName(), e);
            cls = constructor;
            method2 = cls;
            method = method2;
            i = constructor;
            h = cls;
            j = method;
            k = method2;
        }
        i = constructor;
        h = cls;
        j = method;
        k = method2;
    }

    m() {
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:4:0x002c A:{RETURN, ExcHandler: java.lang.IllegalAccessException (unused java.lang.IllegalAccessException), Splitter: B:1:0x0001} */
    /* DevToolsApp WARNING: Missing block: B:4:0x002c, code:
            return false;
     */
    private static boolean k(java.lang.Object r3, java.nio.ByteBuffer r4, int r5, int r6, boolean r7) {
        /*
        r0 = 0;
        r1 = j;	 Catch:{ IllegalAccessException -> 0x002c, IllegalAccessException -> 0x002c }
        r2 = 5;
        r2 = new java.lang.Object[r2];	 Catch:{ IllegalAccessException -> 0x002c, IllegalAccessException -> 0x002c }
        r2[r0] = r4;	 Catch:{ IllegalAccessException -> 0x002c, IllegalAccessException -> 0x002c }
        r4 = 1;
        r5 = java.lang.Integer.valueOf(r5);	 Catch:{ IllegalAccessException -> 0x002c, IllegalAccessException -> 0x002c }
        r2[r4] = r5;	 Catch:{ IllegalAccessException -> 0x002c, IllegalAccessException -> 0x002c }
        r4 = 2;
        r5 = 0;
        r2[r4] = r5;	 Catch:{ IllegalAccessException -> 0x002c, IllegalAccessException -> 0x002c }
        r4 = 3;
        r5 = java.lang.Integer.valueOf(r6);	 Catch:{ IllegalAccessException -> 0x002c, IllegalAccessException -> 0x002c }
        r2[r4] = r5;	 Catch:{ IllegalAccessException -> 0x002c, IllegalAccessException -> 0x002c }
        r4 = 4;
        r5 = java.lang.Boolean.valueOf(r7);	 Catch:{ IllegalAccessException -> 0x002c, IllegalAccessException -> 0x002c }
        r2[r4] = r5;	 Catch:{ IllegalAccessException -> 0x002c, IllegalAccessException -> 0x002c }
        r3 = r1.invoke(r3, r2);	 Catch:{ IllegalAccessException -> 0x002c, IllegalAccessException -> 0x002c }
        r3 = (java.lang.Boolean) r3;	 Catch:{ IllegalAccessException -> 0x002c, IllegalAccessException -> 0x002c }
        r3 = r3.booleanValue();	 Catch:{ IllegalAccessException -> 0x002c, IllegalAccessException -> 0x002c }
        return r3;
    L_0x002c:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.d.m.k(java.lang.Object, java.nio.ByteBuffer, int, int, boolean):boolean");
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:4:0x0019 A:{RETURN, ExcHandler: java.lang.IllegalAccessException (unused java.lang.IllegalAccessException), Splitter: B:1:0x0001} */
    /* DevToolsApp WARNING: Missing block: B:4:0x0019, code:
            return null;
     */
    private static android.graphics.Typeface l(java.lang.Object r4) {
        /*
        r0 = 0;
        r1 = h;	 Catch:{ IllegalAccessException -> 0x0019, IllegalAccessException -> 0x0019 }
        r2 = 1;
        r1 = java.lang.reflect.Array.newInstance(r1, r2);	 Catch:{ IllegalAccessException -> 0x0019, IllegalAccessException -> 0x0019 }
        r3 = 0;
        java.lang.reflect.Array.set(r1, r3, r4);	 Catch:{ IllegalAccessException -> 0x0019, IllegalAccessException -> 0x0019 }
        r4 = k;	 Catch:{ IllegalAccessException -> 0x0019, IllegalAccessException -> 0x0019 }
        r2 = new java.lang.Object[r2];	 Catch:{ IllegalAccessException -> 0x0019, IllegalAccessException -> 0x0019 }
        r2[r3] = r1;	 Catch:{ IllegalAccessException -> 0x0019, IllegalAccessException -> 0x0019 }
        r4 = r4.invoke(r0, r2);	 Catch:{ IllegalAccessException -> 0x0019, IllegalAccessException -> 0x0019 }
        r4 = (android.graphics.Typeface) r4;	 Catch:{ IllegalAccessException -> 0x0019, IllegalAccessException -> 0x0019 }
        return r4;
    L_0x0019:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.d.m.l(java.lang.Object):android.graphics.Typeface");
    }

    public static boolean m() {
        Method method = j;
        if (method == null) {
            Log.w(d, "Unable to collect necessary private methods.Fallback to legacy implementation.");
        }
        return method != null;
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:3:0x000a A:{ExcHandler: java.lang.IllegalAccessException (unused java.lang.IllegalAccessException), Splitter: B:0:0x0000} */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:3:0x000a A:{ExcHandler: java.lang.IllegalAccessException (unused java.lang.IllegalAccessException), Splitter: B:0:0x0000} */
    /* DevToolsApp WARNING: Missing block: B:4:0x000b, code:
            return null;
     */
    private static java.lang.Object n() {
        /*
        r0 = i;	 Catch:{ IllegalAccessException -> 0x000a, IllegalAccessException -> 0x000a, IllegalAccessException -> 0x000a }
        r1 = 0;
        r1 = new java.lang.Object[r1];	 Catch:{ IllegalAccessException -> 0x000a, IllegalAccessException -> 0x000a, IllegalAccessException -> 0x000a }
        r0 = r0.newInstance(r1);	 Catch:{ IllegalAccessException -> 0x000a, IllegalAccessException -> 0x000a, IllegalAccessException -> 0x000a }
        return r0;
    L_0x000a:
        r0 = 0;
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.d.m.n():java.lang.Object");
    }

    @k0
    public Typeface b(Context context, c cVar, Resources resources, int i) {
        Object n = n();
        if (n == null) {
            return null;
        }
        for (d dVar : cVar.a()) {
            ByteBuffer b = r.b(context, resources, dVar.b());
            if (b == null || !k(n, b, dVar.c(), dVar.e(), dVar.f())) {
                return null;
            }
        }
        return l(n);
    }

    @k0
    public Typeface c(Context context, @k0 CancellationSignal cancellationSignal, @j0 h[] hVarArr, int i) {
        Object n = n();
        if (n == null) {
            return null;
        }
        i iVar = new i();
        for (h hVar : hVarArr) {
            Uri c = hVar.c();
            ByteBuffer byteBuffer = (ByteBuffer) iVar.get(c);
            if (byteBuffer == null) {
                byteBuffer = r.f(context, cancellationSignal, c);
                iVar.put(c, byteBuffer);
            }
            if (byteBuffer == null || !k(n, byteBuffer, hVar.b(), hVar.d(), hVar.e())) {
                return null;
            }
        }
        Typeface l = l(n);
        return l == null ? null : Typeface.create(l, i);
    }
}
