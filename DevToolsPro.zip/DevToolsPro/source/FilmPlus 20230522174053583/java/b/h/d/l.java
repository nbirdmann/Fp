package b.h.d;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;
import android.util.Log;
import androidx.annotation.j0;
import androidx.annotation.o0;
import androidx.annotation.r0;
import androidx.annotation.r0.a;
import androidx.core.content.i.d.c;
import androidx.core.content.i.d.d;
import b.h.k.b.h;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

@o0(21)
@r0({a.c})
class l extends q {
    private static final String d = "TypefaceCompatApi21Impl";
    private static final String e = "android.graphics.FontFamily";
    private static final String f = "addFontWeightStyle";
    private static final String g = "createFromFamiliesWithDefault";
    private static Class<?> h;
    private static Constructor<?> i;
    private static Method j;
    private static Method k;
    private static boolean l;

    l() {
    }

    private static boolean k(Object obj, String str, int i, boolean z) {
        Throwable e;
        n();
        try {
            return ((Boolean) j.invoke(obj, new Object[]{str, Integer.valueOf(i), Boolean.valueOf(z)})).booleanValue();
        } catch (IllegalAccessException e2) {
            e = e2;
            throw new RuntimeException(e);
        } catch (InvocationTargetException e3) {
            e = e3;
            throw new RuntimeException(e);
        }
    }

    private static Typeface l(Object obj) {
        Throwable e;
        n();
        try {
            Array.set(Array.newInstance(h, 1), 0, obj);
            return (Typeface) k.invoke(null, new Object[]{r0});
        } catch (IllegalAccessException e2) {
            e = e2;
            throw new RuntimeException(e);
        } catch (InvocationTargetException e3) {
            e = e3;
            throw new RuntimeException(e);
        }
    }

    private File m(@j0 ParcelFileDescriptor parcelFileDescriptor) {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("/proc/self/fd/");
            stringBuilder.append(parcelFileDescriptor.getFd());
            String readlink = Os.readlink(stringBuilder.toString());
            if (OsConstants.S_ISREG(Os.stat(readlink).st_mode)) {
                return new File(readlink);
            }
        } catch (ErrnoException unused) {
            return null;
        }
    }

    private static void n() {
        Method method;
        Method method2;
        Throwable e;
        if (!l) {
            Class cls;
            l = true;
            Constructor constructor = null;
            try {
                cls = Class.forName(e);
                Constructor constructor2 = cls.getConstructor(new Class[0]);
                method = cls.getMethod(f, new Class[]{String.class, Integer.TYPE, Boolean.TYPE});
                Object newInstance = Array.newInstance(cls, 1);
                constructor = Typeface.class.getMethod(g, new Class[]{newInstance.getClass()});
                method2 = constructor;
                constructor = constructor2;
            } catch (ClassNotFoundException e2) {
                e = e2;
                Log.e(d, e.getClass().getName(), e);
                method2 = constructor;
                cls = method2;
                method = cls;
                i = constructor;
                h = cls;
                j = method;
                k = method2;
            } catch (NoSuchMethodException e3) {
                e = e3;
                Log.e(d, e.getClass().getName(), e);
                method2 = constructor;
                cls = method2;
                method = cls;
                i = constructor;
                h = cls;
                j = method;
                k = method2;
            }
            i = constructor;
            h = cls;
            j = method;
            k = method2;
        }
    }

    private static Object o() {
        Throwable e;
        n();
        try {
            return i.newInstance(new Object[0]);
        } catch (IllegalAccessException e2) {
            e = e2;
            throw new RuntimeException(e);
        } catch (InstantiationException e3) {
            e = e3;
            throw new RuntimeException(e);
        } catch (InvocationTargetException e4) {
            e = e4;
            throw new RuntimeException(e);
        }
    }

    public Typeface b(Context context, c cVar, Resources resources, int i) {
        Object o = o();
        d[] a = cVar.a();
        int length = a.length;
        int i2 = 0;
        while (i2 < length) {
            d dVar = a[i2];
            File e = r.e(context);
            if (e == null) {
                return null;
            }
            try {
                if (!r.c(e, resources, dVar.b())) {
                    e.delete();
                    return null;
                } else if (k(o, e.getPath(), dVar.e(), dVar.f())) {
                    e.delete();
                    i2++;
                } else {
                    e.delete();
                    return null;
                }
            } catch (RuntimeException unused) {
                e.delete();
                return null;
            } catch (Throwable th) {
                e.delete();
                throw th;
            }
        }
        return l(o);
    }

    public Typeface c(Context context, CancellationSignal cancellationSignal, @j0 h[] hVarArr, int i) {
        if (hVarArr.length < 1) {
            return null;
        }
        h h = h(hVarArr, i);
        try {
            ParcelFileDescriptor openFileDescriptor = context.getContentResolver().openFileDescriptor(h.c(), "r", cancellationSignal);
            if (openFileDescriptor == null) {
                if (openFileDescriptor != null) {
                    openFileDescriptor.close();
                }
                return null;
            }
            InputStream fileInputStream;
            try {
                File m = m(openFileDescriptor);
                Typeface d;
                if (m == null || !m.canRead()) {
                    fileInputStream = new FileInputStream(openFileDescriptor.getFileDescriptor());
                    d = super.d(context, fileInputStream);
                    fileInputStream.close();
                    openFileDescriptor.close();
                    return d;
                }
                d = Typeface.createFromFile(m);
                openFileDescriptor.close();
                return d;
            } catch (Throwable th) {
                openFileDescriptor.close();
            }
        } catch (IOException unused) {
            return null;
        } catch (Throwable th2) {
            th.addSuppressed(th2);
        }
    }
}
