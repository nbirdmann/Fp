package b.h.d;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Build.VERSION;
import android.os.CancellationSignal;
import android.os.Handler;
import androidx.annotation.j0;
import androidx.annotation.k0;
import androidx.annotation.r0;
import androidx.annotation.r0.a;
import androidx.core.content.i.d;
import androidx.core.content.i.d.c;
import androidx.core.content.i.d.e;
import b.e.g;
import b.h.k.b;
import b.h.k.b.h;

@SuppressLint({"NewApi"})
public class k {
    private static final q a;
    private static final g<String, Typeface> b = new g(16);

    static {
        int i = VERSION.SDK_INT;
        if (i >= 29) {
            a = new p();
        } else if (i >= 28) {
            a = new o();
        } else if (i >= 26) {
            a = new n();
        } else if (i >= 24 && m.m()) {
            a = new m();
        } else if (i >= 21) {
            a = new l();
        } else {
            a = new q();
        }
    }

    private k() {
    }

    @j0
    public static Typeface a(@j0 Context context, @k0 Typeface typeface, int i) {
        if (context != null) {
            if (VERSION.SDK_INT < 21) {
                Typeface g = g(context, typeface, i);
                if (g != null) {
                    return g;
                }
            }
            return Typeface.create(typeface, i);
        }
        throw new IllegalArgumentException("Context cannot be null");
    }

    @k0
    @r0({a.c})
    public static Typeface b(@j0 Context context, @k0 CancellationSignal cancellationSignal, @j0 h[] hVarArr, int i) {
        return a.c(context, cancellationSignal, hVarArr, i);
    }

    @k0
    @r0({a.c})
    public static Typeface c(@j0 Context context, @j0 d.a aVar, @j0 Resources resources, int i, int i2, @k0 androidx.core.content.i.g.a aVar2, @k0 Handler handler, boolean z) {
        Typeface h;
        if (aVar instanceof e) {
            e eVar = (e) aVar;
            boolean z2 = false;
            if (z ? eVar.a() != 0 : aVar2 != null) {
                z2 = true;
            }
            h = b.h(context, eVar.b(), aVar2, handler, z2, z ? eVar.c() : -1, i2);
        } else {
            h = a.b(context, (c) aVar, resources, i2);
            if (aVar2 != null) {
                if (h != null) {
                    aVar2.b(h, handler);
                } else {
                    aVar2.a(-3, handler);
                }
            }
        }
        if (h != null) {
            b.j(e(resources, i, i2), h);
        }
        return h;
    }

    @k0
    @r0({a.c})
    public static Typeface d(@j0 Context context, @j0 Resources resources, int i, String str, int i2) {
        Typeface e = a.e(context, resources, i, str, i2);
        if (e != null) {
            b.j(e(resources, i, i2), e);
        }
        return e;
    }

    private static String e(Resources resources, int i, int i2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(resources.getResourcePackageName(i));
        String str = com.guideplus.co.download_manager.download.a.p;
        stringBuilder.append(str);
        stringBuilder.append(i);
        stringBuilder.append(str);
        stringBuilder.append(i2);
        return stringBuilder.toString();
    }

    @k0
    @r0({a.c})
    public static Typeface f(@j0 Resources resources, int i, int i2) {
        return (Typeface) b.f(e(resources, i, i2));
    }

    @k0
    private static Typeface g(Context context, Typeface typeface, int i) {
        q qVar = a;
        c i2 = qVar.i(typeface);
        return i2 == null ? null : qVar.b(context, i2, context.getResources(), i);
    }
}
