package b.h.d;

import android.graphics.BlendMode;
import android.graphics.BlendModeColorFilter;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffColorFilter;
import android.os.Build.VERSION;
import androidx.annotation.j0;
import androidx.annotation.k0;

public class b {
    private b() {
    }

    @k0
    public static ColorFilter a(int i, @j0 c cVar) {
        ColorFilter colorFilter = null;
        if (VERSION.SDK_INT >= 29) {
            BlendMode a = d.a(cVar);
            if (a != null) {
                colorFilter = new BlendModeColorFilter(i, a);
            }
            return colorFilter;
        }
        Mode b = d.b(cVar);
        if (b != null) {
            colorFilter = new PorterDuffColorFilter(i, b);
        }
        return colorFilter;
    }
}
