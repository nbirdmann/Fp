package b.h.d;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.CancellationSignal;
import android.util.Log;
import androidx.annotation.j0;
import androidx.annotation.k0;
import androidx.annotation.r0;
import androidx.core.content.i.d.d;
import b.h.k.b.h;
import com.guideplus.co.download_manager.download.f;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.concurrent.ConcurrentHashMap;

@r0({androidx.annotation.r0.a.c})
class q {
    private static final String a = "TypefaceCompatBaseImpl";
    private static final int b = 0;
    private ConcurrentHashMap<Long, androidx.core.content.i.d.c> c = new ConcurrentHashMap();

    private interface c<T> {
        int a(T t);

        boolean b(T t);
    }

    class a implements c<h> {
        a() {
        }

        /* renamed from: c */
        public int a(h hVar) {
            return hVar.d();
        }

        /* renamed from: d */
        public boolean b(h hVar) {
            return hVar.e();
        }
    }

    class b implements c<d> {
        b() {
        }

        /* renamed from: c */
        public int a(d dVar) {
            return dVar.e();
        }

        /* renamed from: d */
        public boolean b(d dVar) {
            return dVar.f();
        }
    }

    q() {
    }

    private void a(Typeface typeface, androidx.core.content.i.d.c cVar) {
        long j = j(typeface);
        if (j != 0) {
            this.c.put(Long.valueOf(j), cVar);
        }
    }

    private d f(androidx.core.content.i.d.c cVar, int i) {
        return (d) g(cVar.a(), i, new b());
    }

    private static <T> T g(T[] tArr, int i, c<T> cVar) {
        int i2 = (i & 1) == 0 ? f.Z : 700;
        boolean z = (i & 2) != 0;
        T t = null;
        int i3 = Integer.MAX_VALUE;
        for (T t2 : tArr) {
            int abs = (Math.abs(cVar.a(t2) - i2) * 2) + (cVar.b(t2) == z ? 0 : 1);
            if (t == null || i3 > abs) {
                t = t2;
                i3 = abs;
            }
        }
        return t;
    }

    private static long j(@k0 Typeface typeface) {
        String str = "Could not retrieve font from family.";
        String str2 = a;
        if (typeface == null) {
            return 0;
        }
        try {
            Field declaredField = Typeface.class.getDeclaredField("native_instance");
            declaredField.setAccessible(true);
            str = ((Number) declaredField.get(typeface)).longValue();
            return str;
        } catch (Throwable e) {
            Log.e(str2, str, e);
            return 0;
        } catch (Throwable e2) {
            Log.e(str2, str, e2);
            return 0;
        }
    }

    @k0
    public Typeface b(Context context, androidx.core.content.i.d.c cVar, Resources resources, int i) {
        d f = f(cVar, i);
        if (f == null) {
            return null;
        }
        Typeface d = k.d(context, resources, f.b(), f.a(), i);
        a(d, cVar);
        return d;
    }

    @k0
    public Typeface c(Context context, @k0 CancellationSignal cancellationSignal, @j0 h[] hVarArr, int i) {
        Throwable th;
        Closeable closeable = null;
        if (hVarArr.length < 1) {
            return null;
        }
        Closeable openInputStream;
        try {
            openInputStream = context.getContentResolver().openInputStream(h(hVarArr, i).c());
            try {
                Typeface d = d(context, openInputStream);
                r.a(openInputStream);
                return d;
            } catch (IOException unused) {
                r.a(openInputStream);
                return null;
            } catch (Throwable th2) {
                th = th2;
                closeable = openInputStream;
                r.a(closeable);
                throw th;
            }
        } catch (IOException unused2) {
            openInputStream = null;
        } catch (Throwable th3) {
            th = th3;
            r.a(closeable);
            throw th;
        }
    }

    protected Typeface d(Context context, InputStream inputStream) {
        File e = r.e(context);
        if (e == null) {
            return null;
        }
        try {
            if (r.d(e, inputStream)) {
                Typeface createFromFile = Typeface.createFromFile(e.getPath());
                e.delete();
                return createFromFile;
            }
            e.delete();
            return null;
        } catch (RuntimeException unused) {
            e.delete();
            return null;
        } catch (Throwable th) {
            e.delete();
            throw th;
        }
    }

    @k0
    public Typeface e(Context context, Resources resources, int i, String str, int i2) {
        File e = r.e(context);
        if (e == null) {
            return null;
        }
        try {
            if (r.c(e, resources, i)) {
                Typeface createFromFile = Typeface.createFromFile(e.getPath());
                e.delete();
                return createFromFile;
            }
            e.delete();
            return null;
        } catch (RuntimeException unused) {
            e.delete();
            return null;
        } catch (Throwable th) {
            e.delete();
            throw th;
        }
    }

    protected h h(h[] hVarArr, int i) {
        return (h) g(hVarArr, i, new a());
    }

    @k0
    androidx.core.content.i.d.c i(Typeface typeface) {
        long j = j(typeface);
        return j == 0 ? null : (androidx.core.content.i.d.c) this.c.get(Long.valueOf(j));
    }
}
