package b.h.d;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.Typeface.Builder;
import android.graphics.fonts.FontVariationAxis;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import androidx.annotation.j0;
import androidx.annotation.k0;
import androidx.annotation.o0;
import androidx.annotation.r0;
import androidx.annotation.r0.a;
import androidx.core.content.i.d.c;
import androidx.core.content.i.d.d;
import b.h.k.b;
import b.h.k.b.h;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.Map;

@o0(26)
@r0({a.c})
public class n extends l {
    private static final String m = "TypefaceCompatApi26Impl";
    private static final String n = "android.graphics.FontFamily";
    private static final String o = "addFontFromAssetManager";
    private static final String p = "addFontFromBuffer";
    private static final String q = "createFromFamiliesWithDefault";
    private static final String r = "freeze";
    private static final String s = "abortCreation";
    private static final int t = -1;
    protected final Method A;
    protected final Class<?> u;
    protected final Constructor<?> v;
    protected final Method w;
    protected final Method x;
    protected final Method y;
    protected final Method z;

    public n() {
        Constructor z;
        Method v;
        Method w;
        Method A;
        Method u;
        Method method;
        Throwable e;
        StringBuilder stringBuilder;
        Class cls = null;
        try {
            Class y = y();
            z = z(y);
            v = v(y);
            w = w(y);
            A = A(y);
            u = u(y);
            cls = x(y);
            Class cls2 = y;
            method = cls;
            cls = cls2;
        } catch (ClassNotFoundException e2) {
            e = e2;
            stringBuilder = new StringBuilder();
            stringBuilder.append("Unable to collect necessary methods for class ");
            stringBuilder.append(e.getClass().getName());
            Log.e(m, stringBuilder.toString(), e);
            method = cls;
            z = method;
            v = z;
            w = v;
            A = w;
            u = A;
            this.u = cls;
            this.v = z;
            this.w = v;
            this.x = w;
            this.y = A;
            this.z = u;
            this.A = method;
        } catch (NoSuchMethodException e3) {
            e = e3;
            stringBuilder = new StringBuilder();
            stringBuilder.append("Unable to collect necessary methods for class ");
            stringBuilder.append(e.getClass().getName());
            Log.e(m, stringBuilder.toString(), e);
            method = cls;
            z = method;
            v = z;
            w = v;
            A = w;
            u = A;
            this.u = cls;
            this.v = z;
            this.w = v;
            this.x = w;
            this.y = A;
            this.z = u;
            this.A = method;
        }
        this.u = cls;
        this.v = z;
        this.w = v;
        this.x = w;
        this.y = A;
        this.z = u;
        this.A = method;
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:3:0x000a A:{ExcHandler: java.lang.IllegalAccessException (unused java.lang.IllegalAccessException), Splitter: B:0:0x0000} */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:3:0x000a A:{ExcHandler: java.lang.IllegalAccessException (unused java.lang.IllegalAccessException), Splitter: B:0:0x0000} */
    /* DevToolsApp WARNING: Missing block: B:4:0x000b, code:
            return null;
     */
    @androidx.annotation.k0
    private java.lang.Object o() {
        /*
        r2 = this;
        r0 = r2.v;	 Catch:{ IllegalAccessException -> 0x000a, IllegalAccessException -> 0x000a, IllegalAccessException -> 0x000a }
        r1 = 0;
        r1 = new java.lang.Object[r1];	 Catch:{ IllegalAccessException -> 0x000a, IllegalAccessException -> 0x000a, IllegalAccessException -> 0x000a }
        r0 = r0.newInstance(r1);	 Catch:{ IllegalAccessException -> 0x000a, IllegalAccessException -> 0x000a, IllegalAccessException -> 0x000a }
        return r0;
    L_0x000a:
        r0 = 0;
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.d.n.o():java.lang.Object");
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:2:0x0008 A:{RETURN, ExcHandler: java.lang.IllegalAccessException (unused java.lang.IllegalAccessException), Splitter: B:0:0x0000} */
    /* DevToolsApp WARNING: Missing block: B:2:0x0008, code:
            return;
     */
    private void p(java.lang.Object r3) {
        /*
        r2 = this;
        r0 = r2.z;	 Catch:{ IllegalAccessException -> 0x0008, IllegalAccessException -> 0x0008 }
        r1 = 0;
        r1 = new java.lang.Object[r1];	 Catch:{ IllegalAccessException -> 0x0008, IllegalAccessException -> 0x0008 }
        r0.invoke(r3, r1);	 Catch:{ IllegalAccessException -> 0x0008, IllegalAccessException -> 0x0008 }
    L_0x0008:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.d.n.p(java.lang.Object):void");
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:4:0x003f A:{RETURN, ExcHandler: java.lang.IllegalAccessException (unused java.lang.IllegalAccessException), Splitter: B:1:0x0001} */
    /* DevToolsApp WARNING: Missing block: B:4:0x003f, code:
            return false;
     */
    private boolean q(android.content.Context r4, java.lang.Object r5, java.lang.String r6, int r7, int r8, int r9, @androidx.annotation.k0 android.graphics.fonts.FontVariationAxis[] r10) {
        /*
        r3 = this;
        r0 = 0;
        r1 = r3.w;	 Catch:{ IllegalAccessException -> 0x003f, IllegalAccessException -> 0x003f }
        r2 = 8;
        r2 = new java.lang.Object[r2];	 Catch:{ IllegalAccessException -> 0x003f, IllegalAccessException -> 0x003f }
        r4 = r4.getAssets();	 Catch:{ IllegalAccessException -> 0x003f, IllegalAccessException -> 0x003f }
        r2[r0] = r4;	 Catch:{ IllegalAccessException -> 0x003f, IllegalAccessException -> 0x003f }
        r4 = 1;
        r2[r4] = r6;	 Catch:{ IllegalAccessException -> 0x003f, IllegalAccessException -> 0x003f }
        r4 = 2;
        r6 = java.lang.Integer.valueOf(r0);	 Catch:{ IllegalAccessException -> 0x003f, IllegalAccessException -> 0x003f }
        r2[r4] = r6;	 Catch:{ IllegalAccessException -> 0x003f, IllegalAccessException -> 0x003f }
        r4 = 3;
        r6 = java.lang.Boolean.FALSE;	 Catch:{ IllegalAccessException -> 0x003f, IllegalAccessException -> 0x003f }
        r2[r4] = r6;	 Catch:{ IllegalAccessException -> 0x003f, IllegalAccessException -> 0x003f }
        r4 = 4;
        r6 = java.lang.Integer.valueOf(r7);	 Catch:{ IllegalAccessException -> 0x003f, IllegalAccessException -> 0x003f }
        r2[r4] = r6;	 Catch:{ IllegalAccessException -> 0x003f, IllegalAccessException -> 0x003f }
        r4 = 5;
        r6 = java.lang.Integer.valueOf(r8);	 Catch:{ IllegalAccessException -> 0x003f, IllegalAccessException -> 0x003f }
        r2[r4] = r6;	 Catch:{ IllegalAccessException -> 0x003f, IllegalAccessException -> 0x003f }
        r4 = 6;
        r6 = java.lang.Integer.valueOf(r9);	 Catch:{ IllegalAccessException -> 0x003f, IllegalAccessException -> 0x003f }
        r2[r4] = r6;	 Catch:{ IllegalAccessException -> 0x003f, IllegalAccessException -> 0x003f }
        r4 = 7;
        r2[r4] = r10;	 Catch:{ IllegalAccessException -> 0x003f, IllegalAccessException -> 0x003f }
        r4 = r1.invoke(r5, r2);	 Catch:{ IllegalAccessException -> 0x003f, IllegalAccessException -> 0x003f }
        r4 = (java.lang.Boolean) r4;	 Catch:{ IllegalAccessException -> 0x003f, IllegalAccessException -> 0x003f }
        r4 = r4.booleanValue();	 Catch:{ IllegalAccessException -> 0x003f, IllegalAccessException -> 0x003f }
        return r4;
    L_0x003f:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.d.n.q(android.content.Context, java.lang.Object, java.lang.String, int, int, int, android.graphics.fonts.FontVariationAxis[]):boolean");
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:4:0x002c A:{RETURN, ExcHandler: java.lang.IllegalAccessException (unused java.lang.IllegalAccessException), Splitter: B:1:0x0001} */
    /* DevToolsApp WARNING: Missing block: B:4:0x002c, code:
            return false;
     */
    private boolean r(java.lang.Object r4, java.nio.ByteBuffer r5, int r6, int r7, int r8) {
        /*
        r3 = this;
        r0 = 0;
        r1 = r3.x;	 Catch:{ IllegalAccessException -> 0x002c, IllegalAccessException -> 0x002c }
        r2 = 5;
        r2 = new java.lang.Object[r2];	 Catch:{ IllegalAccessException -> 0x002c, IllegalAccessException -> 0x002c }
        r2[r0] = r5;	 Catch:{ IllegalAccessException -> 0x002c, IllegalAccessException -> 0x002c }
        r5 = 1;
        r6 = java.lang.Integer.valueOf(r6);	 Catch:{ IllegalAccessException -> 0x002c, IllegalAccessException -> 0x002c }
        r2[r5] = r6;	 Catch:{ IllegalAccessException -> 0x002c, IllegalAccessException -> 0x002c }
        r5 = 2;
        r6 = 0;
        r2[r5] = r6;	 Catch:{ IllegalAccessException -> 0x002c, IllegalAccessException -> 0x002c }
        r5 = 3;
        r6 = java.lang.Integer.valueOf(r7);	 Catch:{ IllegalAccessException -> 0x002c, IllegalAccessException -> 0x002c }
        r2[r5] = r6;	 Catch:{ IllegalAccessException -> 0x002c, IllegalAccessException -> 0x002c }
        r5 = 4;
        r6 = java.lang.Integer.valueOf(r8);	 Catch:{ IllegalAccessException -> 0x002c, IllegalAccessException -> 0x002c }
        r2[r5] = r6;	 Catch:{ IllegalAccessException -> 0x002c, IllegalAccessException -> 0x002c }
        r4 = r1.invoke(r4, r2);	 Catch:{ IllegalAccessException -> 0x002c, IllegalAccessException -> 0x002c }
        r4 = (java.lang.Boolean) r4;	 Catch:{ IllegalAccessException -> 0x002c, IllegalAccessException -> 0x002c }
        r4 = r4.booleanValue();	 Catch:{ IllegalAccessException -> 0x002c, IllegalAccessException -> 0x002c }
        return r4;
    L_0x002c:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.d.n.r(java.lang.Object, java.nio.ByteBuffer, int, int, int):boolean");
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:4:0x0010 A:{RETURN, ExcHandler: java.lang.IllegalAccessException (unused java.lang.IllegalAccessException), Splitter: B:1:0x0001} */
    /* DevToolsApp WARNING: Missing block: B:4:0x0010, code:
            return false;
     */
    private boolean s(java.lang.Object r4) {
        /*
        r3 = this;
        r0 = 0;
        r1 = r3.y;	 Catch:{ IllegalAccessException -> 0x0010, IllegalAccessException -> 0x0010 }
        r2 = new java.lang.Object[r0];	 Catch:{ IllegalAccessException -> 0x0010, IllegalAccessException -> 0x0010 }
        r4 = r1.invoke(r4, r2);	 Catch:{ IllegalAccessException -> 0x0010, IllegalAccessException -> 0x0010 }
        r4 = (java.lang.Boolean) r4;	 Catch:{ IllegalAccessException -> 0x0010, IllegalAccessException -> 0x0010 }
        r4 = r4.booleanValue();	 Catch:{ IllegalAccessException -> 0x0010, IllegalAccessException -> 0x0010 }
        return r4;
    L_0x0010:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.d.n.s(java.lang.Object):boolean");
    }

    private boolean t() {
        if (this.w == null) {
            Log.w(m, "Unable to collect necessary private methods. Fallback to legacy implementation.");
        }
        return this.w != null;
    }

    protected Method A(Class<?> cls) throws NoSuchMethodException {
        return cls.getMethod(r, new Class[0]);
    }

    @k0
    public Typeface b(Context context, c cVar, Resources resources, int i) {
        if (!t()) {
            return super.b(context, cVar, resources, i);
        }
        Object o = o();
        if (o == null) {
            return null;
        }
        d[] a = cVar.a();
        int length = a.length;
        int i2 = 0;
        while (i2 < length) {
            d dVar = a[i2];
            if (q(context, o, dVar.a(), dVar.c(), dVar.e(), dVar.f(), FontVariationAxis.fromFontVariationSettings(dVar.d()))) {
                i2++;
            } else {
                p(o);
                return null;
            }
        }
        return !s(o) ? null : l(o);
    }

    @k0
    public Typeface c(Context context, @k0 CancellationSignal cancellationSignal, @j0 h[] hVarArr, int i) {
        if (hVarArr.length < 1) {
            return null;
        }
        if (t()) {
            Map j = b.j(context, hVarArr, cancellationSignal);
            Object o = o();
            if (o == null) {
                return null;
            }
            Object obj = null;
            for (h hVar : hVarArr) {
                ByteBuffer byteBuffer = (ByteBuffer) j.get(hVar.c());
                if (byteBuffer != null) {
                    if (r(o, byteBuffer, hVar.b(), hVar.d(), hVar.e())) {
                        obj = 1;
                    } else {
                        p(o);
                        return null;
                    }
                }
            }
            if (obj == null) {
                p(o);
                return null;
            } else if (!s(o)) {
                return null;
            } else {
                Typeface l = l(o);
                return l == null ? null : Typeface.create(l, i);
            }
        } else {
            h h = h(hVarArr, i);
            ParcelFileDescriptor openFileDescriptor;
            try {
                openFileDescriptor = context.getContentResolver().openFileDescriptor(h.c(), "r", cancellationSignal);
                if (openFileDescriptor == null) {
                    if (openFileDescriptor != null) {
                        openFileDescriptor.close();
                    }
                    return null;
                }
                Typeface build = new Builder(openFileDescriptor.getFileDescriptor()).setWeight(h.d()).setItalic(h.e()).build();
                openFileDescriptor.close();
                return build;
            } catch (IOException unused) {
                return null;
            } catch (Throwable th) {
                th.addSuppressed(th);
            }
        }
    }

    @k0
    public Typeface e(Context context, Resources resources, int i, String str, int i2) {
        if (!t()) {
            return super.e(context, resources, i, str, i2);
        }
        Object o = o();
        if (o == null) {
            return null;
        }
        if (q(context, o, str, 0, -1, -1, null)) {
            return !s(o) ? null : l(o);
        } else {
            p(o);
            return null;
        }
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:4:0x0028 A:{RETURN, ExcHandler: java.lang.IllegalAccessException (unused java.lang.IllegalAccessException), Splitter: B:1:0x0001} */
    /* DevToolsApp WARNING: Missing block: B:4:0x0028, code:
            return null;
     */
    @androidx.annotation.k0
    protected android.graphics.Typeface l(java.lang.Object r6) {
        /*
        r5 = this;
        r0 = 0;
        r1 = r5.u;	 Catch:{ IllegalAccessException -> 0x0028, IllegalAccessException -> 0x0028 }
        r2 = 1;
        r1 = java.lang.reflect.Array.newInstance(r1, r2);	 Catch:{ IllegalAccessException -> 0x0028, IllegalAccessException -> 0x0028 }
        r3 = 0;
        java.lang.reflect.Array.set(r1, r3, r6);	 Catch:{ IllegalAccessException -> 0x0028, IllegalAccessException -> 0x0028 }
        r6 = r5.A;	 Catch:{ IllegalAccessException -> 0x0028, IllegalAccessException -> 0x0028 }
        r4 = 3;
        r4 = new java.lang.Object[r4];	 Catch:{ IllegalAccessException -> 0x0028, IllegalAccessException -> 0x0028 }
        r4[r3] = r1;	 Catch:{ IllegalAccessException -> 0x0028, IllegalAccessException -> 0x0028 }
        r1 = -1;
        r3 = java.lang.Integer.valueOf(r1);	 Catch:{ IllegalAccessException -> 0x0028, IllegalAccessException -> 0x0028 }
        r4[r2] = r3;	 Catch:{ IllegalAccessException -> 0x0028, IllegalAccessException -> 0x0028 }
        r2 = 2;
        r1 = java.lang.Integer.valueOf(r1);	 Catch:{ IllegalAccessException -> 0x0028, IllegalAccessException -> 0x0028 }
        r4[r2] = r1;	 Catch:{ IllegalAccessException -> 0x0028, IllegalAccessException -> 0x0028 }
        r6 = r6.invoke(r0, r4);	 Catch:{ IllegalAccessException -> 0x0028, IllegalAccessException -> 0x0028 }
        r6 = (android.graphics.Typeface) r6;	 Catch:{ IllegalAccessException -> 0x0028, IllegalAccessException -> 0x0028 }
        return r6;
    L_0x0028:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.d.n.l(java.lang.Object):android.graphics.Typeface");
    }

    protected Method u(Class<?> cls) throws NoSuchMethodException {
        return cls.getMethod(s, new Class[0]);
    }

    protected Method v(Class<?> cls) throws NoSuchMethodException {
        r0 = new Class[8];
        Class cls2 = Integer.TYPE;
        r0[2] = cls2;
        r0[3] = Boolean.TYPE;
        r0[4] = cls2;
        r0[5] = cls2;
        r0[6] = cls2;
        r0[7] = FontVariationAxis[].class;
        return cls.getMethod(o, r0);
    }

    protected Method w(Class<?> cls) throws NoSuchMethodException {
        r0 = new Class[5];
        Class cls2 = Integer.TYPE;
        r0[1] = cls2;
        r0[2] = FontVariationAxis[].class;
        r0[3] = cls2;
        r0[4] = cls2;
        return cls.getMethod(p, r0);
    }

    protected Method x(Class<?> cls) throws NoSuchMethodException {
        r2 = new Class[3];
        Class cls2 = Integer.TYPE;
        r2[1] = cls2;
        r2[2] = cls2;
        Method declaredMethod = Typeface.class.getDeclaredMethod(q, r2);
        declaredMethod.setAccessible(true);
        return declaredMethod;
    }

    protected Class<?> y() throws ClassNotFoundException {
        return Class.forName(n);
    }

    protected Constructor<?> z(Class<?> cls) throws NoSuchMethodException {
        return cls.getConstructor(new Class[0]);
    }
}
