package b.h.d;

import android.graphics.Typeface;
import androidx.annotation.o0;
import androidx.annotation.r0;
import androidx.annotation.r0.a;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

@o0(28)
@r0({a.c})
public class o extends n {
    private static final String B = "createFromFamiliesWithDefault";
    private static final int C = -1;
    private static final String D = "sans-serif";

    protected Typeface l(Object obj) {
        Throwable e;
        try {
            Array.set(Array.newInstance(this.u, 1), 0, obj);
            return (Typeface) this.A.invoke(null, new Object[]{r0, "sans-serif", Integer.valueOf(-1), Integer.valueOf(-1)});
        } catch (IllegalAccessException e2) {
            e = e2;
            throw new RuntimeException(e);
        } catch (InvocationTargetException e3) {
            e = e3;
            throw new RuntimeException(e);
        }
    }

    protected Method x(Class<?> cls) throws NoSuchMethodException {
        r2 = new Class[4];
        Class cls2 = Integer.TYPE;
        r2[2] = cls2;
        r2[3] = cls2;
        Method declaredMethod = Typeface.class.getDeclaredMethod(B, r2);
        declaredMethod.setAccessible(true);
        return declaredMethod;
    }
}
