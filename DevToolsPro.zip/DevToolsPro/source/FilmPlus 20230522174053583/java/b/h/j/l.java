package b.h.j;

import android.os.Parcel;
import androidx.annotation.j0;

public final class l {
    private l() {
    }

    public static boolean a(@j0 Parcel parcel) {
        return parcel.readInt() != 0;
    }

    public static void b(@j0 Parcel parcel, boolean z) {
        parcel.writeInt(z);
    }
}
