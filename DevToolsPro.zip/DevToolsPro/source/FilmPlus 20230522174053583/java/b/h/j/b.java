package b.h.j;

import android.os.Build.VERSION;
import android.os.CancellationSignal;
import androidx.annotation.k0;

public final class b {
    private boolean a;
    private a b;
    private Object c;
    private boolean d;

    public interface a {
        void onCancel();
    }

    /* DevToolsApp ERROR: DevToolsAppRE in pass: o00Ooo
        g.d.a.b.DevToolsAppRE: Exception block dominator not found, method:b.h.j.b.f():void, dom blocks: []
        	at OooOO0O.OooO0O0.OooO0o.OooO0oO.o000O0Oo.o00Ooo.OooO0o(SourceFile:112)
        	at OooO.OooO0O0.OooO0OO.OooO0oo.o00000OO.o0000o(SourceFile:3)
        	at OooOO0O.OooO0O0.OooO0o.OooO0oO.o00000O.accept(SourceFile:1)
        	at OooO0oo.OooO00o.OooO00o.OooO0OO.OooOoOO.Oooo0.OooO00o(SourceFile:2)
        	at OooO.OooO0O0.OooO0OO.OooO0oo.o00000OO.o0000o0o(SourceFile:5)
        	at OooO.OooO0O0.OooO0OO.OooO0oo.o00000OO.o00oO0O(SourceFile:11)
        	at OooOO0O.OooO0O0.OooO00o.accept(SourceFile:1)
        	at OooO0oo.OooO00o.OooO00o.OooO0OO.OooOoOO.Oooo0.OooO00o(SourceFile:2)
        	at OooO.OooO0O0.OooO0OO.OooO0oo.o00000OO.o00oO0O(SourceFile:17)
        	at OooOO0O.OooO00o.OooO00o.run(SourceFile:8)
        */
    private void f() {
        /*
        r1 = this;
    L_0x0000:
        r0 = r1.d;
        if (r0 == 0) goto L_0x000a;
    L_0x0004:
        r1.wait();	 Catch:{ InterruptedException -> 0x0008 }
        goto L_0x0000;
        goto L_0x0000;
    L_0x000a:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.j.b.f():void");
    }

    /* DevToolsApp WARNING: Missing block: B:9:0x0012, code:
            if (r0 == null) goto L_0x001a;
     */
    /* DevToolsApp WARNING: Missing block: B:11:?, code:
            r0.onCancel();
     */
    /* DevToolsApp WARNING: Missing block: B:13:0x001a, code:
            if (r1 == null) goto L_0x0033;
     */
    /* DevToolsApp WARNING: Missing block: B:15:0x0020, code:
            if (android.os.Build.VERSION.SDK_INT < 16) goto L_0x0033;
     */
    /* DevToolsApp WARNING: Missing block: B:16:0x0022, code:
            ((android.os.CancellationSignal) r1).cancel();
     */
    /* DevToolsApp WARNING: Missing block: B:17:0x0028, code:
            monitor-enter(r4);
     */
    /* DevToolsApp WARNING: Missing block: B:19:?, code:
            r4.d = false;
            notifyAll();
     */
    /* DevToolsApp WARNING: Missing block: B:26:0x0033, code:
            monitor-enter(r4);
     */
    /* DevToolsApp WARNING: Missing block: B:28:?, code:
            r4.d = false;
            notifyAll();
     */
    /* DevToolsApp WARNING: Missing block: B:29:0x0039, code:
            monitor-exit(r4);
     */
    /* DevToolsApp WARNING: Missing block: B:30:0x003a, code:
            return;
     */
    public void a() {
        /*
        r4 = this;
        monitor-enter(r4);
        r0 = r4.a;	 Catch:{ all -> 0x003e }
        if (r0 == 0) goto L_0x0007;
    L_0x0005:
        monitor-exit(r4);	 Catch:{ all -> 0x003e }
        return;
    L_0x0007:
        r0 = 1;
        r4.a = r0;	 Catch:{ all -> 0x003e }
        r4.d = r0;	 Catch:{ all -> 0x003e }
        r0 = r4.b;	 Catch:{ all -> 0x003e }
        r1 = r4.c;	 Catch:{ all -> 0x003e }
        monitor-exit(r4);	 Catch:{ all -> 0x003e }
        r2 = 0;
        if (r0 == 0) goto L_0x001a;
    L_0x0014:
        r0.onCancel();	 Catch:{ all -> 0x0018 }
        goto L_0x001a;
    L_0x0018:
        r0 = move-exception;
        goto L_0x0028;
    L_0x001a:
        if (r1 == 0) goto L_0x0033;
    L_0x001c:
        r0 = android.os.Build.VERSION.SDK_INT;	 Catch:{ all -> 0x0018 }
        r3 = 16;
        if (r0 < r3) goto L_0x0033;
    L_0x0022:
        r1 = (android.os.CancellationSignal) r1;	 Catch:{ all -> 0x0018 }
        r1.cancel();	 Catch:{ all -> 0x0018 }
        goto L_0x0033;
    L_0x0028:
        monitor-enter(r4);
        r4.d = r2;	 Catch:{ all -> 0x0030 }
        r4.notifyAll();	 Catch:{ all -> 0x0030 }
        monitor-exit(r4);	 Catch:{ all -> 0x0030 }
        throw r0;
    L_0x0030:
        r0 = move-exception;
        monitor-exit(r4);	 Catch:{ all -> 0x0030 }
        throw r0;
    L_0x0033:
        monitor-enter(r4);
        r4.d = r2;	 Catch:{ all -> 0x003b }
        r4.notifyAll();	 Catch:{ all -> 0x003b }
        monitor-exit(r4);	 Catch:{ all -> 0x003b }
        return;
    L_0x003b:
        r0 = move-exception;
        monitor-exit(r4);	 Catch:{ all -> 0x003b }
        throw r0;
    L_0x003e:
        r0 = move-exception;
        monitor-exit(r4);	 Catch:{ all -> 0x003e }
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.j.b.a():void");
    }

    @k0
    public Object b() {
        if (VERSION.SDK_INT < 16) {
            return null;
        }
        Object obj;
        synchronized (this) {
            if (this.c == null) {
                CancellationSignal cancellationSignal = new CancellationSignal();
                this.c = cancellationSignal;
                if (this.a) {
                    cancellationSignal.cancel();
                }
            }
            obj = this.c;
        }
        return obj;
    }

    public boolean c() {
        boolean z;
        synchronized (this) {
            z = this.a;
        }
        return z;
    }

    public void d(@k0 a aVar) {
        synchronized (this) {
            f();
            if (this.b == aVar) {
                return;
            }
            this.b = aVar;
            if (!this.a || aVar == null) {
                return;
            }
            aVar.onCancel();
        }
    }

    public void e() {
        if (c()) {
            throw new k();
        }
    }
}
