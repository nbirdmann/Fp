package b.h.j;

import androidx.annotation.b0;
import androidx.annotation.j0;
import androidx.annotation.k0;
import java.util.Locale;

interface h {
    @b0(from = -1)
    int a(Locale locale);

    String b();

    Object c();

    @k0
    Locale d(@j0 String[] strArr);

    Locale get(int i);

    boolean isEmpty();

    @b0(from = 0)
    int size();
}
