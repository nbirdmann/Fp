package b.h.j;

import android.os.Parcel;
import android.os.Parcelable.ClassLoaderCreator;
import android.os.Parcelable.Creator;

@Deprecated
public final class m {

    static class a<T> implements ClassLoaderCreator<T> {
        private final n<T> a;

        a(n<T> nVar) {
            this.a = nVar;
        }

        public T createFromParcel(Parcel parcel) {
            return this.a.createFromParcel(parcel, null);
        }

        public T createFromParcel(Parcel parcel, ClassLoader classLoader) {
            return this.a.createFromParcel(parcel, classLoader);
        }

        public T[] newArray(int i) {
            return this.a.newArray(i);
        }
    }

    private m() {
    }

    @Deprecated
    public static <T> Creator<T> a(n<T> nVar) {
        return new a(nVar);
    }
}
