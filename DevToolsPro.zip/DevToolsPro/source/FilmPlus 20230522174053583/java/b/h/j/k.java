package b.h.j;

import androidx.annotation.k0;

public class k extends RuntimeException {
    public k() {
        this(null);
    }

    public k(@k0 String str) {
        if (str == null) {
            str = "The operation has been canceled.";
        }
        super(str);
    }
}
