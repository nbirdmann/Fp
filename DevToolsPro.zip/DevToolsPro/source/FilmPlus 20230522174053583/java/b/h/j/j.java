package b.h.j;

import android.annotation.SuppressLint;
import android.os.Build.VERSION;
import android.os.Message;
import androidx.annotation.j0;

public final class j {
    private static boolean a = true;
    private static boolean b = true;

    private j() {
    }

    @SuppressLint({"NewApi"})
    public static boolean a(@j0 Message message) {
        int i = VERSION.SDK_INT;
        if (i >= 22) {
            return message.isAsynchronous();
        }
        if (b && i >= 16) {
            try {
                return message.isAsynchronous();
            } catch (NoSuchMethodError unused) {
                b = false;
            }
        }
        return false;
    }

    @SuppressLint({"NewApi"})
    public static void b(@j0 Message message, boolean z) {
        int i = VERSION.SDK_INT;
        if (i >= 22) {
            message.setAsynchronous(z);
            return;
        }
        if (a && i >= 16) {
            try {
                message.setAsynchronous(z);
            } catch (NoSuchMethodError unused) {
                a = false;
            }
        }
    }
}
