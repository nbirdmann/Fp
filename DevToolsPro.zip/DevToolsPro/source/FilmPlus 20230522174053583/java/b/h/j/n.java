package b.h.j;

import android.os.Parcel;

@Deprecated
public interface n<T> {
    T createFromParcel(Parcel parcel, ClassLoader classLoader);

    T[] newArray(int i);
}
