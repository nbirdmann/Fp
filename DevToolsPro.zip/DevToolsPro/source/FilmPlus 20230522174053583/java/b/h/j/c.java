package b.h.j;

import android.content.res.Configuration;
import android.os.Build.VERSION;
import androidx.annotation.j0;

public final class c {
    private c() {
    }

    @j0
    public static f a(@j0 Configuration configuration) {
        if (VERSION.SDK_INT >= 24) {
            return f.n(configuration.getLocales());
        }
        return f.a(configuration.locale);
    }
}
