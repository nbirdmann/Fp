package b.h.j;

import android.os.Build.VERSION;
import android.os.LocaleList;
import androidx.annotation.b0;
import androidx.annotation.j0;
import androidx.annotation.k0;
import androidx.annotation.o0;
import androidx.annotation.s0;
import com.guideplus.co.download_manager.download.a;
import java.util.Locale;

public final class f {
    private static final f a = a(new Locale[0]);
    private h b;

    private f(h hVar) {
        this.b = hVar;
    }

    @j0
    public static f a(@j0 Locale... localeArr) {
        return VERSION.SDK_INT >= 24 ? n(new LocaleList(localeArr)) : new f(new g(localeArr));
    }

    static Locale b(String str) {
        Object obj = a.p;
        String[] split;
        if (str.contains(obj)) {
            split = str.split(obj, -1);
            if (split.length > 2) {
                return new Locale(split[0], split[1], split[2]);
            }
            if (split.length > 1) {
                return new Locale(split[0], split[1]);
            }
            if (split.length == 1) {
                return new Locale(split[0]);
            }
        }
        obj = "_";
        if (!str.contains(obj)) {
            return new Locale(str);
        }
        split = str.split(obj, -1);
        if (split.length > 2) {
            return new Locale(split[0], split[1], split[2]);
        }
        if (split.length > 1) {
            return new Locale(split[0], split[1]);
        }
        if (split.length == 1) {
            return new Locale(split[0]);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Can not parse language tag: [");
        stringBuilder.append(str);
        stringBuilder.append("]");
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    @j0
    public static f c(@k0 String str) {
        if (str == null || str.isEmpty()) {
            return g();
        }
        String[] split = str.split(",", -1);
        int length = split.length;
        Locale[] localeArr = new Locale[length];
        for (int i = 0; i < length; i++) {
            localeArr[i] = VERSION.SDK_INT >= 21 ? Locale.forLanguageTag(split[i]) : b(split[i]);
        }
        return a(localeArr);
    }

    @s0(min = 1)
    @j0
    public static f e() {
        if (VERSION.SDK_INT >= 24) {
            return n(LocaleList.getAdjustedDefault());
        }
        return a(Locale.getDefault());
    }

    @s0(min = 1)
    @j0
    public static f f() {
        if (VERSION.SDK_INT >= 24) {
            return n(LocaleList.getDefault());
        }
        return a(Locale.getDefault());
    }

    @j0
    public static f g() {
        return a;
    }

    @o0(24)
    @j0
    public static f n(@j0 LocaleList localeList) {
        return new f(new i(localeList));
    }

    @o0(24)
    @Deprecated
    public static f o(Object obj) {
        return n((LocaleList) obj);
    }

    public Locale d(int i) {
        return this.b.get(i);
    }

    public boolean equals(Object obj) {
        return (obj instanceof f) && this.b.equals(((f) obj).b);
    }

    @k0
    public Locale h(@j0 String[] strArr) {
        return this.b.d(strArr);
    }

    public int hashCode() {
        return this.b.hashCode();
    }

    @b0(from = -1)
    public int i(Locale locale) {
        return this.b.a(locale);
    }

    public boolean j() {
        return this.b.isEmpty();
    }

    @b0(from = 0)
    public int k() {
        return this.b.size();
    }

    @j0
    public String l() {
        return this.b.b();
    }

    @k0
    public Object m() {
        return this.b.c();
    }

    public String toString() {
        return this.b.toString();
    }
}
