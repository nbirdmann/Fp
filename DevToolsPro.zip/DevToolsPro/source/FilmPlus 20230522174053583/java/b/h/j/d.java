package b.h.j;

import android.os.Build.VERSION;
import android.os.Environment;
import android.util.Log;
import androidx.annotation.j0;
import java.io.File;
import java.io.IOException;

public final class d {
    private static final String a = "EnvironmentCompat";
    public static final String b = "unknown";

    private d() {
    }

    @j0
    public static String a(@j0 File file) {
        int i = VERSION.SDK_INT;
        if (i >= 21) {
            return Environment.getExternalStorageState(file);
        }
        if (i >= 19) {
            return Environment.getStorageState(file);
        }
        try {
            if (file.getCanonicalPath().startsWith(Environment.getExternalStorageDirectory().getCanonicalPath())) {
                return Environment.getExternalStorageState();
            }
        } catch (IOException e) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Failed to resolve canonical path: ");
            stringBuilder.append(e);
            Log.w(a, stringBuilder.toString());
        }
        return "unknown";
    }
}
