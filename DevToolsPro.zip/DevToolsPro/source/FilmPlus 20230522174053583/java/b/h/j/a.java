package b.h.j;

import android.os.Build.VERSION;

public class a {
    private a() {
    }

    @Deprecated
    public static boolean a() {
        return VERSION.SDK_INT >= 24;
    }

    @Deprecated
    public static boolean b() {
        return VERSION.SDK_INT >= 25;
    }

    @Deprecated
    public static boolean c() {
        return VERSION.SDK_INT >= 26;
    }

    @Deprecated
    public static boolean d() {
        return VERSION.SDK_INT >= 27;
    }

    @Deprecated
    public static boolean e() {
        return VERSION.SDK_INT >= 28;
    }

    @Deprecated
    public static boolean f() {
        return VERSION.SDK_INT >= 29;
    }

    public static boolean g() {
        String str = VERSION.CODENAME;
        return str.length() == 1 && str.charAt(0) >= 'R' && str.charAt(0) <= 'Z';
    }
}
