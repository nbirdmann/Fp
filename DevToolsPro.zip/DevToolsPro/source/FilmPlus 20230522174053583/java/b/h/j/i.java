package b.h.j;

import android.os.LocaleList;
import androidx.annotation.j0;
import androidx.annotation.k0;
import androidx.annotation.o0;
import java.util.Locale;

@o0(24)
final class i implements h {
    private final LocaleList a;

    i(LocaleList localeList) {
        this.a = localeList;
    }

    public int a(Locale locale) {
        return this.a.indexOf(locale);
    }

    public String b() {
        return this.a.toLanguageTags();
    }

    public Object c() {
        return this.a;
    }

    @k0
    public Locale d(@j0 String[] strArr) {
        return this.a.getFirstMatch(strArr);
    }

    public boolean equals(Object obj) {
        return this.a.equals(((h) obj).c());
    }

    public Locale get(int i) {
        return this.a.get(i);
    }

    public int hashCode() {
        return this.a.hashCode();
    }

    public boolean isEmpty() {
        return this.a.isEmpty();
    }

    public int size() {
        return this.a.size();
    }

    public String toString() {
        return this.a.toString();
    }
}
