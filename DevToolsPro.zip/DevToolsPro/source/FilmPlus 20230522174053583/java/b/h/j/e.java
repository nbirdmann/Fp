package b.h.j;

import android.os.Build.VERSION;
import android.os.Handler;
import android.os.Message;
import androidx.annotation.j0;
import androidx.annotation.k0;

public final class e {
    private static final String a = "HandlerCompat";

    private e() {
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:20:0x0052 A:{ExcHandler: java.lang.IllegalAccessException (unused java.lang.IllegalAccessException), Splitter: B:6:0x000f} */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:20:0x0052 A:{ExcHandler: java.lang.IllegalAccessException (unused java.lang.IllegalAccessException), Splitter: B:6:0x000f} */
    /* DevToolsApp WARNING: Missing block: B:20:0x0052, code:
            android.util.Log.v(a, "Unable to invoke Handler(Looper, Callback, boolean) constructor");
     */
    @androidx.annotation.j0
    public static android.os.Handler a(@androidx.annotation.j0 android.os.Looper r7) {
        /*
        r0 = android.os.Build.VERSION.SDK_INT;
        r1 = 28;
        if (r0 < r1) goto L_0x000b;
    L_0x0006:
        r7 = android.os.Handler.createAsync(r7);
        return r7;
    L_0x000b:
        r1 = 16;
        if (r0 < r1) goto L_0x0059;
    L_0x000f:
        r0 = android.os.Handler.class;
        r1 = 3;
        r2 = new java.lang.Class[r1];	 Catch:{ IllegalAccessException -> 0x0052, IllegalAccessException -> 0x0052, IllegalAccessException -> 0x0052, InvocationTargetException -> 0x0039 }
        r3 = android.os.Looper.class;
        r4 = 0;
        r2[r4] = r3;	 Catch:{ IllegalAccessException -> 0x0052, IllegalAccessException -> 0x0052, IllegalAccessException -> 0x0052, InvocationTargetException -> 0x0039 }
        r3 = android.os.Handler.Callback.class;
        r5 = 1;
        r2[r5] = r3;	 Catch:{ IllegalAccessException -> 0x0052, IllegalAccessException -> 0x0052, IllegalAccessException -> 0x0052, InvocationTargetException -> 0x0039 }
        r3 = java.lang.Boolean.TYPE;	 Catch:{ IllegalAccessException -> 0x0052, IllegalAccessException -> 0x0052, IllegalAccessException -> 0x0052, InvocationTargetException -> 0x0039 }
        r6 = 2;
        r2[r6] = r3;	 Catch:{ IllegalAccessException -> 0x0052, IllegalAccessException -> 0x0052, IllegalAccessException -> 0x0052, InvocationTargetException -> 0x0039 }
        r0 = r0.getDeclaredConstructor(r2);	 Catch:{ IllegalAccessException -> 0x0052, IllegalAccessException -> 0x0052, IllegalAccessException -> 0x0052, InvocationTargetException -> 0x0039 }
        r1 = new java.lang.Object[r1];	 Catch:{ IllegalAccessException -> 0x0052, IllegalAccessException -> 0x0052, IllegalAccessException -> 0x0052, InvocationTargetException -> 0x0039 }
        r1[r4] = r7;	 Catch:{ IllegalAccessException -> 0x0052, IllegalAccessException -> 0x0052, IllegalAccessException -> 0x0052, InvocationTargetException -> 0x0039 }
        r2 = 0;
        r1[r5] = r2;	 Catch:{ IllegalAccessException -> 0x0052, IllegalAccessException -> 0x0052, IllegalAccessException -> 0x0052, InvocationTargetException -> 0x0039 }
        r2 = java.lang.Boolean.TRUE;	 Catch:{ IllegalAccessException -> 0x0052, IllegalAccessException -> 0x0052, IllegalAccessException -> 0x0052, InvocationTargetException -> 0x0039 }
        r1[r6] = r2;	 Catch:{ IllegalAccessException -> 0x0052, IllegalAccessException -> 0x0052, IllegalAccessException -> 0x0052, InvocationTargetException -> 0x0039 }
        r0 = r0.newInstance(r1);	 Catch:{ IllegalAccessException -> 0x0052, IllegalAccessException -> 0x0052, IllegalAccessException -> 0x0052, InvocationTargetException -> 0x0039 }
        r0 = (android.os.Handler) r0;	 Catch:{ IllegalAccessException -> 0x0052, IllegalAccessException -> 0x0052, IllegalAccessException -> 0x0052, InvocationTargetException -> 0x0039 }
        return r0;
    L_0x0039:
        r7 = move-exception;
        r7 = r7.getCause();
        r0 = r7 instanceof java.lang.RuntimeException;
        if (r0 != 0) goto L_0x004f;
    L_0x0042:
        r0 = r7 instanceof java.lang.Error;
        if (r0 == 0) goto L_0x0049;
    L_0x0046:
        r7 = (java.lang.Error) r7;
        throw r7;
    L_0x0049:
        r0 = new java.lang.RuntimeException;
        r0.<init>(r7);
        throw r0;
    L_0x004f:
        r7 = (java.lang.RuntimeException) r7;
        throw r7;
    L_0x0052:
        r0 = "HandlerCompat";
        r1 = "Unable to invoke Handler(Looper, Callback, boolean) constructor";
        android.util.Log.v(r0, r1);
    L_0x0059:
        r0 = new android.os.Handler;
        r0.<init>(r7);
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.j.e.a(android.os.Looper):android.os.Handler");
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:20:0x0051 A:{ExcHandler: java.lang.IllegalAccessException (unused java.lang.IllegalAccessException), Splitter: B:6:0x000f} */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:20:0x0051 A:{ExcHandler: java.lang.IllegalAccessException (unused java.lang.IllegalAccessException), Splitter: B:6:0x000f} */
    /* DevToolsApp WARNING: Missing block: B:20:0x0051, code:
            android.util.Log.v(a, "Unable to invoke Handler(Looper, Callback, boolean) constructor");
     */
    @androidx.annotation.j0
    public static android.os.Handler b(@androidx.annotation.j0 android.os.Looper r7, @androidx.annotation.j0 android.os.Handler.Callback r8) {
        /*
        r0 = android.os.Build.VERSION.SDK_INT;
        r1 = 28;
        if (r0 < r1) goto L_0x000b;
    L_0x0006:
        r7 = android.os.Handler.createAsync(r7, r8);
        return r7;
    L_0x000b:
        r1 = 16;
        if (r0 < r1) goto L_0x0058;
    L_0x000f:
        r0 = android.os.Handler.class;
        r1 = 3;
        r2 = new java.lang.Class[r1];	 Catch:{ IllegalAccessException -> 0x0051, IllegalAccessException -> 0x0051, IllegalAccessException -> 0x0051, InvocationTargetException -> 0x0038 }
        r3 = android.os.Looper.class;
        r4 = 0;
        r2[r4] = r3;	 Catch:{ IllegalAccessException -> 0x0051, IllegalAccessException -> 0x0051, IllegalAccessException -> 0x0051, InvocationTargetException -> 0x0038 }
        r3 = android.os.Handler.Callback.class;
        r5 = 1;
        r2[r5] = r3;	 Catch:{ IllegalAccessException -> 0x0051, IllegalAccessException -> 0x0051, IllegalAccessException -> 0x0051, InvocationTargetException -> 0x0038 }
        r3 = java.lang.Boolean.TYPE;	 Catch:{ IllegalAccessException -> 0x0051, IllegalAccessException -> 0x0051, IllegalAccessException -> 0x0051, InvocationTargetException -> 0x0038 }
        r6 = 2;
        r2[r6] = r3;	 Catch:{ IllegalAccessException -> 0x0051, IllegalAccessException -> 0x0051, IllegalAccessException -> 0x0051, InvocationTargetException -> 0x0038 }
        r0 = r0.getDeclaredConstructor(r2);	 Catch:{ IllegalAccessException -> 0x0051, IllegalAccessException -> 0x0051, IllegalAccessException -> 0x0051, InvocationTargetException -> 0x0038 }
        r1 = new java.lang.Object[r1];	 Catch:{ IllegalAccessException -> 0x0051, IllegalAccessException -> 0x0051, IllegalAccessException -> 0x0051, InvocationTargetException -> 0x0038 }
        r1[r4] = r7;	 Catch:{ IllegalAccessException -> 0x0051, IllegalAccessException -> 0x0051, IllegalAccessException -> 0x0051, InvocationTargetException -> 0x0038 }
        r1[r5] = r8;	 Catch:{ IllegalAccessException -> 0x0051, IllegalAccessException -> 0x0051, IllegalAccessException -> 0x0051, InvocationTargetException -> 0x0038 }
        r2 = java.lang.Boolean.TRUE;	 Catch:{ IllegalAccessException -> 0x0051, IllegalAccessException -> 0x0051, IllegalAccessException -> 0x0051, InvocationTargetException -> 0x0038 }
        r1[r6] = r2;	 Catch:{ IllegalAccessException -> 0x0051, IllegalAccessException -> 0x0051, IllegalAccessException -> 0x0051, InvocationTargetException -> 0x0038 }
        r0 = r0.newInstance(r1);	 Catch:{ IllegalAccessException -> 0x0051, IllegalAccessException -> 0x0051, IllegalAccessException -> 0x0051, InvocationTargetException -> 0x0038 }
        r0 = (android.os.Handler) r0;	 Catch:{ IllegalAccessException -> 0x0051, IllegalAccessException -> 0x0051, IllegalAccessException -> 0x0051, InvocationTargetException -> 0x0038 }
        return r0;
    L_0x0038:
        r7 = move-exception;
        r7 = r7.getCause();
        r8 = r7 instanceof java.lang.RuntimeException;
        if (r8 != 0) goto L_0x004e;
    L_0x0041:
        r8 = r7 instanceof java.lang.Error;
        if (r8 == 0) goto L_0x0048;
    L_0x0045:
        r7 = (java.lang.Error) r7;
        throw r7;
    L_0x0048:
        r8 = new java.lang.RuntimeException;
        r8.<init>(r7);
        throw r8;
    L_0x004e:
        r7 = (java.lang.RuntimeException) r7;
        throw r7;
    L_0x0051:
        r0 = "HandlerCompat";
        r1 = "Unable to invoke Handler(Looper, Callback, boolean) constructor";
        android.util.Log.v(r0, r1);
    L_0x0058:
        r0 = new android.os.Handler;
        r0.<init>(r7, r8);
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.j.e.b(android.os.Looper, android.os.Handler$Callback):android.os.Handler");
    }

    public static boolean c(@j0 Handler handler, @j0 Runnable runnable, @k0 Object obj, long j) {
        if (VERSION.SDK_INT >= 28) {
            return handler.postDelayed(runnable, obj, j);
        }
        Message obtain = Message.obtain(handler, runnable);
        obtain.obj = obj;
        return handler.sendMessageDelayed(obtain, j);
    }
}
