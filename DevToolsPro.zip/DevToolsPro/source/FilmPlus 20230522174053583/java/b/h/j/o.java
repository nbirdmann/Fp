package b.h.j;

import android.os.Build.VERSION;
import android.os.Trace;
import android.util.Log;
import androidx.annotation.j0;
import java.lang.reflect.Method;

public final class o {
    private static final String a = "TraceCompat";
    private static long b;
    private static Method c;
    private static Method d;
    private static Method e;
    private static Method f;

    static {
        Class cls = String.class;
        int i = VERSION.SDK_INT;
        if (i >= 18 && i < 29) {
            try {
                b = Trace.class.getField("TRACE_TAG_APP").getLong(null);
                Class[] clsArr = new Class[1];
                Class cls2 = Long.TYPE;
                clsArr[0] = cls2;
                c = Trace.class.getMethod("isTagEnabled", clsArr);
                Class[] clsArr2 = new Class[3];
                clsArr2[0] = cls2;
                clsArr2[1] = cls;
                clsArr2[2] = Integer.TYPE;
                d = Trace.class.getMethod("asyncTraceBegin", clsArr2);
                e = Trace.class.getMethod("asyncTraceEnd", new Class[]{cls2, cls, r8});
                f = Trace.class.getMethod("traceCounter", new Class[]{cls2, cls, r8});
            } catch (Throwable e) {
                Log.i(a, "Unable to initialize via reflection.", e);
            }
        }
    }

    private o() {
    }

    public static void a(@j0 String str, int i) {
        int i2 = VERSION.SDK_INT;
        if (i2 >= 29) {
            Trace.beginAsyncSection(str, i);
        } else if (i2 >= 18) {
            try {
                d.invoke(null, new Object[]{Long.valueOf(b), str, Integer.valueOf(i)});
            } catch (Exception unused) {
                Log.v(a, "Unable to invoke asyncTraceBegin() via reflection.");
            }
        }
    }

    public static void b(@j0 String str) {
        if (VERSION.SDK_INT >= 18) {
            Trace.beginSection(str);
        }
    }

    public static void c(@j0 String str, int i) {
        int i2 = VERSION.SDK_INT;
        if (i2 >= 29) {
            Trace.endAsyncSection(str, i);
        } else if (i2 >= 18) {
            try {
                e.invoke(null, new Object[]{Long.valueOf(b), str, Integer.valueOf(i)});
            } catch (Exception unused) {
                Log.v(a, "Unable to invoke endAsyncSection() via reflection.");
            }
        }
    }

    public static void d() {
        if (VERSION.SDK_INT >= 18) {
            Trace.endSection();
        }
    }

    public static boolean e() {
        int i = VERSION.SDK_INT;
        if (i >= 29) {
            return Trace.isEnabled();
        }
        if (i >= 18) {
            try {
                return ((Boolean) c.invoke(null, new Object[]{Long.valueOf(b)})).booleanValue();
            } catch (Exception unused) {
                Log.v(a, "Unable to invoke isTagEnabled() via reflection.");
            }
        }
        return false;
    }

    public static void f(@j0 String str, int i) {
        int i2 = VERSION.SDK_INT;
        if (i2 >= 29) {
            Trace.setCounter(str, (long) i);
        } else if (i2 >= 18) {
            try {
                f.invoke(null, new Object[]{Long.valueOf(b), str, Integer.valueOf(i)});
            } catch (Exception unused) {
                Log.v(a, "Unable to invoke traceCounter() via reflection.");
            }
        }
    }
}
