package b.h.c;

import android.database.CursorWindow;
import android.os.Build.VERSION;
import androidx.annotation.j0;
import androidx.annotation.k0;

public final class a {
    private a() {
    }

    @j0
    public static CursorWindow a(@k0 String str, long j) {
        int i = VERSION.SDK_INT;
        return i >= 28 ? new CursorWindow(str, j) : i >= 15 ? new CursorWindow(str) : new CursorWindow(false);
    }
}
