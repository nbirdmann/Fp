package b.h.i;

import android.net.Uri;
import androidx.annotation.j0;

public final class d {
    private d() {
    }

    @j0
    public static String a(@j0 Uri uri) {
        StringBuilder stringBuilder;
        String scheme = uri.getScheme();
        String schemeSpecificPart = uri.getSchemeSpecificPart();
        if (scheme != null) {
            if (scheme.equalsIgnoreCase("tel") || scheme.equalsIgnoreCase("sip") || scheme.equalsIgnoreCase("sms") || scheme.equalsIgnoreCase("smsto") || scheme.equalsIgnoreCase("mailto") || scheme.equalsIgnoreCase("nfc")) {
                stringBuilder = new StringBuilder(64);
                stringBuilder.append(scheme);
                stringBuilder.append(':');
                if (schemeSpecificPart != null) {
                    for (int i = 0; i < schemeSpecificPart.length(); i++) {
                        char charAt = schemeSpecificPart.charAt(i);
                        if (charAt == '-' || charAt == '@' || charAt == '.') {
                            stringBuilder.append(charAt);
                        } else {
                            stringBuilder.append('x');
                        }
                    }
                }
                return stringBuilder.toString();
            } else if (scheme.equalsIgnoreCase("http") || scheme.equalsIgnoreCase("https") || scheme.equalsIgnoreCase("ftp") || scheme.equalsIgnoreCase("rtsp")) {
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("//");
                String str = "";
                stringBuilder2.append(uri.getHost() != null ? uri.getHost() : str);
                if (uri.getPort() != -1) {
                    StringBuilder stringBuilder3 = new StringBuilder();
                    stringBuilder3.append(":");
                    stringBuilder3.append(uri.getPort());
                    str = stringBuilder3.toString();
                }
                stringBuilder2.append(str);
                stringBuilder2.append("/...");
                schemeSpecificPart = stringBuilder2.toString();
            }
        }
        stringBuilder = new StringBuilder(64);
        if (scheme != null) {
            stringBuilder.append(scheme);
            stringBuilder.append(':');
        }
        if (schemeSpecificPart != null) {
            stringBuilder.append(schemeSpecificPart);
        }
        return stringBuilder.toString();
    }
}
