package b.h.i;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build.VERSION;
import androidx.annotation.j0;
import androidx.annotation.k0;
import androidx.annotation.q0;
import androidx.annotation.r0;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public final class a {
    public static final int a = 1;
    public static final int b = 2;
    public static final int c = 3;

    @r0({androidx.annotation.r0.a.c})
    @Retention(RetentionPolicy.SOURCE)
    public @interface a {
    }

    private a() {
    }

    @k0
    @SuppressLint({"ReferencesDeprecated"})
    @q0("android.permission.ACCESS_NETWORK_STATE")
    public static NetworkInfo a(@j0 ConnectivityManager connectivityManager, @j0 Intent intent) {
        NetworkInfo networkInfo = (NetworkInfo) intent.getParcelableExtra("networkInfo");
        return networkInfo != null ? connectivityManager.getNetworkInfo(networkInfo.getType()) : null;
    }

    public static int b(@j0 ConnectivityManager connectivityManager) {
        return VERSION.SDK_INT >= 24 ? connectivityManager.getRestrictBackgroundStatus() : 3;
    }

    @q0("android.permission.ACCESS_NETWORK_STATE")
    public static boolean c(@j0 ConnectivityManager connectivityManager) {
        if (VERSION.SDK_INT >= 16) {
            return connectivityManager.isActiveNetworkMetered();
        }
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        if (activeNetworkInfo == null) {
            return true;
        }
        int type = activeNetworkInfo.getType();
        return (type == 1 || type == 7 || type == 9) ? false : true;
    }
}
