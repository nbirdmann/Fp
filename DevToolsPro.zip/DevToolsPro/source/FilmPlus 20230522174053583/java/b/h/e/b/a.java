package b.h.e.b;

import android.content.Context;
import android.hardware.fingerprint.FingerprintManager;
import android.hardware.fingerprint.FingerprintManager.AuthenticationCallback;
import android.hardware.fingerprint.FingerprintManager.AuthenticationResult;
import android.hardware.fingerprint.FingerprintManager.CryptoObject;
import android.os.Build.VERSION;
import android.os.CancellationSignal;
import android.os.Handler;
import androidx.annotation.j0;
import androidx.annotation.k0;
import androidx.annotation.o0;
import androidx.annotation.q0;
import java.security.Signature;
import javax.crypto.Cipher;
import javax.crypto.Mac;

@Deprecated
public class a {
    private final Context a;

    class a extends AuthenticationCallback {
        final /* synthetic */ b a;

        a(b bVar) {
            this.a = bVar;
        }

        public void onAuthenticationError(int i, CharSequence charSequence) {
            this.a.a(i, charSequence);
        }

        public void onAuthenticationFailed() {
            this.a.b();
        }

        public void onAuthenticationHelp(int i, CharSequence charSequence) {
            this.a.c(i, charSequence);
        }

        public void onAuthenticationSucceeded(AuthenticationResult authenticationResult) {
            this.a.d(new c(a.f(authenticationResult.getCryptoObject())));
        }
    }

    public static abstract class b {
        public void a(int i, CharSequence charSequence) {
        }

        public void b() {
        }

        public void c(int i, CharSequence charSequence) {
        }

        public void d(c cVar) {
        }
    }

    public static final class c {
        private final d a;

        public c(d dVar) {
            this.a = dVar;
        }

        public d a() {
            return this.a;
        }
    }

    public static class d {
        private final Signature a;
        private final Cipher b;
        private final Mac c;

        public d(@j0 Signature signature) {
            this.a = signature;
            this.b = null;
            this.c = null;
        }

        public d(@j0 Cipher cipher) {
            this.b = cipher;
            this.a = null;
            this.c = null;
        }

        public d(@j0 Mac mac) {
            this.c = mac;
            this.b = null;
            this.a = null;
        }

        @k0
        public Cipher a() {
            return this.b;
        }

        @k0
        public Mac b() {
            return this.c;
        }

        @k0
        public Signature c() {
            return this.a;
        }
    }

    private a(Context context) {
        this.a = context;
    }

    @j0
    public static a b(@j0 Context context) {
        return new a(context);
    }

    @k0
    @o0(23)
    private static FingerprintManager c(@j0 Context context) {
        int i = VERSION.SDK_INT;
        return i == 23 ? (FingerprintManager) context.getSystemService(FingerprintManager.class) : (i <= 23 || !context.getPackageManager().hasSystemFeature("android.hardware.fingerprint")) ? null : (FingerprintManager) context.getSystemService(FingerprintManager.class);
    }

    @o0(23)
    static d f(CryptoObject cryptoObject) {
        d dVar = null;
        if (cryptoObject == null) {
            return null;
        }
        if (cryptoObject.getCipher() != null) {
            return new d(cryptoObject.getCipher());
        }
        if (cryptoObject.getSignature() != null) {
            return new d(cryptoObject.getSignature());
        }
        if (cryptoObject.getMac() != null) {
            dVar = new d(cryptoObject.getMac());
        }
        return dVar;
    }

    @o0(23)
    private static AuthenticationCallback g(b bVar) {
        return new a(bVar);
    }

    @o0(23)
    private static CryptoObject h(d dVar) {
        CryptoObject cryptoObject = null;
        if (dVar == null) {
            return null;
        }
        if (dVar.a() != null) {
            return new CryptoObject(dVar.a());
        }
        if (dVar.c() != null) {
            return new CryptoObject(dVar.c());
        }
        if (dVar.b() != null) {
            cryptoObject = new CryptoObject(dVar.b());
        }
        return cryptoObject;
    }

    @q0("android.permission.USE_FINGERPRINT")
    public void a(@k0 d dVar, int i, @k0 b.h.j.b bVar, @j0 b bVar2, @k0 Handler handler) {
        if (VERSION.SDK_INT >= 23) {
            FingerprintManager c = c(this.a);
            if (c != null) {
                c.authenticate(h(dVar), bVar != null ? (CancellationSignal) bVar.b() : null, i, g(bVar2), handler);
            }
        }
    }

    @q0("android.permission.USE_FINGERPRINT")
    public boolean d() {
        if (VERSION.SDK_INT < 23) {
            return false;
        }
        FingerprintManager c = c(this.a);
        return c != null && c.hasEnrolledFingerprints();
    }

    @q0("android.permission.USE_FINGERPRINT")
    public boolean e() {
        if (VERSION.SDK_INT < 23) {
            return false;
        }
        FingerprintManager c = c(this.a);
        return c != null && c.isHardwareDetected();
    }
}
