package b.h.e.a;

import android.content.Context;
import android.hardware.display.DisplayManager;
import android.os.Build.VERSION;
import android.view.Display;
import android.view.WindowManager;
import androidx.annotation.j0;
import androidx.annotation.k0;
import java.util.WeakHashMap;

public final class a {
    private static final WeakHashMap<Context, a> a = new WeakHashMap();
    public static final String b = "android.hardware.display.category.PRESENTATION";
    private final Context c;

    private a(Context context) {
        this.c = context;
    }

    @j0
    public static a d(@j0 Context context) {
        a aVar;
        WeakHashMap weakHashMap = a;
        synchronized (weakHashMap) {
            aVar = (a) weakHashMap.get(context);
            if (aVar == null) {
                aVar = new a(context);
                weakHashMap.put(context, aVar);
            }
        }
        return aVar;
    }

    @k0
    public Display a(int i) {
        if (VERSION.SDK_INT >= 17) {
            return ((DisplayManager) this.c.getSystemService(com.google.firebase.messaging.j0.f.a.N)).getDisplay(i);
        }
        Display defaultDisplay = ((WindowManager) this.c.getSystemService("window")).getDefaultDisplay();
        return defaultDisplay.getDisplayId() == i ? defaultDisplay : null;
    }

    @j0
    public Display[] b() {
        if (VERSION.SDK_INT >= 17) {
            return ((DisplayManager) this.c.getSystemService(com.google.firebase.messaging.j0.f.a.N)).getDisplays();
        }
        return new Display[]{((WindowManager) this.c.getSystemService("window")).getDefaultDisplay()};
    }

    @j0
    public Display[] c(@k0 String str) {
        if (VERSION.SDK_INT >= 17) {
            return ((DisplayManager) this.c.getSystemService(com.google.firebase.messaging.j0.f.a.N)).getDisplays(str);
        }
        if (str == null) {
            return new Display[0];
        }
        return new Display[]{((WindowManager) this.c.getSystemService("window")).getDefaultDisplay()};
    }
}
