package b.h.g;

import android.location.LocationManager;
import android.os.Build.VERSION;
import androidx.annotation.j0;

public final class a {
    private a() {
    }

    public static boolean a(@j0 LocationManager locationManager) {
        if (VERSION.SDK_INT >= 28) {
            return locationManager.isLocationEnabled();
        }
        boolean z = locationManager.isProviderEnabled("network") || locationManager.isProviderEnabled("gps");
        return z;
    }
}
