package b.h.m;

import android.annotation.SuppressLint;
import android.os.Build.VERSION;
import android.text.Html;
import android.text.Html.ImageGetter;
import android.text.Html.TagHandler;
import android.text.Spanned;
import androidx.annotation.j0;
import androidx.annotation.k0;

@SuppressLint({"InlinedApi"})
public final class b {
    public static final int a = 0;
    public static final int b = 1;
    public static final int c = 1;
    public static final int d = 2;
    public static final int e = 4;
    public static final int f = 8;
    public static final int g = 16;
    public static final int h = 32;
    public static final int i = 256;
    public static final int j = 0;
    public static final int k = 63;

    private b() {
    }

    @j0
    public static Spanned a(@j0 String str, int i) {
        return VERSION.SDK_INT >= 24 ? Html.fromHtml(str, i) : Html.fromHtml(str);
    }

    @j0
    public static Spanned b(@j0 String str, int i, @k0 ImageGetter imageGetter, @k0 TagHandler tagHandler) {
        return VERSION.SDK_INT >= 24 ? Html.fromHtml(str, i, imageGetter, tagHandler) : Html.fromHtml(str, imageGetter, tagHandler);
    }

    @j0
    public static String c(@j0 Spanned spanned, int i) {
        return VERSION.SDK_INT >= 24 ? Html.toHtml(spanned, i) : Html.toHtml(spanned);
    }
}
