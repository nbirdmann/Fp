package b.h.m;

import java.nio.CharBuffer;
import java.util.Locale;

public final class f {
    public static final e a = new e(null, false);
    public static final e b = new e(null, true);
    public static final e c;
    public static final e d;
    public static final e e = new e(a.a, false);
    public static final e f = f.b;
    private static final int g = 0;
    private static final int h = 1;
    private static final int i = 2;

    private interface c {
        int a(CharSequence charSequence, int i, int i2);
    }

    private static class a implements c {
        static final a a = new a(true);
        private final boolean b;

        private a(boolean z) {
            this.b = z;
        }

        public int a(CharSequence charSequence, int i, int i2) {
            i2 += i;
            Object obj = null;
            while (i < i2) {
                int a = f.a(Character.getDirectionality(charSequence.charAt(i)));
                if (a != 0) {
                    if (a != 1) {
                        continue;
                        i++;
                    } else if (!this.b) {
                        return 1;
                    }
                } else if (this.b) {
                    return 0;
                }
                obj = 1;
                i++;
            }
            return obj != null ? this.b : 2;
        }
    }

    private static class b implements c {
        static final b a = new b();

        private b() {
        }

        public int a(CharSequence charSequence, int i, int i2) {
            i2 += i;
            int i3 = 2;
            while (i < i2 && i3 == 2) {
                i3 = f.b(Character.getDirectionality(charSequence.charAt(i)));
                i++;
            }
            return i3;
        }
    }

    private static abstract class d implements e {
        private final c a;

        d(c cVar) {
            this.a = cVar;
        }

        private boolean d(CharSequence charSequence, int i, int i2) {
            int a = this.a.a(charSequence, i, i2);
            return a != 0 ? a != 1 ? c() : false : true;
        }

        public boolean a(char[] cArr, int i, int i2) {
            return b(CharBuffer.wrap(cArr), i, i2);
        }

        public boolean b(CharSequence charSequence, int i, int i2) {
            if (charSequence != null && i >= 0 && i2 >= 0 && charSequence.length() - i2 >= i) {
                return this.a == null ? c() : d(charSequence, i, i2);
            } else {
                throw new IllegalArgumentException();
            }
        }

        protected abstract boolean c();
    }

    private static class e extends d {
        private final boolean b;

        e(c cVar, boolean z) {
            super(cVar);
            this.b = z;
        }

        protected boolean c() {
            return this.b;
        }
    }

    private static class f extends d {
        static final f b = new f();

        f() {
            super(null);
        }

        protected boolean c() {
            return g.b(Locale.getDefault()) == 1;
        }
    }

    static {
        c cVar = b.a;
        c = new e(cVar, false);
        d = new e(cVar, true);
    }

    private f() {
    }

    static int a(int i) {
        return i != 0 ? (i == 1 || i == 2) ? 0 : 2 : 1;
    }

    static int b(int i) {
        if (i != 0) {
            if (!(i == 1 || i == 2)) {
                switch (i) {
                    case 14:
                    case 15:
                        break;
                    case 16:
                    case 17:
                        break;
                    default:
                        return 2;
                }
            }
            return 0;
        }
        return 1;
    }
}
