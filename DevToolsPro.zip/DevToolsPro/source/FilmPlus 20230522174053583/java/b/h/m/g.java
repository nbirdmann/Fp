package b.h.m;

import android.os.Build.VERSION;
import android.text.TextUtils;
import androidx.annotation.j0;
import androidx.annotation.k0;
import f.j3.h0;
import java.util.Locale;

public final class g {
    private static final Locale a;
    private static final String b = "Arab";
    private static final String c = "Hebr";

    static {
        String str = "";
        a = new Locale(str, str);
    }

    private g() {
    }

    private static int a(@j0 Locale locale) {
        byte directionality = Character.getDirectionality(locale.getDisplayName(locale).charAt(0));
        return (directionality == (byte) 1 || directionality == (byte) 2) ? 1 : 0;
    }

    public static int b(@k0 Locale locale) {
        if (VERSION.SDK_INT >= 17) {
            return TextUtils.getLayoutDirectionFromLocale(locale);
        }
        if (!(locale == null || locale.equals(a))) {
            String c = c.c(locale);
            if (c == null) {
                return a(locale);
            }
            if (c.equalsIgnoreCase(b) || c.equalsIgnoreCase(c)) {
                return 1;
            }
        }
        return 0;
    }

    @j0
    public static String c(@j0 String str) {
        if (VERSION.SDK_INT >= 17) {
            return TextUtils.htmlEncode(str);
        }
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < str.length(); i++) {
            char charAt = str.charAt(i);
            if (charAt == h0.a) {
                stringBuilder.append("&quot;");
            } else if (charAt == h0.d) {
                stringBuilder.append("&lt;");
            } else if (charAt == h0.e) {
                stringBuilder.append("&gt;");
            } else if (charAt == h0.c) {
                stringBuilder.append("&amp;");
            } else if (charAt != '\'') {
                stringBuilder.append(charAt);
            } else {
                stringBuilder.append("&#39;");
            }
        }
        return stringBuilder.toString();
    }
}
