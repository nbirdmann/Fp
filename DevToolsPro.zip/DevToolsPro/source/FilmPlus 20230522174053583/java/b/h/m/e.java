package b.h.m;

public interface e {
    boolean a(char[] cArr, int i, int i2);

    boolean b(CharSequence charSequence, int i, int i2);
}
