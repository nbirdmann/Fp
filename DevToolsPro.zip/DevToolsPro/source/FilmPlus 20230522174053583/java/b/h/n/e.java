package b.h.n;

import android.os.Build.VERSION;
import androidx.annotation.k0;
import java.util.Arrays;
import java.util.Objects;

public class e {
    private e() {
    }

    public static boolean a(@k0 Object obj, @k0 Object obj2) {
        if (VERSION.SDK_INT >= 19) {
            return Objects.equals(obj, obj2);
        }
        boolean z = obj == obj2 || (obj != null && obj.equals(obj2));
        return z;
    }

    public static int b(@k0 Object... objArr) {
        return VERSION.SDK_INT >= 19 ? Objects.hash(objArr) : Arrays.hashCode(objArr);
    }

    public static int c(@k0 Object obj) {
        return obj != null ? obj.hashCode() : 0;
    }
}
