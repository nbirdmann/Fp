package b.h.n;

import android.util.Log;
import androidx.annotation.j0;
import androidx.annotation.k0;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class a {
    private final File a;
    private final File b;

    public a(@j0 File file) {
        this.a = file;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(file.getPath());
        stringBuilder.append(".bak");
        this.b = new File(stringBuilder.toString());
    }

    private static boolean h(@j0 FileOutputStream fileOutputStream) {
        try {
            fileOutputStream.getFD().sync();
            return true;
        } catch (IOException unused) {
            return false;
        }
    }

    public void a() {
        this.a.delete();
        this.b.delete();
    }

    public void b(@k0 FileOutputStream fileOutputStream) {
        if (fileOutputStream != null) {
            h(fileOutputStream);
            try {
                fileOutputStream.close();
                this.a.delete();
                this.b.renameTo(this.a);
            } catch (Throwable e) {
                Log.w("AtomicFile", "failWrite: Got exception:", e);
            }
        }
    }

    public void c(@k0 FileOutputStream fileOutputStream) {
        if (fileOutputStream != null) {
            h(fileOutputStream);
            try {
                fileOutputStream.close();
                this.b.delete();
            } catch (Throwable e) {
                Log.w("AtomicFile", "finishWrite: Got exception:", e);
            }
        }
    }

    @j0
    public File d() {
        return this.a;
    }

    @j0
    public FileInputStream e() throws FileNotFoundException {
        if (this.b.exists()) {
            this.a.delete();
            this.b.renameTo(this.a);
        }
        return new FileInputStream(this.a);
    }

    @j0
    public byte[] f() throws IOException {
        FileInputStream e = e();
        try {
            byte[] bArr = new byte[e.available()];
            int i = 0;
            while (true) {
                int read = e.read(bArr, i, bArr.length - i);
                if (read <= 0) {
                    break;
                }
                i += read;
                read = e.available();
                if (read > bArr.length - i) {
                    Object obj = new byte[(read + i)];
                    System.arraycopy(bArr, 0, obj, 0, i);
                    bArr = obj;
                }
            }
            return bArr;
        } finally {
            e.close();
        }
    }

    /* DevToolsApp ERROR: DevToolsAppRE in pass: o00Ooo
        g.d.a.b.DevToolsAppRE: Exception block dominator not found, method:b.h.n.a.g():java.io.FileOutputStream, dom blocks: []
        	at OooOO0O.OooO0O0.OooO0o.OooO0oO.o000O0Oo.o00Ooo.OooO0o(SourceFile:112)
        	at OooO.OooO0O0.OooO0OO.OooO0oo.o00000OO.o0000o(SourceFile:3)
        	at OooOO0O.OooO0O0.OooO0o.OooO0oO.o00000O.accept(SourceFile:1)
        	at OooO0oo.OooO00o.OooO00o.OooO0OO.OooOoOO.Oooo0.OooO00o(SourceFile:2)
        	at OooO.OooO0O0.OooO0OO.OooO0oo.o00000OO.o0000o0o(SourceFile:5)
        	at OooO.OooO0O0.OooO0OO.OooO0oo.o00000OO.o00oO0O(SourceFile:11)
        	at OooOO0O.OooO00o.OooO00o.run(SourceFile:8)
        */
    @androidx.annotation.j0
    public java.io.FileOutputStream g() throws java.io.IOException {
        /*
        r3 = this;
        r0 = r3.a;
        r0 = r0.exists();
        if (r0 == 0) goto L_0x0042;
    L_0x0008:
        r0 = r3.b;
        r0 = r0.exists();
        if (r0 != 0) goto L_0x003d;
    L_0x0010:
        r0 = r3.a;
        r1 = r3.b;
        r0 = r0.renameTo(r1);
        if (r0 != 0) goto L_0x0042;
    L_0x001a:
        r0 = new java.lang.StringBuilder;
        r0.<init>();
        r1 = "Couldn't rename file ";
        r0.append(r1);
        r1 = r3.a;
        r0.append(r1);
        r1 = " to backup file ";
        r0.append(r1);
        r1 = r3.b;
        r0.append(r1);
        r0 = r0.toString();
        r1 = "AtomicFile";
        android.util.Log.w(r1, r0);
        goto L_0x0042;
    L_0x003d:
        r0 = r3.a;
        r0.delete();
    L_0x0042:
        r0 = new java.io.FileOutputStream;	 Catch:{ FileNotFoundException -> 0x004a }
        r1 = r3.a;	 Catch:{ FileNotFoundException -> 0x004a }
        r0.<init>(r1);	 Catch:{ FileNotFoundException -> 0x004a }
        goto L_0x005e;
        r0 = r3.a;
        r0 = r0.getParentFile();
        r0 = r0.mkdirs();
        if (r0 == 0) goto L_0x0078;
    L_0x0057:
        r0 = new java.io.FileOutputStream;	 Catch:{ FileNotFoundException -> 0x005f }
        r1 = r3.a;	 Catch:{ FileNotFoundException -> 0x005f }
        r0.<init>(r1);	 Catch:{ FileNotFoundException -> 0x005f }
    L_0x005e:
        return r0;
    L_0x005f:
        r0 = new java.io.IOException;
        r1 = new java.lang.StringBuilder;
        r1.<init>();
        r2 = "Couldn't create ";
        r1.append(r2);
        r2 = r3.a;
        r1.append(r2);
        r1 = r1.toString();
        r0.<init>(r1);
        throw r0;
    L_0x0078:
        r0 = new java.io.IOException;
        r1 = new java.lang.StringBuilder;
        r1.<init>();
        r2 = "Couldn't create directory ";
        r1.append(r2);
        r2 = r3.a;
        r1.append(r2);
        r1 = r1.toString();
        r0.<init>(r1);
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.n.a.g():java.io.FileOutputStream");
    }
}
