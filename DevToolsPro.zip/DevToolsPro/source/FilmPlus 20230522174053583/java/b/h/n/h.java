package b.h.n;

import androidx.annotation.j0;
import androidx.annotation.k0;

public final class h {

    public interface a<T> {
        @k0
        T a();

        boolean b(@j0 T t);
    }

    public static class b<T> implements a<T> {
        private final Object[] a;
        private int b;

        public b(int i) {
            if (i > 0) {
                this.a = new Object[i];
                return;
            }
            throw new IllegalArgumentException("The max pool size must be > 0");
        }

        private boolean c(@j0 T t) {
            for (int i = 0; i < this.b; i++) {
                if (this.a[i] == t) {
                    return true;
                }
            }
            return false;
        }

        public T a() {
            int i = this.b;
            if (i <= 0) {
                return null;
            }
            int i2 = i - 1;
            Object[] objArr = this.a;
            T t = objArr[i2];
            objArr[i2] = null;
            this.b = i - 1;
            return t;
        }

        public boolean b(@j0 T t) {
            if (c(t)) {
                throw new IllegalStateException("Already in the pool!");
            }
            int i = this.b;
            Object[] objArr = this.a;
            if (i >= objArr.length) {
                return false;
            }
            objArr[i] = t;
            this.b = i + 1;
            return true;
        }
    }

    public static class c<T> extends b<T> {
        private final Object c = new Object();

        public c(int i) {
            super(i);
        }

        public T a() {
            T a;
            synchronized (this.c) {
                a = super.a();
            }
            return a;
        }

        public boolean b(@j0 T t) {
            boolean b;
            synchronized (this.c) {
                b = super.b(t);
            }
            return b;
        }
    }

    private h() {
    }
}
