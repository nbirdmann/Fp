package b.h.n;

public interface k<T> {
    T get();
}
