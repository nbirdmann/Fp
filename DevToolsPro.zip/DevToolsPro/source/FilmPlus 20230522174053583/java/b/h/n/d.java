package b.h.n;

import android.util.Log;
import androidx.annotation.r0;
import androidx.annotation.r0.a;
import java.io.Writer;

@r0({a.c})
@Deprecated
public class d extends Writer {
    private final String a;
    private StringBuilder b = new StringBuilder(128);

    public d(String str) {
        this.a = str;
    }

    private void a() {
        if (this.b.length() > 0) {
            Log.d(this.a, this.b.toString());
            StringBuilder stringBuilder = this.b;
            stringBuilder.delete(0, stringBuilder.length());
        }
    }

    public void close() {
        a();
    }

    public void flush() {
        a();
    }

    public void write(char[] cArr, int i, int i2) {
        for (int i3 = 0; i3 < i2; i3++) {
            char c = cArr[i + i3];
            if (c == 10) {
                a();
            } else {
                this.b.append(c);
            }
        }
    }
}
