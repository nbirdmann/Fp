package b.h.n;

public interface b<T> {
    void d(T t);
}
