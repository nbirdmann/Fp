package b.h.n;

import android.annotation.SuppressLint;

public interface j<T> {
    @SuppressLint({"UnknownNullness"})
    boolean b(T t);
}
