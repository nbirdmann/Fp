package b.h.n;

import androidx.annotation.j0;
import androidx.annotation.k0;

public class f<F, S> {
    @k0
    public final F a;
    @k0
    public final S b;

    public f(@k0 F f, @k0 S s) {
        this.a = f;
        this.b = s;
    }

    @j0
    public static <A, B> f<A, B> a(@k0 A a, @k0 B b) {
        return new f(a, b);
    }

    public boolean equals(Object obj) {
        boolean z = false;
        if (!(obj instanceof f)) {
            return false;
        }
        f fVar = (f) obj;
        if (e.a(fVar.a, this.a) && e.a(fVar.b, this.b)) {
            z = true;
        }
        return z;
    }

    public int hashCode() {
        Object obj = this.a;
        int i = 0;
        int hashCode = obj == null ? 0 : obj.hashCode();
        Object obj2 = this.b;
        if (obj2 != null) {
            i = obj2.hashCode();
        }
        return hashCode ^ i;
    }

    @j0
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Pair{");
        stringBuilder.append(String.valueOf(this.a));
        stringBuilder.append(" ");
        stringBuilder.append(String.valueOf(this.b));
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
}
