package b.h.o;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import androidx.annotation.k0;

public interface d0 {
    @k0
    ColorStateList getSupportBackgroundTintList();

    @k0
    Mode getSupportBackgroundTintMode();

    void setSupportBackgroundTintList(@k0 ColorStateList colorStateList);

    void setSupportBackgroundTintMode(@k0 Mode mode);
}
