package b.h.o;

import android.view.View;

public interface k0 {
    void a(View view);

    void b(View view);

    void c(View view);
}
