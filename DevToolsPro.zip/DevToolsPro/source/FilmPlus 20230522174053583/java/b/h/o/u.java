package b.h.o;

import android.view.View;
import androidx.annotation.j0;

public interface u extends w {
    void onNestedPreScroll(@j0 View view, int i, int i2, @j0 int[] iArr, int i3);

    void onNestedScroll(@j0 View view, int i, int i2, int i3, int i4, int i5);

    void onNestedScrollAccepted(@j0 View view, @j0 View view2, int i, int i2);

    boolean onStartNestedScroll(@j0 View view, @j0 View view2, int i, int i2);

    void onStopNestedScroll(@j0 View view, int i);
}
