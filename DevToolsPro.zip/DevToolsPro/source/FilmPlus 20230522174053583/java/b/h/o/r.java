package b.h.o;

import androidx.annotation.j0;
import androidx.annotation.k0;

public interface r extends q {
    void dispatchNestedScroll(int i, int i2, int i3, int i4, @k0 int[] iArr, int i5, @j0 int[] iArr2);
}
