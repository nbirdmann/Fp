package b.h.o;

import android.view.View;

public interface y {
    o0 a(View view, o0 o0Var);
}
