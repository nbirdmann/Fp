package b.h.o;

import android.view.View;

public class l0 implements k0 {
    public void a(View view) {
    }

    public void b(View view) {
    }

    public void c(View view) {
    }
}
