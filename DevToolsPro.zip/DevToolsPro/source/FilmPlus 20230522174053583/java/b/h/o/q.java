package b.h.o;

import androidx.annotation.k0;

public interface q extends s {
    boolean dispatchNestedPreScroll(int i, int i2, @k0 int[] iArr, @k0 int[] iArr2, int i3);

    boolean dispatchNestedScroll(int i, int i2, int i3, int i4, @k0 int[] iArr, int i5);

    boolean hasNestedScrollingParent(int i);

    boolean startNestedScroll(int i, int i2);

    void stopNestedScroll(int i);
}
