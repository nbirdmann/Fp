package b.h.o;

import android.view.View;
import androidx.annotation.j0;

public interface w {
    int getNestedScrollAxes();

    boolean onNestedFling(@j0 View view, float f, float f2, boolean z);

    boolean onNestedPreFling(@j0 View view, float f, float f2);

    void onNestedPreScroll(@j0 View view, int i, int i2, @j0 int[] iArr);

    void onNestedScroll(@j0 View view, int i, int i2, int i3, int i4);

    void onNestedScrollAccepted(@j0 View view, @j0 View view2, int i);

    boolean onStartNestedScroll(@j0 View view, @j0 View view2, int i);

    void onStopNestedScroll(@j0 View view);
}
