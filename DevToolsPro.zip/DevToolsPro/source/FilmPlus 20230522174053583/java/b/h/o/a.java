package b.h.o;

import android.os.Build.VERSION;
import android.os.Bundle;
import android.text.style.ClickableSpan;
import android.util.SparseArray;
import android.view.View;
import android.view.View.AccessibilityDelegate;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import androidx.annotation.o0;
import androidx.annotation.r0;
import b.h.o.p0.d;
import b.h.o.p0.e;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.List;

public class a {
    private static final AccessibilityDelegate DEFAULT_DELEGATE = new AccessibilityDelegate();
    private final AccessibilityDelegate mBridge;
    private final AccessibilityDelegate mOriginalDelegate;

    static final class a extends AccessibilityDelegate {
        final a a;

        a(a aVar) {
            this.a = aVar;
        }

        public boolean dispatchPopulateAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            return this.a.dispatchPopulateAccessibilityEvent(view, accessibilityEvent);
        }

        @o0(16)
        public AccessibilityNodeProvider getAccessibilityNodeProvider(View view) {
            e accessibilityNodeProvider = this.a.getAccessibilityNodeProvider(view);
            return accessibilityNodeProvider != null ? (AccessibilityNodeProvider) accessibilityNodeProvider.d() : null;
        }

        public void onInitializeAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            this.a.onInitializeAccessibilityEvent(view, accessibilityEvent);
        }

        public void onInitializeAccessibilityNodeInfo(View view, AccessibilityNodeInfo accessibilityNodeInfo) {
            d T1 = d.T1(accessibilityNodeInfo);
            T1.B1(f0.U0(view));
            T1.h1(f0.I0(view));
            T1.v1(f0.H(view));
            this.a.onInitializeAccessibilityNodeInfo(view, T1);
            T1.f(accessibilityNodeInfo.getText(), view);
            List a = a.a(view);
            for (int i = 0; i < a.size(); i++) {
                T1.b((b.h.o.p0.d.a) a.get(i));
            }
        }

        public void onPopulateAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            this.a.onPopulateAccessibilityEvent(view, accessibilityEvent);
        }

        public boolean onRequestSendAccessibilityEvent(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
            return this.a.onRequestSendAccessibilityEvent(viewGroup, view, accessibilityEvent);
        }

        public boolean performAccessibilityAction(View view, int i, Bundle bundle) {
            return this.a.performAccessibilityAction(view, i, bundle);
        }

        public void sendAccessibilityEvent(View view, int i) {
            this.a.sendAccessibilityEvent(view, i);
        }

        public void sendAccessibilityEventUnchecked(View view, AccessibilityEvent accessibilityEvent) {
            this.a.sendAccessibilityEventUnchecked(view, accessibilityEvent);
        }
    }

    public a() {
        this(DEFAULT_DELEGATE);
    }

    @r0({androidx.annotation.r0.a.c})
    public a(AccessibilityDelegate accessibilityDelegate) {
        this.mOriginalDelegate = accessibilityDelegate;
        this.mBridge = new a(this);
    }

    static List<b.h.o.p0.d.a> a(View view) {
        List<b.h.o.p0.d.a> list = (List) view.getTag(b.h.a.e.d0);
        return list == null ? Collections.emptyList() : list;
    }

    private boolean b(ClickableSpan clickableSpan, View view) {
        if (clickableSpan != null) {
            ClickableSpan[] w = d.w(view.createAccessibilityNodeInfo().getText());
            int i = 0;
            while (w != null && i < w.length) {
                if (clickableSpan.equals(w[i])) {
                    return true;
                }
                i++;
            }
        }
        return false;
    }

    private boolean c(int i, View view) {
        SparseArray sparseArray = (SparseArray) view.getTag(b.h.a.e.e0);
        if (sparseArray != null) {
            WeakReference weakReference = (WeakReference) sparseArray.get(i);
            if (weakReference != null) {
                ClickableSpan clickableSpan = (ClickableSpan) weakReference.get();
                if (b(clickableSpan, view)) {
                    clickableSpan.onClick(view);
                    return true;
                }
            }
        }
        return false;
    }

    public boolean dispatchPopulateAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
        return this.mOriginalDelegate.dispatchPopulateAccessibilityEvent(view, accessibilityEvent);
    }

    public e getAccessibilityNodeProvider(View view) {
        if (VERSION.SDK_INT >= 16) {
            AccessibilityNodeProvider accessibilityNodeProvider = this.mOriginalDelegate.getAccessibilityNodeProvider(view);
            if (accessibilityNodeProvider != null) {
                return new e(accessibilityNodeProvider);
            }
        }
        return null;
    }

    AccessibilityDelegate getBridge() {
        return this.mBridge;
    }

    public void onInitializeAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
        this.mOriginalDelegate.onInitializeAccessibilityEvent(view, accessibilityEvent);
    }

    public void onInitializeAccessibilityNodeInfo(View view, d dVar) {
        this.mOriginalDelegate.onInitializeAccessibilityNodeInfo(view, dVar.S1());
    }

    public void onPopulateAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
        this.mOriginalDelegate.onPopulateAccessibilityEvent(view, accessibilityEvent);
    }

    public boolean onRequestSendAccessibilityEvent(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
        return this.mOriginalDelegate.onRequestSendAccessibilityEvent(viewGroup, view, accessibilityEvent);
    }

    public boolean performAccessibilityAction(View view, int i, Bundle bundle) {
        List a = a(view);
        boolean z = false;
        for (int i2 = 0; i2 < a.size(); i2++) {
            b.h.o.p0.d.a aVar = (b.h.o.p0.d.a) a.get(i2);
            if (aVar.b() == i) {
                z = aVar.d(view, bundle);
                break;
            }
        }
        if (!z && VERSION.SDK_INT >= 16) {
            z = this.mOriginalDelegate.performAccessibilityAction(view, i, bundle);
        }
        return (z || i != b.h.a.e.a) ? z : c(bundle.getInt(b.h.o.p0.a.a, -1), view);
    }

    public void sendAccessibilityEvent(View view, int i) {
        this.mOriginalDelegate.sendAccessibilityEvent(view, i);
    }

    public void sendAccessibilityEventUnchecked(View view, AccessibilityEvent accessibilityEvent) {
        this.mOriginalDelegate.sendAccessibilityEventUnchecked(view, accessibilityEvent);
    }
}
