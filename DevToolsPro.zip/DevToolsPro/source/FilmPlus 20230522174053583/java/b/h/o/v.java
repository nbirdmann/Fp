package b.h.o;

import android.view.View;
import androidx.annotation.j0;

public interface v extends u {
    void onNestedScroll(@j0 View view, int i, int i2, int i3, int i4, int i5, @j0 int[] iArr);
}
