package b.h.o;

import android.view.View;

public interface m0 {
    void a(View view);
}
