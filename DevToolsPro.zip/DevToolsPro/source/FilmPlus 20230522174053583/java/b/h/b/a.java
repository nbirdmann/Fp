package b.h.b;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.pm.PackageManager;
import android.os.Build.VERSION;
import androidx.annotation.j0;
import androidx.annotation.k0;

public final class a {
    public static final int a = 1;
    public static final int b = 2;
    public static final int c = 4;
    public static final int d = 8;
    public static final int e = 32;
    public static final int f = -1;
    public static final int g = 2;
    public static final int h = 4;
    public static final int i = 8;
    public static final int j = 16;
    public static final int k = 32;

    private a() {
    }

    @j0
    public static String a(int i) {
        return i != 1 ? i != 2 ? i != 4 ? i != 8 ? "UNKNOWN" : "CAPABILITY_CAN_FILTER_KEY_EVENTS" : "CAPABILITY_CAN_REQUEST_ENHANCED_WEB_ACCESSIBILITY" : "CAPABILITY_CAN_REQUEST_TOUCH_EXPLORATION" : "CAPABILITY_CAN_RETRIEVE_WINDOW_CONTENT";
    }

    @j0
    public static String b(int i) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("[");
        while (i > 0) {
            int numberOfTrailingZeros = 1 << Integer.numberOfTrailingZeros(i);
            i &= numberOfTrailingZeros ^ -1;
            if (stringBuilder.length() > 1) {
                stringBuilder.append(", ");
            }
            if (numberOfTrailingZeros == 1) {
                stringBuilder.append("FEEDBACK_SPOKEN");
            } else if (numberOfTrailingZeros == 2) {
                stringBuilder.append("FEEDBACK_HAPTIC");
            } else if (numberOfTrailingZeros == 4) {
                stringBuilder.append("FEEDBACK_AUDIBLE");
            } else if (numberOfTrailingZeros == 8) {
                stringBuilder.append("FEEDBACK_VISUAL");
            } else if (numberOfTrailingZeros == 16) {
                stringBuilder.append("FEEDBACK_GENERIC");
            }
        }
        stringBuilder.append("]");
        return stringBuilder.toString();
    }

    @k0
    public static String c(int i) {
        return i != 1 ? i != 2 ? i != 4 ? i != 8 ? i != 16 ? i != 32 ? null : "FLAG_REQUEST_FILTER_KEY_EVENTS" : "FLAG_REPORT_VIEW_IDS" : "FLAG_REQUEST_ENHANCED_WEB_ACCESSIBILITY" : "FLAG_REQUEST_TOUCH_EXPLORATION_MODE" : "FLAG_INCLUDE_NOT_IMPORTANT_VIEWS" : "DEFAULT";
    }

    public static int d(@j0 AccessibilityServiceInfo accessibilityServiceInfo) {
        return VERSION.SDK_INT >= 18 ? accessibilityServiceInfo.getCapabilities() : accessibilityServiceInfo.getCanRetrieveWindowContent() ? 1 : 0;
    }

    @k0
    public static String e(@j0 AccessibilityServiceInfo accessibilityServiceInfo, @j0 PackageManager packageManager) {
        return VERSION.SDK_INT >= 16 ? accessibilityServiceInfo.loadDescription(packageManager) : accessibilityServiceInfo.getDescription();
    }
}
