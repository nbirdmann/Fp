package b.h.f.b;

import android.view.Menu;
import androidx.annotation.r0;

@r0({androidx.annotation.r0.a.c})
public interface a extends Menu {
    public static final int a = 65535;
    public static final int b = 0;
    public static final int c = -65536;
    public static final int d = 16;
    public static final int e = 69647;
    public static final int f = 4;

    void setGroupDividerEnabled(boolean z);
}
