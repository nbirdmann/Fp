package b.j.b;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.ClassLoaderCreator;
import android.os.Parcelable.Creator;
import androidx.annotation.j0;
import androidx.annotation.k0;

public abstract class a implements Parcelable {
    public static final Creator<a> CREATOR = new b();
    public static final a a = new a();
    private final Parcelable b;

    static class a extends a {
        a() {
            super();
        }
    }

    static class b implements ClassLoaderCreator<a> {
        b() {
        }

        /* renamed from: a */
        public a createFromParcel(Parcel parcel) {
            return createFromParcel(parcel, null);
        }

        /* renamed from: b */
        public a createFromParcel(Parcel parcel, ClassLoader classLoader) {
            if (parcel.readParcelable(classLoader) == null) {
                return a.a;
            }
            throw new IllegalStateException("superState must be null");
        }

        /* renamed from: c */
        public a[] newArray(int i) {
            return new a[i];
        }
    }

    private a() {
        this.b = null;
    }

    protected a(@j0 Parcel parcel) {
        this(parcel, null);
    }

    protected a(@j0 Parcel parcel, @k0 ClassLoader classLoader) {
        Parcelable readParcelable = parcel.readParcelable(classLoader);
        if (readParcelable == null) {
            readParcelable = a;
        }
        this.b = readParcelable;
    }

    protected a(@j0 Parcelable parcelable) {
        if (parcelable != null) {
            if (parcelable == a) {
                parcelable = null;
            }
            this.b = parcelable;
            return;
        }
        throw new IllegalArgumentException("superState must not be null");
    }

    @k0
    public final Parcelable a() {
        return this.b;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeParcelable(this.b, i);
    }
}
