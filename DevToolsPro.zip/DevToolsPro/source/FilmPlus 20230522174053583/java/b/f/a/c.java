package b.f.a;

public class c {
    a<b> a = new b(256);
    a<h> b = new b(256);
    h[] c = new h[32];
}
