package b.f.a.i;

import java.util.HashSet;
import java.util.Iterator;

public class q {
    public static final int a = 0;
    public static final int b = 1;
    public static final int c = 2;
    HashSet<q> d = new HashSet(2);
    int e = 0;

    public void a(q qVar) {
        this.d.add(qVar);
    }

    public void b() {
        this.e = 1;
        Iterator it = this.d.iterator();
        while (it.hasNext()) {
            ((q) it.next()).h();
        }
    }

    public void c() {
        this.e = 0;
        Iterator it = this.d.iterator();
        while (it.hasNext()) {
            ((q) it.next()).c();
        }
    }

    public void d() {
        if (this instanceof o) {
            this.e = 0;
        }
        Iterator it = this.d.iterator();
        while (it.hasNext()) {
            ((q) it.next()).d();
        }
    }

    public boolean e() {
        return this.e == 1;
    }

    public void f(p pVar) {
    }

    public void g() {
        this.e = 0;
        this.d.clear();
    }

    public void h() {
    }
}
