package b.f.a.i;

import b.f.a.h;
import java.util.ArrayList;
import java.util.HashSet;

public class e {
    private static final boolean a = false;
    public static final int b = 0;
    public static final int c = 1;
    public static final int d = 2;
    private static final int e = -1;
    private o f = new o(this);
    final h g;
    final d h;
    e i;
    public int j = 0;
    int k = -1;
    private c l = c.NONE;
    private b m = b.RELAXED;
    private int n = 0;
    h o;

    static /* synthetic */ class a {
        static final /* synthetic */ int[] a;

        /* DevToolsApp WARNING: Failed to process nested try/catch */
        /* DevToolsApp WARNING: Missing block: B:18:?, code:
            a[b.f.a.i.e.d.a.ordinal()] = 9;
     */
        static {
            /*
            r0 = b.f.a.i.e.d.values();
            r0 = r0.length;
            r0 = new int[r0];
            a = r0;
            r1 = b.f.a.i.e.d.CENTER;	 Catch:{ NoSuchFieldError -> 0x0012 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0012 }
            r2 = 1;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0012 }
        L_0x0012:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x001d }
            r1 = b.f.a.i.e.d.LEFT;	 Catch:{ NoSuchFieldError -> 0x001d }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x001d }
            r2 = 2;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x001d }
        L_0x001d:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x0028 }
            r1 = b.f.a.i.e.d.RIGHT;	 Catch:{ NoSuchFieldError -> 0x0028 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0028 }
            r2 = 3;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0028 }
        L_0x0028:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x0033 }
            r1 = b.f.a.i.e.d.TOP;	 Catch:{ NoSuchFieldError -> 0x0033 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0033 }
            r2 = 4;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0033 }
        L_0x0033:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x003e }
            r1 = b.f.a.i.e.d.BOTTOM;	 Catch:{ NoSuchFieldError -> 0x003e }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x003e }
            r2 = 5;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x003e }
        L_0x003e:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x0049 }
            r1 = b.f.a.i.e.d.BASELINE;	 Catch:{ NoSuchFieldError -> 0x0049 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0049 }
            r2 = 6;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0049 }
        L_0x0049:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x0054 }
            r1 = b.f.a.i.e.d.CENTER_X;	 Catch:{ NoSuchFieldError -> 0x0054 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0054 }
            r2 = 7;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0054 }
        L_0x0054:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x0060 }
            r1 = b.f.a.i.e.d.CENTER_Y;	 Catch:{ NoSuchFieldError -> 0x0060 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0060 }
            r2 = 8;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0060 }
        L_0x0060:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x006c }
            r1 = b.f.a.i.e.d.NONE;	 Catch:{ NoSuchFieldError -> 0x006c }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x006c }
            r2 = 9;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x006c }
        L_0x006c:
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: b.f.a.i.e.a.<clinit>():void");
        }
    }

    public enum b {
        RELAXED,
        STRICT
    }

    public enum c {
        NONE,
        STRONG,
        WEAK
    }

    public enum d {
        NONE,
        LEFT,
        TOP,
        RIGHT,
        BOTTOM,
        BASELINE,
        CENTER,
        CENTER_X,
        CENTER_Y
    }

    public e(h hVar, d dVar) {
        this.g = hVar;
        this.h = dVar;
    }

    private boolean t(h hVar, HashSet<h> hashSet) {
        if (hashSet.contains(hVar)) {
            return false;
        }
        hashSet.add(hVar);
        if (hVar == i()) {
            return true;
        }
        ArrayList t = hVar.t();
        int size = t.size();
        for (int i = 0; i < size; i++) {
            e eVar = (e) t.get(i);
            if (eVar.v(this) && eVar.q() && t(eVar.o().i(), hashSet)) {
                return true;
            }
        }
        return false;
    }

    public void A(b.f.a.c cVar) {
        h hVar = this.o;
        if (hVar == null) {
            this.o = new h(b.f.a.h.b.UNRESTRICTED, null);
        } else {
            hVar.g();
        }
    }

    public void B(int i) {
        this.n = i;
    }

    public void C(b bVar) {
        this.m = bVar;
    }

    public void D(int i) {
        if (q()) {
            this.k = i;
        }
    }

    public void E(int i) {
        if (q()) {
            this.j = i;
        }
    }

    public void F(c cVar) {
        if (q()) {
            this.l = cVar;
        }
    }

    public boolean a(e eVar, int i) {
        return c(eVar, i, -1, c.STRONG, 0, false);
    }

    public boolean b(e eVar, int i, int i2) {
        return c(eVar, i, -1, c.STRONG, i2, false);
    }

    public boolean c(e eVar, int i, int i2, c cVar, int i3, boolean z) {
        if (eVar == null) {
            this.i = null;
            this.j = 0;
            this.k = -1;
            this.l = c.NONE;
            this.n = 2;
            return true;
        } else if (!z && !x(eVar)) {
            return false;
        } else {
            this.i = eVar;
            if (i > 0) {
                this.j = i;
            } else {
                this.j = 0;
            }
            this.k = i2;
            this.l = cVar;
            this.n = i3;
            return true;
        }
    }

    public boolean d(e eVar, int i, c cVar, int i2) {
        return c(eVar, i, -1, cVar, i2, false);
    }

    public int e() {
        return this.n;
    }

    public b f() {
        return this.m;
    }

    public int g() {
        if (this.g.o0() == 8) {
            return 0;
        }
        if (this.k > -1) {
            e eVar = this.i;
            if (eVar != null && eVar.g.o0() == 8) {
                return this.k;
            }
        }
        return this.j;
    }

    public final e h() {
        switch (a.a[this.h.ordinal()]) {
            case 1:
            case 6:
            case 7:
            case 8:
            case 9:
                return null;
            case 2:
                return this.g.W;
            case 3:
                return this.g.U;
            case 4:
                return this.g.X;
            case 5:
                return this.g.V;
            default:
                throw new AssertionError(this.h.name());
        }
    }

    public h i() {
        return this.g;
    }

    public int j() {
        switch (a.a[this.h.ordinal()]) {
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
                return 2;
            case 6:
                return 1;
            case 7:
            case 8:
            case 9:
                return 0;
            default:
                throw new AssertionError(this.h.name());
        }
    }

    public o k() {
        return this.f;
    }

    public int l() {
        switch (a.a[this.h.ordinal()]) {
            case 1:
                return 3;
            case 2:
            case 3:
                return 1;
            case 4:
            case 5:
                return 0;
            case 6:
                return 2;
            case 7:
                return 0;
            case 8:
                return 1;
            case 9:
                return 0;
            default:
                throw new AssertionError(this.h.name());
        }
    }

    public h m() {
        return this.o;
    }

    public c n() {
        return this.l;
    }

    public e o() {
        return this.i;
    }

    public d p() {
        return this.h;
    }

    public boolean q() {
        return this.i != null;
    }

    public boolean r(h hVar) {
        if (t(hVar, new HashSet())) {
            return false;
        }
        h a0 = i().a0();
        return a0 == hVar || hVar.a0() == a0;
    }

    public boolean s(h hVar, e eVar) {
        return r(hVar);
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.g.z());
        stringBuilder.append(":");
        stringBuilder.append(this.h.toString());
        return stringBuilder.toString();
    }

    public boolean u() {
        switch (a.a[this.h.ordinal()]) {
            case 1:
            case 6:
            case 7:
            case 8:
            case 9:
                return false;
            case 2:
            case 3:
            case 4:
            case 5:
                return true;
            default:
                throw new AssertionError(this.h.name());
        }
    }

    public boolean v(e eVar) {
        Enum p = eVar.p();
        Enum enumR = this.h;
        boolean z = true;
        if (p == enumR) {
            return true;
        }
        switch (a.a[enumR.ordinal()]) {
            case 1:
                if (p == d.BASELINE) {
                    z = false;
                }
                return z;
            case 2:
            case 3:
            case 7:
                if (!(p == d.LEFT || p == d.RIGHT || p == d.CENTER_X)) {
                    z = false;
                }
                return z;
            case 4:
            case 5:
            case 6:
            case 8:
                if (!(p == d.TOP || p == d.BOTTOM || p == d.CENTER_Y || p == d.BASELINE)) {
                    z = false;
                }
                return z;
            case 9:
                return false;
            default:
                throw new AssertionError(this.h.name());
        }
    }

    public boolean w(e eVar) {
        d dVar = this.h;
        if (dVar == d.CENTER) {
            return false;
        }
        if (dVar == eVar.p()) {
            return true;
        }
        int[] iArr = a.a;
        int i;
        switch (iArr[this.h.ordinal()]) {
            case 1:
            case 6:
            case 9:
                return false;
            case 2:
                i = iArr[eVar.p().ordinal()];
                return i == 3 || i == 7;
            case 3:
                i = iArr[eVar.p().ordinal()];
                return i == 2 || i == 7;
            case 4:
                i = iArr[eVar.p().ordinal()];
                return i == 5 || i == 8;
            case 5:
                i = iArr[eVar.p().ordinal()];
                return i == 4 || i == 8;
            case 7:
                i = iArr[eVar.p().ordinal()];
                return i == 2 || i == 3;
            case 8:
                i = iArr[eVar.p().ordinal()];
                return i == 4 || i == 5;
            default:
                throw new AssertionError(this.h.name());
        }
    }

    public boolean x(e eVar) {
        boolean z = false;
        if (eVar == null) {
            return false;
        }
        Enum p = eVar.p();
        Enum enumR = this.h;
        if (p == enumR) {
            return enumR != d.BASELINE || (eVar.i().v0() && i().v0());
        } else {
            boolean z2;
            switch (a.a[enumR.ordinal()]) {
                case 1:
                    if (!(p == d.BASELINE || p == d.CENTER_X || p == d.CENTER_Y)) {
                        z = true;
                    }
                    return z;
                case 2:
                case 3:
                    z2 = p == d.LEFT || p == d.RIGHT;
                    if (eVar.i() instanceof k) {
                        if (z2 || p == d.CENTER_X) {
                            z = true;
                        }
                        z2 = z;
                    }
                    return z2;
                case 4:
                case 5:
                    z2 = p == d.TOP || p == d.BOTTOM;
                    if (eVar.i() instanceof k) {
                        if (z2 || p == d.CENTER_Y) {
                            z = true;
                        }
                        z2 = z;
                    }
                    return z2;
                case 6:
                case 7:
                case 8:
                case 9:
                    return false;
                default:
                    throw new AssertionError(this.h.name());
            }
        }
    }

    public boolean y() {
        switch (a.a[this.h.ordinal()]) {
            case 1:
            case 2:
            case 3:
            case 7:
                return false;
            case 4:
            case 5:
            case 6:
            case 8:
            case 9:
                return true;
            default:
                throw new AssertionError(this.h.name());
        }
    }

    public void z() {
        this.i = null;
        this.j = 0;
        this.k = -1;
        this.l = c.STRONG;
        this.n = 0;
        this.m = b.RELAXED;
        this.f.g();
    }
}
