package b.f.a.i;

import b.f.a.i.h.c;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class a {
    private a() {
    }

    public static void a(i iVar) {
        if ((iVar.f2() & 32) != 32) {
            j(iVar);
            return;
        }
        iVar.A1 = true;
        iVar.u1 = false;
        iVar.v1 = false;
        iVar.w1 = false;
        List<h> list = iVar.c1;
        List<j> list2 = iVar.t1;
        c N = iVar.N();
        c cVar = c.WRAP_CONTENT;
        Object obj = N == cVar ? 1 : null;
        Object obj2 = iVar.n0() == cVar ? 1 : null;
        boolean z = (obj == null && obj2 == null) ? false : true;
        list2.clear();
        for (h hVar : list) {
            hVar.R = null;
            hVar.S0 = false;
            hVar.N0();
        }
        for (h hVar2 : list) {
            if (hVar2.R == null && !b(hVar2, list2, z)) {
                j(iVar);
                iVar.A1 = false;
                return;
            }
        }
        int i = 0;
        int i2 = 0;
        for (j jVar : list2) {
            i = Math.max(i, c(jVar, 0));
            i2 = Math.max(i2, c(jVar, 1));
        }
        if (obj != null) {
            iVar.l1(c.FIXED);
            iVar.F1(i);
            iVar.u1 = true;
            iVar.v1 = true;
            iVar.x1 = i;
        }
        if (obj2 != null) {
            iVar.B1(c.FIXED);
            iVar.g1(i2);
            iVar.u1 = true;
            iVar.w1 = true;
            iVar.y1 = i2;
        }
        i(list2, 0, iVar.p0());
        i(list2, 1, iVar.J());
    }

    private static boolean b(h hVar, List<j> list, boolean z) {
        j jVar = new j(new ArrayList(), true);
        list.add(jVar);
        return k(hVar, jVar, list, z);
    }

    private static int c(j jVar, int i) {
        int i2 = i * 2;
        List b = jVar.b(i);
        int size = b.size();
        int i3 = 0;
        for (int i4 = 0; i4 < size; i4++) {
            h hVar = (h) b.get(i4);
            e[] eVarArr = hVar.c0;
            int i5 = i2 + 1;
            boolean z = eVarArr[i5].i == null || !(eVarArr[i2].i == null || eVarArr[i5].i == null);
            i3 = Math.max(i3, d(hVar, i, z, 0));
        }
        jVar.e[i] = i3;
        return i3;
    }

    private static int d(h hVar, int i, boolean z, int i2) {
        h hVar2 = hVar;
        int i3 = i;
        boolean z2 = z;
        int i4 = 0;
        if (!hVar2.Q0) {
            return 0;
        }
        int u;
        int J;
        int i5;
        int i6;
        int i7;
        int i8;
        Iterator it;
        int i9;
        Object obj = (hVar2.Y.i == null || i3 != 1) ? null : 1;
        if (z2) {
            u = hVar.u();
            J = hVar.J() - hVar.u();
            i5 = i3 * 2;
            i6 = i5 + 1;
        } else {
            u = hVar.J() - hVar.u();
            J = hVar.u();
            i6 = i3 * 2;
            i5 = i6 + 1;
        }
        e[] eVarArr = hVar2.c0;
        if (eVarArr[i6].i == null || eVarArr[i5].i != null) {
            i7 = 1;
        } else {
            i7 = -1;
            i8 = i6;
            i6 = i5;
            i5 = i8;
        }
        int g = (eVarArr[i5].g() * i7) + e(hVar, i);
        int i10 = (obj != null ? i2 - u : i2) + g;
        int p0 = (i3 == 0 ? hVar.p0() : hVar.J()) * i7;
        Iterator it2 = hVar2.c0[i5].k().d.iterator();
        while (it2.hasNext()) {
            i4 = Math.max(i4, d(((o) ((q) it2.next())).l.g, i3, z2, i10));
        }
        Iterator it3 = hVar2.c0[i6].k().d.iterator();
        int i11 = 0;
        while (it3.hasNext()) {
            it = it3;
            i11 = Math.max(i11, d(((o) ((q) it3.next())).l.g, i3, z2, p0 + i10));
            it3 = it;
        }
        if (obj != null) {
            i4 -= u;
            i11 += J;
        } else {
            i11 += (i3 == 0 ? hVar.p0() : hVar.J()) * i7;
        }
        int i12 = 1;
        int i13;
        if (i3 == 1) {
            it3 = hVar2.Y.k().d.iterator();
            int i14 = 0;
            while (it3.hasNext()) {
                it = it3;
                o oVar = (o) ((q) it3.next());
                if (i7 == i12) {
                    i14 = Math.max(i14, d(oVar.l.g, i3, z2, u + i10));
                    i13 = i6;
                } else {
                    i13 = i6;
                    i14 = Math.max(i14, d(oVar.l.g, i3, z2, (J * i7) + i10));
                }
                it3 = it;
                i6 = i13;
                i12 = 1;
            }
            i13 = i6;
            i12 = i14;
            i9 = (hVar2.Y.k().d.size() <= 0 || obj != null) ? i12 : i7 == 1 ? i12 + u : i12 - J;
        } else {
            i13 = i6;
            i9 = 0;
        }
        g += Math.max(i4, Math.max(i11, i9));
        p0 += i10;
        if (i7 == -1) {
            i8 = p0;
            p0 = i10;
            i10 = i8;
        }
        if (z2) {
            m.e(hVar2, i3, i10);
            hVar2.d1(i10, p0, i3);
        } else {
            hVar2.R.a(hVar2, i3);
            hVar2.w1(i10, i3);
        }
        if (hVar.A(i) == c.MATCH_CONSTRAINT && hVar2.i0 != 0.0f) {
            hVar2.R.a(hVar2, i3);
        }
        e[] eVarArr2 = hVar2.c0;
        if (!(eVarArr2[i5].i == null || eVarArr2[r17].i == null)) {
            h a0 = hVar.a0();
            e[] eVarArr3 = hVar2.c0;
            if (eVarArr3[i5].i.g == a0 && eVarArr3[r17].i.g == a0) {
                hVar2.R.a(hVar2, i3);
            }
        }
        return g;
    }

    private static int e(h hVar, int i) {
        int i2 = i * 2;
        e[] eVarArr = hVar.c0;
        e eVar = eVarArr[i2];
        e eVar2 = eVarArr[i2 + 1];
        e eVar3 = eVar.i;
        if (eVar3 != null) {
            h hVar2 = eVar3.g;
            h hVar3 = hVar.f0;
            if (hVar2 == hVar3) {
                eVar3 = eVar2.i;
                if (eVar3 != null && eVar3.g == hVar3) {
                    return (int) (((float) (((hVar3.T(i) - eVar.g()) - eVar2.g()) - hVar.T(i))) * (i == 0 ? hVar.z0 : hVar.A0));
                }
            }
        }
        return 0;
    }

    private static void f(i iVar, h hVar, j jVar) {
        jVar.d = false;
        iVar.A1 = false;
        hVar.Q0 = false;
    }

    private static int g(h hVar) {
        c N = hVar.N();
        c cVar = c.MATCH_CONSTRAINT;
        int J;
        if (N == cVar) {
            J = (int) (hVar.j0 == 0 ? ((float) hVar.J()) * hVar.i0 : ((float) hVar.J()) / hVar.i0);
            hVar.F1(J);
            return J;
        } else if (hVar.n0() != cVar) {
            return -1;
        } else {
            J = (int) (hVar.j0 == 1 ? ((float) hVar.p0()) * hVar.i0 : ((float) hVar.p0()) / hVar.i0);
            hVar.g1(J);
            return J;
        }
    }

    private static void h(e eVar) {
        q k = eVar.k();
        e eVar2 = eVar.i;
        if (eVar2 != null && eVar2.i != eVar) {
            eVar2.k().a(k);
        }
    }

    public static void i(List<j> list, int i, int i2) {
        int size = list.size();
        for (int i3 = 0; i3 < size; i3++) {
            for (h hVar : ((j) list.get(i3)).c(i)) {
                if (hVar.Q0) {
                    l(hVar, i, i2);
                }
            }
        }
    }

    private static void j(i iVar) {
        iVar.t1.clear();
        iVar.t1.add(0, new j(iVar.c1));
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:124:0x017a  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:136:0x019c  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:108:0x0151  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:124:0x017a  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:136:0x019c  */
    /* DevToolsApp WARNING: Missing block: B:85:0x0112, code:
            if (r4.g == r5) goto L_0x0114;
     */
    /* DevToolsApp WARNING: Missing block: B:112:0x015b, code:
            if (r4.g == r5) goto L_0x015d;
     */
    private static boolean k(b.f.a.i.h r8, b.f.a.i.j r9, java.util.List<b.f.a.i.j> r10, boolean r11) {
        /*
        r0 = 1;
        if (r8 != 0) goto L_0x0004;
    L_0x0003:
        return r0;
    L_0x0004:
        r1 = 0;
        r8.R0 = r1;
        r2 = r8.a0();
        r2 = (b.f.a.i.i) r2;
        r3 = r8.R;
        if (r3 != 0) goto L_0x01ca;
    L_0x0011:
        r8.Q0 = r0;
        r3 = r9.a;
        r3.add(r8);
        r8.R = r9;
        r3 = r8.U;
        r3 = r3.i;
        if (r3 != 0) goto L_0x0044;
    L_0x0020:
        r3 = r8.W;
        r3 = r3.i;
        if (r3 != 0) goto L_0x0044;
    L_0x0026:
        r3 = r8.V;
        r3 = r3.i;
        if (r3 != 0) goto L_0x0044;
    L_0x002c:
        r3 = r8.X;
        r3 = r3.i;
        if (r3 != 0) goto L_0x0044;
    L_0x0032:
        r3 = r8.Y;
        r3 = r3.i;
        if (r3 != 0) goto L_0x0044;
    L_0x0038:
        r3 = r8.b0;
        r3 = r3.i;
        if (r3 != 0) goto L_0x0044;
    L_0x003e:
        f(r2, r8, r9);
        if (r11 == 0) goto L_0x0044;
    L_0x0043:
        return r1;
    L_0x0044:
        r3 = r8.V;
        r3 = r3.i;
        if (r3 == 0) goto L_0x0077;
    L_0x004a:
        r3 = r8.X;
        r3 = r3.i;
        if (r3 == 0) goto L_0x0077;
    L_0x0050:
        r3 = r2.n0();
        r4 = b.f.a.i.h.c.WRAP_CONTENT;
        if (r11 == 0) goto L_0x005c;
    L_0x0058:
        f(r2, r8, r9);
        return r1;
    L_0x005c:
        r3 = r8.V;
        r3 = r3.i;
        r3 = r3.g;
        r4 = r8.a0();
        if (r3 != r4) goto L_0x0074;
    L_0x0068:
        r3 = r8.X;
        r3 = r3.i;
        r3 = r3.g;
        r4 = r8.a0();
        if (r3 == r4) goto L_0x0077;
    L_0x0074:
        f(r2, r8, r9);
    L_0x0077:
        r3 = r8.U;
        r3 = r3.i;
        if (r3 == 0) goto L_0x00aa;
    L_0x007d:
        r3 = r8.W;
        r3 = r3.i;
        if (r3 == 0) goto L_0x00aa;
    L_0x0083:
        r3 = r2.N();
        r4 = b.f.a.i.h.c.WRAP_CONTENT;
        if (r11 == 0) goto L_0x008f;
    L_0x008b:
        f(r2, r8, r9);
        return r1;
    L_0x008f:
        r3 = r8.U;
        r3 = r3.i;
        r3 = r3.g;
        r4 = r8.a0();
        if (r3 != r4) goto L_0x00a7;
    L_0x009b:
        r3 = r8.W;
        r3 = r3.i;
        r3 = r3.g;
        r4 = r8.a0();
        if (r3 == r4) goto L_0x00aa;
    L_0x00a7:
        f(r2, r8, r9);
    L_0x00aa:
        r3 = r8.N();
        r4 = b.f.a.i.h.c.MATCH_CONSTRAINT;
        if (r3 != r4) goto L_0x00b4;
    L_0x00b2:
        r3 = 1;
        goto L_0x00b5;
    L_0x00b4:
        r3 = 0;
    L_0x00b5:
        r5 = r8.n0();
        if (r5 != r4) goto L_0x00bd;
    L_0x00bb:
        r5 = 1;
        goto L_0x00be;
    L_0x00bd:
        r5 = 0;
    L_0x00be:
        r3 = r3 ^ r5;
        if (r3 == 0) goto L_0x00cc;
    L_0x00c1:
        r3 = r8.i0;
        r5 = 0;
        r3 = (r3 > r5 ? 1 : (r3 == r5 ? 0 : -1));
        if (r3 == 0) goto L_0x00cc;
    L_0x00c8:
        g(r8);
        goto L_0x00de;
    L_0x00cc:
        r3 = r8.N();
        if (r3 == r4) goto L_0x00d8;
    L_0x00d2:
        r3 = r8.n0();
        if (r3 != r4) goto L_0x00de;
    L_0x00d8:
        f(r2, r8, r9);
        if (r11 == 0) goto L_0x00de;
    L_0x00dd:
        return r1;
    L_0x00de:
        r3 = r8.U;
        r3 = r3.i;
        if (r3 != 0) goto L_0x00ea;
    L_0x00e4:
        r4 = r8.W;
        r4 = r4.i;
        if (r4 == 0) goto L_0x0114;
    L_0x00ea:
        if (r3 == 0) goto L_0x00f8;
    L_0x00ec:
        r4 = r3.g;
        r5 = r8.f0;
        if (r4 != r5) goto L_0x00f8;
    L_0x00f2:
        r4 = r8.W;
        r4 = r4.i;
        if (r4 == 0) goto L_0x0114;
    L_0x00f8:
        r4 = r8.W;
        r4 = r4.i;
        if (r4 == 0) goto L_0x0106;
    L_0x00fe:
        r5 = r4.g;
        r6 = r8.f0;
        if (r5 != r6) goto L_0x0106;
    L_0x0104:
        if (r3 == 0) goto L_0x0114;
    L_0x0106:
        if (r3 == 0) goto L_0x0127;
    L_0x0108:
        r3 = r3.g;
        r5 = r8.f0;
        if (r3 != r5) goto L_0x0127;
    L_0x010e:
        if (r4 == 0) goto L_0x0127;
    L_0x0110:
        r3 = r4.g;
        if (r3 != r5) goto L_0x0127;
    L_0x0114:
        r3 = r8.b0;
        r3 = r3.i;
        if (r3 != 0) goto L_0x0127;
    L_0x011a:
        r3 = r8 instanceof b.f.a.i.k;
        if (r3 != 0) goto L_0x0127;
    L_0x011e:
        r3 = r8 instanceof b.f.a.i.l;
        if (r3 != 0) goto L_0x0127;
    L_0x0122:
        r3 = r9.f;
        r3.add(r8);
    L_0x0127:
        r3 = r8.V;
        r3 = r3.i;
        if (r3 != 0) goto L_0x0133;
    L_0x012d:
        r4 = r8.X;
        r4 = r4.i;
        if (r4 == 0) goto L_0x015d;
    L_0x0133:
        if (r3 == 0) goto L_0x0141;
    L_0x0135:
        r4 = r3.g;
        r5 = r8.f0;
        if (r4 != r5) goto L_0x0141;
    L_0x013b:
        r4 = r8.X;
        r4 = r4.i;
        if (r4 == 0) goto L_0x015d;
    L_0x0141:
        r4 = r8.X;
        r4 = r4.i;
        if (r4 == 0) goto L_0x014f;
    L_0x0147:
        r5 = r4.g;
        r6 = r8.f0;
        if (r5 != r6) goto L_0x014f;
    L_0x014d:
        if (r3 == 0) goto L_0x015d;
    L_0x014f:
        if (r3 == 0) goto L_0x0176;
    L_0x0151:
        r3 = r3.g;
        r5 = r8.f0;
        if (r3 != r5) goto L_0x0176;
    L_0x0157:
        if (r4 == 0) goto L_0x0176;
    L_0x0159:
        r3 = r4.g;
        if (r3 != r5) goto L_0x0176;
    L_0x015d:
        r3 = r8.b0;
        r3 = r3.i;
        if (r3 != 0) goto L_0x0176;
    L_0x0163:
        r3 = r8.Y;
        r3 = r3.i;
        if (r3 != 0) goto L_0x0176;
    L_0x0169:
        r3 = r8 instanceof b.f.a.i.k;
        if (r3 != 0) goto L_0x0176;
    L_0x016d:
        r3 = r8 instanceof b.f.a.i.l;
        if (r3 != 0) goto L_0x0176;
    L_0x0171:
        r3 = r9.g;
        r3.add(r8);
    L_0x0176:
        r3 = r8 instanceof b.f.a.i.l;
        if (r3 == 0) goto L_0x0196;
    L_0x017a:
        f(r2, r8, r9);
        if (r11 == 0) goto L_0x0180;
    L_0x017f:
        return r1;
    L_0x0180:
        r3 = r8;
        r3 = (b.f.a.i.l) r3;
        r4 = 0;
    L_0x0184:
        r5 = r3.d1;
        if (r4 >= r5) goto L_0x0196;
    L_0x0188:
        r5 = r3.c1;
        r5 = r5[r4];
        r5 = k(r5, r9, r10, r11);
        if (r5 != 0) goto L_0x0193;
    L_0x0192:
        return r1;
    L_0x0193:
        r4 = r4 + 1;
        goto L_0x0184;
    L_0x0196:
        r3 = r8.c0;
        r3 = r3.length;
        r4 = 0;
    L_0x019a:
        if (r4 >= r3) goto L_0x01c9;
    L_0x019c:
        r5 = r8.c0;
        r5 = r5[r4];
        r6 = r5.i;
        if (r6 == 0) goto L_0x01c6;
    L_0x01a4:
        r6 = r6.g;
        r7 = r8.a0();
        if (r6 == r7) goto L_0x01c6;
    L_0x01ac:
        r6 = r5.h;
        r7 = b.f.a.i.e.d.CENTER;
        if (r6 != r7) goto L_0x01b8;
    L_0x01b2:
        f(r2, r8, r9);
        if (r11 == 0) goto L_0x01bb;
    L_0x01b7:
        return r1;
    L_0x01b8:
        h(r5);
    L_0x01bb:
        r5 = r5.i;
        r5 = r5.g;
        r5 = k(r5, r9, r10, r11);
        if (r5 != 0) goto L_0x01c6;
    L_0x01c5:
        return r1;
    L_0x01c6:
        r4 = r4 + 1;
        goto L_0x019a;
    L_0x01c9:
        return r0;
    L_0x01ca:
        if (r3 == r9) goto L_0x0207;
    L_0x01cc:
        r11 = r9.a;
        r2 = r3.a;
        r11.addAll(r2);
        r11 = r9.f;
        r2 = r8.R;
        r2 = r2.f;
        r11.addAll(r2);
        r11 = r9.g;
        r2 = r8.R;
        r2 = r2.g;
        r11.addAll(r2);
        r11 = r8.R;
        r2 = r11.d;
        if (r2 != 0) goto L_0x01ed;
    L_0x01eb:
        r9.d = r1;
    L_0x01ed:
        r10.remove(r11);
        r8 = r8.R;
        r8 = r8.a;
        r8 = r8.iterator();
    L_0x01f8:
        r10 = r8.hasNext();
        if (r10 == 0) goto L_0x0207;
    L_0x01fe:
        r10 = r8.next();
        r10 = (b.f.a.i.h) r10;
        r10.R = r9;
        goto L_0x01f8;
    L_0x0207:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.f.a.i.a.k(b.f.a.i.h, b.f.a.i.j, java.util.List, boolean):boolean");
    }

    private static void l(h hVar, int i, int i2) {
        int i3 = i * 2;
        e[] eVarArr = hVar.c0;
        e eVar = eVarArr[i3];
        e eVar2 = eVarArr[i3 + 1];
        Object obj = (eVar.i == null || eVar2.i == null) ? null : 1;
        if (obj != null) {
            m.e(hVar, i, e(hVar, i) + eVar.g());
        } else if (hVar.i0 == 0.0f || hVar.A(i) != c.MATCH_CONSTRAINT) {
            i2 -= hVar.b0(i);
            i3 = i2 - hVar.T(i);
            hVar.d1(i3, i2, i);
            m.e(hVar, i, i3);
        } else {
            i2 = g(hVar);
            i3 = (int) hVar.c0[i3].k().q;
            int i4 = i3 + i2;
            eVar2.k().p = eVar.k();
            eVar2.k().q = (float) i2;
            eVar2.k().e = 1;
            hVar.d1(i3, i4, i);
        }
    }
}
