package b.f.a.i;

import b.f.a.e;
import b.f.a.f;
import b.f.a.h;
import b.f.a.i.e.d;

public class o extends q {
    public static final int f = 0;
    public static final int g = 1;
    public static final int h = 2;
    public static final int i = 3;
    public static final int j = 4;
    public static final int k = 5;
    e l;
    float m;
    o n;
    float o;
    o p;
    float q;
    int r = 0;
    private o s;
    private float t;
    private p u = null;
    private int v = 1;
    private p w = null;
    private int x = 1;

    public o(e eVar) {
        this.l = eVar;
    }

    public void f(p pVar) {
        p pVar2 = this.u;
        if (pVar2 == pVar) {
            this.u = null;
            this.o = (float) this.v;
        } else if (pVar2 == this.w) {
            this.w = null;
            this.t = (float) this.x;
        }
        h();
    }

    public void g() {
        super.g();
        this.n = null;
        this.o = 0.0f;
        this.u = null;
        this.v = 1;
        this.w = null;
        this.x = 1;
        this.p = null;
        this.q = 0.0f;
        this.m = 0.0f;
        this.s = null;
        this.t = 0.0f;
        this.r = 0;
    }

    public void h() {
        Object obj = 1;
        if (this.e != 1) {
            int i = this.r;
            if (i != 4) {
                o oVar;
                f P;
                o oVar2;
                o oVar3;
                q qVar = this.u;
                if (qVar != null) {
                    if (qVar.e == 1) {
                        this.o = ((float) this.v) * qVar.f;
                    } else {
                        return;
                    }
                }
                qVar = this.w;
                if (qVar != null) {
                    if (qVar.e == 1) {
                        this.t = ((float) this.x) * qVar.f;
                    } else {
                        return;
                    }
                }
                if (i == 1) {
                    qVar = this.n;
                    if (qVar == null || qVar.e == 1) {
                        if (qVar == null) {
                            this.p = this;
                            this.q = this.o;
                        } else {
                            this.p = qVar.p;
                            this.q = qVar.q + this.o;
                        }
                        b();
                    }
                }
                if (i == 2) {
                    qVar = this.n;
                    if (qVar != null && qVar.e == 1) {
                        oVar = this.s;
                        if (oVar != null) {
                            qVar = oVar.n;
                            if (qVar != null && qVar.e == 1) {
                                float f;
                                if (e.P() != null) {
                                    P = e.P();
                                    P.w++;
                                }
                                oVar2 = this.n;
                                this.p = oVar2.p;
                                oVar = this.s;
                                o oVar4 = oVar.n;
                                oVar.p = oVar4.p;
                                e eVar = this.l;
                                d dVar = eVar.h;
                                d dVar2 = d.RIGHT;
                                int i2 = 0;
                                if (!(dVar == dVar2 || dVar == d.BOTTOM)) {
                                    obj = null;
                                }
                                float f2 = obj != null ? oVar2.q - oVar4.q : oVar4.q - oVar2.q;
                                if (dVar == d.LEFT || dVar == dVar2) {
                                    f2 -= (float) eVar.g.p0();
                                    f = this.l.g.z0;
                                } else {
                                    f2 -= (float) eVar.g.J();
                                    f = this.l.g.A0;
                                }
                                int g = this.l.g();
                                int g2 = this.s.l.g();
                                if (this.l.o() == this.s.l.o()) {
                                    f = 0.5f;
                                    g2 = 0;
                                } else {
                                    i2 = g;
                                }
                                float f3 = (float) i2;
                                float f4 = (float) g2;
                                f2 = (f2 - f3) - f4;
                                if (obj != null) {
                                    oVar3 = this.s;
                                    oVar3.q = (oVar3.n.q + f4) + (f2 * f);
                                    this.q = (this.n.q - f3) - (f2 * (1.0f - f));
                                } else {
                                    this.q = (this.n.q + f3) + (f2 * f);
                                    oVar3 = this.s;
                                    oVar3.q = (oVar3.n.q - f4) - (f2 * (1.0f - f));
                                }
                                b();
                                this.s.b();
                            }
                        }
                    }
                }
                if (i == 3) {
                    qVar = this.n;
                    if (qVar != null && qVar.e == 1) {
                        oVar = this.s;
                        if (oVar != null) {
                            qVar = oVar.n;
                            if (qVar != null && qVar.e == 1) {
                                if (e.P() != null) {
                                    P = e.P();
                                    P.x++;
                                }
                                oVar2 = this.n;
                                this.p = oVar2.p;
                                oVar3 = this.s;
                                oVar = oVar3.n;
                                oVar3.p = oVar.p;
                                this.q = oVar2.q + this.o;
                                oVar3.q = oVar.q + oVar3.o;
                                b();
                                this.s.b();
                            }
                        }
                    }
                }
                if (i == 5) {
                    this.l.g.P0();
                }
            }
        }
    }

    void i(e eVar) {
        h m = this.l.m();
        o oVar = this.p;
        if (oVar == null) {
            eVar.f(m, (int) (this.q + 0.5f));
        } else {
            eVar.e(m, eVar.u(oVar.l), (int) (this.q + 0.5f), 6);
        }
    }

    public void j(int i, o oVar, int i2) {
        this.r = i;
        this.n = oVar;
        this.o = (float) i2;
        oVar.a(this);
    }

    public void k(o oVar, int i) {
        this.n = oVar;
        this.o = (float) i;
        oVar.a(this);
    }

    public void l(o oVar, int i, p pVar) {
        this.n = oVar;
        oVar.a(this);
        this.u = pVar;
        this.v = i;
        pVar.a(this);
    }

    public float m() {
        return this.q;
    }

    public void n(o oVar, float f) {
        int i = this.e;
        if (i == 0 || !(this.p == oVar || this.q == f)) {
            this.p = oVar;
            this.q = f;
            if (i == 1) {
                c();
            }
            b();
        }
    }

    String o(int i) {
        return i == 1 ? "DIRECT" : i == 2 ? "CENTER" : i == 3 ? "MATCH" : i == 4 ? "CHAIN" : i == 5 ? "BARRIER" : "UNCONNECTED";
    }

    public void p(o oVar, float f) {
        this.s = oVar;
        this.t = f;
    }

    public void q(o oVar, int i, p pVar) {
        this.s = oVar;
        this.w = pVar;
        this.x = i;
    }

    public void r(int i) {
        this.r = i;
    }

    public void s() {
        e o = this.l.o();
        if (o != null) {
            if (o.o() == this.l) {
                this.r = 4;
                o.k().r = 4;
            }
            int g = this.l.g();
            d dVar = this.l.h;
            if (dVar == d.RIGHT || dVar == d.BOTTOM) {
                g = -g;
            }
            k(o.k(), g);
        }
    }

    public String toString() {
        StringBuilder stringBuilder;
        if (this.e == 1) {
            String str = ", RESOLVED: ";
            String str2 = "[";
            if (this.p == this) {
                stringBuilder = new StringBuilder();
                stringBuilder.append(str2);
                stringBuilder.append(this.l);
                stringBuilder.append(str);
                stringBuilder.append(this.q);
                stringBuilder.append("]  type: ");
                stringBuilder.append(o(this.r));
                return stringBuilder.toString();
            }
            stringBuilder = new StringBuilder();
            stringBuilder.append(str2);
            stringBuilder.append(this.l);
            stringBuilder.append(str);
            stringBuilder.append(this.p);
            stringBuilder.append(":");
            stringBuilder.append(this.q);
            stringBuilder.append("] type: ");
            stringBuilder.append(o(this.r));
            return stringBuilder.toString();
        }
        stringBuilder = new StringBuilder();
        stringBuilder.append("{ ");
        stringBuilder.append(this.l);
        stringBuilder.append(" UNRESOLVED} type: ");
        stringBuilder.append(o(this.r));
        return stringBuilder.toString();
    }
}
