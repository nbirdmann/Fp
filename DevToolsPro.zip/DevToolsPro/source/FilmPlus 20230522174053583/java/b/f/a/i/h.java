package b.f.a.i;

import b.f.a.e;
import b.f.a.i.e.d;
import java.util.ArrayList;

public class h {
    private static final boolean a = false;
    protected static final int b = 1;
    protected static final int c = 2;
    public static final int d = 0;
    public static final int e = 1;
    public static final int f = 2;
    public static final int g = 3;
    public static final int h = 4;
    public static final int i = -1;
    public static final int j = 0;
    public static final int k = 1;
    public static final int l = 0;
    public static final int m = 4;
    public static final int n = 8;
    public static final int o = 0;
    public static final int p = 1;
    public static final int q = 2;
    private static final int r = -2;
    protected static final int s = 0;
    protected static final int t = 1;
    protected static final int u = 2;
    protected static final int v = 3;
    protected static final int w = 4;
    static final int x = 0;
    static final int y = 1;
    public static float z = 0.5f;
    public int A;
    float A0;
    public int B;
    private Object B0;
    p C;
    private int C0;
    p D;
    private int D0;
    int E;
    private String E0;
    int F;
    private String F0;
    int[] G;
    int G0;
    int H;
    int H0;
    int I;
    int I0;
    float J;
    int J0;
    int K;
    boolean K0;
    int L;
    boolean L0;
    float M;
    boolean M0;
    boolean N;
    boolean N0;
    boolean O;
    boolean O0;
    int P;
    boolean P0;
    float Q;
    boolean Q0;
    j R;
    boolean R0;
    private int[] S;
    boolean S0;
    private float T;
    int T0;
    e U;
    int U0;
    e V;
    boolean V0;
    e W;
    boolean W0;
    e X;
    float[] X0;
    e Y;
    protected h[] Y0;
    e Z;
    protected h[] Z0;
    e a0;
    h a1;
    e b0;
    h b1;
    protected e[] c0;
    protected ArrayList<e> d0;
    protected c[] e0;
    h f0;
    int g0;
    int h0;
    protected float i0;
    protected int j0;
    protected int k0;
    protected int l0;
    int m0;
    int n0;
    private int o0;
    private int p0;
    private int q0;
    private int r0;
    protected int s0;
    protected int t0;
    int u0;
    protected int v0;
    protected int w0;
    private int x0;
    private int y0;
    float z0;

    static /* synthetic */ class a {
        static final /* synthetic */ int[] a;
        static final /* synthetic */ int[] b;

        /* DevToolsApp WARNING: Failed to process nested try/catch */
        /* DevToolsApp WARNING: Missing block: B:30:?, code:
            a[b.f.a.i.e.d.a.ordinal()] = 9;
     */
        static {
            /*
            r0 = b.f.a.i.h.c.values();
            r0 = r0.length;
            r0 = new int[r0];
            b = r0;
            r1 = 1;
            r2 = b.f.a.i.h.c.FIXED;	 Catch:{ NoSuchFieldError -> 0x0012 }
            r2 = r2.ordinal();	 Catch:{ NoSuchFieldError -> 0x0012 }
            r0[r2] = r1;	 Catch:{ NoSuchFieldError -> 0x0012 }
        L_0x0012:
            r0 = 2;
            r2 = b;	 Catch:{ NoSuchFieldError -> 0x001d }
            r3 = b.f.a.i.h.c.WRAP_CONTENT;	 Catch:{ NoSuchFieldError -> 0x001d }
            r3 = r3.ordinal();	 Catch:{ NoSuchFieldError -> 0x001d }
            r2[r3] = r0;	 Catch:{ NoSuchFieldError -> 0x001d }
        L_0x001d:
            r2 = 3;
            r3 = b;	 Catch:{ NoSuchFieldError -> 0x0028 }
            r4 = b.f.a.i.h.c.MATCH_PARENT;	 Catch:{ NoSuchFieldError -> 0x0028 }
            r4 = r4.ordinal();	 Catch:{ NoSuchFieldError -> 0x0028 }
            r3[r4] = r2;	 Catch:{ NoSuchFieldError -> 0x0028 }
        L_0x0028:
            r3 = 4;
            r4 = b;	 Catch:{ NoSuchFieldError -> 0x0033 }
            r5 = b.f.a.i.h.c.MATCH_CONSTRAINT;	 Catch:{ NoSuchFieldError -> 0x0033 }
            r5 = r5.ordinal();	 Catch:{ NoSuchFieldError -> 0x0033 }
            r4[r5] = r3;	 Catch:{ NoSuchFieldError -> 0x0033 }
        L_0x0033:
            r4 = b.f.a.i.e.d.values();
            r4 = r4.length;
            r4 = new int[r4];
            a = r4;
            r5 = b.f.a.i.e.d.LEFT;	 Catch:{ NoSuchFieldError -> 0x0044 }
            r5 = r5.ordinal();	 Catch:{ NoSuchFieldError -> 0x0044 }
            r4[r5] = r1;	 Catch:{ NoSuchFieldError -> 0x0044 }
        L_0x0044:
            r1 = a;	 Catch:{ NoSuchFieldError -> 0x004e }
            r4 = b.f.a.i.e.d.TOP;	 Catch:{ NoSuchFieldError -> 0x004e }
            r4 = r4.ordinal();	 Catch:{ NoSuchFieldError -> 0x004e }
            r1[r4] = r0;	 Catch:{ NoSuchFieldError -> 0x004e }
        L_0x004e:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x0058 }
            r1 = b.f.a.i.e.d.RIGHT;	 Catch:{ NoSuchFieldError -> 0x0058 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0058 }
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0058 }
        L_0x0058:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x0062 }
            r1 = b.f.a.i.e.d.BOTTOM;	 Catch:{ NoSuchFieldError -> 0x0062 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0062 }
            r0[r1] = r3;	 Catch:{ NoSuchFieldError -> 0x0062 }
        L_0x0062:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x006d }
            r1 = b.f.a.i.e.d.BASELINE;	 Catch:{ NoSuchFieldError -> 0x006d }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x006d }
            r2 = 5;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x006d }
        L_0x006d:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x0078 }
            r1 = b.f.a.i.e.d.CENTER;	 Catch:{ NoSuchFieldError -> 0x0078 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0078 }
            r2 = 6;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0078 }
        L_0x0078:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x0083 }
            r1 = b.f.a.i.e.d.CENTER_X;	 Catch:{ NoSuchFieldError -> 0x0083 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0083 }
            r2 = 7;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0083 }
        L_0x0083:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x008f }
            r1 = b.f.a.i.e.d.CENTER_Y;	 Catch:{ NoSuchFieldError -> 0x008f }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x008f }
            r2 = 8;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x008f }
        L_0x008f:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x009b }
            r1 = b.f.a.i.e.d.NONE;	 Catch:{ NoSuchFieldError -> 0x009b }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x009b }
            r2 = 9;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x009b }
        L_0x009b:
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: b.f.a.i.h.a.<clinit>():void");
        }
    }

    public enum b {
        BEGIN,
        MIDDLE,
        END,
        TOP,
        VERTICAL_MIDDLE,
        BOTTOM,
        LEFT,
        RIGHT
    }

    public enum c {
        FIXED,
        WRAP_CONTENT,
        MATCH_CONSTRAINT,
        MATCH_PARENT
    }

    public h() {
        this.A = -1;
        this.B = -1;
        this.E = 0;
        this.F = 0;
        this.G = new int[2];
        this.H = 0;
        this.I = 0;
        this.J = 1.0f;
        this.K = 0;
        this.L = 0;
        this.M = 1.0f;
        this.P = -1;
        this.Q = 1.0f;
        this.R = null;
        this.S = new int[]{Integer.MAX_VALUE, Integer.MAX_VALUE};
        this.T = 0.0f;
        this.U = new e(this, d.LEFT);
        this.V = new e(this, d.TOP);
        this.W = new e(this, d.RIGHT);
        this.X = new e(this, d.BOTTOM);
        this.Y = new e(this, d.BASELINE);
        this.Z = new e(this, d.CENTER_X);
        this.a0 = new e(this, d.CENTER_Y);
        this.b0 = new e(this, d.CENTER);
        this.c0 = new e[]{this.U, this.W, this.V, this.X, this.Y, r5};
        this.d0 = new ArrayList();
        r5 = new c[2];
        c cVar = c.FIXED;
        r5[0] = cVar;
        r5[1] = cVar;
        this.e0 = r5;
        this.f0 = null;
        this.g0 = 0;
        this.h0 = 0;
        this.i0 = 0.0f;
        this.j0 = -1;
        this.k0 = 0;
        this.l0 = 0;
        this.m0 = 0;
        this.n0 = 0;
        this.o0 = 0;
        this.p0 = 0;
        this.q0 = 0;
        this.r0 = 0;
        this.s0 = 0;
        this.t0 = 0;
        this.u0 = 0;
        float f = z;
        this.z0 = f;
        this.A0 = f;
        this.C0 = 0;
        this.D0 = 0;
        this.E0 = null;
        this.F0 = null;
        this.Q0 = false;
        this.R0 = false;
        this.S0 = false;
        this.T0 = 0;
        this.U0 = 0;
        this.X0 = new float[]{-1.0f, -1.0f};
        this.Y0 = new h[]{null, null};
        this.Z0 = new h[]{null, null};
        this.a1 = null;
        this.b1 = null;
        a();
    }

    public h(int i, int i2) {
        this(0, 0, i, i2);
    }

    public h(int i, int i2, int i3, int i4) {
        this.A = -1;
        this.B = -1;
        this.E = 0;
        this.F = 0;
        this.G = new int[2];
        this.H = 0;
        this.I = 0;
        this.J = 1.0f;
        this.K = 0;
        this.L = 0;
        this.M = 1.0f;
        this.P = -1;
        this.Q = 1.0f;
        this.R = null;
        this.S = new int[]{Integer.MAX_VALUE, Integer.MAX_VALUE};
        this.T = 0.0f;
        this.U = new e(this, d.LEFT);
        this.V = new e(this, d.TOP);
        this.W = new e(this, d.RIGHT);
        this.X = new e(this, d.BOTTOM);
        this.Y = new e(this, d.BASELINE);
        this.Z = new e(this, d.CENTER_X);
        this.a0 = new e(this, d.CENTER_Y);
        this.b0 = new e(this, d.CENTER);
        this.c0 = new e[]{this.U, this.W, this.V, this.X, this.Y, r5};
        this.d0 = new ArrayList();
        r5 = new c[2];
        c cVar = c.FIXED;
        r5[0] = cVar;
        r5[1] = cVar;
        this.e0 = r5;
        this.f0 = null;
        this.g0 = 0;
        this.h0 = 0;
        this.i0 = 0.0f;
        this.j0 = -1;
        this.k0 = 0;
        this.l0 = 0;
        this.m0 = 0;
        this.n0 = 0;
        this.o0 = 0;
        this.p0 = 0;
        this.q0 = 0;
        this.r0 = 0;
        this.s0 = 0;
        this.t0 = 0;
        this.u0 = 0;
        float f = z;
        this.z0 = f;
        this.A0 = f;
        this.C0 = 0;
        this.D0 = 0;
        this.E0 = null;
        this.F0 = null;
        this.Q0 = false;
        this.R0 = false;
        this.S0 = false;
        this.T0 = 0;
        this.U0 = 0;
        this.X0 = new float[]{-1.0f, -1.0f};
        this.Y0 = new h[]{null, null};
        this.Z0 = new h[]{null, null};
        this.a1 = null;
        this.b1 = null;
        this.k0 = i;
        this.l0 = i2;
        this.g0 = i3;
        this.h0 = i4;
        a();
        r();
    }

    private void a() {
        this.d0.add(this.U);
        this.d0.add(this.V);
        this.d0.add(this.W);
        this.d0.add(this.X);
        this.d0.add(this.Z);
        this.d0.add(this.a0);
        this.d0.add(this.b0);
        this.d0.add(this.Y);
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:92:0x01c9 A:{SKIP} */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:92:0x01c9 A:{SKIP} */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:163:0x02e2  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:174:0x0303  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:177:0x030c  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:163:0x02e2  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:174:0x0303  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:177:0x030c  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:160:0x02d3  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:153:0x028e  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:163:0x02e2  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:174:0x0303  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:177:0x030c  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:153:0x028e  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:160:0x02d3  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:163:0x02e2  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:174:0x0303  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:177:0x030c  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:177:0x030c  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:60:0x0105  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:50:0x00db  */
    private void e(b.f.a.e r25, boolean r26, b.f.a.h r27, b.f.a.h r28, b.f.a.i.h.c r29, boolean r30, b.f.a.i.e r31, b.f.a.i.e r32, int r33, int r34, int r35, int r36, float r37, boolean r38, boolean r39, int r40, int r41, int r42, float r43, boolean r44) {
        /*
        r24 = this;
        r0 = r24;
        r10 = r25;
        r11 = r27;
        r12 = r28;
        r13 = r31;
        r14 = r32;
        r1 = r35;
        r2 = r36;
        r15 = r10.u(r13);
        r9 = r10.u(r14);
        r3 = r31.o();
        r8 = r10.u(r3);
        r3 = r32.o();
        r7 = r10.u(r3);
        r3 = r10.k;
        r6 = 1;
        r4 = 6;
        r5 = 0;
        if (r3 == 0) goto L_0x0066;
    L_0x002f:
        r3 = r31.k();
        r3 = r3.e;
        if (r3 != r6) goto L_0x0066;
    L_0x0037:
        r3 = r32.k();
        r3 = r3.e;
        if (r3 != r6) goto L_0x0066;
    L_0x003f:
        r1 = b.f.a.e.P();
        if (r1 == 0) goto L_0x0050;
    L_0x0045:
        r1 = b.f.a.e.P();
        r2 = r1.s;
        r6 = 1;
        r2 = r2 + r6;
        r1.s = r2;
    L_0x0050:
        r1 = r31.k();
        r1.i(r10);
        r1 = r32.k();
        r1.i(r10);
        if (r39 != 0) goto L_0x0065;
    L_0x0060:
        if (r26 == 0) goto L_0x0065;
    L_0x0062:
        r10.k(r12, r9, r5, r4);
    L_0x0065:
        return;
    L_0x0066:
        r3 = b.f.a.e.P();
        if (r3 == 0) goto L_0x0078;
    L_0x006c:
        r3 = b.f.a.e.P();
        r4 = r3.B;
        r16 = 1;
        r4 = r4 + r16;
        r3.B = r4;
    L_0x0078:
        r16 = r31.q();
        r17 = r32.q();
        r3 = r0.b0;
        r19 = r3.q();
        if (r17 == 0) goto L_0x008b;
    L_0x0088:
        r3 = r16 + 1;
        goto L_0x008d;
    L_0x008b:
        r3 = r16;
    L_0x008d:
        if (r19 == 0) goto L_0x0091;
    L_0x008f:
        r3 = r3 + 1;
    L_0x0091:
        r5 = r3;
        if (r38 == 0) goto L_0x0096;
    L_0x0094:
        r3 = 3;
        goto L_0x0098;
    L_0x0096:
        r3 = r40;
    L_0x0098:
        r20 = b.f.a.i.h.a.b;
        r21 = r29.ordinal();
        r4 = r20[r21];
        r14 = 2;
        r13 = 4;
        if (r4 == r6) goto L_0x00ab;
    L_0x00a4:
        if (r4 == r14) goto L_0x00ab;
    L_0x00a6:
        r14 = 3;
        if (r4 == r14) goto L_0x00ab;
    L_0x00a9:
        if (r4 == r13) goto L_0x00ad;
    L_0x00ab:
        r4 = 0;
        goto L_0x00b1;
    L_0x00ad:
        if (r3 != r13) goto L_0x00b0;
    L_0x00af:
        goto L_0x00ab;
    L_0x00b0:
        r4 = 1;
    L_0x00b1:
        r14 = r0.D0;
        r13 = 8;
        if (r14 != r13) goto L_0x00ba;
    L_0x00b7:
        r4 = 0;
        r13 = 0;
        goto L_0x00bd;
    L_0x00ba:
        r13 = r4;
        r4 = r34;
    L_0x00bd:
        if (r44 == 0) goto L_0x00d8;
    L_0x00bf:
        if (r16 != 0) goto L_0x00cb;
    L_0x00c1:
        if (r17 != 0) goto L_0x00cb;
    L_0x00c3:
        if (r19 != 0) goto L_0x00cb;
    L_0x00c5:
        r14 = r33;
        r10.f(r15, r14);
        goto L_0x00d8;
    L_0x00cb:
        if (r16 == 0) goto L_0x00d8;
    L_0x00cd:
        if (r17 != 0) goto L_0x00d8;
    L_0x00cf:
        r14 = r31.g();
        r6 = 6;
        r10.e(r15, r8, r14, r6);
        goto L_0x00d9;
    L_0x00d8:
        r6 = 6;
    L_0x00d9:
        if (r13 != 0) goto L_0x0105;
    L_0x00db:
        if (r30 == 0) goto L_0x00f2;
    L_0x00dd:
        r6 = 0;
        r14 = 3;
        r10.e(r9, r15, r6, r14);
        r4 = 6;
        if (r1 <= 0) goto L_0x00e8;
    L_0x00e5:
        r10.k(r9, r15, r1, r4);
    L_0x00e8:
        r6 = 2147483647; // 0x7fffffff float:NaN double:1.060997895E-314;
        if (r2 >= r6) goto L_0x00f0;
    L_0x00ed:
        r10.m(r9, r15, r2, r4);
    L_0x00f0:
        r6 = 6;
        goto L_0x00f6;
    L_0x00f2:
        r14 = 3;
        r10.e(r9, r15, r4, r6);
    L_0x00f6:
        r14 = r41;
        r30 = r3;
        r0 = r5;
        r1 = r7;
        r21 = r8;
        r22 = r13;
        r2 = 2;
        r13 = r42;
        goto L_0x01e0;
    L_0x0105:
        r14 = 3;
        r2 = -2;
        r14 = r41;
        r6 = r42;
        if (r14 != r2) goto L_0x010e;
    L_0x010d:
        r14 = r4;
    L_0x010e:
        if (r6 != r2) goto L_0x0111;
    L_0x0110:
        r6 = r4;
    L_0x0111:
        r2 = 6;
        if (r14 <= 0) goto L_0x011b;
    L_0x0114:
        r10.k(r9, r15, r14, r2);
        r4 = java.lang.Math.max(r4, r14);
    L_0x011b:
        if (r6 <= 0) goto L_0x0124;
    L_0x011d:
        r10.m(r9, r15, r6, r2);
        r4 = java.lang.Math.min(r4, r6);
    L_0x0124:
        r2 = 1;
        if (r3 != r2) goto L_0x014d;
    L_0x0127:
        if (r26 == 0) goto L_0x0139;
    L_0x0129:
        r2 = 6;
        r10.e(r9, r15, r4, r2);
        r30 = r3;
        r0 = r5;
        r1 = r7;
        r21 = r8;
        r34 = r13;
        r8 = r4;
        r13 = r6;
        goto L_0x01c4;
    L_0x0139:
        r2 = 6;
        if (r39 == 0) goto L_0x0144;
    L_0x013c:
        r34 = r13;
        r13 = 4;
        r10.e(r9, r15, r4, r13);
        goto L_0x01bc;
    L_0x0144:
        r34 = r13;
        r2 = 1;
        r13 = 4;
        r10.e(r9, r15, r4, r2);
        goto L_0x01bc;
    L_0x014d:
        r34 = r13;
        r2 = 2;
        r13 = 4;
        if (r3 != r2) goto L_0x01bc;
    L_0x0153:
        r2 = r31.p();
        r13 = b.f.a.i.e.d.TOP;
        if (r2 == r13) goto L_0x017f;
    L_0x015b:
        r2 = r31.p();
        r21 = r3;
        r3 = b.f.a.i.e.d.BOTTOM;
        if (r2 != r3) goto L_0x0166;
    L_0x0165:
        goto L_0x0181;
    L_0x0166:
        r2 = r0.f0;
        r3 = b.f.a.i.e.d.LEFT;
        r2 = r2.s(r3);
        r2 = r10.u(r2);
        r3 = r0.f0;
        r13 = b.f.a.i.e.d.RIGHT;
        r3 = r3.s(r13);
        r3 = r10.u(r3);
        goto L_0x0197;
    L_0x017f:
        r21 = r3;
    L_0x0181:
        r2 = r0.f0;
        r2 = r2.s(r13);
        r2 = r10.u(r2);
        r3 = r0.f0;
        r13 = b.f.a.i.e.d.BOTTOM;
        r3 = r3.s(r13);
        r3 = r10.u(r3);
    L_0x0197:
        r23 = r2;
        r13 = r3;
        r2 = r25.v();
        r18 = 1;
        r20 = 6;
        r0 = r21;
        r3 = r9;
        r21 = r8;
        r8 = r4;
        r4 = r15;
        r30 = r0;
        r0 = r5;
        r5 = r13;
        r13 = r6;
        r6 = r23;
        r1 = r7;
        r7 = r43;
        r2 = r2.j(r3, r4, r5, r6, r7);
        r10.d(r2);
        r5 = 0;
        goto L_0x01c6;
    L_0x01bc:
        r30 = r3;
        r0 = r5;
        r13 = r6;
        r1 = r7;
        r21 = r8;
        r8 = r4;
    L_0x01c4:
        r5 = r34;
    L_0x01c6:
        r2 = 2;
        if (r5 == 0) goto L_0x01de;
    L_0x01c9:
        if (r0 == r2) goto L_0x01de;
    L_0x01cb:
        if (r38 != 0) goto L_0x01de;
    L_0x01cd:
        r3 = java.lang.Math.max(r14, r8);
        if (r13 <= 0) goto L_0x01d7;
    L_0x01d3:
        r3 = java.lang.Math.min(r13, r3);
    L_0x01d7:
        r4 = 6;
        r10.e(r9, r15, r3, r4);
        r22 = 0;
        goto L_0x01e0;
    L_0x01de:
        r22 = r5;
    L_0x01e0:
        if (r44 == 0) goto L_0x0313;
    L_0x01e2:
        if (r39 == 0) goto L_0x01e6;
    L_0x01e4:
        goto L_0x0313;
    L_0x01e6:
        r0 = 5;
        if (r16 != 0) goto L_0x01f5;
    L_0x01e9:
        if (r17 != 0) goto L_0x01f5;
    L_0x01eb:
        if (r19 != 0) goto L_0x01f5;
    L_0x01ed:
        if (r26 == 0) goto L_0x0307;
    L_0x01ef:
        r2 = 0;
        r10.k(r12, r9, r2, r0);
        goto L_0x0307;
    L_0x01f5:
        r2 = 0;
        if (r16 == 0) goto L_0x0201;
    L_0x01f8:
        if (r17 != 0) goto L_0x0201;
    L_0x01fa:
        if (r26 == 0) goto L_0x0307;
    L_0x01fc:
        r10.k(r12, r9, r2, r0);
        goto L_0x0307;
    L_0x0201:
        if (r16 != 0) goto L_0x0215;
    L_0x0203:
        if (r17 == 0) goto L_0x0215;
    L_0x0205:
        r3 = r32.g();
        r3 = -r3;
        r4 = 6;
        r10.e(r9, r1, r3, r4);
        if (r26 == 0) goto L_0x0307;
    L_0x0210:
        r10.k(r15, r11, r2, r0);
        goto L_0x0307;
    L_0x0215:
        if (r16 == 0) goto L_0x0307;
    L_0x0217:
        if (r17 == 0) goto L_0x0307;
    L_0x0219:
        if (r22 == 0) goto L_0x0281;
    L_0x021b:
        r8 = r1;
        r7 = 6;
        if (r26 == 0) goto L_0x0224;
    L_0x021f:
        if (r35 != 0) goto L_0x0224;
    L_0x0221:
        r10.k(r9, r15, r2, r7);
    L_0x0224:
        if (r30 != 0) goto L_0x024e;
    L_0x0226:
        if (r13 > 0) goto L_0x022e;
    L_0x0228:
        if (r14 <= 0) goto L_0x022b;
    L_0x022a:
        goto L_0x022e;
    L_0x022b:
        r4 = 6;
        r6 = 0;
        goto L_0x0230;
    L_0x022e:
        r4 = 4;
        r6 = 1;
    L_0x0230:
        r1 = r31.g();
        r5 = r21;
        r10.e(r15, r5, r1, r4);
        r1 = r32.g();
        r1 = -r1;
        r10.e(r9, r8, r1, r4);
        if (r13 > 0) goto L_0x0248;
    L_0x0243:
        if (r14 <= 0) goto L_0x0246;
    L_0x0245:
        goto L_0x0248;
    L_0x0246:
        r1 = 0;
        goto L_0x0249;
    L_0x0248:
        r1 = 1;
    L_0x0249:
        r13 = r6;
        r14 = 1;
        r16 = 5;
        goto L_0x0259;
    L_0x024e:
        r4 = r30;
        r5 = r21;
        r14 = 1;
        if (r4 != r14) goto L_0x025c;
    L_0x0255:
        r1 = 1;
        r13 = 1;
        r16 = 6;
    L_0x0259:
        r6 = r24;
        goto L_0x028c;
    L_0x025c:
        r1 = 3;
        r6 = r24;
        if (r4 != r1) goto L_0x027f;
    L_0x0261:
        if (r38 != 0) goto L_0x026c;
    L_0x0263:
        r1 = r6.P;
        r2 = -1;
        if (r1 == r2) goto L_0x026c;
    L_0x0268:
        if (r13 > 0) goto L_0x026c;
    L_0x026a:
        r4 = 6;
        goto L_0x026d;
    L_0x026c:
        r4 = 4;
    L_0x026d:
        r1 = r31.g();
        r10.e(r15, r5, r1, r4);
        r1 = r32.g();
        r1 = -r1;
        r10.e(r9, r8, r1, r4);
        r1 = 1;
        r13 = 1;
        goto L_0x028a;
    L_0x027f:
        r1 = 0;
        goto L_0x0289;
    L_0x0281:
        r6 = r24;
        r8 = r1;
        r5 = r21;
        r7 = 6;
        r14 = 1;
        r1 = 1;
    L_0x0289:
        r13 = 0;
    L_0x028a:
        r16 = 5;
    L_0x028c:
        if (r1 == 0) goto L_0x02d3;
    L_0x028e:
        r4 = r31.g();
        r17 = r32.g();
        r1 = r25;
        r2 = r15;
        r3 = r5;
        r18 = r5;
        r5 = r37;
        r6 = r8;
        r19 = 6;
        r7 = r9;
        r14 = r8;
        r0 = r18;
        r12 = 6;
        r8 = r17;
        r12 = r9;
        r9 = r16;
        r1.c(r2, r3, r4, r5, r6, r7, r8, r9);
        r1 = r31;
        r2 = r1.i;
        r2 = r2.g;
        r2 = r2 instanceof b.f.a.i.b;
        r3 = r32;
        r4 = r3.i;
        r4 = r4.g;
        r4 = r4 instanceof b.f.a.i.b;
        if (r2 == 0) goto L_0x02c9;
    L_0x02c0:
        if (r4 != 0) goto L_0x02c9;
    L_0x02c2:
        r6 = r26;
        r2 = 6;
        r4 = 5;
        r18 = 1;
        goto L_0x02e0;
    L_0x02c9:
        if (r2 != 0) goto L_0x02da;
    L_0x02cb:
        if (r4 == 0) goto L_0x02da;
    L_0x02cd:
        r18 = r26;
        r2 = 5;
        r4 = 6;
        r6 = 1;
        goto L_0x02e0;
    L_0x02d3:
        r1 = r31;
        r3 = r32;
        r0 = r5;
        r14 = r8;
        r12 = r9;
    L_0x02da:
        r6 = r26;
        r18 = r6;
        r2 = 5;
        r4 = 5;
    L_0x02e0:
        if (r13 == 0) goto L_0x02e4;
    L_0x02e2:
        r2 = 6;
        r4 = 6;
    L_0x02e4:
        if (r22 != 0) goto L_0x02e8;
    L_0x02e6:
        if (r6 != 0) goto L_0x02ea;
    L_0x02e8:
        if (r13 == 0) goto L_0x02f1;
    L_0x02ea:
        r1 = r31.g();
        r10.k(r15, r0, r1, r4);
    L_0x02f1:
        if (r22 != 0) goto L_0x02f5;
    L_0x02f3:
        if (r18 != 0) goto L_0x02f7;
    L_0x02f5:
        if (r13 == 0) goto L_0x02ff;
    L_0x02f7:
        r0 = r32.g();
        r0 = -r0;
        r10.m(r12, r14, r0, r2);
    L_0x02ff:
        r0 = 6;
        r1 = 0;
        if (r26 == 0) goto L_0x030a;
    L_0x0303:
        r10.k(r15, r11, r1, r0);
        goto L_0x030a;
    L_0x0307:
        r12 = r9;
        r0 = 6;
        r1 = 0;
    L_0x030a:
        if (r26 == 0) goto L_0x0312;
    L_0x030c:
        r2 = r28;
        r3 = 6;
        r10.k(r2, r12, r1, r3);
    L_0x0312:
        return;
    L_0x0313:
        r2 = r12;
        r1 = 0;
        r3 = 6;
        r4 = 2;
        r12 = r9;
        if (r0 >= r4) goto L_0x0322;
    L_0x031a:
        if (r26 == 0) goto L_0x0322;
    L_0x031c:
        r10.k(r15, r11, r1, r3);
        r10.k(r2, r12, r1, r3);
    L_0x0322:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.f.a.i.h.e(b.f.a.e, boolean, b.f.a.h, b.f.a.h, b.f.a.i.h$c, boolean, b.f.a.i.e, b.f.a.i.e, int, int, int, int, float, boolean, boolean, int, int, int, float, boolean):void");
    }

    private boolean x0(int i) {
        i *= 2;
        e[] eVarArr = this.c0;
        if (!(eVarArr[i].i == null || eVarArr[i].i.i == eVarArr[i])) {
            i++;
            if (eVarArr[i].i != null && eVarArr[i].i.i == eVarArr[i]) {
                return true;
            }
        }
        return false;
    }

    public c A(int i) {
        return i == 0 ? N() : i == 1 ? n0() : null;
    }

    public boolean A0() {
        e eVar = this.U;
        e eVar2 = eVar.i;
        if (eVar2 == null || eVar2.i != eVar) {
            eVar = this.W;
            eVar2 = eVar.i;
            if (eVar2 == null || eVar2.i != eVar) {
                return false;
            }
        }
        return true;
    }

    public void A1(int i, int i2) {
        this.l0 = i;
        i2 -= i;
        this.h0 = i2;
        i = this.w0;
        if (i2 < i) {
            this.h0 = i;
        }
    }

    public float B() {
        return this.i0;
    }

    public boolean B0() {
        e eVar = this.V;
        e eVar2 = eVar.i;
        if (eVar2 == null || eVar2.i != eVar) {
            eVar = this.X;
            eVar2 = eVar.i;
            if (eVar2 == null || eVar2.i != eVar) {
                return false;
            }
        }
        return true;
    }

    public void B1(c cVar) {
        this.e0[1] = cVar;
        if (cVar == c.WRAP_CONTENT) {
            g1(this.y0);
        }
    }

    public int C() {
        return this.j0;
    }

    public boolean C0() {
        h a0 = a0();
        if (a0 == null) {
            return false;
        }
        while (a0 != null) {
            if (a0 instanceof i) {
                return true;
            }
            a0 = a0.a0();
        }
        return false;
    }

    public void C1(int i, int i2, int i3, float f) {
        this.F = i;
        this.K = i2;
        this.L = i3;
        this.M = f;
        if (f < 1.0f && i == 0) {
            this.F = 2;
        }
    }

    public int D() {
        return I() + this.r0;
    }

    public boolean D0() {
        return this.f0 == null;
    }

    public void D1(float f) {
        this.X0[1] = f;
    }

    public int E() {
        return this.r0;
    }

    public boolean E0() {
        if (this instanceof i) {
            h hVar = this.f0;
            if (hVar == null || !(hVar instanceof i)) {
                return true;
            }
        }
        return false;
    }

    public void E1(int i) {
        this.D0 = i;
    }

    public int F() {
        return H() + this.q0;
    }

    public boolean F0() {
        return this.F == 0 && this.i0 == 0.0f && this.K == 0 && this.L == 0 && this.e0[1] == c.MATCH_CONSTRAINT;
    }

    public void F1(int i) {
        this.g0 = i;
        int i2 = this.v0;
        if (i < i2) {
            this.g0 = i2;
        }
    }

    public int G() {
        return this.q0;
    }

    public boolean G0() {
        return this.E == 0 && this.i0 == 0.0f && this.H == 0 && this.I == 0 && this.e0[0] == c.MATCH_CONSTRAINT;
    }

    public void G1(boolean z) {
        this.N = z;
    }

    public int H() {
        return this.o0 + this.s0;
    }

    public boolean H0() {
        return this.N;
    }

    public void H1(int i) {
        this.y0 = i;
    }

    public int I() {
        return this.p0 + this.t0;
    }

    public void I0() {
        this.U.z();
        this.V.z();
        this.W.z();
        this.X.z();
        this.Y.z();
        this.Z.z();
        this.a0.z();
        this.b0.z();
        this.f0 = null;
        this.T = 0.0f;
        this.g0 = 0;
        this.h0 = 0;
        this.i0 = 0.0f;
        this.j0 = -1;
        this.k0 = 0;
        this.l0 = 0;
        this.o0 = 0;
        this.p0 = 0;
        this.q0 = 0;
        this.r0 = 0;
        this.s0 = 0;
        this.t0 = 0;
        this.u0 = 0;
        this.v0 = 0;
        this.w0 = 0;
        this.x0 = 0;
        this.y0 = 0;
        float f = z;
        this.z0 = f;
        this.A0 = f;
        c[] cVarArr = this.e0;
        c cVar = c.FIXED;
        cVarArr[0] = cVar;
        cVarArr[1] = cVar;
        this.B0 = null;
        this.C0 = 0;
        this.D0 = 0;
        this.F0 = null;
        this.O0 = false;
        this.P0 = false;
        this.T0 = 0;
        this.U0 = 0;
        this.V0 = false;
        this.W0 = false;
        float[] fArr = this.X0;
        fArr[0] = -1.0f;
        fArr[1] = -1.0f;
        this.A = -1;
        this.B = -1;
        int[] iArr = this.S;
        iArr[0] = Integer.MAX_VALUE;
        iArr[1] = Integer.MAX_VALUE;
        this.E = 0;
        this.F = 0;
        this.J = 1.0f;
        this.M = 1.0f;
        this.I = Integer.MAX_VALUE;
        this.L = Integer.MAX_VALUE;
        this.H = 0;
        this.K = 0;
        this.P = -1;
        this.Q = 1.0f;
        p pVar = this.C;
        if (pVar != null) {
            pVar.g();
        }
        pVar = this.D;
        if (pVar != null) {
            pVar.g();
        }
        this.R = null;
        this.Q0 = false;
        this.R0 = false;
        this.S0 = false;
    }

    public void I1(int i) {
        this.x0 = i;
    }

    public int J() {
        return this.D0 == 8 ? 0 : this.h0;
    }

    public void J0() {
        L0();
        y1(z);
        i1(z);
        if (!(this instanceof i)) {
            c N = N();
            c cVar = c.MATCH_CONSTRAINT;
            if (N == cVar) {
                if (p0() == r0()) {
                    l1(c.WRAP_CONTENT);
                } else if (p0() > X()) {
                    l1(c.FIXED);
                }
            }
            if (n0() == cVar) {
                if (J() == q0()) {
                    B1(c.WRAP_CONTENT);
                } else if (J() > W()) {
                    B1(c.FIXED);
                }
            }
        }
    }

    public void J1(int i) {
        this.k0 = i;
    }

    public float K() {
        return this.z0;
    }

    public void K0(e eVar) {
        if (a0() == null || !(a0() instanceof i) || !((i) a0()).j2()) {
            e s = s(d.LEFT);
            e s2 = s(d.RIGHT);
            e s3 = s(d.TOP);
            e s4 = s(d.BOTTOM);
            e s5 = s(d.CENTER);
            e s6 = s(d.CENTER_X);
            e s7 = s(d.CENTER_Y);
            if (eVar == s5) {
                if (s.q() && s2.q() && s.o() == s2.o()) {
                    s.z();
                    s2.z();
                }
                if (s3.q() && s4.q() && s3.o() == s4.o()) {
                    s3.z();
                    s4.z();
                }
                this.z0 = 0.5f;
                this.A0 = 0.5f;
            } else if (eVar == s6) {
                if (s.q() && s2.q() && s.o().i() == s2.o().i()) {
                    s.z();
                    s2.z();
                }
                this.z0 = 0.5f;
            } else if (eVar == s7) {
                if (s3.q() && s4.q() && s3.o().i() == s4.o().i()) {
                    s3.z();
                    s4.z();
                }
                this.A0 = 0.5f;
            } else if (eVar == s || eVar == s2) {
                if (s.q() && s.o() == s2.o()) {
                    s5.z();
                }
            } else if ((eVar == s3 || eVar == s4) && s3.q() && s3.o() == s4.o()) {
                s5.z();
            }
            eVar.z();
        }
    }

    public void K1(int i) {
        this.l0 = i;
    }

    public h L() {
        if (!A0()) {
            return null;
        }
        h hVar = this;
        h hVar2 = null;
        while (hVar2 == null && hVar != null) {
            e s = hVar.s(d.LEFT);
            s = s == null ? null : s.o();
            h i = s == null ? null : s.i();
            if (i == a0()) {
                return hVar;
            }
            e o = i == null ? null : i.s(d.RIGHT).o();
            if (o == null || o.i() == hVar) {
                hVar = i;
            } else {
                hVar2 = hVar;
            }
        }
        return hVar2;
    }

    public void L0() {
        h a0 = a0();
        if (a0 == null || !(a0 instanceof i) || !((i) a0()).j2()) {
            int size = this.d0.size();
            for (int i = 0; i < size; i++) {
                ((e) this.d0.get(i)).z();
            }
        }
    }

    public void L1(boolean z, boolean z2, boolean z3, boolean z4) {
        if (this.P == -1) {
            if (z3 && !z4) {
                this.P = 0;
            } else if (!z3 && z4) {
                this.P = 1;
                if (this.j0 == -1) {
                    this.Q = 1.0f / this.Q;
                }
            }
        }
        if (this.P == 0 && (!this.V.q() || !this.X.q())) {
            this.P = 1;
        } else if (this.P == 1 && !(this.U.q() && this.W.q())) {
            this.P = 0;
        }
        if (this.P == -1 && !(this.V.q() && this.X.q() && this.U.q() && this.W.q())) {
            if (this.V.q() && this.X.q()) {
                this.P = 0;
            } else if (this.U.q() && this.W.q()) {
                this.Q = 1.0f / this.Q;
                this.P = 1;
            }
        }
        if (this.P == -1) {
            if (z && !z2) {
                this.P = 0;
            } else if (!z && z2) {
                this.Q = 1.0f / this.Q;
                this.P = 1;
            }
        }
        if (this.P == -1) {
            int i = this.H;
            if (i > 0 && this.K == 0) {
                this.P = 0;
            } else if (i == 0 && this.K > 0) {
                this.Q = 1.0f / this.Q;
                this.P = 1;
            }
        }
        if (this.P == -1 && z && z2) {
            this.Q = 1.0f / this.Q;
            this.P = 1;
        }
    }

    public int M() {
        return this.T0;
    }

    public void M0(int i) {
        h a0 = a0();
        if (a0 == null || !(a0 instanceof i) || !((i) a0()).j2()) {
            int size = this.d0.size();
            for (int i2 = 0; i2 < size; i2++) {
                e eVar = (e) this.d0.get(i2);
                if (i == eVar.e()) {
                    if (eVar.y()) {
                        y1(z);
                    } else {
                        i1(z);
                    }
                    eVar.z();
                }
            }
        }
    }

    public void M1() {
        int i = this.k0;
        int i2 = this.l0;
        int i3 = this.g0 + i;
        int i4 = this.h0 + i2;
        this.o0 = i;
        this.p0 = i2;
        this.q0 = i3 - i;
        this.r0 = i4 - i2;
    }

    public c N() {
        return this.e0[0];
    }

    public void N0() {
        for (int i = 0; i < 6; i++) {
            this.c0[i].k().g();
        }
    }

    public void N1(e eVar) {
        int S = eVar.S(this.U);
        int S2 = eVar.S(this.V);
        int S3 = eVar.S(this.W);
        int S4 = eVar.S(this.X);
        int i = S4 - S2;
        if (S3 - S < 0 || i < 0 || S == Integer.MIN_VALUE || S == Integer.MAX_VALUE || S2 == Integer.MIN_VALUE || S2 == Integer.MAX_VALUE || S3 == Integer.MIN_VALUE || S3 == Integer.MAX_VALUE || S4 == Integer.MIN_VALUE || S4 == Integer.MAX_VALUE) {
            S4 = 0;
            S = 0;
            S2 = 0;
            S3 = 0;
        }
        e1(S, S2, S3, S4);
    }

    public int O() {
        return this.p0 + this.r0;
    }

    public void O0(b.f.a.c cVar) {
        this.U.A(cVar);
        this.V.A(cVar);
        this.W.A(cVar);
        this.X.A(cVar);
        this.Y.A(cVar);
        this.b0.A(cVar);
        this.Z.A(cVar);
        this.a0.A(cVar);
    }

    public void O1() {
        for (int i = 0; i < 6; i++) {
            this.c0[i].k().s();
        }
    }

    public int P() {
        return this.o0 + this.q0;
    }

    public void P0() {
    }

    int Q() {
        return this.o0;
    }

    public void Q0(int i) {
        this.u0 = i;
    }

    int R() {
        return this.p0;
    }

    public void R0(Object obj) {
        this.B0 = obj;
    }

    public int S() {
        return s0();
    }

    public void S0(int i) {
        if (i >= 0) {
            this.C0 = i;
        } else {
            this.C0 = 0;
        }
    }

    public int T(int i) {
        return i == 0 ? p0() : i == 1 ? J() : 0;
    }

    public void T0(String str) {
        this.E0 = str;
    }

    public int U() {
        return this.S[1];
    }

    public void U0(e eVar, String str) {
        this.E0 = str;
        b.f.a.h u = eVar.u(this.U);
        b.f.a.h u2 = eVar.u(this.V);
        b.f.a.h u3 = eVar.u(this.W);
        b.f.a.h u4 = eVar.u(this.X);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(str);
        stringBuilder.append(".left");
        u.h(stringBuilder.toString());
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(str);
        stringBuilder2.append(".top");
        u2.h(stringBuilder2.toString());
        stringBuilder2 = new StringBuilder();
        stringBuilder2.append(str);
        stringBuilder2.append(".right");
        u3.h(stringBuilder2.toString());
        stringBuilder2 = new StringBuilder();
        stringBuilder2.append(str);
        stringBuilder2.append(".bottom");
        u4.h(stringBuilder2.toString());
        if (this.u0 > 0) {
            b.f.a.h u5 = eVar.u(this.Y);
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append(str);
            stringBuilder2.append(".baseline");
            u5.h(stringBuilder2.toString());
        }
    }

    public int V() {
        return this.S[0];
    }

    public void V0(int i, int i2) {
        this.g0 = i;
        int i3 = this.v0;
        if (i < i3) {
            this.g0 = i3;
        }
        this.h0 = i2;
        i = this.w0;
        if (i2 < i) {
            this.h0 = i;
        }
    }

    public int W() {
        return this.w0;
    }

    public void W0(float f, int i) {
        this.i0 = f;
        this.j0 = i;
    }

    public int X() {
        return this.v0;
    }

    public void X0(String str) {
        if (str == null || str.length() == 0) {
            this.i0 = 0.0f;
            return;
        }
        float parseFloat;
        int i = -1;
        int length = str.length();
        int indexOf = str.indexOf(44);
        int i2 = 0;
        if (indexOf > 0 && indexOf < length - 1) {
            String substring = str.substring(0, indexOf);
            if (substring.equalsIgnoreCase(b.m.b.a.w4)) {
                i = 0;
            } else if (substring.equalsIgnoreCase("H")) {
                i = 1;
            }
            i2 = indexOf + 1;
        }
        indexOf = str.indexOf(58);
        if (indexOf < 0 || indexOf >= length - 1) {
            str = str.substring(i2);
            if (str.length() > 0) {
                parseFloat = Float.parseFloat(str);
            }
        } else {
            String substring2 = str.substring(i2, indexOf);
            str = str.substring(indexOf + 1);
            if (substring2.length() > 0 && str.length() > 0) {
                try {
                    float parseFloat2 = Float.parseFloat(substring2);
                    parseFloat = Float.parseFloat(str);
                    if (parseFloat2 > 0.0f && parseFloat > 0.0f) {
                        parseFloat = i == 1 ? Math.abs(parseFloat / parseFloat2) : Math.abs(parseFloat2 / parseFloat);
                    }
                } catch (NumberFormatException unused) {
                    parseFloat = 0.0f;
                }
            }
        }
        if (parseFloat > 0.0f) {
            this.i0 = parseFloat;
            this.j0 = i;
        }
    }

    public int Y() {
        int i = this.h0;
        if (this.e0[1] != c.MATCH_CONSTRAINT) {
            return i;
        }
        if (this.F == 1) {
            i = Math.max(this.K, i);
        } else {
            i = this.K;
            if (i > 0) {
                this.h0 = i;
            } else {
                i = 0;
            }
        }
        int i2 = this.L;
        return (i2 <= 0 || i2 >= i) ? i : i2;
    }

    public void Y0(int i) {
        this.r0 = i;
    }

    public int Z() {
        int i = this.g0;
        if (this.e0[0] != c.MATCH_CONSTRAINT) {
            return i;
        }
        if (this.E == 1) {
            i = Math.max(this.H, i);
        } else {
            i = this.H;
            if (i > 0) {
                this.g0 = i;
            } else {
                i = 0;
            }
        }
        int i2 = this.I;
        return (i2 <= 0 || i2 >= i) ? i : i2;
    }

    public void Z0(int i, int i2) {
        i -= this.s0;
        this.o0 = i;
        i2 -= this.t0;
        this.p0 = i2;
        this.k0 = i;
        this.l0 = i2;
    }

    public h a0() {
        return this.f0;
    }

    public void a1(int i) {
        this.q0 = i;
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:153:0x029e  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:152:0x0295  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:157:0x02ac  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:156:0x02a4  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:164:0x030c  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:160:0x02e3  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:167:0x0316  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:152:0x0295  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:153:0x029e  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:156:0x02a4  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:157:0x02ac  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:160:0x02e3  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:164:0x030c  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:167:0x0316  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:147:0x028b  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:141:0x0256  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:153:0x029e  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:152:0x0295  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:157:0x02ac  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:156:0x02a4  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:164:0x030c  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:160:0x02e3  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:167:0x0316  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:122:0x0222  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:113:0x01bb  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:126:0x0234  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:125:0x0233 A:{RETURN} */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:103:0x0196  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:99:0x018c  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:107:0x01a2  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:113:0x01bb  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:122:0x0222  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:125:0x0233 A:{RETURN} */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:126:0x0234  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:99:0x018c  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:103:0x0196  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:107:0x01a2  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:122:0x0222  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:113:0x01bb  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:126:0x0234  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:125:0x0233 A:{RETURN} */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:103:0x0196  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:99:0x018c  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:107:0x01a2  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:113:0x01bb  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:122:0x0222  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:125:0x0233 A:{RETURN} */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:126:0x0234  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:99:0x018c  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:103:0x0196  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:107:0x01a2  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:122:0x0222  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:113:0x01bb  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:126:0x0234  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:125:0x0233 A:{RETURN} */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:103:0x0196  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:99:0x018c  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:107:0x01a2  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:113:0x01bb  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:122:0x0222  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:125:0x0233 A:{RETURN} */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:126:0x0234  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:99:0x018c  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:103:0x0196  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:107:0x01a2  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:122:0x0222  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:113:0x01bb  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:126:0x0234  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:125:0x0233 A:{RETURN} */
    public void b(b.f.a.e r42) {
        /*
        r41 = this;
        r15 = r41;
        r14 = r42;
        r0 = r15.U;
        r21 = r14.u(r0);
        r0 = r15.W;
        r10 = r14.u(r0);
        r0 = r15.V;
        r6 = r14.u(r0);
        r0 = r15.X;
        r4 = r14.u(r0);
        r0 = r15.Y;
        r3 = r14.u(r0);
        r0 = r15.f0;
        r1 = 8;
        r2 = 1;
        r13 = 0;
        if (r0 == 0) goto L_0x00af;
    L_0x002a:
        if (r0 == 0) goto L_0x0036;
    L_0x002c:
        r5 = r0.e0;
        r5 = r5[r13];
        r7 = b.f.a.i.h.c.WRAP_CONTENT;
        if (r5 != r7) goto L_0x0036;
    L_0x0034:
        r5 = 1;
        goto L_0x0037;
    L_0x0036:
        r5 = 0;
    L_0x0037:
        if (r0 == 0) goto L_0x0043;
    L_0x0039:
        r0 = r0.e0;
        r0 = r0[r2];
        r7 = b.f.a.i.h.c.WRAP_CONTENT;
        if (r0 != r7) goto L_0x0043;
    L_0x0041:
        r0 = 1;
        goto L_0x0044;
    L_0x0043:
        r0 = 0;
    L_0x0044:
        r7 = r15.x0(r13);
        if (r7 == 0) goto L_0x0053;
    L_0x004a:
        r7 = r15.f0;
        r7 = (b.f.a.i.i) r7;
        r7.Z1(r15, r13);
        r7 = 1;
        goto L_0x0057;
    L_0x0053:
        r7 = r41.A0();
    L_0x0057:
        r8 = r15.x0(r2);
        if (r8 == 0) goto L_0x0066;
    L_0x005d:
        r8 = r15.f0;
        r8 = (b.f.a.i.i) r8;
        r8.Z1(r15, r2);
        r8 = 1;
        goto L_0x006a;
    L_0x0066:
        r8 = r41.B0();
    L_0x006a:
        if (r5 == 0) goto L_0x0087;
    L_0x006c:
        r9 = r15.D0;
        if (r9 == r1) goto L_0x0087;
    L_0x0070:
        r9 = r15.U;
        r9 = r9.i;
        if (r9 != 0) goto L_0x0087;
    L_0x0076:
        r9 = r15.W;
        r9 = r9.i;
        if (r9 != 0) goto L_0x0087;
    L_0x007c:
        r9 = r15.f0;
        r9 = r9.W;
        r9 = r14.u(r9);
        r14.k(r9, r10, r13, r2);
    L_0x0087:
        if (r0 == 0) goto L_0x00a8;
    L_0x0089:
        r9 = r15.D0;
        if (r9 == r1) goto L_0x00a8;
    L_0x008d:
        r9 = r15.V;
        r9 = r9.i;
        if (r9 != 0) goto L_0x00a8;
    L_0x0093:
        r9 = r15.X;
        r9 = r9.i;
        if (r9 != 0) goto L_0x00a8;
    L_0x0099:
        r9 = r15.Y;
        if (r9 != 0) goto L_0x00a8;
    L_0x009d:
        r9 = r15.f0;
        r9 = r9.X;
        r9 = r14.u(r9);
        r14.k(r9, r4, r13, r2);
    L_0x00a8:
        r12 = r0;
        r0 = r5;
        r16 = r7;
        r22 = r8;
        goto L_0x00b5;
    L_0x00af:
        r0 = 0;
        r12 = 0;
        r16 = 0;
        r22 = 0;
    L_0x00b5:
        r5 = r15.g0;
        r7 = r15.v0;
        if (r5 >= r7) goto L_0x00bc;
    L_0x00bb:
        goto L_0x00bd;
    L_0x00bc:
        r7 = r5;
    L_0x00bd:
        r8 = r15.h0;
        r9 = r15.w0;
        if (r8 >= r9) goto L_0x00c4;
    L_0x00c3:
        goto L_0x00c5;
    L_0x00c4:
        r9 = r8;
    L_0x00c5:
        r11 = r15.e0;
        r1 = r11[r13];
        r13 = b.f.a.i.h.c.MATCH_CONSTRAINT;
        r20 = r3;
        if (r1 == r13) goto L_0x00d1;
    L_0x00cf:
        r1 = 1;
        goto L_0x00d2;
    L_0x00d1:
        r1 = 0;
    L_0x00d2:
        r3 = r11[r2];
        if (r3 == r13) goto L_0x00d8;
    L_0x00d6:
        r3 = 1;
        goto L_0x00d9;
    L_0x00d8:
        r3 = 0;
    L_0x00d9:
        r2 = r15.j0;
        r15.P = r2;
        r24 = r4;
        r4 = r15.i0;
        r15.Q = r4;
        r25 = r6;
        r6 = r15.E;
        r19 = r7;
        r7 = r15.F;
        r26 = 0;
        r27 = 4;
        r28 = r10;
        r26 = (r4 > r26 ? 1 : (r4 == r26 ? 0 : -1));
        if (r26 <= 0) goto L_0x0177;
    L_0x00f5:
        r10 = r15.D0;
        r29 = r9;
        r9 = 8;
        if (r10 == r9) goto L_0x0179;
    L_0x00fd:
        r9 = 0;
        r10 = r11[r9];
        if (r10 != r13) goto L_0x0105;
    L_0x0102:
        if (r6 != 0) goto L_0x0105;
    L_0x0104:
        r6 = 3;
    L_0x0105:
        r10 = 1;
        r9 = r11[r10];
        if (r9 != r13) goto L_0x010d;
    L_0x010a:
        if (r7 != 0) goto L_0x010d;
    L_0x010c:
        r7 = 3;
    L_0x010d:
        r9 = 0;
        r14 = r11[r9];
        if (r14 != r13) goto L_0x011f;
    L_0x0112:
        r9 = r11[r10];
        if (r9 != r13) goto L_0x011f;
    L_0x0116:
        r9 = 3;
        if (r6 != r9) goto L_0x0120;
    L_0x0119:
        if (r7 != r9) goto L_0x0120;
    L_0x011b:
        r15.L1(r0, r12, r1, r3);
        goto L_0x016c;
    L_0x011f:
        r9 = 3;
    L_0x0120:
        r1 = 0;
        r3 = r11[r1];
        if (r3 != r13) goto L_0x0143;
    L_0x0125:
        if (r6 != r9) goto L_0x0143;
    L_0x0127:
        r15.P = r1;
        r1 = (float) r8;
        r4 = r4 * r1;
        r1 = (int) r4;
        r3 = 1;
        r2 = r11[r3];
        r10 = r1;
        if (r2 == r13) goto L_0x013c;
    L_0x0133:
        r31 = r7;
        r18 = 0;
        r27 = 0;
        r30 = 4;
        goto L_0x0183;
    L_0x013c:
        r30 = r6;
        r31 = r7;
        r18 = 0;
        goto L_0x0174;
    L_0x0143:
        r3 = 1;
        r1 = r11[r3];
        if (r1 != r13) goto L_0x016c;
    L_0x0148:
        r1 = 3;
        if (r7 != r1) goto L_0x016c;
    L_0x014b:
        r15.P = r3;
        r1 = -1;
        if (r2 != r1) goto L_0x0155;
    L_0x0150:
        r1 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r1 = r1 / r4;
        r15.Q = r1;
    L_0x0155:
        r1 = r15.Q;
        r2 = (float) r5;
        r1 = r1 * r2;
        r1 = (int) r1;
        r18 = 0;
        r2 = r11[r18];
        r29 = r1;
        r30 = r6;
        if (r2 == r13) goto L_0x0170;
    L_0x0165:
        r10 = r19;
        r27 = 0;
        r31 = 4;
        goto L_0x0183;
    L_0x016c:
        r18 = 0;
        r30 = r6;
    L_0x0170:
        r31 = r7;
        r10 = r19;
    L_0x0174:
        r27 = 1;
        goto L_0x0183;
    L_0x0177:
        r29 = r9;
    L_0x0179:
        r18 = 0;
        r30 = r6;
        r31 = r7;
        r10 = r19;
        r27 = 0;
    L_0x0183:
        r1 = r15.G;
        r1[r18] = r30;
        r2 = 1;
        r1[r2] = r31;
        if (r27 == 0) goto L_0x0196;
    L_0x018c:
        r1 = r15.P;
        r14 = -1;
        if (r1 == 0) goto L_0x0193;
    L_0x0191:
        if (r1 != r14) goto L_0x0197;
    L_0x0193:
        r26 = 1;
        goto L_0x0199;
    L_0x0196:
        r14 = -1;
    L_0x0197:
        r26 = 0;
    L_0x0199:
        r1 = r15.e0;
        r2 = 0;
        r1 = r1[r2];
        r6 = b.f.a.i.h.c.WRAP_CONTENT;
        if (r1 != r6) goto L_0x01a9;
    L_0x01a2:
        r1 = r15 instanceof b.f.a.i.i;
        if (r1 == 0) goto L_0x01a9;
    L_0x01a6:
        r32 = 1;
        goto L_0x01ab;
    L_0x01a9:
        r32 = 0;
    L_0x01ab:
        r1 = r15.b0;
        r1 = r1.q();
        r2 = 1;
        r23 = r1 ^ 1;
        r1 = r15.A;
        r4 = 2;
        r33 = 0;
        if (r1 == r4) goto L_0x0222;
    L_0x01bb:
        r1 = r15.f0;
        if (r1 == 0) goto L_0x01ca;
    L_0x01bf:
        r1 = r1.W;
        r3 = r42;
        r1 = r3.u(r1);
        r34 = r1;
        goto L_0x01ce;
    L_0x01ca:
        r3 = r42;
        r34 = r33;
    L_0x01ce:
        r1 = r15.f0;
        if (r1 == 0) goto L_0x01db;
    L_0x01d2:
        r1 = r1.U;
        r1 = r3.u(r1);
        r35 = r1;
        goto L_0x01dd;
    L_0x01db:
        r35 = r33;
    L_0x01dd:
        r1 = r15.e0;
        r13 = 0;
        r5 = r1[r13];
        r7 = r15.U;
        r8 = r15.W;
        r9 = r15.k0;
        r11 = r15.v0;
        r1 = r15.S;
        r1 = r1[r13];
        r36 = r12;
        r12 = r1;
        r1 = r15.z0;
        r13 = r1;
        r1 = r15.H;
        r17 = r1;
        r1 = r15.I;
        r18 = r1;
        r1 = r15.J;
        r19 = r1;
        r37 = r0;
        r0 = r41;
        r1 = r42;
        r2 = r37;
        r38 = r20;
        r3 = r35;
        r4 = r34;
        r40 = r6;
        r39 = r25;
        r6 = r32;
        r25 = r28;
        r14 = r26;
        r15 = r16;
        r16 = r30;
        r20 = r23;
        r0.e(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20);
        goto L_0x022c;
    L_0x0222:
        r40 = r6;
        r36 = r12;
        r38 = r20;
        r39 = r25;
        r25 = r28;
    L_0x022c:
        r15 = r41;
        r0 = r15.B;
        r1 = 2;
        if (r0 != r1) goto L_0x0234;
    L_0x0233:
        return;
    L_0x0234:
        r0 = r15.e0;
        r14 = 1;
        r0 = r0[r14];
        r1 = r40;
        if (r0 != r1) goto L_0x0243;
    L_0x023d:
        r0 = r15 instanceof b.f.a.i.i;
        if (r0 == 0) goto L_0x0243;
    L_0x0241:
        r6 = 1;
        goto L_0x0244;
    L_0x0243:
        r6 = 0;
    L_0x0244:
        if (r27 == 0) goto L_0x0250;
    L_0x0246:
        r0 = r15.P;
        if (r0 == r14) goto L_0x024d;
    L_0x024a:
        r1 = -1;
        if (r0 != r1) goto L_0x0250;
    L_0x024d:
        r16 = 1;
        goto L_0x0252;
    L_0x0250:
        r16 = 0;
    L_0x0252:
        r0 = r15.u0;
        if (r0 <= 0) goto L_0x028b;
    L_0x0256:
        r0 = r15.Y;
        r0 = r0.k();
        r0 = r0.e;
        if (r0 != r14) goto L_0x026c;
    L_0x0260:
        r0 = r15.Y;
        r0 = r0.k();
        r10 = r42;
        r0.i(r10);
        goto L_0x028d;
    L_0x026c:
        r10 = r42;
        r0 = r41.u();
        r1 = 6;
        r2 = r38;
        r4 = r39;
        r10.e(r2, r4, r0, r1);
        r0 = r15.Y;
        r0 = r0.i;
        if (r0 == 0) goto L_0x028f;
    L_0x0280:
        r0 = r10.u(r0);
        r3 = 0;
        r10.e(r2, r0, r3, r1);
        r20 = 0;
        goto L_0x0291;
    L_0x028b:
        r10 = r42;
    L_0x028d:
        r4 = r39;
    L_0x028f:
        r20 = r23;
    L_0x0291:
        r0 = r15.f0;
        if (r0 == 0) goto L_0x029e;
    L_0x0295:
        r0 = r0.X;
        r0 = r10.u(r0);
        r23 = r0;
        goto L_0x02a0;
    L_0x029e:
        r23 = r33;
    L_0x02a0:
        r0 = r15.f0;
        if (r0 == 0) goto L_0x02ac;
    L_0x02a4:
        r0 = r0.V;
        r0 = r10.u(r0);
        r3 = r0;
        goto L_0x02ae;
    L_0x02ac:
        r3 = r33;
    L_0x02ae:
        r0 = r15.e0;
        r5 = r0[r14];
        r7 = r15.V;
        r8 = r15.X;
        r9 = r15.l0;
        r11 = r15.w0;
        r0 = r15.S;
        r12 = r0[r14];
        r13 = r15.A0;
        r0 = r15.K;
        r17 = r0;
        r0 = r15.L;
        r18 = r0;
        r0 = r15.M;
        r19 = r0;
        r0 = r41;
        r1 = r42;
        r2 = r36;
        r26 = r4;
        r4 = r23;
        r10 = r29;
        r14 = r16;
        r15 = r22;
        r16 = r31;
        r0.e(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20);
        if (r27 == 0) goto L_0x030c;
    L_0x02e3:
        r6 = 6;
        r7 = r41;
        r0 = r7.P;
        r1 = 1;
        if (r0 != r1) goto L_0x02fb;
    L_0x02eb:
        r5 = r7.Q;
        r0 = r42;
        r1 = r24;
        r2 = r26;
        r3 = r25;
        r4 = r21;
        r0.n(r1, r2, r3, r4, r5, r6);
        goto L_0x030e;
    L_0x02fb:
        r5 = r7.Q;
        r6 = 6;
        r0 = r42;
        r1 = r25;
        r2 = r21;
        r3 = r24;
        r4 = r26;
        r0.n(r1, r2, r3, r4, r5, r6);
        goto L_0x030e;
    L_0x030c:
        r7 = r41;
    L_0x030e:
        r0 = r7.b0;
        r0 = r0.q();
        if (r0 == 0) goto L_0x0336;
    L_0x0316:
        r0 = r7.b0;
        r0 = r0.o();
        r0 = r0.i();
        r1 = r7.T;
        r2 = 1119092736; // 0x42b40000 float:90.0 double:5.529052754E-315;
        r1 = r1 + r2;
        r1 = (double) r1;
        r1 = java.lang.Math.toRadians(r1);
        r1 = (float) r1;
        r2 = r7.b0;
        r2 = r2.g();
        r3 = r42;
        r3.b(r7, r0, r1, r2);
    L_0x0336:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.f.a.i.h.b(b.f.a.e):void");
    }

    int b0(int i) {
        return i == 0 ? this.m0 : i == 1 ? this.n0 : 0;
    }

    public void b1(int i) {
        i -= this.s0;
        this.o0 = i;
        this.k0 = i;
    }

    public boolean c() {
        return this.D0 != 8;
    }

    public p c0() {
        if (this.D == null) {
            this.D = new p();
        }
        return this.D;
    }

    public void c1(int i) {
        i -= this.t0;
        this.p0 = i;
        this.l0 = i;
    }

    public void d(int i) {
        m.a(i, this);
    }

    public p d0() {
        if (this.C == null) {
            this.C = new p();
        }
        return this.C;
    }

    public void d1(int i, int i2, int i3) {
        if (i3 == 0) {
            k1(i, i2);
        } else if (i3 == 1) {
            A1(i, i2);
        }
        this.R0 = true;
    }

    public int e0() {
        return s0() + this.g0;
    }

    public void e1(int i, int i2, int i3, int i4) {
        i3 -= i;
        i4 -= i2;
        this.k0 = i;
        this.l0 = i2;
        if (this.D0 == 8) {
            this.g0 = 0;
            this.h0 = 0;
            return;
        }
        c[] cVarArr = this.e0;
        c cVar = cVarArr[0];
        c cVar2 = c.FIXED;
        if (cVar == cVar2) {
            i2 = this.g0;
            if (i3 < i2) {
                i3 = i2;
            }
        }
        if (cVarArr[1] == cVar2) {
            i = this.h0;
            if (i4 < i) {
                i4 = i;
            }
        }
        this.g0 = i3;
        this.h0 = i4;
        i = this.w0;
        if (i4 < i) {
            this.h0 = i;
        }
        i = this.v0;
        if (i3 < i) {
            this.g0 = i;
        }
        this.R0 = true;
    }

    public void f(d dVar, h hVar, d dVar2) {
        h(dVar, hVar, dVar2, 0, b.f.a.i.e.c.STRONG);
    }

    public s f0() {
        h hVar = this;
        while (hVar.a0() != null) {
            hVar = hVar.a0();
        }
        return hVar instanceof s ? (s) hVar : null;
    }

    public void f1(d dVar, int i) {
        int i2 = a.a[dVar.ordinal()];
        if (i2 == 1) {
            this.U.k = i;
        } else if (i2 == 2) {
            this.V.k = i;
        } else if (i2 == 3) {
            this.W.k = i;
        } else if (i2 == 4) {
            this.X.k = i;
        }
    }

    public void g(d dVar, h hVar, d dVar2, int i) {
        h(dVar, hVar, dVar2, i, b.f.a.i.e.c.STRONG);
    }

    protected int g0() {
        return this.k0 + this.s0;
    }

    public void g1(int i) {
        this.h0 = i;
        int i2 = this.w0;
        if (i < i2) {
            this.h0 = i2;
        }
    }

    public void h(d dVar, h hVar, d dVar2, int i, b.f.a.i.e.c cVar) {
        i(dVar, hVar, dVar2, i, cVar, 0);
    }

    protected int h0() {
        return this.l0 + this.t0;
    }

    public void h1(boolean z) {
        this.O = z;
    }

    public void i(d dVar, h hVar, d dVar2, int i, b.f.a.i.e.c cVar, int i2) {
        d dVar3 = dVar;
        h hVar2 = hVar;
        d dVar4 = dVar2;
        int i3 = i2;
        d dVar5 = d.CENTER;
        int i4 = 0;
        d dVar6;
        e s;
        e s2;
        d dVar7;
        h hVar3;
        b.f.a.i.e.c cVar2;
        int i5;
        if (dVar3 != dVar5) {
            e s3;
            e s4;
            d dVar8 = d.CENTER_X;
            if (dVar3 == dVar8) {
                dVar6 = d.LEFT;
                if (dVar4 == dVar6 || dVar4 == d.RIGHT) {
                    s = s(dVar6);
                    s3 = hVar.s(dVar2);
                    s4 = s(d.RIGHT);
                    s.b(s3, 0, i3);
                    s4.b(s3, 0, i3);
                    s(dVar8).b(s3, 0, i3);
                    return;
                }
            }
            dVar6 = d.CENTER_Y;
            if (dVar3 == dVar6) {
                d dVar9 = d.TOP;
                if (dVar4 == dVar9 || dVar4 == d.BOTTOM) {
                    s = hVar.s(dVar2);
                    s(dVar9).b(s, 0, i3);
                    s(d.BOTTOM).b(s, 0, i3);
                    s(dVar6).b(s, 0, i3);
                    return;
                }
            }
            if (dVar3 == dVar8 && dVar4 == dVar8) {
                dVar3 = d.LEFT;
                s(dVar3).b(hVar2.s(dVar3), 0, i3);
                dVar3 = d.RIGHT;
                s(dVar3).b(hVar2.s(dVar3), 0, i3);
                s(dVar8).b(hVar.s(dVar2), 0, i3);
            } else if (dVar3 == dVar6 && dVar4 == dVar6) {
                dVar3 = d.TOP;
                s(dVar3).b(hVar2.s(dVar3), 0, i3);
                dVar3 = d.BOTTOM;
                s(dVar3).b(hVar2.s(dVar3), 0, i3);
                s(dVar6).b(hVar.s(dVar2), 0, i3);
            } else {
                s4 = s(dVar);
                e s5 = hVar.s(dVar2);
                if (s4.x(s5)) {
                    d dVar10 = d.BASELINE;
                    if (dVar3 == dVar10) {
                        s = s(d.TOP);
                        s2 = s(d.BOTTOM);
                        if (s != null) {
                            s.z();
                        }
                        if (s2 != null) {
                            s2.z();
                        }
                    } else {
                        if (dVar3 == d.TOP || dVar3 == d.BOTTOM) {
                            s2 = s(dVar10);
                            if (s2 != null) {
                                s2.z();
                            }
                            s2 = s(dVar5);
                            if (s2.o() != s5) {
                                s2.z();
                            }
                            s = s(dVar).h();
                            s2 = s(dVar6);
                            if (s2.q()) {
                                s.z();
                                s2.z();
                            }
                        } else if (dVar3 == d.LEFT || dVar3 == d.RIGHT) {
                            s3 = s(dVar5);
                            if (s3.o() != s5) {
                                s3.z();
                            }
                            s = s(dVar).h();
                            s2 = s(dVar8);
                            if (s2.q()) {
                                s.z();
                                s2.z();
                            }
                        }
                        i4 = i;
                    }
                    s4.d(s5, i4, cVar, i3);
                    s5.i().n(s4.i());
                }
            }
        } else if (dVar4 == dVar5) {
            Object obj;
            dVar7 = d.LEFT;
            s = s(dVar7);
            dVar4 = d.RIGHT;
            s2 = s(dVar4);
            d dVar11 = d.TOP;
            e s6 = s(dVar11);
            d dVar12 = d.BOTTOM;
            e s7 = s(dVar12);
            Object obj2 = 1;
            if ((s == null || !s.q()) && (s2 == null || !s2.q())) {
                hVar3 = hVar;
                cVar2 = cVar;
                dVar3 = dVar12;
                i5 = i2;
                i(dVar7, hVar3, dVar7, 0, cVar2, i5);
                i(dVar4, hVar3, dVar4, 0, cVar2, i5);
                obj = 1;
            } else {
                dVar3 = dVar12;
                obj = null;
            }
            if ((s6 == null || !s6.q()) && (s7 == null || !s7.q())) {
                hVar3 = hVar;
                cVar2 = cVar;
                i5 = i2;
                i(dVar11, hVar3, dVar11, 0, cVar2, i5);
                i(dVar3, hVar3, dVar3, 0, cVar2, i5);
            } else {
                obj2 = null;
            }
            if (obj != null && obj2 != null) {
                s(dVar5).b(hVar2.s(dVar5), 0, i3);
            } else if (obj != null) {
                dVar3 = d.CENTER_X;
                s(dVar3).b(hVar2.s(dVar3), 0, i3);
            } else if (obj2 != null) {
                dVar3 = d.CENTER_Y;
                s(dVar3).b(hVar2.s(dVar3), 0, i3);
            }
        } else {
            dVar6 = d.LEFT;
            if (dVar4 == dVar6 || dVar4 == d.RIGHT) {
                i(dVar6, hVar, dVar2, 0, cVar, i2);
                try {
                    i(d.RIGHT, hVar, dVar2, 0, cVar, i2);
                    s(dVar5).b(hVar.s(dVar2), 0, i3);
                } catch (Throwable th) {
                    Throwable th2 = th;
                }
            } else {
                dVar6 = d.TOP;
                if (dVar4 == dVar6 || dVar4 == d.BOTTOM) {
                    hVar3 = hVar;
                    dVar7 = dVar2;
                    cVar2 = cVar;
                    i5 = i2;
                    i(dVar6, hVar3, dVar7, 0, cVar2, i5);
                    i(d.BOTTOM, hVar3, dVar7, 0, cVar2, i5);
                    s(dVar5).b(hVar.s(dVar2), 0, i3);
                }
            }
        }
    }

    public int i0() {
        return t0();
    }

    public void i1(float f) {
        this.z0 = f;
    }

    public void j(e eVar, e eVar2, int i) {
        l(eVar, eVar2, i, b.f.a.i.e.c.STRONG, 0);
    }

    public String j0() {
        return this.F0;
    }

    public void j1(int i) {
        this.T0 = i;
    }

    public void k(e eVar, e eVar2, int i, int i2) {
        l(eVar, eVar2, i, b.f.a.i.e.c.STRONG, i2);
    }

    public float k0() {
        return this.A0;
    }

    public void k1(int i, int i2) {
        this.k0 = i;
        i2 -= i;
        this.g0 = i2;
        i = this.v0;
        if (i2 < i) {
            this.g0 = i;
        }
    }

    public void l(e eVar, e eVar2, int i, b.f.a.i.e.c cVar, int i2) {
        if (eVar.i() == this) {
            i(eVar.p(), eVar2.i(), eVar2.p(), i, cVar, i2);
        }
    }

    public h l0() {
        if (!B0()) {
            return null;
        }
        h hVar = this;
        h hVar2 = null;
        while (hVar2 == null && hVar != null) {
            e s = hVar.s(d.TOP);
            s = s == null ? null : s.o();
            h i = s == null ? null : s.i();
            if (i == a0()) {
                return hVar;
            }
            e o = i == null ? null : i.s(d.BOTTOM).o();
            if (o == null || o.i() == hVar) {
                hVar = i;
            } else {
                hVar2 = hVar;
            }
        }
        return hVar2;
    }

    public void l1(c cVar) {
        this.e0[0] = cVar;
        if (cVar == c.WRAP_CONTENT) {
            F1(this.x0);
        }
    }

    public void m(h hVar, float f, int i) {
        d dVar = d.CENTER;
        w0(dVar, hVar, dVar, i, 0);
        this.T = f;
    }

    public int m0() {
        return this.U0;
    }

    public void m1(int i, int i2, int i3, float f) {
        this.E = i;
        this.H = i2;
        this.I = i3;
        this.J = f;
        if (f < 1.0f && i == 0) {
            this.E = 2;
        }
    }

    public void n(h hVar) {
    }

    public c n0() {
        return this.e0[1];
    }

    public void n1(float f) {
        this.X0[0] = f;
    }

    public void o(e eVar) {
        eVar.u(this.U);
        eVar.u(this.V);
        eVar.u(this.W);
        eVar.u(this.X);
        if (this.u0 > 0) {
            eVar.u(this.Y);
        }
    }

    public int o0() {
        return this.D0;
    }

    public void o1(int i, int i2) {
        if (i2 == 0) {
            F1(i);
        } else if (i2 == 1) {
            g1(i);
        }
    }

    public void p(h hVar) {
        ArrayList t = t();
        int size = t.size();
        for (int i = 0; i < size; i++) {
            e eVar = (e) t.get(i);
            if (eVar.q() && eVar.o().i() == hVar && eVar.e() == 2) {
                eVar.z();
            }
        }
    }

    public int p0() {
        return this.D0 == 8 ? 0 : this.g0;
    }

    public void p1(int i) {
        this.S[1] = i;
    }

    public void q(h hVar) {
        ArrayList t = t();
        int size = t.size();
        for (int i = 0; i < size; i++) {
            e eVar = (e) t.get(i);
            if (eVar.q() && eVar.o().i() == hVar) {
                eVar.z();
            }
        }
    }

    public int q0() {
        return this.y0;
    }

    public void q1(int i) {
        this.S[0] = i;
    }

    public void r() {
        int i = this.k0;
        int i2 = this.l0;
        int i3 = this.g0 + i;
        int i4 = this.h0 + i2;
        this.o0 = i;
        this.p0 = i2;
        this.q0 = i3 - i;
        this.r0 = i4 - i2;
    }

    public int r0() {
        return this.x0;
    }

    public void r1(int i) {
        if (i < 0) {
            this.w0 = 0;
        } else {
            this.w0 = i;
        }
    }

    public e s(d dVar) {
        switch (a.a[dVar.ordinal()]) {
            case 1:
                return this.U;
            case 2:
                return this.V;
            case 3:
                return this.W;
            case 4:
                return this.X;
            case 5:
                return this.Y;
            case 6:
                return this.b0;
            case 7:
                return this.Z;
            case 8:
                return this.a0;
            case 9:
                return null;
            default:
                throw new AssertionError(dVar.name());
        }
    }

    public int s0() {
        return this.k0;
    }

    public void s1(int i) {
        if (i < 0) {
            this.v0 = 0;
        } else {
            this.v0 = i;
        }
    }

    public ArrayList<e> t() {
        return this.d0;
    }

    public int t0() {
        return this.l0;
    }

    public void t1(int i, int i2) {
        this.s0 = i;
        this.t0 = i2;
    }

    public String toString() {
        StringBuilder stringBuilder;
        String stringBuilder2;
        StringBuilder stringBuilder3 = new StringBuilder();
        String str = " ";
        String str2 = "";
        if (this.F0 != null) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("type: ");
            stringBuilder.append(this.F0);
            stringBuilder.append(str);
            stringBuilder2 = stringBuilder.toString();
        } else {
            stringBuilder2 = str2;
        }
        stringBuilder3.append(stringBuilder2);
        if (this.E0 != null) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("id: ");
            stringBuilder.append(this.E0);
            stringBuilder.append(str);
            str2 = stringBuilder.toString();
        }
        stringBuilder3.append(str2);
        stringBuilder3.append("(");
        stringBuilder3.append(this.k0);
        stringBuilder3.append(", ");
        stringBuilder3.append(this.l0);
        stringBuilder3.append(") - (");
        stringBuilder3.append(this.g0);
        stringBuilder2 = " x ";
        stringBuilder3.append(stringBuilder2);
        stringBuilder3.append(this.h0);
        stringBuilder3.append(") wrap: (");
        stringBuilder3.append(this.x0);
        stringBuilder3.append(stringBuilder2);
        stringBuilder3.append(this.y0);
        stringBuilder3.append(")");
        return stringBuilder3.toString();
    }

    public int u() {
        return this.u0;
    }

    public boolean u0(h hVar) {
        h a0 = a0();
        if (a0 == hVar) {
            return true;
        }
        if (a0 == hVar.a0()) {
            return false;
        }
        while (a0 != null) {
            if (a0 == hVar || a0 == hVar.a0()) {
                return true;
            }
            a0 = a0.a0();
        }
        return false;
    }

    public void u1(int i, int i2) {
        this.k0 = i;
        this.l0 = i2;
    }

    public float v(int i) {
        return i == 0 ? this.z0 : i == 1 ? this.A0 : -1.0f;
    }

    public boolean v0() {
        return this.u0 > 0;
    }

    public void v1(h hVar) {
        this.f0 = hVar;
    }

    public int w() {
        return t0() + this.h0;
    }

    public void w0(d dVar, h hVar, d dVar2, int i, int i2) {
        s(dVar).c(hVar.s(dVar2), i, i2, b.f.a.i.e.c.STRONG, 0, true);
    }

    void w1(int i, int i2) {
        if (i2 == 0) {
            this.m0 = i;
        } else if (i2 == 1) {
            this.n0 = i;
        }
    }

    public Object x() {
        return this.B0;
    }

    public void x1(String str) {
        this.F0 = str;
    }

    public int y() {
        return this.C0;
    }

    public boolean y0() {
        return this.U.k().e == 1 && this.W.k().e == 1 && this.V.k().e == 1 && this.X.k().e == 1;
    }

    public void y1(float f) {
        this.A0 = f;
    }

    public String z() {
        return this.E0;
    }

    public boolean z0() {
        return this.O;
    }

    public void z1(int i) {
        this.U0 = i;
    }
}
