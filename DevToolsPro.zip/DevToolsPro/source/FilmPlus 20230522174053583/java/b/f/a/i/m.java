package b.f.a.i;

import b.f.a.e;
import b.f.a.i.h.c;

public class m {
    public static final int a = 0;
    public static final int b = 1;
    public static final int c = 2;
    public static final int d = 4;
    public static final int e = 8;
    public static final int f = 16;
    public static final int g = 32;
    public static final int h = 7;
    static boolean[] i = new boolean[3];
    static final int j = 0;
    static final int k = 1;
    static final int l = 2;

    static void a(int i, h hVar) {
        h hVar2 = hVar;
        hVar.O1();
        q k = hVar2.U.k();
        q k2 = hVar2.V.k();
        q k3 = hVar2.W.k();
        q k4 = hVar2.X.k();
        Object obj = (i & 8) == 8 ? 1 : null;
        c cVar = hVar2.e0[0];
        c cVar2 = c.MATCH_CONSTRAINT;
        Object obj2 = (cVar == cVar2 && d(hVar2, 0)) ? 1 : null;
        if (!(k.r == 4 || k3.r == 4)) {
            if (hVar2.e0[0] == c.FIXED || (obj2 != null && hVar.o0() == 8)) {
                e eVar = hVar2.U.i;
                if (eVar == null && hVar2.W.i == null) {
                    k.r(1);
                    k3.r(1);
                    if (obj != null) {
                        k3.l(k, 1, hVar.d0());
                    } else {
                        k3.k(k, hVar.p0());
                    }
                } else if (eVar != null && hVar2.W.i == null) {
                    k.r(1);
                    k3.r(1);
                    if (obj != null) {
                        k3.l(k, 1, hVar.d0());
                    } else {
                        k3.k(k, hVar.p0());
                    }
                } else if (eVar == null && hVar2.W.i != null) {
                    k.r(1);
                    k3.r(1);
                    k.k(k3, -hVar.p0());
                    if (obj != null) {
                        k.l(k3, -1, hVar.d0());
                    } else {
                        k.k(k3, -hVar.p0());
                    }
                } else if (!(eVar == null || hVar2.W.i == null)) {
                    k.r(2);
                    k3.r(2);
                    if (obj != null) {
                        hVar.d0().a(k);
                        hVar.d0().a(k3);
                        k.q(k3, -1, hVar.d0());
                        k3.q(k, 1, hVar.d0());
                    } else {
                        k.p(k3, (float) (-hVar.p0()));
                        k3.p(k, (float) hVar.p0());
                    }
                }
            } else if (obj2 != null) {
                int p0 = hVar.p0();
                k.r(1);
                k3.r(1);
                e eVar2 = hVar2.U.i;
                if (eVar2 == null && hVar2.W.i == null) {
                    if (obj != null) {
                        k3.l(k, 1, hVar.d0());
                    } else {
                        k3.k(k, p0);
                    }
                } else if (eVar2 == null || hVar2.W.i != null) {
                    if (eVar2 != null || hVar2.W.i == null) {
                        if (!(eVar2 == null || hVar2.W.i == null)) {
                            if (obj != null) {
                                hVar.d0().a(k);
                                hVar.d0().a(k3);
                            }
                            if (hVar2.i0 == 0.0f) {
                                k.r(3);
                                k3.r(3);
                                k.p(k3, 0.0f);
                                k3.p(k, 0.0f);
                            } else {
                                k.r(2);
                                k3.r(2);
                                k.p(k3, (float) (-p0));
                                k3.p(k, (float) p0);
                                hVar2.F1(p0);
                            }
                        }
                    } else if (obj != null) {
                        k.l(k3, -1, hVar.d0());
                    } else {
                        k.k(k3, -p0);
                    }
                } else if (obj != null) {
                    k3.l(k, 1, hVar.d0());
                } else {
                    k3.k(k, p0);
                }
            }
        }
        Object obj3 = (hVar2.e0[1] == cVar2 && d(hVar2, 1)) ? 1 : null;
        if (k2.r != 4 && k4.r != 4) {
            if (hVar2.e0[1] == c.FIXED || (obj3 != null && hVar.o0() == 8)) {
                e eVar3 = hVar2.V.i;
                if (eVar3 == null && hVar2.X.i == null) {
                    k2.r(1);
                    k4.r(1);
                    if (obj != null) {
                        k4.l(k2, 1, hVar.c0());
                    } else {
                        k4.k(k2, hVar.J());
                    }
                    eVar3 = hVar2.Y;
                    if (eVar3.i != null) {
                        eVar3.k().r(1);
                        k2.j(1, hVar2.Y.k(), -hVar2.u0);
                    }
                } else if (eVar3 != null && hVar2.X.i == null) {
                    k2.r(1);
                    k4.r(1);
                    if (obj != null) {
                        k4.l(k2, 1, hVar.c0());
                    } else {
                        k4.k(k2, hVar.J());
                    }
                    if (hVar2.u0 > 0) {
                        hVar2.Y.k().j(1, k2, hVar2.u0);
                    }
                } else if (eVar3 == null && hVar2.X.i != null) {
                    k2.r(1);
                    k4.r(1);
                    if (obj != null) {
                        k2.l(k4, -1, hVar.c0());
                    } else {
                        k2.k(k4, -hVar.J());
                    }
                    if (hVar2.u0 > 0) {
                        hVar2.Y.k().j(1, k2, hVar2.u0);
                    }
                } else if (eVar3 != null && hVar2.X.i != null) {
                    k2.r(2);
                    k4.r(2);
                    if (obj != null) {
                        k2.q(k4, -1, hVar.c0());
                        k4.q(k2, 1, hVar.c0());
                        hVar.c0().a(k2);
                        hVar.d0().a(k4);
                    } else {
                        k2.p(k4, (float) (-hVar.J()));
                        k4.p(k2, (float) hVar.J());
                    }
                    if (hVar2.u0 > 0) {
                        hVar2.Y.k().j(1, k2, hVar2.u0);
                    }
                }
            } else if (obj3 != null) {
                int J = hVar.J();
                k2.r(1);
                k4.r(1);
                e eVar4 = hVar2.V.i;
                if (eVar4 == null && hVar2.X.i == null) {
                    if (obj != null) {
                        k4.l(k2, 1, hVar.c0());
                    } else {
                        k4.k(k2, J);
                    }
                } else if (eVar4 == null || hVar2.X.i != null) {
                    if (eVar4 != null || hVar2.X.i == null) {
                        if (eVar4 != null && hVar2.X.i != null) {
                            if (obj != null) {
                                hVar.c0().a(k2);
                                hVar.d0().a(k4);
                            }
                            if (hVar2.i0 == 0.0f) {
                                k2.r(3);
                                k4.r(3);
                                k2.p(k4, 0.0f);
                                k4.p(k2, 0.0f);
                                return;
                            }
                            k2.r(2);
                            k4.r(2);
                            k2.p(k4, (float) (-J));
                            k4.p(k2, (float) J);
                            hVar2.g1(J);
                            if (hVar2.u0 > 0) {
                                hVar2.Y.k().j(1, k2, hVar2.u0);
                            }
                        }
                    } else if (obj != null) {
                        k2.l(k4, -1, hVar.c0());
                    } else {
                        k2.k(k4, -J);
                    }
                } else if (obj != null) {
                    k4.l(k2, 1, hVar.c0());
                } else {
                    k4.k(k2, J);
                }
            }
        }
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:70:0x00fb  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:69:0x00f8  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:123:0x01ca  */
    /* DevToolsApp WARNING: Missing block: B:9:0x002a, code:
            if (r7 == 2) goto L_0x002c;
     */
    /* DevToolsApp WARNING: Missing block: B:11:0x002e, code:
            r7 = null;
     */
    /* DevToolsApp WARNING: Missing block: B:19:0x003c, code:
            if (r7 == 2) goto L_0x002c;
     */
    static boolean b(b.f.a.i.i r24, b.f.a.e r25, int r26, int r27, b.f.a.i.d r28) {
        /*
        r0 = r25;
        r1 = r26;
        r2 = r28;
        r3 = r2.a;
        r4 = r2.c;
        r5 = r2.b;
        r6 = r2.d;
        r7 = r2.e;
        r2 = r2.k;
        r8 = r24;
        r8 = r8.e0;
        r8 = r8[r1];
        r9 = b.f.a.i.h.c.WRAP_CONTENT;
        r8 = 2;
        r10 = 1;
        if (r1 != 0) goto L_0x0030;
    L_0x001e:
        r7 = r7.T0;
        if (r7 != 0) goto L_0x0024;
    L_0x0022:
        r11 = 1;
        goto L_0x0025;
    L_0x0024:
        r11 = 0;
    L_0x0025:
        if (r7 != r10) goto L_0x0029;
    L_0x0027:
        r12 = 1;
        goto L_0x002a;
    L_0x0029:
        r12 = 0;
    L_0x002a:
        if (r7 != r8) goto L_0x002e;
    L_0x002c:
        r7 = 1;
        goto L_0x003f;
    L_0x002e:
        r7 = 0;
        goto L_0x003f;
    L_0x0030:
        r7 = r7.U0;
        if (r7 != 0) goto L_0x0036;
    L_0x0034:
        r11 = 1;
        goto L_0x0037;
    L_0x0036:
        r11 = 0;
    L_0x0037:
        if (r7 != r10) goto L_0x003b;
    L_0x0039:
        r12 = 1;
        goto L_0x003c;
    L_0x003b:
        r12 = 0;
    L_0x003c:
        if (r7 != r8) goto L_0x002e;
    L_0x003e:
        goto L_0x002c;
    L_0x003f:
        r14 = r3;
        r10 = 0;
        r13 = 0;
        r15 = 0;
        r16 = 0;
        r17 = 0;
    L_0x0047:
        r8 = 8;
        if (r13 != 0) goto L_0x00fe;
    L_0x004b:
        r9 = r14.o0();
        if (r9 == r8) goto L_0x0095;
    L_0x0051:
        r15 = r15 + 1;
        if (r1 != 0) goto L_0x005a;
    L_0x0055:
        r9 = r14.p0();
        goto L_0x005e;
    L_0x005a:
        r9 = r14.J();
    L_0x005e:
        r9 = (float) r9;
        r16 = r16 + r9;
        if (r14 == r5) goto L_0x006e;
    L_0x0063:
        r9 = r14.c0;
        r9 = r9[r27];
        r9 = r9.g();
        r9 = (float) r9;
        r16 = r16 + r9;
    L_0x006e:
        if (r14 == r6) goto L_0x007d;
    L_0x0070:
        r9 = r14.c0;
        r19 = r27 + 1;
        r9 = r9[r19];
        r9 = r9.g();
        r9 = (float) r9;
        r16 = r16 + r9;
    L_0x007d:
        r9 = r14.c0;
        r9 = r9[r27];
        r9 = r9.g();
        r9 = (float) r9;
        r17 = r17 + r9;
        r9 = r14.c0;
        r19 = r27 + 1;
        r9 = r9[r19];
        r9 = r9.g();
        r9 = (float) r9;
        r17 = r17 + r9;
    L_0x0095:
        r9 = r14.c0;
        r9 = r9[r27];
        r9 = r14.o0();
        if (r9 == r8) goto L_0x00d3;
    L_0x009f:
        r8 = r14.e0;
        r8 = r8[r1];
        r9 = b.f.a.i.h.c.MATCH_CONSTRAINT;
        if (r8 != r9) goto L_0x00d3;
    L_0x00a7:
        r10 = r10 + 1;
        if (r1 != 0) goto L_0x00bb;
    L_0x00ab:
        r8 = r14.E;
        if (r8 == 0) goto L_0x00b1;
    L_0x00af:
        r8 = 0;
        return r8;
    L_0x00b1:
        r8 = 0;
        r9 = r14.H;
        if (r9 != 0) goto L_0x00ba;
    L_0x00b6:
        r9 = r14.I;
        if (r9 == 0) goto L_0x00ca;
    L_0x00ba:
        return r8;
    L_0x00bb:
        r8 = 0;
        r9 = r14.F;
        if (r9 == 0) goto L_0x00c1;
    L_0x00c0:
        return r8;
    L_0x00c1:
        r9 = r14.K;
        if (r9 != 0) goto L_0x00d2;
    L_0x00c5:
        r9 = r14.L;
        if (r9 == 0) goto L_0x00ca;
    L_0x00c9:
        goto L_0x00d2;
    L_0x00ca:
        r9 = r14.i0;
        r18 = 0;
        r9 = (r9 > r18 ? 1 : (r9 == r18 ? 0 : -1));
        if (r9 == 0) goto L_0x00d3;
    L_0x00d2:
        return r8;
    L_0x00d3:
        r8 = r14.c0;
        r9 = r27 + 1;
        r8 = r8[r9];
        r8 = r8.i;
        if (r8 == 0) goto L_0x00f5;
    L_0x00dd:
        r8 = r8.g;
        r9 = r8.c0;
        r20 = r8;
        r8 = r9[r27];
        r8 = r8.i;
        if (r8 == 0) goto L_0x00f5;
    L_0x00e9:
        r8 = r9[r27];
        r8 = r8.i;
        r8 = r8.g;
        if (r8 == r14) goto L_0x00f2;
    L_0x00f1:
        goto L_0x00f5;
    L_0x00f2:
        r9 = r20;
        goto L_0x00f6;
    L_0x00f5:
        r9 = 0;
    L_0x00f6:
        if (r9 == 0) goto L_0x00fb;
    L_0x00f8:
        r14 = r9;
        goto L_0x0047;
    L_0x00fb:
        r13 = 1;
        goto L_0x0047;
    L_0x00fe:
        r9 = r3.c0;
        r9 = r9[r27];
        r9 = r9.k();
        r13 = r4.c0;
        r19 = r27 + 1;
        r13 = r13[r19];
        r13 = r13.k();
        r8 = r9.n;
        if (r8 == 0) goto L_0x0379;
    L_0x0114:
        r21 = r3;
        r3 = r13.n;
        if (r3 != 0) goto L_0x011c;
    L_0x011a:
        goto L_0x0379;
    L_0x011c:
        r8 = r8.e;
        r0 = 1;
        if (r8 != r0) goto L_0x0377;
    L_0x0121:
        r3 = r3.e;
        if (r3 == r0) goto L_0x0127;
    L_0x0125:
        goto L_0x0377;
    L_0x0127:
        if (r10 <= 0) goto L_0x012d;
    L_0x0129:
        if (r10 == r15) goto L_0x012d;
    L_0x012b:
        r0 = 0;
        return r0;
    L_0x012d:
        if (r7 != 0) goto L_0x0136;
    L_0x012f:
        if (r11 != 0) goto L_0x0136;
    L_0x0131:
        if (r12 == 0) goto L_0x0134;
    L_0x0133:
        goto L_0x0136;
    L_0x0134:
        r0 = 0;
        goto L_0x014f;
    L_0x0136:
        if (r5 == 0) goto L_0x0142;
    L_0x0138:
        r0 = r5.c0;
        r0 = r0[r27];
        r0 = r0.g();
        r0 = (float) r0;
        goto L_0x0143;
    L_0x0142:
        r0 = 0;
    L_0x0143:
        if (r6 == 0) goto L_0x014f;
    L_0x0145:
        r3 = r6.c0;
        r3 = r3[r19];
        r3 = r3.g();
        r3 = (float) r3;
        r0 = r0 + r3;
    L_0x014f:
        r3 = r9.n;
        r3 = r3.q;
        r6 = r13.n;
        r6 = r6.q;
        r8 = (r3 > r6 ? 1 : (r3 == r6 ? 0 : -1));
        if (r8 >= 0) goto L_0x015d;
    L_0x015b:
        r6 = r6 - r3;
        goto L_0x015f;
    L_0x015d:
        r6 = r3 - r6;
    L_0x015f:
        r6 = r6 - r16;
        r22 = 1;
        if (r10 <= 0) goto L_0x0219;
    L_0x0165:
        if (r10 != r15) goto L_0x0219;
    L_0x0167:
        r0 = r14.a0();
        if (r0 == 0) goto L_0x017b;
    L_0x016d:
        r0 = r14.a0();
        r0 = r0.e0;
        r0 = r0[r1];
        r5 = b.f.a.i.h.c.WRAP_CONTENT;
        if (r0 != r5) goto L_0x017b;
    L_0x0179:
        r0 = 0;
        return r0;
    L_0x017b:
        r6 = r6 + r16;
        r6 = r6 - r17;
        r0 = r3;
        r3 = r21;
    L_0x0182:
        if (r3 == 0) goto L_0x0217;
    L_0x0184:
        r5 = b.f.a.e.d;
        if (r5 == 0) goto L_0x019a;
    L_0x0188:
        r7 = r5.B;
        r7 = r7 - r22;
        r5.B = r7;
        r7 = r5.s;
        r7 = r7 + r22;
        r5.s = r7;
        r7 = r5.y;
        r7 = r7 + r22;
        r5.y = r7;
    L_0x019a:
        r5 = r3.Z0;
        r5 = r5[r1];
        if (r5 != 0) goto L_0x01a6;
    L_0x01a0:
        if (r3 != r4) goto L_0x01a3;
    L_0x01a2:
        goto L_0x01a6;
    L_0x01a3:
        r8 = r25;
        goto L_0x0214;
    L_0x01a6:
        r7 = (float) r10;
        r7 = r6 / r7;
        r8 = 0;
        r11 = (r2 > r8 ? 1 : (r2 == r8 ? 0 : -1));
        if (r11 <= 0) goto L_0x01c0;
    L_0x01ae:
        r7 = r3.X0;
        r8 = r7[r1];
        r11 = -1082130432; // 0xffffffffbf800000 float:-1.0 double:NaN;
        r8 = (r8 > r11 ? 1 : (r8 == r11 ? 0 : -1));
        if (r8 != 0) goto L_0x01bb;
    L_0x01b8:
        r18 = 0;
        goto L_0x01c2;
    L_0x01bb:
        r7 = r7[r1];
        r7 = r7 * r6;
        r7 = r7 / r2;
    L_0x01c0:
        r18 = r7;
    L_0x01c2:
        r7 = r3.o0();
        r8 = 8;
        if (r7 != r8) goto L_0x01cc;
    L_0x01ca:
        r18 = 0;
    L_0x01cc:
        r7 = r3.c0;
        r7 = r7[r27];
        r7 = r7.g();
        r7 = (float) r7;
        r0 = r0 + r7;
        r7 = r3.c0;
        r7 = r7[r27];
        r7 = r7.k();
        r8 = r9.p;
        r7.n(r8, r0);
        r7 = r3.c0;
        r7 = r7[r19];
        r7 = r7.k();
        r8 = r9.p;
        r0 = r0 + r18;
        r7.n(r8, r0);
        r7 = r3.c0;
        r7 = r7[r27];
        r7 = r7.k();
        r8 = r25;
        r7.i(r8);
        r7 = r3.c0;
        r7 = r7[r19];
        r7 = r7.k();
        r7.i(r8);
        r3 = r3.c0;
        r3 = r3[r19];
        r3 = r3.g();
        r3 = (float) r3;
        r0 = r0 + r3;
    L_0x0214:
        r3 = r5;
        goto L_0x0182;
    L_0x0217:
        r0 = 1;
        return r0;
    L_0x0219:
        r8 = r25;
        r2 = 0;
        r2 = (r6 > r2 ? 1 : (r6 == r2 ? 0 : -1));
        if (r2 >= 0) goto L_0x0223;
    L_0x0220:
        r7 = 1;
        r11 = 0;
        r12 = 0;
    L_0x0223:
        if (r7 == 0) goto L_0x02a3;
    L_0x0225:
        r6 = r6 - r0;
        r2 = r21;
        r0 = r2.v(r1);
        r6 = r6 * r0;
        r3 = r3 + r6;
        r0 = r3;
    L_0x0230:
        r3 = r2;
        if (r3 == 0) goto L_0x02aa;
    L_0x0233:
        r2 = b.f.a.e.d;
        if (r2 == 0) goto L_0x0249;
    L_0x0237:
        r5 = r2.B;
        r5 = r5 - r22;
        r2.B = r5;
        r5 = r2.s;
        r5 = r5 + r22;
        r2.s = r5;
        r5 = r2.y;
        r5 = r5 + r22;
        r2.y = r5;
    L_0x0249:
        r2 = r3.Z0;
        r2 = r2[r1];
        if (r2 != 0) goto L_0x0251;
    L_0x024f:
        if (r3 != r4) goto L_0x0230;
    L_0x0251:
        if (r1 != 0) goto L_0x0258;
    L_0x0253:
        r5 = r3.p0();
        goto L_0x025c;
    L_0x0258:
        r5 = r3.J();
    L_0x025c:
        r5 = (float) r5;
        r6 = r3.c0;
        r6 = r6[r27];
        r6 = r6.g();
        r6 = (float) r6;
        r0 = r0 + r6;
        r6 = r3.c0;
        r6 = r6[r27];
        r6 = r6.k();
        r7 = r9.p;
        r6.n(r7, r0);
        r6 = r3.c0;
        r6 = r6[r19];
        r6 = r6.k();
        r7 = r9.p;
        r0 = r0 + r5;
        r6.n(r7, r0);
        r5 = r3.c0;
        r5 = r5[r27];
        r5 = r5.k();
        r5.i(r8);
        r5 = r3.c0;
        r5 = r5[r19];
        r5 = r5.k();
        r5.i(r8);
        r3 = r3.c0;
        r3 = r3[r19];
        r3 = r3.g();
        r3 = (float) r3;
        r0 = r0 + r3;
        goto L_0x0230;
    L_0x02a3:
        r2 = r21;
        if (r11 != 0) goto L_0x02ad;
    L_0x02a7:
        if (r12 == 0) goto L_0x02aa;
    L_0x02a9:
        goto L_0x02ad;
    L_0x02aa:
        r0 = 1;
        goto L_0x0376;
    L_0x02ad:
        if (r11 == 0) goto L_0x02b1;
    L_0x02af:
        r6 = r6 - r0;
        goto L_0x02b4;
    L_0x02b1:
        if (r12 == 0) goto L_0x02b4;
    L_0x02b3:
        goto L_0x02af;
    L_0x02b4:
        r0 = r15 + 1;
        r0 = (float) r0;
        r0 = r6 / r0;
        if (r12 == 0) goto L_0x02c6;
    L_0x02bb:
        r7 = 1;
        if (r15 <= r7) goto L_0x02c2;
    L_0x02be:
        r0 = r15 + -1;
        r0 = (float) r0;
        goto L_0x02c4;
    L_0x02c2:
        r0 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
    L_0x02c4:
        r0 = r6 / r0;
    L_0x02c6:
        r6 = r2.o0();
        r7 = 8;
        if (r6 == r7) goto L_0x02d1;
    L_0x02ce:
        r6 = r3 + r0;
        goto L_0x02d2;
    L_0x02d1:
        r6 = r3;
    L_0x02d2:
        if (r12 == 0) goto L_0x02e1;
    L_0x02d4:
        r7 = 1;
        if (r15 <= r7) goto L_0x02e1;
    L_0x02d7:
        r6 = r5.c0;
        r6 = r6[r27];
        r6 = r6.g();
        r6 = (float) r6;
        r6 = r6 + r3;
    L_0x02e1:
        if (r11 == 0) goto L_0x02ef;
    L_0x02e3:
        if (r5 == 0) goto L_0x02ef;
    L_0x02e5:
        r3 = r5.c0;
        r3 = r3[r27];
        r3 = r3.g();
        r3 = (float) r3;
        r6 = r6 + r3;
    L_0x02ef:
        r3 = r2;
        if (r3 == 0) goto L_0x02aa;
    L_0x02f2:
        r2 = b.f.a.e.d;
        if (r2 == 0) goto L_0x0308;
    L_0x02f6:
        r10 = r2.B;
        r10 = r10 - r22;
        r2.B = r10;
        r10 = r2.s;
        r10 = r10 + r22;
        r2.s = r10;
        r10 = r2.y;
        r10 = r10 + r22;
        r2.y = r10;
    L_0x0308:
        r2 = r3.Z0;
        r2 = r2[r1];
        if (r2 != 0) goto L_0x0314;
    L_0x030e:
        if (r3 != r4) goto L_0x0311;
    L_0x0310:
        goto L_0x0314;
    L_0x0311:
        r7 = 8;
        goto L_0x02ef;
    L_0x0314:
        if (r1 != 0) goto L_0x031b;
    L_0x0316:
        r7 = r3.p0();
        goto L_0x031f;
    L_0x031b:
        r7 = r3.J();
    L_0x031f:
        r7 = (float) r7;
        if (r3 == r5) goto L_0x032c;
    L_0x0322:
        r10 = r3.c0;
        r10 = r10[r27];
        r10 = r10.g();
        r10 = (float) r10;
        r6 = r6 + r10;
    L_0x032c:
        r10 = r3.c0;
        r10 = r10[r27];
        r10 = r10.k();
        r11 = r9.p;
        r10.n(r11, r6);
        r10 = r3.c0;
        r10 = r10[r19];
        r10 = r10.k();
        r11 = r9.p;
        r12 = r6 + r7;
        r10.n(r11, r12);
        r10 = r3.c0;
        r10 = r10[r27];
        r10 = r10.k();
        r10.i(r8);
        r10 = r3.c0;
        r10 = r10[r19];
        r10 = r10.k();
        r10.i(r8);
        r3 = r3.c0;
        r3 = r3[r19];
        r3 = r3.g();
        r3 = (float) r3;
        r7 = r7 + r3;
        r6 = r6 + r7;
        if (r2 == 0) goto L_0x0311;
    L_0x036b:
        r3 = r2.o0();
        r7 = 8;
        if (r3 == r7) goto L_0x02ef;
    L_0x0373:
        r6 = r6 + r0;
        goto L_0x02ef;
    L_0x0376:
        return r0;
    L_0x0377:
        r0 = 0;
        return r0;
    L_0x0379:
        r0 = 0;
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.f.a.i.m.b(b.f.a.i.i, b.f.a.e, int, int, b.f.a.i.d):boolean");
    }

    static void c(i iVar, e eVar, h hVar) {
        int i;
        c cVar = iVar.e0[0];
        c cVar2 = c.WRAP_CONTENT;
        if (cVar != cVar2 && hVar.e0[0] == c.MATCH_PARENT) {
            i = hVar.U.j;
            int p0 = iVar.p0() - hVar.W.j;
            e eVar2 = hVar.U;
            eVar2.o = eVar.u(eVar2);
            eVar2 = hVar.W;
            eVar2.o = eVar.u(eVar2);
            eVar.f(hVar.U.o, i);
            eVar.f(hVar.W.o, p0);
            hVar.A = 2;
            hVar.k1(i, p0);
        }
        if (iVar.e0[1] != cVar2 && hVar.e0[1] == c.MATCH_PARENT) {
            i = hVar.V.j;
            int J = iVar.J() - hVar.X.j;
            e eVar3 = hVar.V;
            eVar3.o = eVar.u(eVar3);
            eVar3 = hVar.X;
            eVar3.o = eVar.u(eVar3);
            eVar.f(hVar.V.o, i);
            eVar.f(hVar.X.o, J);
            if (hVar.u0 > 0 || hVar.o0() == 8) {
                eVar3 = hVar.Y;
                eVar3.o = eVar.u(eVar3);
                eVar.f(hVar.Y.o, hVar.u0 + i);
            }
            hVar.B = 2;
            hVar.A1(i, J);
        }
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:26:0x0039 A:{RETURN} */
    private static boolean d(b.f.a.i.h r6, int r7) {
        /*
        r0 = r6.e0;
        r1 = r0[r7];
        r2 = b.f.a.i.h.c.MATCH_CONSTRAINT;
        r3 = 0;
        if (r1 == r2) goto L_0x000a;
    L_0x0009:
        return r3;
    L_0x000a:
        r1 = r6.i0;
        r4 = 0;
        r5 = 1;
        r1 = (r1 > r4 ? 1 : (r1 == r4 ? 0 : -1));
        if (r1 == 0) goto L_0x001b;
    L_0x0012:
        if (r7 != 0) goto L_0x0015;
    L_0x0014:
        goto L_0x0016;
    L_0x0015:
        r5 = 0;
    L_0x0016:
        r6 = r0[r5];
        if (r6 != r2) goto L_0x001a;
    L_0x001a:
        return r3;
    L_0x001b:
        if (r7 != 0) goto L_0x002b;
    L_0x001d:
        r7 = r6.E;
        if (r7 == 0) goto L_0x0022;
    L_0x0021:
        return r3;
    L_0x0022:
        r7 = r6.H;
        if (r7 != 0) goto L_0x002a;
    L_0x0026:
        r6 = r6.I;
        if (r6 == 0) goto L_0x0039;
    L_0x002a:
        return r3;
    L_0x002b:
        r7 = r6.F;
        if (r7 == 0) goto L_0x0030;
    L_0x002f:
        return r3;
    L_0x0030:
        r7 = r6.K;
        if (r7 != 0) goto L_0x003a;
    L_0x0034:
        r6 = r6.L;
        if (r6 == 0) goto L_0x0039;
    L_0x0038:
        goto L_0x003a;
    L_0x0039:
        return r5;
    L_0x003a:
        return r3;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.f.a.i.m.d(b.f.a.i.h, int):boolean");
    }

    static void e(h hVar, int i, int i2) {
        int i3 = i * 2;
        int i4 = i3 + 1;
        hVar.c0[i3].k().p = hVar.a0().U.k();
        hVar.c0[i3].k().q = (float) i2;
        hVar.c0[i3].k().e = 1;
        hVar.c0[i4].k().p = hVar.c0[i3].k();
        hVar.c0[i4].k().q = (float) hVar.T(i);
        hVar.c0[i4].k().e = 1;
    }
}
