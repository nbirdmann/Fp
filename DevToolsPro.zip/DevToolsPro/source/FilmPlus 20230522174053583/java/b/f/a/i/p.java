package b.f.a.i;

public class p extends q {
    float f = 0.0f;

    public void g() {
        super.g();
        this.f = 0.0f;
    }

    public void i() {
        this.e = 2;
    }

    public void j(int i) {
        int i2 = this.e;
        if (i2 == 0 || this.f != ((float) i)) {
            this.f = (float) i;
            if (i2 == 1) {
                c();
            }
            b();
        }
    }
}
