package b.f.a.i;

import b.f.a.e;
import b.f.a.i.e.c;
import b.f.a.i.e.d;

public class f extends i {
    private a E1 = a.MIDDLE;

    public enum a {
        BEGIN,
        MIDDLE,
        END,
        TOP,
        VERTICAL_MIDDLE,
        BOTTOM,
        LEFT,
        RIGHT
    }

    public f(int i, int i2) {
        super(i, i2);
    }

    public f(int i, int i2, int i3, int i4) {
        super(i, i2, i3, i4);
    }

    public void b(e eVar) {
        if (this.c1.size() != 0) {
            c cVar;
            d dVar;
            int i = 0;
            int size = this.c1.size();
            h hVar = this;
            while (i < size) {
                d dVar2;
                h hVar2 = (h) this.c1.get(i);
                if (hVar != this) {
                    dVar2 = d.LEFT;
                    d dVar3 = d.RIGHT;
                    hVar2.f(dVar2, hVar, dVar3);
                    hVar.f(dVar3, hVar2, dVar2);
                } else {
                    c cVar2 = c.STRONG;
                    if (this.E1 == a.END) {
                        cVar2 = c.WEAK;
                    }
                    cVar = cVar2;
                    dVar = d.LEFT;
                    hVar2.h(dVar, hVar, dVar, 0, cVar);
                }
                dVar2 = d.TOP;
                hVar2.f(dVar2, this, dVar2);
                dVar2 = d.BOTTOM;
                hVar2.f(dVar2, this, dVar2);
                i++;
                hVar = hVar2;
            }
            if (hVar != this) {
                c cVar3 = c.STRONG;
                if (this.E1 == a.BEGIN) {
                    cVar3 = c.WEAK;
                }
                cVar = cVar3;
                dVar = d.RIGHT;
                hVar.h(dVar, this, dVar, 0, cVar);
            }
        }
        super.b(eVar);
    }
}
