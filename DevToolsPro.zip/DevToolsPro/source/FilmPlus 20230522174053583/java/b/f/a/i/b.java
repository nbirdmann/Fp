package b.f.a.i;

import b.f.a.e;
import b.f.a.f;
import b.f.a.h;
import b.f.a.i.h.c;
import java.util.ArrayList;

public class b extends l {
    public static final int e1 = 0;
    public static final int f1 = 1;
    public static final int g1 = 2;
    public static final int h1 = 3;
    private int i1 = 0;
    private ArrayList<o> j1 = new ArrayList(4);
    private boolean k1 = true;

    public void N0() {
        super.N0();
        this.j1.clear();
    }

    public void P0() {
        q k;
        int i = this.i1;
        float f = Float.MAX_VALUE;
        if (i != 0) {
            if (i == 1) {
                k = this.W.k();
            } else if (i == 2) {
                k = this.V.k();
            } else if (i == 3) {
                k = this.X.k();
            } else {
                return;
            }
            f = 0.0f;
        } else {
            k = this.U.k();
        }
        int size = this.j1.size();
        o oVar = null;
        int i2 = 0;
        while (i2 < size) {
            o oVar2 = (o) this.j1.get(i2);
            if (oVar2.e == 1) {
                float f2;
                o oVar3;
                int i3 = this.i1;
                if (i3 == 0 || i3 == 2) {
                    f2 = oVar2.q;
                    if (f2 < f) {
                        oVar3 = oVar2.p;
                    } else {
                        i2++;
                    }
                } else {
                    f2 = oVar2.q;
                    if (f2 > f) {
                        oVar3 = oVar2.p;
                    } else {
                        i2++;
                    }
                }
                oVar = oVar3;
                f = f2;
                i2++;
            } else {
                return;
            }
        }
        if (e.P() != null) {
            f P = e.P();
            P.z++;
        }
        k.p = oVar;
        k.q = f;
        k.b();
        i = this.i1;
        if (i == 0) {
            this.W.k().n(oVar, f);
        } else if (i == 1) {
            this.U.k().n(oVar, f);
        } else if (i == 2) {
            this.X.k().n(oVar, f);
        } else if (i == 3) {
            this.V.k().n(oVar, f);
        }
    }

    public boolean R1() {
        return this.k1;
    }

    public void S1(boolean z) {
        this.k1 = z;
    }

    public void T1(int i) {
        this.i1 = i;
    }

    public void b(e eVar) {
        e[] eVarArr;
        e[] eVarArr2 = this.c0;
        eVarArr2[0] = this.U;
        eVarArr2[2] = this.V;
        eVarArr2[1] = this.W;
        eVarArr2[3] = this.X;
        int i = 0;
        while (true) {
            eVarArr = this.c0;
            if (i >= eVarArr.length) {
                break;
            }
            eVarArr[i].o = eVar.u(eVarArr[i]);
            i++;
        }
        i = this.i1;
        if (i >= 0 && i < 4) {
            boolean z;
            e eVar2 = eVarArr[i];
            for (int i2 = 0; i2 < this.d1; i2++) {
                h hVar = this.c1[i2];
                if (this.k1 || hVar.c()) {
                    int i3 = this.i1;
                    if ((i3 != 0 && i3 != 1) || hVar.N() != c.MATCH_CONSTRAINT) {
                        i3 = this.i1;
                        if ((i3 == 2 || i3 == 3) && hVar.n0() == c.MATCH_CONSTRAINT) {
                        }
                    }
                    z = true;
                    break;
                }
            }
            z = false;
            int i4 = this.i1;
            if (i4 == 0 || i4 == 1 ? a0().N() != c.WRAP_CONTENT : a0().n0() != c.WRAP_CONTENT) {
                z = false;
            }
            for (i4 = 0; i4 < this.d1; i4++) {
                h hVar2 = this.c1[i4];
                if (this.k1 || hVar2.c()) {
                    h u = eVar.u(hVar2.c0[this.i1]);
                    e[] eVarArr3 = hVar2.c0;
                    int i5 = this.i1;
                    eVarArr3[i5].o = u;
                    if (i5 == 0 || i5 == 2) {
                        eVar.l(eVar2.o, u, z);
                    } else {
                        eVar.i(eVar2.o, u, z);
                    }
                }
            }
            i = this.i1;
            if (i == 0) {
                eVar.e(this.W.o, this.U.o, 0, 6);
                if (!z) {
                    eVar.e(this.U.o, this.f0.W.o, 0, 5);
                }
            } else if (i == 1) {
                eVar.e(this.U.o, this.W.o, 0, 6);
                if (!z) {
                    eVar.e(this.U.o, this.f0.U.o, 0, 5);
                }
            } else if (i == 2) {
                eVar.e(this.X.o, this.V.o, 0, 6);
                if (!z) {
                    eVar.e(this.V.o, this.f0.X.o, 0, 5);
                }
            } else if (i == 3) {
                eVar.e(this.V.o, this.X.o, 0, 6);
                if (!z) {
                    eVar.e(this.V.o, this.f0.V.o, 0, 5);
                }
            }
        }
    }

    public boolean c() {
        return true;
    }

    public void d(int i) {
        h hVar = this.f0;
        if (hVar != null && ((i) hVar).o2(2)) {
            q k;
            i = this.i1;
            if (i == 0) {
                k = this.U.k();
            } else if (i == 1) {
                k = this.W.k();
            } else if (i == 2) {
                k = this.V.k();
            } else if (i == 3) {
                k = this.X.k();
            } else {
                return;
            }
            k.r(5);
            int i2 = this.i1;
            if (i2 == 0 || i2 == 1) {
                this.V.k().n(null, 0.0f);
                this.X.k().n(null, 0.0f);
            } else {
                this.U.k().n(null, 0.0f);
                this.W.k().n(null, 0.0f);
            }
            this.j1.clear();
            for (i2 = 0; i2 < this.d1; i2++) {
                h hVar2 = this.c1[i2];
                if (this.k1 || hVar2.c()) {
                    int i3 = this.i1;
                    q k2 = i3 != 0 ? i3 != 1 ? i3 != 2 ? i3 != 3 ? null : hVar2.X.k() : hVar2.V.k() : hVar2.W.k() : hVar2.U.k();
                    if (k2 != null) {
                        this.j1.add(k2);
                        k2.a(k);
                    }
                }
            }
        }
    }
}
