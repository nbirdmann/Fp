package b.f.a.i;

import b.f.a.e;

class c {
    private static final boolean a = false;

    c() {
    }

    static void a(i iVar, e eVar, int i) {
        int i2;
        d[] dVarArr;
        int i3;
        int i4 = 0;
        if (i == 0) {
            i2 = iVar.p1;
            dVarArr = iVar.s1;
            i3 = i2;
            i2 = 0;
        } else {
            i2 = 2;
            i3 = iVar.q1;
            dVarArr = iVar.r1;
        }
        while (i4 < i3) {
            d dVar = dVarArr[i4];
            dVar.a();
            if (!iVar.o2(4)) {
                b(iVar, eVar, i, i2, dVar);
            } else if (!m.b(iVar, eVar, i, i2, dVar)) {
                b(iVar, eVar, i, i2, dVar);
            }
            i4++;
        }
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:282:0x0362 A:{SYNTHETIC} */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:186:0x0361  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:78:0x0145  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:81:0x0161  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:199:0x0381  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:249:0x0485  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:244:0x0450  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:259:0x04ad  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:258:0x04aa  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:263:0x04b6  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:262:0x04b3  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:265:0x04ba  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:270:0x04ca  */
    /* DevToolsApp WARNING: Missing block: B:13:0x002d, code:
            if (r8 == 2) goto L_0x003e;
     */
    /* DevToolsApp WARNING: Missing block: B:21:0x003c, code:
            if (r8 == 2) goto L_0x003e;
     */
    /* DevToolsApp WARNING: Missing block: B:23:0x0040, code:
            r5 = null;
     */
    static void b(b.f.a.i.i r37, b.f.a.e r38, int r39, int r40, b.f.a.i.d r41) {
        /*
        r0 = r37;
        r9 = r38;
        r1 = r41;
        r10 = r1.a;
        r11 = r1.c;
        r12 = r1.b;
        r13 = r1.d;
        r2 = r1.e;
        r3 = r1.k;
        r4 = r0.e0;
        r4 = r4[r39];
        r5 = b.f.a.i.h.c.WRAP_CONTENT;
        r7 = 1;
        if (r4 != r5) goto L_0x001d;
    L_0x001b:
        r4 = 1;
        goto L_0x001e;
    L_0x001d:
        r4 = 0;
    L_0x001e:
        r5 = 2;
        if (r39 != 0) goto L_0x0030;
    L_0x0021:
        r8 = r2.T0;
        if (r8 != 0) goto L_0x0027;
    L_0x0025:
        r14 = 1;
        goto L_0x0028;
    L_0x0027:
        r14 = 0;
    L_0x0028:
        if (r8 != r7) goto L_0x002c;
    L_0x002a:
        r15 = 1;
        goto L_0x002d;
    L_0x002c:
        r15 = 0;
    L_0x002d:
        if (r8 != r5) goto L_0x0040;
    L_0x002f:
        goto L_0x003e;
    L_0x0030:
        r8 = r2.U0;
        if (r8 != 0) goto L_0x0036;
    L_0x0034:
        r14 = 1;
        goto L_0x0037;
    L_0x0036:
        r14 = 0;
    L_0x0037:
        if (r8 != r7) goto L_0x003b;
    L_0x0039:
        r15 = 1;
        goto L_0x003c;
    L_0x003b:
        r15 = 0;
    L_0x003c:
        if (r8 != r5) goto L_0x0040;
    L_0x003e:
        r5 = 1;
        goto L_0x0041;
    L_0x0040:
        r5 = 0;
    L_0x0041:
        r7 = r10;
        r8 = 0;
    L_0x0043:
        r21 = 0;
        if (r8 != 0) goto L_0x0118;
    L_0x0047:
        r6 = r7.c0;
        r6 = r6[r40];
        if (r4 != 0) goto L_0x0053;
    L_0x004d:
        if (r5 == 0) goto L_0x0050;
    L_0x004f:
        goto L_0x0053;
    L_0x0050:
        r23 = 4;
        goto L_0x0055;
    L_0x0053:
        r23 = 1;
    L_0x0055:
        r24 = r6.g();
        r25 = r3;
        r3 = r6.i;
        if (r3 == 0) goto L_0x0067;
    L_0x005f:
        if (r7 == r10) goto L_0x0067;
    L_0x0061:
        r3 = r3.g();
        r24 = r24 + r3;
    L_0x0067:
        r3 = r24;
        if (r5 == 0) goto L_0x0075;
    L_0x006b:
        if (r7 == r10) goto L_0x0075;
    L_0x006d:
        if (r7 == r12) goto L_0x0075;
    L_0x006f:
        r24 = r8;
        r23 = r15;
        r8 = 6;
        goto L_0x0085;
    L_0x0075:
        if (r14 == 0) goto L_0x007f;
    L_0x0077:
        if (r4 == 0) goto L_0x007f;
    L_0x0079:
        r24 = r8;
        r23 = r15;
        r8 = 4;
        goto L_0x0085;
    L_0x007f:
        r24 = r8;
        r8 = r23;
        r23 = r15;
    L_0x0085:
        r15 = r6.i;
        if (r15 == 0) goto L_0x00ae;
    L_0x0089:
        if (r7 != r12) goto L_0x0098;
    L_0x008b:
        r26 = r14;
        r14 = r6.o;
        r15 = r15.o;
        r27 = r2;
        r2 = 5;
        r9.k(r14, r15, r3, r2);
        goto L_0x00a4;
    L_0x0098:
        r27 = r2;
        r26 = r14;
        r2 = r6.o;
        r14 = r15.o;
        r15 = 6;
        r9.k(r2, r14, r3, r15);
    L_0x00a4:
        r2 = r6.o;
        r6 = r6.i;
        r6 = r6.o;
        r9.e(r2, r6, r3, r8);
        goto L_0x00b2;
    L_0x00ae:
        r27 = r2;
        r26 = r14;
    L_0x00b2:
        if (r4 == 0) goto L_0x00e7;
    L_0x00b4:
        r2 = r7.o0();
        r3 = 8;
        if (r2 == r3) goto L_0x00d6;
    L_0x00bc:
        r2 = r7.e0;
        r2 = r2[r39];
        r3 = b.f.a.i.h.c.MATCH_CONSTRAINT;
        if (r2 != r3) goto L_0x00d6;
    L_0x00c4:
        r2 = r7.c0;
        r3 = r40 + 1;
        r3 = r2[r3];
        r3 = r3.o;
        r2 = r2[r40];
        r2 = r2.o;
        r6 = 5;
        r8 = 0;
        r9.k(r3, r2, r8, r6);
        goto L_0x00d7;
    L_0x00d6:
        r8 = 0;
    L_0x00d7:
        r2 = r7.c0;
        r2 = r2[r40];
        r2 = r2.o;
        r3 = r0.c0;
        r3 = r3[r40];
        r3 = r3.o;
        r6 = 6;
        r9.k(r2, r3, r8, r6);
    L_0x00e7:
        r2 = r7.c0;
        r3 = r40 + 1;
        r2 = r2[r3];
        r2 = r2.i;
        if (r2 == 0) goto L_0x0106;
    L_0x00f1:
        r2 = r2.g;
        r3 = r2.c0;
        r6 = r3[r40];
        r6 = r6.i;
        if (r6 == 0) goto L_0x0106;
    L_0x00fb:
        r3 = r3[r40];
        r3 = r3.i;
        r3 = r3.g;
        if (r3 == r7) goto L_0x0104;
    L_0x0103:
        goto L_0x0106;
    L_0x0104:
        r21 = r2;
    L_0x0106:
        if (r21 == 0) goto L_0x010d;
    L_0x0108:
        r7 = r21;
        r8 = r24;
        goto L_0x010e;
    L_0x010d:
        r8 = 1;
    L_0x010e:
        r15 = r23;
        r3 = r25;
        r14 = r26;
        r2 = r27;
        goto L_0x0043;
    L_0x0118:
        r27 = r2;
        r25 = r3;
        r26 = r14;
        r23 = r15;
        if (r13 == 0) goto L_0x0142;
    L_0x0122:
        r2 = r11.c0;
        r3 = r40 + 1;
        r6 = r2[r3];
        r6 = r6.i;
        if (r6 == 0) goto L_0x0142;
    L_0x012c:
        r6 = r13.c0;
        r6 = r6[r3];
        r7 = r6.o;
        r2 = r2[r3];
        r2 = r2.i;
        r2 = r2.o;
        r3 = r6.g();
        r3 = -r3;
        r6 = 5;
        r9.m(r7, r2, r3, r6);
        goto L_0x0143;
    L_0x0142:
        r6 = 5;
    L_0x0143:
        if (r4 == 0) goto L_0x015d;
    L_0x0145:
        r0 = r0.c0;
        r2 = r40 + 1;
        r0 = r0[r2];
        r0 = r0.o;
        r3 = r11.c0;
        r4 = r3[r2];
        r4 = r4.o;
        r2 = r3[r2];
        r2 = r2.g();
        r3 = 6;
        r9.k(r0, r4, r2, r3);
    L_0x015d:
        r0 = r1.h;
        if (r0 == 0) goto L_0x020c;
    L_0x0161:
        r2 = r0.size();
        r3 = 1;
        if (r2 <= r3) goto L_0x020c;
    L_0x0168:
        r4 = r1.n;
        if (r4 == 0) goto L_0x0174;
    L_0x016c:
        r4 = r1.p;
        if (r4 != 0) goto L_0x0174;
    L_0x0170:
        r4 = r1.j;
        r4 = (float) r4;
        goto L_0x0176;
    L_0x0174:
        r4 = r25;
    L_0x0176:
        r7 = 0;
        r14 = r21;
        r8 = 0;
        r29 = 0;
    L_0x017c:
        if (r8 >= r2) goto L_0x020c;
    L_0x017e:
        r15 = r0.get(r8);
        r15 = (b.f.a.i.h) r15;
        r3 = r15.X0;
        r3 = r3[r39];
        r19 = (r3 > r7 ? 1 : (r3 == r7 ? 0 : -1));
        if (r19 >= 0) goto L_0x01a8;
    L_0x018c:
        r3 = r1.p;
        if (r3 == 0) goto L_0x01a3;
    L_0x0190:
        r3 = r15.c0;
        r15 = r40 + 1;
        r15 = r3[r15];
        r15 = r15.o;
        r3 = r3[r40];
        r3 = r3.o;
        r6 = 4;
        r7 = 0;
        r9.e(r15, r3, r7, r6);
        r6 = 6;
        goto L_0x01be;
    L_0x01a3:
        r6 = 4;
        r3 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r7 = 0;
        goto L_0x01a9;
    L_0x01a8:
        r6 = 4;
    L_0x01a9:
        r20 = (r3 > r7 ? 1 : (r3 == r7 ? 0 : -1));
        if (r20 != 0) goto L_0x01c3;
    L_0x01ad:
        r3 = r15.c0;
        r15 = r40 + 1;
        r15 = r3[r15];
        r15 = r15.o;
        r3 = r3[r40];
        r3 = r3.o;
        r6 = 6;
        r7 = 0;
        r9.e(r15, r3, r7, r6);
    L_0x01be:
        r25 = r0;
        r17 = r2;
        goto L_0x0201;
    L_0x01c3:
        r6 = 6;
        r7 = 0;
        if (r14 == 0) goto L_0x01fa;
    L_0x01c7:
        r14 = r14.c0;
        r6 = r14[r40];
        r6 = r6.o;
        r17 = r40 + 1;
        r14 = r14[r17];
        r14 = r14.o;
        r7 = r15.c0;
        r25 = r0;
        r0 = r7[r40];
        r0 = r0.o;
        r7 = r7[r17];
        r7 = r7.o;
        r17 = r2;
        r2 = r38.v();
        r28 = r2;
        r30 = r4;
        r31 = r3;
        r32 = r6;
        r33 = r14;
        r34 = r0;
        r35 = r7;
        r28.l(r29, r30, r31, r32, r33, r34, r35);
        r9.d(r2);
        goto L_0x01fe;
    L_0x01fa:
        r25 = r0;
        r17 = r2;
    L_0x01fe:
        r29 = r3;
        r14 = r15;
    L_0x0201:
        r8 = r8 + 1;
        r2 = r17;
        r0 = r25;
        r3 = 1;
        r6 = 5;
        r7 = 0;
        goto L_0x017c;
    L_0x020c:
        if (r12 == 0) goto L_0x026e;
    L_0x020e:
        if (r12 == r13) goto L_0x0212;
    L_0x0210:
        if (r5 == 0) goto L_0x026e;
    L_0x0212:
        r0 = r10.c0;
        r1 = r0[r40];
        r2 = r11.c0;
        r3 = r40 + 1;
        r4 = r2[r3];
        r5 = r0[r40];
        r5 = r5.i;
        if (r5 == 0) goto L_0x022a;
    L_0x0222:
        r0 = r0[r40];
        r0 = r0.i;
        r0 = r0.o;
        r5 = r0;
        goto L_0x022c;
    L_0x022a:
        r5 = r21;
    L_0x022c:
        r0 = r2[r3];
        r0 = r0.i;
        if (r0 == 0) goto L_0x023a;
    L_0x0232:
        r0 = r2[r3];
        r0 = r0.i;
        r0 = r0.o;
        r6 = r0;
        goto L_0x023c;
    L_0x023a:
        r6 = r21;
    L_0x023c:
        if (r12 != r13) goto L_0x0244;
    L_0x023e:
        r0 = r12.c0;
        r1 = r0[r40];
        r4 = r0[r3];
    L_0x0244:
        if (r5 == 0) goto L_0x0496;
    L_0x0246:
        if (r6 == 0) goto L_0x0496;
    L_0x0248:
        if (r39 != 0) goto L_0x024f;
    L_0x024a:
        r0 = r27;
        r0 = r0.z0;
        goto L_0x0253;
    L_0x024f:
        r0 = r27;
        r0 = r0.A0;
    L_0x0253:
        r7 = r0;
        r3 = r1.g();
        r8 = r4.g();
        r1 = r1.o;
        r10 = r4.o;
        r14 = 5;
        r0 = r38;
        r2 = r5;
        r4 = r7;
        r5 = r6;
        r6 = r10;
        r7 = r8;
        r8 = r14;
        r0.c(r1, r2, r3, r4, r5, r6, r7, r8);
        goto L_0x0496;
    L_0x026e:
        if (r26 == 0) goto L_0x0366;
    L_0x0270:
        if (r12 == 0) goto L_0x0366;
    L_0x0272:
        r0 = r1.j;
        if (r0 <= 0) goto L_0x027d;
    L_0x0276:
        r1 = r1.i;
        if (r1 != r0) goto L_0x027d;
    L_0x027a:
        r16 = 1;
        goto L_0x027f;
    L_0x027d:
        r16 = 0;
    L_0x027f:
        r14 = r12;
        r15 = r14;
    L_0x0281:
        if (r14 == 0) goto L_0x0496;
    L_0x0283:
        r0 = r14.Z0;
        r0 = r0[r39];
        r8 = r0;
    L_0x0288:
        if (r8 == 0) goto L_0x0297;
    L_0x028a:
        r0 = r8.o0();
        r6 = 8;
        if (r0 != r6) goto L_0x0299;
    L_0x0292:
        r0 = r8.Z0;
        r8 = r0[r39];
        goto L_0x0288;
    L_0x0297:
        r6 = 8;
    L_0x0299:
        if (r8 != 0) goto L_0x02a6;
    L_0x029b:
        if (r14 != r13) goto L_0x029e;
    L_0x029d:
        goto L_0x02a6;
    L_0x029e:
        r17 = r8;
        r18 = 4;
        r20 = 6;
        goto L_0x0359;
    L_0x02a6:
        r0 = r14.c0;
        r0 = r0[r40];
        r1 = r0.o;
        r2 = r0.i;
        if (r2 == 0) goto L_0x02b3;
    L_0x02b0:
        r2 = r2.o;
        goto L_0x02b5;
    L_0x02b3:
        r2 = r21;
    L_0x02b5:
        if (r15 == r14) goto L_0x02c0;
    L_0x02b7:
        r2 = r15.c0;
        r3 = r40 + 1;
        r2 = r2[r3];
        r2 = r2.o;
        goto L_0x02d5;
    L_0x02c0:
        if (r14 != r12) goto L_0x02d5;
    L_0x02c2:
        if (r15 != r14) goto L_0x02d5;
    L_0x02c4:
        r2 = r10.c0;
        r3 = r2[r40];
        r3 = r3.i;
        if (r3 == 0) goto L_0x02d3;
    L_0x02cc:
        r2 = r2[r40];
        r2 = r2.i;
        r2 = r2.o;
        goto L_0x02d5;
    L_0x02d3:
        r2 = r21;
    L_0x02d5:
        r0 = r0.g();
        r3 = r14.c0;
        r4 = r40 + 1;
        r3 = r3[r4];
        r3 = r3.g();
        if (r8 == 0) goto L_0x02f7;
    L_0x02e5:
        r5 = r8.c0;
        r5 = r5[r40];
        r7 = r5.o;
        r6 = r14.c0;
        r6 = r6[r4];
        r6 = r6.o;
        r36 = r7;
        r7 = r6;
        r6 = r36;
        goto L_0x030a;
    L_0x02f7:
        r5 = r11.c0;
        r5 = r5[r4];
        r5 = r5.i;
        if (r5 == 0) goto L_0x0302;
    L_0x02ff:
        r6 = r5.o;
        goto L_0x0304;
    L_0x0302:
        r6 = r21;
    L_0x0304:
        r7 = r14.c0;
        r7 = r7[r4];
        r7 = r7.o;
    L_0x030a:
        if (r5 == 0) goto L_0x0311;
    L_0x030c:
        r5 = r5.g();
        r3 = r3 + r5;
    L_0x0311:
        if (r15 == 0) goto L_0x031c;
    L_0x0313:
        r5 = r15.c0;
        r5 = r5[r4];
        r5 = r5.g();
        r0 = r0 + r5;
    L_0x031c:
        if (r1 == 0) goto L_0x029e;
    L_0x031e:
        if (r2 == 0) goto L_0x029e;
    L_0x0320:
        if (r6 == 0) goto L_0x029e;
    L_0x0322:
        if (r7 == 0) goto L_0x029e;
    L_0x0324:
        if (r14 != r12) goto L_0x032e;
    L_0x0326:
        r0 = r12.c0;
        r0 = r0[r40];
        r0 = r0.g();
    L_0x032e:
        r5 = r0;
        if (r14 != r13) goto L_0x033c;
    L_0x0331:
        r0 = r13.c0;
        r0 = r0[r4];
        r0 = r0.g();
        r17 = r0;
        goto L_0x033e;
    L_0x033c:
        r17 = r3;
    L_0x033e:
        if (r16 == 0) goto L_0x0343;
    L_0x0340:
        r19 = 6;
        goto L_0x0345;
    L_0x0343:
        r19 = 4;
    L_0x0345:
        r4 = 1056964608; // 0x3f000000 float:0.5 double:5.222099017E-315;
        r0 = r38;
        r3 = r5;
        r5 = r6;
        r18 = 4;
        r20 = 6;
        r6 = r7;
        r7 = r17;
        r17 = r8;
        r8 = r19;
        r0.c(r1, r2, r3, r4, r5, r6, r7, r8);
    L_0x0359:
        r0 = r14.o0();
        r8 = 8;
        if (r0 == r8) goto L_0x0362;
    L_0x0361:
        r15 = r14;
    L_0x0362:
        r14 = r17;
        goto L_0x0281;
    L_0x0366:
        r8 = 8;
        r18 = 4;
        r20 = 6;
        if (r23 == 0) goto L_0x0496;
    L_0x036e:
        if (r12 == 0) goto L_0x0496;
    L_0x0370:
        r0 = r1.j;
        if (r0 <= 0) goto L_0x037b;
    L_0x0374:
        r1 = r1.i;
        if (r1 != r0) goto L_0x037b;
    L_0x0378:
        r16 = 1;
        goto L_0x037d;
    L_0x037b:
        r16 = 0;
    L_0x037d:
        r14 = r12;
        r15 = r14;
    L_0x037f:
        if (r14 == 0) goto L_0x0438;
    L_0x0381:
        r0 = r14.Z0;
        r0 = r0[r39];
    L_0x0385:
        if (r0 == 0) goto L_0x0392;
    L_0x0387:
        r1 = r0.o0();
        if (r1 != r8) goto L_0x0392;
    L_0x038d:
        r0 = r0.Z0;
        r0 = r0[r39];
        goto L_0x0385;
    L_0x0392:
        if (r14 == r12) goto L_0x0425;
    L_0x0394:
        if (r14 == r13) goto L_0x0425;
    L_0x0396:
        if (r0 == 0) goto L_0x0425;
    L_0x0398:
        if (r0 != r13) goto L_0x039d;
    L_0x039a:
        r7 = r21;
        goto L_0x039e;
    L_0x039d:
        r7 = r0;
    L_0x039e:
        r0 = r14.c0;
        r0 = r0[r40];
        r1 = r0.o;
        r2 = r0.i;
        if (r2 == 0) goto L_0x03aa;
    L_0x03a8:
        r2 = r2.o;
    L_0x03aa:
        r2 = r15.c0;
        r3 = r40 + 1;
        r2 = r2[r3];
        r2 = r2.o;
        r0 = r0.g();
        r4 = r14.c0;
        r4 = r4[r3];
        r4 = r4.g();
        if (r7 == 0) goto L_0x03d0;
    L_0x03c0:
        r5 = r7.c0;
        r5 = r5[r40];
        r6 = r5.o;
        r8 = r5.i;
        if (r8 == 0) goto L_0x03cd;
    L_0x03ca:
        r8 = r8.o;
        goto L_0x03e7;
    L_0x03cd:
        r8 = r21;
        goto L_0x03e7;
    L_0x03d0:
        r5 = r14.c0;
        r6 = r5[r3];
        r6 = r6.i;
        if (r6 == 0) goto L_0x03db;
    L_0x03d8:
        r8 = r6.o;
        goto L_0x03dd;
    L_0x03db:
        r8 = r21;
    L_0x03dd:
        r5 = r5[r3];
        r5 = r5.o;
        r36 = r8;
        r8 = r5;
        r5 = r6;
        r6 = r36;
    L_0x03e7:
        if (r5 == 0) goto L_0x03ee;
    L_0x03e9:
        r5 = r5.g();
        r4 = r4 + r5;
    L_0x03ee:
        r17 = r4;
        r4 = r15.c0;
        r3 = r4[r3];
        r3 = r3.g();
        r3 = r3 + r0;
        if (r16 == 0) goto L_0x03fe;
    L_0x03fb:
        r22 = 6;
        goto L_0x0400;
    L_0x03fe:
        r22 = 4;
    L_0x0400:
        if (r1 == 0) goto L_0x041c;
    L_0x0402:
        if (r2 == 0) goto L_0x041c;
    L_0x0404:
        if (r6 == 0) goto L_0x041c;
    L_0x0406:
        if (r8 == 0) goto L_0x041c;
    L_0x0408:
        r4 = 1056964608; // 0x3f000000 float:0.5 double:5.222099017E-315;
        r0 = r38;
        r5 = r6;
        r6 = r8;
        r19 = r7;
        r7 = r17;
        r17 = r15;
        r15 = 8;
        r8 = r22;
        r0.c(r1, r2, r3, r4, r5, r6, r7, r8);
        goto L_0x0422;
    L_0x041c:
        r19 = r7;
        r17 = r15;
        r15 = 8;
    L_0x0422:
        r0 = r19;
        goto L_0x0429;
    L_0x0425:
        r17 = r15;
        r15 = 8;
    L_0x0429:
        r1 = r14.o0();
        if (r1 == r15) goto L_0x0430;
    L_0x042f:
        goto L_0x0432;
    L_0x0430:
        r14 = r17;
    L_0x0432:
        r15 = r14;
        r8 = 8;
        r14 = r0;
        goto L_0x037f;
    L_0x0438:
        r0 = r12.c0;
        r0 = r0[r40];
        r1 = r10.c0;
        r1 = r1[r40];
        r1 = r1.i;
        r2 = r13.c0;
        r3 = r40 + 1;
        r10 = r2[r3];
        r2 = r11.c0;
        r2 = r2[r3];
        r14 = r2.i;
        if (r1 == 0) goto L_0x0485;
    L_0x0450:
        if (r12 == r13) goto L_0x045f;
    L_0x0452:
        r2 = r0.o;
        r1 = r1.o;
        r0 = r0.g();
        r15 = 5;
        r9.e(r2, r1, r0, r15);
        goto L_0x0486;
    L_0x045f:
        r15 = 5;
        if (r14 == 0) goto L_0x0486;
    L_0x0462:
        r2 = r0.o;
        r3 = r1.o;
        r4 = r0.g();
        r5 = 1056964608; // 0x3f000000 float:0.5 double:5.222099017E-315;
        r6 = r10.o;
        r7 = r14.o;
        r8 = r10.g();
        r16 = 5;
        r0 = r38;
        r1 = r2;
        r2 = r3;
        r3 = r4;
        r4 = r5;
        r5 = r6;
        r6 = r7;
        r7 = r8;
        r8 = r16;
        r0.c(r1, r2, r3, r4, r5, r6, r7, r8);
        goto L_0x0486;
    L_0x0485:
        r15 = 5;
    L_0x0486:
        if (r14 == 0) goto L_0x0496;
    L_0x0488:
        if (r12 == r13) goto L_0x0496;
    L_0x048a:
        r0 = r10.o;
        r1 = r14.o;
        r2 = r10.g();
        r2 = -r2;
        r9.e(r0, r1, r2, r15);
    L_0x0496:
        if (r26 != 0) goto L_0x049a;
    L_0x0498:
        if (r23 == 0) goto L_0x04f0;
    L_0x049a:
        if (r12 == 0) goto L_0x04f0;
    L_0x049c:
        r0 = r12.c0;
        r1 = r0[r40];
        r2 = r13.c0;
        r3 = r40 + 1;
        r2 = r2[r3];
        r4 = r1.i;
        if (r4 == 0) goto L_0x04ad;
    L_0x04aa:
        r4 = r4.o;
        goto L_0x04af;
    L_0x04ad:
        r4 = r21;
    L_0x04af:
        r5 = r2.i;
        if (r5 == 0) goto L_0x04b6;
    L_0x04b3:
        r5 = r5.o;
        goto L_0x04b8;
    L_0x04b6:
        r5 = r21;
    L_0x04b8:
        if (r11 == r13) goto L_0x04c8;
    L_0x04ba:
        r5 = r11.c0;
        r5 = r5[r3];
        r5 = r5.i;
        if (r5 == 0) goto L_0x04c6;
    L_0x04c2:
        r5 = r5.o;
        r21 = r5;
    L_0x04c6:
        r5 = r21;
    L_0x04c8:
        if (r12 != r13) goto L_0x04ce;
    L_0x04ca:
        r1 = r0[r40];
        r2 = r0[r3];
    L_0x04ce:
        if (r4 == 0) goto L_0x04f0;
    L_0x04d0:
        if (r5 == 0) goto L_0x04f0;
    L_0x04d2:
        r6 = 1056964608; // 0x3f000000 float:0.5 double:5.222099017E-315;
        r7 = r1.g();
        r0 = r13.c0;
        r0 = r0[r3];
        r8 = r0.g();
        r1 = r1.o;
        r10 = r2.o;
        r11 = 5;
        r0 = r38;
        r2 = r4;
        r3 = r7;
        r4 = r6;
        r6 = r10;
        r7 = r8;
        r8 = r11;
        r0.c(r1, r2, r3, r4, r5, r6, r7, r8);
    L_0x04f0:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.f.a.i.c.b(b.f.a.i.i, b.f.a.e, int, int, b.f.a.i.d):void");
    }
}
