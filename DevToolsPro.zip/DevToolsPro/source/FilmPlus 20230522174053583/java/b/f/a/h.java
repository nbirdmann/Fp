package b.f.a;

import java.util.Arrays;

public class h {
    private static final boolean a = false;
    public static final int b = 0;
    public static final int c = 1;
    public static final int d = 2;
    public static final int e = 3;
    public static final int f = 4;
    public static final int g = 5;
    public static final int h = 6;
    public static final int i = 7;
    private static int j = 1;
    private static int k = 1;
    private static int l = 1;
    private static int m = 1;
    private static int n = 1;
    static final int o = 7;
    private String p;
    public int q;
    int r;
    public int s;
    public float t;
    float[] u;
    b v;
    b[] w;
    int x;
    public int y;

    static /* synthetic */ class a {
        static final /* synthetic */ int[] a;

        /* DevToolsApp WARNING: Failed to process nested try/catch */
        /* DevToolsApp WARNING: Missing block: B:11:0x003e, code:
            return;
     */
        static {
            /*
            r0 = b.f.a.h.b.values();
            r0 = r0.length;
            r0 = new int[r0];
            a = r0;
            r1 = b.f.a.h.b.UNRESTRICTED;	 Catch:{ NoSuchFieldError -> 0x0012 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0012 }
            r2 = 1;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0012 }
        L_0x0012:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x001d }
            r1 = b.f.a.h.b.CONSTANT;	 Catch:{ NoSuchFieldError -> 0x001d }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x001d }
            r2 = 2;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x001d }
        L_0x001d:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x0028 }
            r1 = b.f.a.h.b.SLACK;	 Catch:{ NoSuchFieldError -> 0x0028 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0028 }
            r2 = 3;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0028 }
        L_0x0028:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x0033 }
            r1 = b.f.a.h.b.ERROR;	 Catch:{ NoSuchFieldError -> 0x0033 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0033 }
            r2 = 4;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0033 }
        L_0x0033:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x003e }
            r1 = b.f.a.h.b.UNKNOWN;	 Catch:{ NoSuchFieldError -> 0x003e }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x003e }
            r2 = 5;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x003e }
        L_0x003e:
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: b.f.a.h.a.<clinit>():void");
        }
    }

    public enum b {
        UNRESTRICTED,
        CONSTANT,
        SLACK,
        ERROR,
        UNKNOWN
    }

    public h(b bVar, String str) {
        this.q = -1;
        this.r = -1;
        this.s = 0;
        this.u = new float[7];
        this.w = new b[8];
        this.x = 0;
        this.y = 0;
        this.v = bVar;
    }

    public h(String str, b bVar) {
        this.q = -1;
        this.r = -1;
        this.s = 0;
        this.u = new float[7];
        this.w = new b[8];
        this.x = 0;
        this.y = 0;
        this.p = str;
        this.v = bVar;
    }

    private static String d(b bVar, String str) {
        StringBuilder stringBuilder;
        if (str != null) {
            stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append(k);
            return stringBuilder.toString();
        }
        int i = a.a[bVar.ordinal()];
        if (i == 1) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("U");
            i = l + 1;
            l = i;
            stringBuilder.append(i);
            return stringBuilder.toString();
        } else if (i == 2) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("C");
            i = m + 1;
            m = i;
            stringBuilder.append(i);
            return stringBuilder.toString();
        } else if (i == 3) {
            stringBuilder = new StringBuilder();
            stringBuilder.append(b.m.b.a.u4);
            i = j + 1;
            j = i;
            stringBuilder.append(i);
            return stringBuilder.toString();
        } else if (i == 4) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("e");
            i = k + 1;
            k = i;
            stringBuilder.append(i);
            return stringBuilder.toString();
        } else if (i == 5) {
            stringBuilder = new StringBuilder();
            stringBuilder.append(b.m.b.a.A4);
            i = n + 1;
            n = i;
            stringBuilder.append(i);
            return stringBuilder.toString();
        } else {
            throw new AssertionError(bVar.name());
        }
    }

    static void e() {
        k++;
    }

    public final void a(b bVar) {
        int i = 0;
        while (true) {
            int i2 = this.x;
            if (i >= i2) {
                b[] bVarArr = this.w;
                if (i2 >= bVarArr.length) {
                    this.w = (b[]) Arrays.copyOf(bVarArr, bVarArr.length * 2);
                }
                bVarArr = this.w;
                i2 = this.x;
                bVarArr[i2] = bVar;
                this.x = i2 + 1;
                return;
            } else if (this.w[i] != bVar) {
                i++;
            } else {
                return;
            }
        }
    }

    void b() {
        for (int i = 0; i < 7; i++) {
            this.u[i] = 0.0f;
        }
    }

    public String c() {
        return this.p;
    }

    public final void f(b bVar) {
        int i = this.x;
        for (int i2 = 0; i2 < i; i2++) {
            if (this.w[i2] == bVar) {
                for (int i3 = 0; i3 < (i - i2) - 1; i3++) {
                    b[] bVarArr = this.w;
                    int i4 = i2 + i3;
                    bVarArr[i4] = bVarArr[i4 + 1];
                }
                this.x--;
                return;
            }
        }
    }

    public void g() {
        this.p = null;
        this.v = b.UNKNOWN;
        this.s = 0;
        this.q = -1;
        this.r = -1;
        this.t = 0.0f;
        this.x = 0;
        this.y = 0;
    }

    public void h(String str) {
        this.p = str;
    }

    public void i(b bVar, String str) {
        this.v = bVar;
    }

    String j() {
        StringBuilder stringBuilder;
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(this);
        stringBuilder2.append("[");
        String stringBuilder3 = stringBuilder2.toString();
        Object obj = null;
        Object obj2 = 1;
        for (int i = 0; i < this.u.length; i++) {
            StringBuilder stringBuilder4 = new StringBuilder();
            stringBuilder4.append(stringBuilder3);
            stringBuilder4.append(this.u[i]);
            stringBuilder3 = stringBuilder4.toString();
            float[] fArr = this.u;
            if (fArr[i] > 0.0f) {
                obj = null;
            } else if (fArr[i] < 0.0f) {
                obj = 1;
            }
            if (fArr[i] != 0.0f) {
                obj2 = null;
            }
            if (i < fArr.length - 1) {
                stringBuilder4 = new StringBuilder();
                stringBuilder4.append(stringBuilder3);
                stringBuilder4.append(", ");
                stringBuilder3 = stringBuilder4.toString();
            } else {
                stringBuilder4 = new StringBuilder();
                stringBuilder4.append(stringBuilder3);
                stringBuilder4.append("] ");
                stringBuilder3 = stringBuilder4.toString();
            }
        }
        if (obj != null) {
            stringBuilder = new StringBuilder();
            stringBuilder.append(stringBuilder3);
            stringBuilder.append(" (-)");
            stringBuilder3 = stringBuilder.toString();
        }
        if (obj2 == null) {
            return stringBuilder3;
        }
        stringBuilder = new StringBuilder();
        stringBuilder.append(stringBuilder3);
        stringBuilder.append(" (*)");
        return stringBuilder.toString();
    }

    public final void k(b bVar) {
        int i = this.x;
        for (int i2 = 0; i2 < i; i2++) {
            b[] bVarArr = this.w;
            bVarArr[i2].f.r(bVarArr[i2], bVar, false);
        }
        this.x = 0;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.p);
        return stringBuilder.toString();
    }
}
