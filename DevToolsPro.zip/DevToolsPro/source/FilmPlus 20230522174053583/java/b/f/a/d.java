package b.f.a;

public class d extends b {
    public d(c cVar) {
        super(cVar);
    }

    public void a(h hVar) {
        super.a(hVar);
        hVar.y--;
    }
}
