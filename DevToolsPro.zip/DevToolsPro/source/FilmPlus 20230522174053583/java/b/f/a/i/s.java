package b.f.a.i;

import b.f.a.c;
import java.util.ArrayList;

public class s extends h {
    protected ArrayList<h> c1 = new ArrayList();

    public s(int i, int i2) {
        super(i, i2);
    }

    public s(int i, int i2, int i3, int i4) {
        super(i, i2, i3, i4);
    }

    public static n T1(ArrayList<h> arrayList) {
        n nVar = new n();
        if (arrayList.size() == 0) {
            return nVar;
        }
        int size = arrayList.size();
        int i = Integer.MAX_VALUE;
        int i2 = Integer.MAX_VALUE;
        int i3 = 0;
        int i4 = 0;
        for (int i5 = 0; i5 < size; i5++) {
            h hVar = (h) arrayList.get(i5);
            if (hVar.s0() < i) {
                i = hVar.s0();
            }
            if (hVar.t0() < i2) {
                i2 = hVar.t0();
            }
            if (hVar.e0() > i3) {
                i3 = hVar.e0();
            }
            if (hVar.w() > i4) {
                i4 = hVar.w();
            }
        }
        nVar.f(i, i2, i3 - i, i4 - i2);
        return nVar;
    }

    public void I0() {
        this.c1.clear();
        super.I0();
    }

    public void M1() {
        super.M1();
        ArrayList arrayList = this.c1;
        if (arrayList != null) {
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                h hVar = (h) this.c1.get(i);
                hVar.t1(H(), I());
                if (!(hVar instanceof i)) {
                    hVar.M1();
                }
            }
        }
    }

    public void O0(c cVar) {
        super.O0(cVar);
        int size = this.c1.size();
        for (int i = 0; i < size; i++) {
            ((h) this.c1.get(i)).O0(cVar);
        }
    }

    public void P1(h hVar) {
        this.c1.add(hVar);
        if (hVar.a0() != null) {
            ((s) hVar.a0()).X1(hVar);
        }
        hVar.v1(this);
    }

    public void Q1(h... hVarArr) {
        for (h P1 : hVarArr) {
            P1(P1);
        }
    }

    public h R1(float f, float f2) {
        int H = H();
        int I = I();
        h hVar = (f < ((float) H) || f > ((float) (p0() + H)) || f2 < ((float) I) || f2 > ((float) (J() + I))) ? null : this;
        int size = this.c1.size();
        for (I = 0; I < size; I++) {
            h hVar2 = (h) this.c1.get(I);
            if (hVar2 instanceof s) {
                hVar2 = ((s) hVar2).R1(f, f2);
                if (hVar2 == null) {
                }
            } else {
                int H2 = hVar2.H();
                int I2 = hVar2.I();
                int p0 = hVar2.p0() + H2;
                int J = hVar2.J() + I2;
                if (f >= ((float) H2)) {
                    if (f <= ((float) p0)) {
                        if (f2 >= ((float) I2)) {
                            if (f2 > ((float) J)) {
                            }
                        }
                    }
                }
            }
            hVar = hVar2;
        }
        return hVar;
    }

    public ArrayList<h> S1(int i, int i2, int i3, int i4) {
        ArrayList<h> arrayList = new ArrayList();
        n nVar = new n();
        nVar.f(i, i2, i3, i4);
        i = this.c1.size();
        for (i2 = 0; i2 < i; i2++) {
            h hVar = (h) this.c1.get(i2);
            n nVar2 = new n();
            nVar2.f(hVar.H(), hVar.I(), hVar.p0(), hVar.J());
            if (nVar.e(nVar2)) {
                arrayList.add(hVar);
            }
        }
        return arrayList;
    }

    public ArrayList<h> U1() {
        return this.c1;
    }

    public i V1() {
        h a0 = a0();
        i iVar = this instanceof i ? (i) this : null;
        while (a0 != null) {
            h a02 = a0.a0();
            if (a0 instanceof i) {
                iVar = (i) a0;
            }
            a0 = a02;
        }
        return iVar;
    }

    public void W1() {
        M1();
        ArrayList arrayList = this.c1;
        if (arrayList != null) {
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                h hVar = (h) this.c1.get(i);
                if (hVar instanceof s) {
                    ((s) hVar).W1();
                }
            }
        }
    }

    public void X1(h hVar) {
        this.c1.remove(hVar);
        hVar.v1(null);
    }

    public void Y1() {
        this.c1.clear();
    }

    public void t1(int i, int i2) {
        super.t1(i, i2);
        i = this.c1.size();
        for (i2 = 0; i2 < i; i2++) {
            ((h) this.c1.get(i2)).t1(g0(), h0());
        }
    }
}
