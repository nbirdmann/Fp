package b.f.a.i;

import b.f.a.i.e.c;
import java.util.ArrayList;

public class r {
    private int a;
    private int b;
    private int c;
    private int d;
    private ArrayList<a> e = new ArrayList();

    static class a {
        private e a;
        private e b;
        private int c;
        private c d;
        private int e;

        public a(e eVar) {
            this.a = eVar;
            this.b = eVar.o();
            this.c = eVar.g();
            this.d = eVar.n();
            this.e = eVar.e();
        }

        public void a(h hVar) {
            hVar.s(this.a.p()).d(this.b, this.c, this.d, this.e);
        }

        public void b(h hVar) {
            e s = hVar.s(this.a.p());
            this.a = s;
            if (s != null) {
                this.b = s.o();
                this.c = this.a.g();
                this.d = this.a.n();
                this.e = this.a.e();
                return;
            }
            this.b = null;
            this.c = 0;
            this.d = c.STRONG;
            this.e = 0;
        }
    }

    public r(h hVar) {
        this.a = hVar.s0();
        this.b = hVar.t0();
        this.c = hVar.p0();
        this.d = hVar.J();
        ArrayList t = hVar.t();
        int size = t.size();
        for (int i = 0; i < size; i++) {
            this.e.add(new a((e) t.get(i)));
        }
    }

    public void a(h hVar) {
        hVar.J1(this.a);
        hVar.K1(this.b);
        hVar.F1(this.c);
        hVar.g1(this.d);
        int size = this.e.size();
        for (int i = 0; i < size; i++) {
            ((a) this.e.get(i)).a(hVar);
        }
    }

    public void b(h hVar) {
        this.a = hVar.s0();
        this.b = hVar.t0();
        this.c = hVar.p0();
        this.d = hVar.J();
        int size = this.e.size();
        for (int i = 0; i < size; i++) {
            ((a) this.e.get(i)).b(hVar);
        }
    }
}
