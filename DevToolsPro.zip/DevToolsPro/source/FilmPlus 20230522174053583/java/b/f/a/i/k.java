package b.f.a.i;

import b.f.a.e;
import b.f.a.h;
import b.f.a.i.e.d;
import b.f.a.i.h.c;
import java.util.ArrayList;

public class k extends h {
    public static final int c1 = 0;
    public static final int d1 = 1;
    public static final int e1 = 0;
    public static final int f1 = 1;
    public static final int g1 = 2;
    public static final int h1 = -1;
    protected float i1 = -1.0f;
    protected int j1 = -1;
    protected int k1 = -1;
    private e l1 = this.V;
    private int m1;
    private boolean n1;
    private int o1;
    private n p1;
    private int q1;

    static /* synthetic */ class a {
        static final /* synthetic */ int[] a;

        /* DevToolsApp WARNING: Failed to process nested try/catch */
        /* DevToolsApp WARNING: Missing block: B:18:?, code:
            a[b.f.a.i.e.d.NONE.ordinal()] = 9;
     */
        static {
            /*
            r0 = b.f.a.i.e.d.values();
            r0 = r0.length;
            r0 = new int[r0];
            a = r0;
            r1 = b.f.a.i.e.d.LEFT;	 Catch:{ NoSuchFieldError -> 0x0012 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0012 }
            r2 = 1;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0012 }
        L_0x0012:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x001d }
            r1 = b.f.a.i.e.d.RIGHT;	 Catch:{ NoSuchFieldError -> 0x001d }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x001d }
            r2 = 2;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x001d }
        L_0x001d:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x0028 }
            r1 = b.f.a.i.e.d.TOP;	 Catch:{ NoSuchFieldError -> 0x0028 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0028 }
            r2 = 3;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0028 }
        L_0x0028:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x0033 }
            r1 = b.f.a.i.e.d.BOTTOM;	 Catch:{ NoSuchFieldError -> 0x0033 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0033 }
            r2 = 4;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0033 }
        L_0x0033:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x003e }
            r1 = b.f.a.i.e.d.BASELINE;	 Catch:{ NoSuchFieldError -> 0x003e }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x003e }
            r2 = 5;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x003e }
        L_0x003e:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x0049 }
            r1 = b.f.a.i.e.d.CENTER;	 Catch:{ NoSuchFieldError -> 0x0049 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0049 }
            r2 = 6;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0049 }
        L_0x0049:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x0054 }
            r1 = b.f.a.i.e.d.CENTER_X;	 Catch:{ NoSuchFieldError -> 0x0054 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0054 }
            r2 = 7;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0054 }
        L_0x0054:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x0060 }
            r1 = b.f.a.i.e.d.CENTER_Y;	 Catch:{ NoSuchFieldError -> 0x0060 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0060 }
            r2 = 8;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0060 }
        L_0x0060:
            r0 = a;	 Catch:{ NoSuchFieldError -> 0x006c }
            r1 = b.f.a.i.e.d.NONE;	 Catch:{ NoSuchFieldError -> 0x006c }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x006c }
            r2 = 9;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x006c }
        L_0x006c:
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: b.f.a.i.k.a.<clinit>():void");
        }
    }

    public k() {
        int i = 0;
        this.m1 = 0;
        this.n1 = false;
        this.o1 = 0;
        this.p1 = new n();
        this.q1 = 8;
        this.d0.clear();
        this.d0.add(this.l1);
        int length = this.c0.length;
        while (i < length) {
            this.c0[i] = this.l1;
            i++;
        }
    }

    public void N1(e eVar) {
        if (a0() != null) {
            int S = eVar.S(this.l1);
            if (this.m1 == 1) {
                J1(S);
                K1(0);
                g1(a0().J());
                F1(0);
            } else {
                J1(0);
                K1(S);
                F1(a0().p0());
                g1(0);
            }
        }
    }

    public void P1() {
        if (this.j1 != -1) {
            Z1();
        } else if (this.i1 != -1.0f) {
            Y1();
        } else if (this.k1 != -1) {
            X1();
        }
    }

    public e Q1() {
        return this.l1;
    }

    public n R1() {
        n nVar = this.p1;
        int H = H() - this.q1;
        int I = I();
        int i = this.q1;
        nVar.f(H, I - (i * 2), i * 2, i * 2);
        if (S1() == 0) {
            nVar = this.p1;
            H = H() - (this.q1 * 2);
            I = I();
            i = this.q1;
            nVar.f(H, I - i, i * 2, i * 2);
        }
        return this.p1;
    }

    public int S1() {
        return this.m1;
    }

    public int T1() {
        return this.j1;
    }

    public int U1() {
        return this.i1 != -1.0f ? 0 : this.j1 != -1 ? 1 : this.k1 != -1 ? 2 : -1;
    }

    public int V1() {
        return this.k1;
    }

    public float W1() {
        return this.i1;
    }

    void X1() {
        int s0 = s0();
        if (this.m1 == 0) {
            s0 = t0();
        }
        a2(s0);
    }

    void Y1() {
        int p0 = a0().p0() - s0();
        if (this.m1 == 0) {
            p0 = a0().J() - t0();
        }
        b2(p0);
    }

    public void Z0(int i, int i2) {
        if (this.m1 == 1) {
            i -= this.s0;
            if (this.j1 != -1) {
                a2(i);
                return;
            } else if (this.k1 != -1) {
                b2(a0().p0() - i);
                return;
            } else if (this.i1 != -1.0f) {
                c2(((float) i) / ((float) a0().p0()));
                return;
            } else {
                return;
            }
        }
        i2 -= this.t0;
        if (this.j1 != -1) {
            a2(i2);
        } else if (this.k1 != -1) {
            b2(a0().J() - i2);
        } else if (this.i1 != -1.0f) {
            c2(((float) i2) / ((float) a0().J()));
        }
    }

    void Z1() {
        float s0 = ((float) s0()) / ((float) a0().p0());
        if (this.m1 == 0) {
            s0 = ((float) t0()) / ((float) a0().J());
        }
        c2(s0);
    }

    public void a2(int i) {
        if (i > -1) {
            this.i1 = -1.0f;
            this.j1 = i;
            this.k1 = -1;
        }
    }

    public void b(e eVar) {
        i iVar = (i) a0();
        if (iVar != null) {
            Object s = iVar.s(d.LEFT);
            Object s2 = iVar.s(d.RIGHT);
            h hVar = this.f0;
            int i = 1;
            int i2 = (hVar == null || hVar.e0[0] != c.WRAP_CONTENT) ? 0 : 1;
            if (this.m1 == 0) {
                s = iVar.s(d.TOP);
                s2 = iVar.s(d.BOTTOM);
                h hVar2 = this.f0;
                if (hVar2 == null || hVar2.e0[1] != c.WRAP_CONTENT) {
                    i = 0;
                }
                i2 = i;
            }
            h u;
            if (this.j1 != -1) {
                u = eVar.u(this.l1);
                eVar.e(u, eVar.u(s), this.j1, 6);
                if (i2 != 0) {
                    eVar.k(eVar.u(s2), u, 0, 5);
                }
            } else if (this.k1 != -1) {
                u = eVar.u(this.l1);
                h u2 = eVar.u(s2);
                eVar.e(u, u2, -this.k1, 6);
                if (i2 != 0) {
                    eVar.k(u, eVar.u(s), 0, 5);
                    eVar.k(u2, u, 0, 5);
                }
            } else if (this.i1 != -1.0f) {
                eVar.d(e.x(eVar, eVar.u(this.l1), eVar.u(s), eVar.u(s2), this.i1, this.n1));
            }
        }
    }

    public void b2(int i) {
        if (i > -1) {
            this.i1 = -1.0f;
            this.j1 = -1;
            this.k1 = i;
        }
    }

    public boolean c() {
        return true;
    }

    public void c2(float f) {
        if (f > -1.0f) {
            this.i1 = f;
            this.j1 = -1;
            this.k1 = -1;
        }
    }

    public void d(int i) {
        h a0 = a0();
        if (a0 != null) {
            int i2;
            if (S1() == 1) {
                this.V.k().j(1, a0.V.k(), 0);
                this.X.k().j(1, a0.V.k(), 0);
                if (this.j1 != -1) {
                    this.U.k().j(1, a0.U.k(), this.j1);
                    this.W.k().j(1, a0.U.k(), this.j1);
                } else if (this.k1 != -1) {
                    this.U.k().j(1, a0.W.k(), -this.k1);
                    this.W.k().j(1, a0.W.k(), -this.k1);
                } else if (this.i1 != -1.0f && a0.N() == c.FIXED) {
                    i2 = (int) (((float) a0.g0) * this.i1);
                    this.U.k().j(1, a0.U.k(), i2);
                    this.W.k().j(1, a0.U.k(), i2);
                }
            } else {
                this.U.k().j(1, a0.U.k(), 0);
                this.W.k().j(1, a0.U.k(), 0);
                if (this.j1 != -1) {
                    this.V.k().j(1, a0.V.k(), this.j1);
                    this.X.k().j(1, a0.V.k(), this.j1);
                } else if (this.k1 != -1) {
                    this.V.k().j(1, a0.X.k(), -this.k1);
                    this.X.k().j(1, a0.X.k(), -this.k1);
                } else if (this.i1 != -1.0f && a0.n0() == c.FIXED) {
                    i2 = (int) (((float) a0.h0) * this.i1);
                    this.V.k().j(1, a0.V.k(), i2);
                    this.X.k().j(1, a0.V.k(), i2);
                }
            }
        }
    }

    public void d2(int i) {
        c2(((float) i) / 100.0f);
    }

    public void e2(int i) {
        this.o1 = i;
    }

    public void f2(int i) {
        if (this.m1 != i) {
            this.m1 = i;
            this.d0.clear();
            if (this.m1 == 1) {
                this.l1 = this.U;
            } else {
                this.l1 = this.V;
            }
            this.d0.add(this.l1);
            i = this.c0.length;
            for (int i2 = 0; i2 < i; i2++) {
                this.c0[i2] = this.l1;
            }
        }
    }

    public void g2(boolean z) {
        if (this.n1 != z) {
            this.n1 = z;
        }
    }

    public String j0() {
        return "Guideline";
    }

    public e s(d dVar) {
        switch (a.a[dVar.ordinal()]) {
            case 1:
            case 2:
                if (this.m1 == 1) {
                    return this.l1;
                }
                break;
            case 3:
            case 4:
                if (this.m1 == 0) {
                    return this.l1;
                }
                break;
            case 5:
            case 6:
            case 7:
            case 8:
            case 9:
                return null;
        }
        throw new AssertionError(dVar.name());
    }

    public ArrayList<e> t() {
        return this.d0;
    }
}
