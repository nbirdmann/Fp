package b.f.a.i;

import b.f.a.e;
import b.f.a.f;
import b.f.a.i.e.d;
import b.f.a.i.h.c;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class i extends s {
    private static final boolean d1 = true;
    private static final int e1 = 8;
    private static final boolean f1 = false;
    private static final boolean g1 = false;
    static final boolean h1 = false;
    public boolean A1;
    private boolean B1;
    private boolean C1;
    int D1;
    private boolean i1;
    protected e j1;
    private r k1;
    int l1;
    int m1;
    int n1;
    int o1;
    int p1;
    int q1;
    d[] r1;
    d[] s1;
    public List<j> t1;
    public boolean u1;
    public boolean v1;
    public boolean w1;
    public int x1;
    public int y1;
    private int z1;

    public i() {
        this.i1 = false;
        this.j1 = new e();
        this.p1 = 0;
        this.q1 = 0;
        this.r1 = new d[4];
        this.s1 = new d[4];
        this.t1 = new ArrayList();
        this.u1 = false;
        this.v1 = false;
        this.w1 = false;
        this.x1 = 0;
        this.y1 = 0;
        this.z1 = 7;
        this.A1 = false;
        this.B1 = false;
        this.C1 = false;
        this.D1 = 0;
    }

    public i(int i, int i2) {
        super(i, i2);
        this.i1 = false;
        this.j1 = new e();
        this.p1 = 0;
        this.q1 = 0;
        this.r1 = new d[4];
        this.s1 = new d[4];
        this.t1 = new ArrayList();
        this.u1 = false;
        this.v1 = false;
        this.w1 = false;
        this.x1 = 0;
        this.y1 = 0;
        this.z1 = 7;
        this.A1 = false;
        this.B1 = false;
        this.C1 = false;
        this.D1 = 0;
    }

    public i(int i, int i2, int i3, int i4) {
        super(i, i2, i3, i4);
        this.i1 = false;
        this.j1 = new e();
        this.p1 = 0;
        this.q1 = 0;
        this.r1 = new d[4];
        this.s1 = new d[4];
        this.t1 = new ArrayList();
        this.u1 = false;
        this.v1 = false;
        this.w1 = false;
        this.x1 = 0;
        this.y1 = 0;
        this.z1 = 7;
        this.A1 = false;
        this.B1 = false;
        this.C1 = false;
        this.D1 = 0;
    }

    private void b2(h hVar) {
        int i = this.p1 + 1;
        d[] dVarArr = this.s1;
        if (i >= dVarArr.length) {
            this.s1 = (d[]) Arrays.copyOf(dVarArr, dVarArr.length * 2);
        }
        this.s1[this.p1] = new d(hVar, 0, l2());
        this.p1++;
    }

    private void c2(h hVar) {
        int i = this.q1 + 1;
        d[] dVarArr = this.r1;
        if (i >= dVarArr.length) {
            this.r1 = (d[]) Arrays.copyOf(dVarArr, dVarArr.length * 2);
        }
        this.r1[this.q1] = new d(hVar, 1, l2());
        this.q1++;
    }

    private void s2() {
        this.p1 = 0;
        this.q1 = 0;
    }

    public void I0() {
        this.j1.b0();
        this.l1 = 0;
        this.n1 = 0;
        this.m1 = 0;
        this.o1 = 0;
        this.t1.clear();
        this.A1 = false;
        super.I0();
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:71:0x018f  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:69:0x0184  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:106:0x0258  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:110:0x0282  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:109:0x0275  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:112:0x0287  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:69:0x0184  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:71:0x018f  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:86:0x01dd  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:106:0x0258  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:109:0x0275  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:110:0x0282  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:112:0x0287  */
    public void W1() {
        /*
        r21 = this;
        r1 = r21;
        r2 = r1.k0;
        r3 = r1.l0;
        r0 = r21.p0();
        r4 = 0;
        r5 = java.lang.Math.max(r4, r0);
        r0 = r21.J();
        r6 = java.lang.Math.max(r4, r0);
        r1.B1 = r4;
        r1.C1 = r4;
        r0 = r1.f0;
        if (r0 == 0) goto L_0x0046;
    L_0x001f:
        r0 = r1.k1;
        if (r0 != 0) goto L_0x002a;
    L_0x0023:
        r0 = new b.f.a.i.r;
        r0.<init>(r1);
        r1.k1 = r0;
    L_0x002a:
        r0 = r1.k1;
        r0.b(r1);
        r0 = r1.l1;
        r1.J1(r0);
        r0 = r1.m1;
        r1.K1(r0);
        r21.L0();
        r0 = r1.j1;
        r0 = r0.K();
        r1.O0(r0);
        goto L_0x004a;
    L_0x0046:
        r1.k0 = r4;
        r1.l0 = r4;
    L_0x004a:
        r0 = r1.z1;
        r7 = 32;
        r8 = 8;
        r9 = 1;
        if (r0 == 0) goto L_0x006a;
    L_0x0053:
        r0 = r1.o2(r8);
        if (r0 != 0) goto L_0x005c;
    L_0x0059:
        r21.q2();
    L_0x005c:
        r0 = r1.o2(r7);
        if (r0 != 0) goto L_0x0065;
    L_0x0062:
        r21.n2();
    L_0x0065:
        r0 = r1.j1;
        r0.k = r9;
        goto L_0x006e;
    L_0x006a:
        r0 = r1.j1;
        r0.k = r4;
    L_0x006e:
        r0 = r1.e0;
        r10 = r0[r9];
        r11 = r0[r4];
        r21.s2();
        r0 = r1.t1;
        r0 = r0.size();
        if (r0 != 0) goto L_0x0090;
    L_0x007f:
        r0 = r1.t1;
        r0.clear();
        r0 = r1.t1;
        r12 = new b.f.a.i.j;
        r13 = r1.c1;
        r12.<init>(r13);
        r0.add(r4, r12);
    L_0x0090:
        r0 = r1.t1;
        r12 = r0.size();
        r13 = r1.c1;
        r0 = r21.N();
        r14 = b.f.a.i.h.c.WRAP_CONTENT;
        if (r0 == r14) goto L_0x00a9;
    L_0x00a0:
        r0 = r21.n0();
        if (r0 != r14) goto L_0x00a7;
    L_0x00a6:
        goto L_0x00a9;
    L_0x00a7:
        r14 = 0;
        goto L_0x00aa;
    L_0x00a9:
        r14 = 1;
    L_0x00aa:
        r0 = 0;
        r15 = 0;
    L_0x00ac:
        if (r15 >= r12) goto L_0x02ec;
    L_0x00ae:
        r8 = r1.A1;
        if (r8 != 0) goto L_0x02ec;
    L_0x00b2:
        r8 = r1.t1;
        r8 = r8.get(r15);
        r8 = (b.f.a.i.j) r8;
        r8 = r8.d;
        if (r8 == 0) goto L_0x00c4;
    L_0x00be:
        r20 = r3;
        r19 = r12;
        goto L_0x02de;
    L_0x00c4:
        r8 = r1.o2(r7);
        if (r8 == 0) goto L_0x00f7;
    L_0x00ca:
        r8 = r21.N();
        r7 = b.f.a.i.h.c.FIXED;
        if (r8 != r7) goto L_0x00e9;
    L_0x00d2:
        r8 = r21.n0();
        if (r8 != r7) goto L_0x00e9;
    L_0x00d8:
        r7 = r1.t1;
        r7 = r7.get(r15);
        r7 = (b.f.a.i.j) r7;
        r7 = r7.d();
        r7 = (java.util.ArrayList) r7;
        r1.c1 = r7;
        goto L_0x00f7;
    L_0x00e9:
        r7 = r1.t1;
        r7 = r7.get(r15);
        r7 = (b.f.a.i.j) r7;
        r7 = r7.a;
        r7 = (java.util.ArrayList) r7;
        r1.c1 = r7;
    L_0x00f7:
        r21.s2();
        r7 = r1.c1;
        r7 = r7.size();
        r8 = 0;
    L_0x0101:
        if (r8 >= r7) goto L_0x0119;
    L_0x0103:
        r4 = r1.c1;
        r4 = r4.get(r8);
        r4 = (b.f.a.i.h) r4;
        r9 = r4 instanceof b.f.a.i.s;
        if (r9 == 0) goto L_0x0114;
    L_0x010f:
        r4 = (b.f.a.i.s) r4;
        r4.W1();
    L_0x0114:
        r8 = r8 + 1;
        r4 = 0;
        r9 = 1;
        goto L_0x0101;
    L_0x0119:
        r4 = r0;
        r0 = 0;
        r8 = 1;
    L_0x011c:
        if (r8 == 0) goto L_0x02cb;
    L_0x011e:
        r17 = r4;
        r9 = 1;
        r4 = r0 + 1;
        r0 = r1.j1;	 Catch:{ Exception -> 0x0160 }
        r0.b0();	 Catch:{ Exception -> 0x0160 }
        r21.s2();	 Catch:{ Exception -> 0x0160 }
        r0 = r1.j1;	 Catch:{ Exception -> 0x0160 }
        r1.o(r0);	 Catch:{ Exception -> 0x0160 }
        r0 = 0;
    L_0x0131:
        if (r0 >= r7) goto L_0x0147;
    L_0x0133:
        r9 = r1.c1;	 Catch:{ Exception -> 0x0160 }
        r9 = r9.get(r0);	 Catch:{ Exception -> 0x0160 }
        r9 = (b.f.a.i.h) r9;	 Catch:{ Exception -> 0x0160 }
        r18 = r8;
        r8 = r1.j1;	 Catch:{ Exception -> 0x015c }
        r9.o(r8);	 Catch:{ Exception -> 0x015c }
        r0 = r0 + 1;
        r8 = r18;
        goto L_0x0131;
    L_0x0147:
        r18 = r8;
        r0 = r1.j1;	 Catch:{ Exception -> 0x015c }
        r8 = r1.a2(r0);	 Catch:{ Exception -> 0x015c }
        if (r8 == 0) goto L_0x0159;
    L_0x0151:
        r0 = r1.j1;	 Catch:{ Exception -> 0x0157 }
        r0.X();	 Catch:{ Exception -> 0x0157 }
        goto L_0x0159;
    L_0x0157:
        r0 = move-exception;
        goto L_0x0163;
    L_0x0159:
        r19 = r12;
        goto L_0x0182;
    L_0x015c:
        r0 = move-exception;
        r8 = r18;
        goto L_0x0163;
    L_0x0160:
        r0 = move-exception;
        r18 = r8;
    L_0x0163:
        r0.printStackTrace();
        r9 = java.lang.System.out;
        r18 = r8;
        r8 = new java.lang.StringBuilder;
        r8.<init>();
        r19 = r12;
        r12 = "EXCEPTION : ";
        r8.append(r12);
        r8.append(r0);
        r0 = r8.toString();
        r9.println(r0);
        r8 = r18;
    L_0x0182:
        if (r8 == 0) goto L_0x018f;
    L_0x0184:
        r8 = r1.j1;
        r9 = b.f.a.i.m.i;
        r1.y2(r8, r9);
    L_0x018b:
        r20 = r3;
        r3 = 2;
        goto L_0x01db;
    L_0x018f:
        r8 = r1.j1;
        r1.N1(r8);
        r8 = 0;
    L_0x0195:
        if (r8 >= r7) goto L_0x018b;
    L_0x0197:
        r9 = r1.c1;
        r9 = r9.get(r8);
        r9 = (b.f.a.i.h) r9;
        r12 = r9.e0;
        r16 = 0;
        r12 = r12[r16];
        r0 = b.f.a.i.h.c.MATCH_CONSTRAINT;
        if (r12 != r0) goto L_0x01bc;
    L_0x01a9:
        r12 = r9.p0();
        r20 = r3;
        r3 = r9.r0();
        if (r12 >= r3) goto L_0x01be;
    L_0x01b5:
        r0 = b.f.a.i.m.i;
        r3 = 2;
        r12 = 1;
        r0[r3] = r12;
        goto L_0x01db;
    L_0x01bc:
        r20 = r3;
    L_0x01be:
        r12 = 1;
        r3 = r9.e0;
        r3 = r3[r12];
        if (r3 != r0) goto L_0x01d5;
    L_0x01c5:
        r0 = r9.J();
        r3 = r9.q0();
        if (r0 >= r3) goto L_0x01d5;
    L_0x01cf:
        r0 = b.f.a.i.m.i;
        r3 = 2;
        r0[r3] = r12;
        goto L_0x01db;
    L_0x01d5:
        r3 = 2;
        r8 = r8 + 1;
        r3 = r20;
        goto L_0x0195;
    L_0x01db:
        if (r14 == 0) goto L_0x0247;
    L_0x01dd:
        r8 = 8;
        if (r4 >= r8) goto L_0x0247;
    L_0x01e1:
        r0 = b.f.a.i.m.i;
        r0 = r0[r3];
        if (r0 == 0) goto L_0x0247;
    L_0x01e7:
        r0 = 0;
        r3 = 0;
        r9 = 0;
    L_0x01ea:
        if (r0 >= r7) goto L_0x0210;
    L_0x01ec:
        r12 = r1.c1;
        r12 = r12.get(r0);
        r12 = (b.f.a.i.h) r12;
        r8 = r12.k0;
        r18 = r12.p0();
        r8 = r8 + r18;
        r3 = java.lang.Math.max(r3, r8);
        r8 = r12.l0;
        r12 = r12.J();
        r8 = r8 + r12;
        r9 = java.lang.Math.max(r9, r8);
        r0 = r0 + 1;
        r8 = 8;
        goto L_0x01ea;
    L_0x0210:
        r0 = r1.v0;
        r0 = java.lang.Math.max(r0, r3);
        r3 = r1.w0;
        r3 = java.lang.Math.max(r3, r9);
        r8 = b.f.a.i.h.c.WRAP_CONTENT;
        if (r11 != r8) goto L_0x0232;
    L_0x0220:
        r9 = r21.p0();
        if (r9 >= r0) goto L_0x0232;
    L_0x0226:
        r1.F1(r0);
        r0 = r1.e0;
        r9 = 0;
        r0[r9] = r8;
        r0 = 1;
        r17 = 1;
        goto L_0x0233;
    L_0x0232:
        r0 = 0;
    L_0x0233:
        if (r10 != r8) goto L_0x0248;
    L_0x0235:
        r9 = r21.J();
        if (r9 >= r3) goto L_0x0248;
    L_0x023b:
        r1.g1(r3);
        r0 = r1.e0;
        r3 = 1;
        r0[r3] = r8;
        r0 = 1;
        r17 = 1;
        goto L_0x0248;
    L_0x0247:
        r0 = 0;
    L_0x0248:
        r3 = r1.v0;
        r8 = r21.p0();
        r3 = java.lang.Math.max(r3, r8);
        r8 = r21.p0();
        if (r3 <= r8) goto L_0x0265;
    L_0x0258:
        r1.F1(r3);
        r0 = r1.e0;
        r3 = b.f.a.i.h.c.FIXED;
        r8 = 0;
        r0[r8] = r3;
        r0 = 1;
        r17 = 1;
    L_0x0265:
        r3 = r1.w0;
        r8 = r21.J();
        r3 = java.lang.Math.max(r3, r8);
        r8 = r21.J();
        if (r3 <= r8) goto L_0x0282;
    L_0x0275:
        r1.g1(r3);
        r0 = r1.e0;
        r3 = b.f.a.i.h.c.FIXED;
        r8 = 1;
        r0[r8] = r3;
        r0 = 1;
        r9 = 1;
        goto L_0x0285;
    L_0x0282:
        r8 = 1;
        r9 = r17;
    L_0x0285:
        if (r9 != 0) goto L_0x02c2;
    L_0x0287:
        r3 = r1.e0;
        r12 = 0;
        r3 = r3[r12];
        r12 = b.f.a.i.h.c.WRAP_CONTENT;
        if (r3 != r12) goto L_0x02a6;
    L_0x0290:
        if (r5 <= 0) goto L_0x02a6;
    L_0x0292:
        r3 = r21.p0();
        if (r3 <= r5) goto L_0x02a6;
    L_0x0298:
        r1.B1 = r8;
        r0 = r1.e0;
        r3 = b.f.a.i.h.c.FIXED;
        r9 = 0;
        r0[r9] = r3;
        r1.F1(r5);
        r0 = 1;
        r9 = 1;
    L_0x02a6:
        r3 = r1.e0;
        r3 = r3[r8];
        if (r3 != r12) goto L_0x02c2;
    L_0x02ac:
        if (r6 <= 0) goto L_0x02c2;
    L_0x02ae:
        r3 = r21.J();
        if (r3 <= r6) goto L_0x02c2;
    L_0x02b4:
        r1.C1 = r8;
        r0 = r1.e0;
        r3 = b.f.a.i.h.c.FIXED;
        r0[r8] = r3;
        r1.g1(r6);
        r8 = 1;
        r9 = 1;
        goto L_0x02c3;
    L_0x02c2:
        r8 = r0;
    L_0x02c3:
        r0 = r4;
        r4 = r9;
        r12 = r19;
        r3 = r20;
        goto L_0x011c;
    L_0x02cb:
        r20 = r3;
        r17 = r4;
        r19 = r12;
        r0 = r1.t1;
        r0 = r0.get(r15);
        r0 = (b.f.a.i.j) r0;
        r0.g();
        r0 = r17;
    L_0x02de:
        r15 = r15 + 1;
        r12 = r19;
        r3 = r20;
        r4 = 0;
        r7 = 32;
        r8 = 8;
        r9 = 1;
        goto L_0x00ac;
    L_0x02ec:
        r20 = r3;
        r1.c1 = r13;
        r3 = r1.f0;
        if (r3 == 0) goto L_0x0320;
    L_0x02f4:
        r2 = r1.v0;
        r3 = r21.p0();
        r2 = java.lang.Math.max(r2, r3);
        r3 = r1.w0;
        r4 = r21.J();
        r3 = java.lang.Math.max(r3, r4);
        r4 = r1.k1;
        r4.a(r1);
        r4 = r1.l1;
        r2 = r2 + r4;
        r4 = r1.n1;
        r2 = r2 + r4;
        r1.F1(r2);
        r2 = r1.m1;
        r3 = r3 + r2;
        r2 = r1.o1;
        r3 = r3 + r2;
        r1.g1(r3);
        goto L_0x0326;
    L_0x0320:
        r1.k0 = r2;
        r2 = r20;
        r1.l0 = r2;
    L_0x0326:
        if (r0 == 0) goto L_0x0330;
    L_0x0328:
        r0 = r1.e0;
        r2 = 0;
        r0[r2] = r11;
        r2 = 1;
        r0[r2] = r10;
    L_0x0330:
        r0 = r1.j1;
        r0 = r0.K();
        r1.O0(r0);
        r0 = r21.V1();
        if (r1 != r0) goto L_0x0342;
    L_0x033f:
        r21.M1();
    L_0x0342:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.f.a.i.i.W1():void");
    }

    void Z1(h hVar, int i) {
        if (i == 0) {
            b2(hVar);
        } else if (i == 1) {
            c2(hVar);
        }
    }

    public boolean a2(e eVar) {
        b(eVar);
        int size = this.c1.size();
        for (int i = 0; i < size; i++) {
            h hVar = (h) this.c1.get(i);
            if (hVar instanceof i) {
                c[] cVarArr = hVar.e0;
                c cVar = cVarArr[0];
                c cVar2 = cVarArr[1];
                c cVar3 = c.WRAP_CONTENT;
                if (cVar == cVar3) {
                    hVar.l1(c.FIXED);
                }
                if (cVar2 == cVar3) {
                    hVar.B1(c.FIXED);
                }
                hVar.b(eVar);
                if (cVar == cVar3) {
                    hVar.l1(cVar);
                }
                if (cVar2 == cVar3) {
                    hVar.B1(cVar2);
                }
            } else {
                m.c(this, eVar, hVar);
                hVar.b(eVar);
            }
        }
        if (this.p1 > 0) {
            c.a(this, eVar, 0);
        }
        if (this.q1 > 0) {
            c.a(this, eVar, 1);
        }
        return true;
    }

    public void d(int i) {
        super.d(i);
        int size = this.c1.size();
        for (int i2 = 0; i2 < size; i2++) {
            ((h) this.c1.get(i2)).d(i);
        }
    }

    public void d2(f fVar) {
        this.j1.J(fVar);
    }

    public ArrayList<k> e2() {
        ArrayList<k> arrayList = new ArrayList();
        int size = this.c1.size();
        for (int i = 0; i < size; i++) {
            h hVar = (h) this.c1.get(i);
            if (hVar instanceof k) {
                k kVar = (k) hVar;
                if (kVar.S1() == 0) {
                    arrayList.add(kVar);
                }
            }
        }
        return arrayList;
    }

    public int f2() {
        return this.z1;
    }

    public e g2() {
        return this.j1;
    }

    public ArrayList<k> h2() {
        ArrayList<k> arrayList = new ArrayList();
        int size = this.c1.size();
        for (int i = 0; i < size; i++) {
            h hVar = (h) this.c1.get(i);
            if (hVar instanceof k) {
                k kVar = (k) hVar;
                if (kVar.S1() == 1) {
                    arrayList.add(kVar);
                }
            }
        }
        return arrayList;
    }

    public List<j> i2() {
        return this.t1;
    }

    public String j0() {
        return "ConstraintLayout";
    }

    public boolean j2() {
        return false;
    }

    public boolean k2() {
        return this.C1;
    }

    public boolean l2() {
        return this.i1;
    }

    public boolean m2() {
        return this.B1;
    }

    public void n2() {
        if (!o2(8)) {
            d(this.z1);
        }
        x2();
    }

    public boolean o2(int i) {
        return (this.z1 & i) == i;
    }

    public void p2(int i, int i2) {
        c cVar = this.e0[0];
        c cVar2 = c.WRAP_CONTENT;
        if (cVar != cVar2) {
            p pVar = this.C;
            if (pVar != null) {
                pVar.j(i);
            }
        }
        if (this.e0[1] != cVar2) {
            p pVar2 = this.D;
            if (pVar2 != null) {
                pVar2.j(i2);
            }
        }
    }

    public void q2() {
        int size = this.c1.size();
        N0();
        for (int i = 0; i < size; i++) {
            ((h) this.c1.get(i)).N0();
        }
    }

    public void r2() {
        q2();
        d(this.z1);
    }

    public void t2() {
        q k = s(d.LEFT).k();
        q k2 = s(d.TOP).k();
        k.d();
        k2.d();
        k.n(null, 0.0f);
        k2.n(null, 0.0f);
    }

    public void u2(int i) {
        this.z1 = i;
    }

    public void v2(int i, int i2, int i3, int i4) {
        this.l1 = i;
        this.m1 = i2;
        this.n1 = i3;
        this.o1 = i4;
    }

    public void w2(boolean z) {
        this.i1 = z;
    }

    public void x2() {
        o k = s(d.LEFT).k();
        o k2 = s(d.TOP).k();
        k.n(null, 0.0f);
        k2.n(null, 0.0f);
    }

    public void y2(e eVar, boolean[] zArr) {
        zArr[2] = false;
        N1(eVar);
        int size = this.c1.size();
        for (int i = 0; i < size; i++) {
            h hVar = (h) this.c1.get(i);
            hVar.N1(eVar);
            c cVar = hVar.e0[0];
            c cVar2 = c.MATCH_CONSTRAINT;
            if (cVar == cVar2 && hVar.p0() < hVar.r0()) {
                zArr[2] = true;
            }
            if (hVar.e0[1] == cVar2 && hVar.J() < hVar.q0()) {
                zArr[2] = true;
            }
        }
    }
}
