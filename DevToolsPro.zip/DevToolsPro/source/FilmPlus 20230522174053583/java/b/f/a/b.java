package b.f.a;

public class b implements a {
    private static final boolean a = false;
    private static final float b = 0.001f;
    h c = null;
    float d = 0.0f;
    boolean e = false;
    public final a f;
    boolean g = false;

    public b(c cVar) {
        this.f = new a(this, cVar);
    }

    public void a(h hVar) {
        int i = hVar.s;
        float f = 1.0f;
        if (i != 1) {
            if (i == 2) {
                f = 1000.0f;
            } else if (i == 3) {
                f = 1000000.0f;
            } else if (i == 4) {
                f = 1.0E9f;
            } else if (i == 5) {
                f = 1.0E12f;
            }
        }
        this.f.o(hVar, f);
    }

    public h b(e eVar, boolean[] zArr) {
        return this.f.i(zArr, null);
    }

    public void c(a aVar) {
        if (aVar instanceof b) {
            b bVar = (b) aVar;
            this.c = null;
            this.f.c();
            int i = 0;
            while (true) {
                a aVar2 = bVar.f;
                if (i < aVar2.d) {
                    this.f.a(aVar2.j(i), bVar.f.k(i), true);
                    i++;
                } else {
                    return;
                }
            }
        }
    }

    public void clear() {
        this.f.c();
        this.c = null;
        this.d = 0.0f;
    }

    public b d(e eVar, int i) {
        this.f.o(eVar.s(i, "ep"), 1.0f);
        this.f.o(eVar.s(i, "em"), -1.0f);
        return this;
    }

    b e(h hVar, int i) {
        this.f.o(hVar, (float) i);
        return this;
    }

    boolean f(e eVar) {
        boolean z;
        h b = this.f.b(eVar);
        if (b == null) {
            z = true;
        } else {
            w(b);
            z = false;
        }
        if (this.f.d == 0) {
            this.g = true;
        }
        return z;
    }

    b g(h hVar, h hVar2, int i, float f, h hVar3, h hVar4, int i2) {
        if (hVar2 == hVar3) {
            this.f.o(hVar, 1.0f);
            this.f.o(hVar4, 1.0f);
            this.f.o(hVar2, -2.0f);
            return this;
        }
        if (f == 0.5f) {
            this.f.o(hVar, 1.0f);
            this.f.o(hVar2, -1.0f);
            this.f.o(hVar3, -1.0f);
            this.f.o(hVar4, 1.0f);
            if (i > 0 || i2 > 0) {
                this.d = (float) ((-i) + i2);
            }
        } else if (f <= 0.0f) {
            this.f.o(hVar, -1.0f);
            this.f.o(hVar2, 1.0f);
            this.d = (float) i;
        } else if (f >= 1.0f) {
            this.f.o(hVar3, -1.0f);
            this.f.o(hVar4, 1.0f);
            this.d = (float) i2;
        } else {
            float f2 = 1.0f - f;
            this.f.o(hVar, f2 * 1.0f);
            this.f.o(hVar2, f2 * -1.0f);
            this.f.o(hVar3, -1.0f * f);
            this.f.o(hVar4, 1.0f * f);
            if (i > 0 || i2 > 0) {
                this.d = (((float) (-i)) * f2) + (((float) i2) * f);
            }
        }
        return this;
    }

    public h getKey() {
        return this.c;
    }

    b h(h hVar, int i) {
        this.c = hVar;
        float f = (float) i;
        hVar.t = f;
        this.d = f;
        this.g = true;
        return this;
    }

    b i(h hVar, h hVar2, h hVar3, float f) {
        this.f.o(hVar, -1.0f);
        this.f.o(hVar2, 1.0f - f);
        this.f.o(hVar3, f);
        return this;
    }

    public boolean isEmpty() {
        return this.c == null && this.d == 0.0f && this.f.d == 0;
    }

    public b j(h hVar, h hVar2, h hVar3, h hVar4, float f) {
        this.f.o(hVar, -1.0f);
        this.f.o(hVar2, 1.0f);
        this.f.o(hVar3, f);
        this.f.o(hVar4, -f);
        return this;
    }

    public b k(float f, float f2, float f3, h hVar, int i, h hVar2, int i2, h hVar3, int i3, h hVar4, int i4) {
        if (f2 == 0.0f || f == f3) {
            this.d = (float) ((((-i) - i2) + i3) + i4);
            this.f.o(hVar, 1.0f);
            this.f.o(hVar2, -1.0f);
            this.f.o(hVar4, 1.0f);
            this.f.o(hVar3, -1.0f);
        } else {
            f = (f / f2) / (f3 / f2);
            this.d = (((float) ((-i) - i2)) + (((float) i3) * f)) + (((float) i4) * f);
            this.f.o(hVar, 1.0f);
            this.f.o(hVar2, -1.0f);
            this.f.o(hVar4, f);
            this.f.o(hVar3, -f);
        }
        return this;
    }

    public b l(float f, float f2, float f3, h hVar, h hVar2, h hVar3, h hVar4) {
        this.d = 0.0f;
        if (f2 == 0.0f || f == f3) {
            this.f.o(hVar, 1.0f);
            this.f.o(hVar2, -1.0f);
            this.f.o(hVar4, 1.0f);
            this.f.o(hVar3, -1.0f);
        } else if (f == 0.0f) {
            this.f.o(hVar, 1.0f);
            this.f.o(hVar2, -1.0f);
        } else if (f3 == 0.0f) {
            this.f.o(hVar3, 1.0f);
            this.f.o(hVar4, -1.0f);
        } else {
            f = (f / f2) / (f3 / f2);
            this.f.o(hVar, 1.0f);
            this.f.o(hVar2, -1.0f);
            this.f.o(hVar4, f);
            this.f.o(hVar3, -f);
        }
        return this;
    }

    public b m(h hVar, int i) {
        if (i < 0) {
            this.d = (float) (i * -1);
            this.f.o(hVar, 1.0f);
        } else {
            this.d = (float) i;
            this.f.o(hVar, -1.0f);
        }
        return this;
    }

    public b n(h hVar, h hVar2, int i) {
        Object obj = null;
        if (i != 0) {
            if (i < 0) {
                i *= -1;
                obj = 1;
            }
            this.d = (float) i;
        }
        if (obj == null) {
            this.f.o(hVar, -1.0f);
            this.f.o(hVar2, 1.0f);
        } else {
            this.f.o(hVar, 1.0f);
            this.f.o(hVar2, -1.0f);
        }
        return this;
    }

    public b o(h hVar, int i, h hVar2) {
        this.d = (float) i;
        this.f.o(hVar, -1.0f);
        return this;
    }

    public b p(h hVar, h hVar2, h hVar3, int i) {
        Object obj = null;
        if (i != 0) {
            if (i < 0) {
                i *= -1;
                obj = 1;
            }
            this.d = (float) i;
        }
        if (obj == null) {
            this.f.o(hVar, -1.0f);
            this.f.o(hVar2, 1.0f);
            this.f.o(hVar3, 1.0f);
        } else {
            this.f.o(hVar, 1.0f);
            this.f.o(hVar2, -1.0f);
            this.f.o(hVar3, -1.0f);
        }
        return this;
    }

    public b q(h hVar, h hVar2, h hVar3, int i) {
        Object obj = null;
        if (i != 0) {
            if (i < 0) {
                i *= -1;
                obj = 1;
            }
            this.d = (float) i;
        }
        if (obj == null) {
            this.f.o(hVar, -1.0f);
            this.f.o(hVar2, 1.0f);
            this.f.o(hVar3, -1.0f);
        } else {
            this.f.o(hVar, 1.0f);
            this.f.o(hVar2, -1.0f);
            this.f.o(hVar3, 1.0f);
        }
        return this;
    }

    public b r(h hVar, h hVar2, h hVar3, h hVar4, float f) {
        this.f.o(hVar3, 0.5f);
        this.f.o(hVar4, 0.5f);
        this.f.o(hVar, -0.5f);
        this.f.o(hVar2, -0.5f);
        this.d = -f;
        return this;
    }

    void s() {
        float f = this.d;
        if (f < 0.0f) {
            this.d = f * -1.0f;
            this.f.m();
        }
    }

    boolean t() {
        h hVar = this.c;
        return hVar != null && (hVar.v == b.f.a.h.b.UNRESTRICTED || this.d >= 0.0f);
    }

    public String toString() {
        return z();
    }

    boolean u(h hVar) {
        return this.f.d(hVar);
    }

    h v(h hVar) {
        return this.f.i(null, hVar);
    }

    void w(h hVar) {
        h hVar2 = this.c;
        if (hVar2 != null) {
            this.f.o(hVar2, -1.0f);
            this.c = null;
        }
        float p = this.f.p(hVar, true) * -1.0f;
        this.c = hVar;
        if (p != 1.0f) {
            this.d /= p;
            this.f.f(p);
        }
    }

    public void x() {
        this.c = null;
        this.f.c();
        this.d = 0.0f;
        this.g = false;
    }

    int y() {
        return (((this.c != null ? 4 : 0) + 4) + 4) + this.f.q();
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:27:0x00d0  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:26:0x00c0  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:26:0x00c0  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:27:0x00d0  */
    java.lang.String z() {
        /*
        r9 = this;
        r0 = r9.c;
        r1 = "";
        if (r0 != 0) goto L_0x0018;
    L_0x0006:
        r0 = new java.lang.StringBuilder;
        r0.<init>();
        r0.append(r1);
        r1 = "0";
        r0.append(r1);
        r0 = r0.toString();
        goto L_0x0029;
    L_0x0018:
        r0 = new java.lang.StringBuilder;
        r0.<init>();
        r0.append(r1);
        r1 = r9.c;
        r0.append(r1);
        r0 = r0.toString();
    L_0x0029:
        r1 = new java.lang.StringBuilder;
        r1.<init>();
        r1.append(r0);
        r0 = " = ";
        r1.append(r0);
        r0 = r1.toString();
        r1 = r9.d;
        r2 = 0;
        r3 = 1;
        r4 = 0;
        r1 = (r1 > r4 ? 1 : (r1 == r4 ? 0 : -1));
        if (r1 == 0) goto L_0x0056;
    L_0x0043:
        r1 = new java.lang.StringBuilder;
        r1.<init>();
        r1.append(r0);
        r0 = r9.d;
        r1.append(r0);
        r0 = r1.toString();
        r1 = 1;
        goto L_0x0057;
    L_0x0056:
        r1 = 0;
    L_0x0057:
        r5 = r9.f;
        r5 = r5.d;
    L_0x005b:
        if (r2 >= r5) goto L_0x00ec;
    L_0x005d:
        r6 = r9.f;
        r6 = r6.j(r2);
        if (r6 != 0) goto L_0x0067;
    L_0x0065:
        goto L_0x00e8;
    L_0x0067:
        r7 = r9.f;
        r7 = r7.k(r2);
        r8 = (r7 > r4 ? 1 : (r7 == r4 ? 0 : -1));
        if (r8 != 0) goto L_0x0073;
    L_0x0071:
        goto L_0x00e8;
    L_0x0073:
        r6 = r6.toString();
        r8 = -1082130432; // 0xffffffffbf800000 float:-1.0 double:NaN;
        if (r1 != 0) goto L_0x0091;
    L_0x007b:
        r1 = (r7 > r4 ? 1 : (r7 == r4 ? 0 : -1));
        if (r1 >= 0) goto L_0x00ba;
    L_0x007f:
        r1 = new java.lang.StringBuilder;
        r1.<init>();
        r1.append(r0);
        r0 = "- ";
        r1.append(r0);
        r0 = r1.toString();
        goto L_0x00b8;
    L_0x0091:
        r1 = (r7 > r4 ? 1 : (r7 == r4 ? 0 : -1));
        if (r1 <= 0) goto L_0x00a7;
    L_0x0095:
        r1 = new java.lang.StringBuilder;
        r1.<init>();
        r1.append(r0);
        r0 = " + ";
        r1.append(r0);
        r0 = r1.toString();
        goto L_0x00ba;
    L_0x00a7:
        r1 = new java.lang.StringBuilder;
        r1.<init>();
        r1.append(r0);
        r0 = " - ";
        r1.append(r0);
        r0 = r1.toString();
    L_0x00b8:
        r7 = r7 * r8;
    L_0x00ba:
        r1 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r1 = (r7 > r1 ? 1 : (r7 == r1 ? 0 : -1));
        if (r1 != 0) goto L_0x00d0;
    L_0x00c0:
        r1 = new java.lang.StringBuilder;
        r1.<init>();
        r1.append(r0);
        r1.append(r6);
        r0 = r1.toString();
        goto L_0x00e7;
    L_0x00d0:
        r1 = new java.lang.StringBuilder;
        r1.<init>();
        r1.append(r0);
        r1.append(r7);
        r0 = " ";
        r1.append(r0);
        r1.append(r6);
        r0 = r1.toString();
    L_0x00e7:
        r1 = 1;
    L_0x00e8:
        r2 = r2 + 1;
        goto L_0x005b;
    L_0x00ec:
        if (r1 != 0) goto L_0x00ff;
    L_0x00ee:
        r1 = new java.lang.StringBuilder;
        r1.<init>();
        r1.append(r0);
        r0 = "0.0";
        r1.append(r0);
        r0 = r1.toString();
    L_0x00ff:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.f.a.b.z():java.lang.String");
    }
}
