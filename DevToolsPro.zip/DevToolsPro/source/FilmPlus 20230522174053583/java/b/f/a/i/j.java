package b.f.a.i;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class j {
    public List<h> a;
    int b = -1;
    int c = -1;
    public boolean d = false;
    public final int[] e = new int[]{-1, -1};
    List<h> f = new ArrayList();
    List<h> g = new ArrayList();
    HashSet<h> h = new HashSet();
    HashSet<h> i = new HashSet();
    List<h> j = new ArrayList();
    List<h> k = new ArrayList();

    j(List<h> list) {
        this.a = list;
    }

    j(List<h> list, boolean z) {
        this.a = list;
        this.d = z;
    }

    private void e(ArrayList<h> arrayList, h hVar) {
        if (!hVar.S0) {
            arrayList.add(hVar);
            hVar.S0 = true;
            if (!hVar.y0()) {
                if (hVar instanceof l) {
                    l lVar = (l) hVar;
                    int i = lVar.d1;
                    for (int i2 = 0; i2 < i; i2++) {
                        e(arrayList, lVar.c1[i2]);
                    }
                }
                for (e eVar : hVar.c0) {
                    e eVar2 = eVar2.i;
                    if (eVar2 != null) {
                        h hVar2 = eVar2.g;
                        if (hVar2 != hVar.a0()) {
                            e(arrayList, hVar2);
                        }
                    }
                }
            }
        }
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:24:0x004c  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:23:0x0044  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:32:0x0083  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:27:0x0067  */
    private void f(b.f.a.i.h r7) {
        /*
        r6 = this;
        r0 = r7.Q0;
        if (r0 == 0) goto L_0x00d6;
    L_0x0004:
        r0 = r7.y0();
        if (r0 == 0) goto L_0x000b;
    L_0x000a:
        return;
    L_0x000b:
        r0 = r7.W;
        r0 = r0.i;
        r1 = 0;
        r2 = 1;
        if (r0 == 0) goto L_0x0015;
    L_0x0013:
        r3 = 1;
        goto L_0x0016;
    L_0x0015:
        r3 = 0;
    L_0x0016:
        if (r3 == 0) goto L_0x0019;
    L_0x0018:
        goto L_0x001d;
    L_0x0019:
        r0 = r7.U;
        r0 = r0.i;
    L_0x001d:
        if (r0 == 0) goto L_0x0041;
    L_0x001f:
        r4 = r0.g;
        r5 = r4.R0;
        if (r5 != 0) goto L_0x0028;
    L_0x0025:
        r6.f(r4);
    L_0x0028:
        r4 = r0.h;
        r5 = b.f.a.i.e.d.RIGHT;
        if (r4 != r5) goto L_0x0038;
    L_0x002e:
        r0 = r0.g;
        r4 = r0.k0;
        r0 = r0.p0();
        r4 = r4 + r0;
        goto L_0x0042;
    L_0x0038:
        r5 = b.f.a.i.e.d.LEFT;
        if (r4 != r5) goto L_0x0041;
    L_0x003c:
        r0 = r0.g;
        r4 = r0.k0;
        goto L_0x0042;
    L_0x0041:
        r4 = 0;
    L_0x0042:
        if (r3 == 0) goto L_0x004c;
    L_0x0044:
        r0 = r7.W;
        r0 = r0.g();
        r4 = r4 - r0;
        goto L_0x0058;
    L_0x004c:
        r0 = r7.U;
        r0 = r0.g();
        r3 = r7.p0();
        r0 = r0 + r3;
        r4 = r4 + r0;
    L_0x0058:
        r0 = r7.p0();
        r0 = r4 - r0;
        r7.k1(r0, r4);
        r0 = r7.Y;
        r0 = r0.i;
        if (r0 == 0) goto L_0x0083;
    L_0x0067:
        r1 = r0.g;
        r3 = r1.R0;
        if (r3 != 0) goto L_0x0070;
    L_0x006d:
        r6.f(r1);
    L_0x0070:
        r0 = r0.g;
        r1 = r0.l0;
        r0 = r0.u0;
        r1 = r1 + r0;
        r0 = r7.u0;
        r1 = r1 - r0;
        r0 = r7.h0;
        r0 = r0 + r1;
        r7.A1(r1, r0);
        r7.R0 = r2;
        return;
    L_0x0083:
        r0 = r7.X;
        r0 = r0.i;
        if (r0 == 0) goto L_0x008a;
    L_0x0089:
        r1 = 1;
    L_0x008a:
        if (r1 == 0) goto L_0x008d;
    L_0x008c:
        goto L_0x0091;
    L_0x008d:
        r0 = r7.V;
        r0 = r0.i;
    L_0x0091:
        if (r0 == 0) goto L_0x00b5;
    L_0x0093:
        r3 = r0.g;
        r5 = r3.R0;
        if (r5 != 0) goto L_0x009c;
    L_0x0099:
        r6.f(r3);
    L_0x009c:
        r3 = r0.h;
        r5 = b.f.a.i.e.d.BOTTOM;
        if (r3 != r5) goto L_0x00ad;
    L_0x00a2:
        r0 = r0.g;
        r3 = r0.l0;
        r0 = r0.J();
        r4 = r3 + r0;
        goto L_0x00b5;
    L_0x00ad:
        r5 = b.f.a.i.e.d.TOP;
        if (r3 != r5) goto L_0x00b5;
    L_0x00b1:
        r0 = r0.g;
        r4 = r0.l0;
    L_0x00b5:
        if (r1 == 0) goto L_0x00bf;
    L_0x00b7:
        r0 = r7.X;
        r0 = r0.g();
        r4 = r4 - r0;
        goto L_0x00cb;
    L_0x00bf:
        r0 = r7.V;
        r0 = r0.g();
        r1 = r7.J();
        r0 = r0 + r1;
        r4 = r4 + r0;
    L_0x00cb:
        r0 = r7.J();
        r0 = r4 - r0;
        r7.A1(r0, r4);
        r7.R0 = r2;
    L_0x00d6:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.f.a.i.j.f(b.f.a.i.h):void");
    }

    void a(h hVar, int i) {
        if (i == 0) {
            this.h.add(hVar);
        } else if (i == 1) {
            this.i.add(hVar);
        }
    }

    public List<h> b(int i) {
        return i == 0 ? this.f : i == 1 ? this.g : null;
    }

    Set<h> c(int i) {
        return i == 0 ? this.h : i == 1 ? this.i : null;
    }

    List<h> d() {
        if (!this.j.isEmpty()) {
            return this.j;
        }
        int size = this.a.size();
        for (int i = 0; i < size; i++) {
            h hVar = (h) this.a.get(i);
            if (!hVar.Q0) {
                e((ArrayList) this.j, hVar);
            }
        }
        this.k.clear();
        this.k.addAll(this.a);
        this.k.removeAll(this.j);
        return this.j;
    }

    void g() {
        int size = this.k.size();
        for (int i = 0; i < size; i++) {
            f((h) this.k.get(i));
        }
    }
}
