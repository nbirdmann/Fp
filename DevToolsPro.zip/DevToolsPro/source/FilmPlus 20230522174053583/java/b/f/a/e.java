package b.f.a;

import b.f.a.h.b;
import b.f.a.i.e.d;
import b.f.a.i.h;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.HashMap;

public class e {
    public static final boolean a = false;
    private static final boolean b = false;
    private static int c = 1000;
    public static f d;
    int e;
    private HashMap<String, h> f;
    private a g;
    private int h;
    private int i;
    b[] j;
    public boolean k;
    private boolean[] l;
    int m;
    int n;
    private int o;
    final c p;
    private h[] q;
    private int r;
    private b[] s;
    private final a t;

    interface a {
        void a(h hVar);

        h b(e eVar, boolean[] zArr);

        void c(a aVar);

        void clear();

        h getKey();

        boolean isEmpty();
    }

    public e() {
        this.e = 0;
        this.f = null;
        this.h = 32;
        this.i = 32;
        this.j = null;
        this.k = false;
        this.l = new boolean[32];
        this.m = 1;
        this.n = 0;
        this.o = 32;
        this.q = new h[c];
        this.r = 0;
        this.s = new b[32];
        this.j = new b[32];
        a0();
        c cVar = new c();
        this.p = cVar;
        this.g = new d(cVar);
        this.t = new b(cVar);
    }

    public static b A(e eVar, h hVar, h hVar2, int i, boolean z) {
        h B = eVar.B();
        b v = eVar.v();
        v.q(hVar, hVar2, B, i);
        if (z) {
            eVar.p(v, (int) (v.f.g(B) * -1.0f));
        }
        return v;
    }

    private h C(String str, b bVar) {
        f fVar = d;
        if (fVar != null) {
            fVar.l++;
        }
        if (this.m + 1 >= this.i) {
            W();
        }
        h a = a(bVar, null);
        a.h(str);
        int i = this.e + 1;
        this.e = i;
        this.m++;
        a.q = i;
        if (this.f == null) {
            this.f = new HashMap();
        }
        this.f.put(str, a);
        this.p.c[this.e] = a;
        return a;
    }

    private void E() {
        F();
        String str = "";
        int i = 0;
        while (true) {
            String str2 = "\n";
            if (i < this.n) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(str);
                stringBuilder.append(this.j[i]);
                str = stringBuilder.toString();
                stringBuilder = new StringBuilder();
                stringBuilder.append(str);
                stringBuilder.append(str2);
                str = stringBuilder.toString();
                i++;
            } else {
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append(str);
                stringBuilder2.append(this.g);
                stringBuilder2.append(str2);
                System.out.println(stringBuilder2.toString());
                return;
            }
        }
    }

    private void F() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Display Rows (");
        stringBuilder.append(this.n);
        stringBuilder.append("x");
        stringBuilder.append(this.m);
        stringBuilder.append(")\n");
        System.out.println(stringBuilder.toString());
    }

    private int I(a aVar) throws Exception {
        float f;
        Object obj;
        int i = 0;
        while (true) {
            f = 0.0f;
            if (i >= this.n) {
                obj = null;
                break;
            }
            b[] bVarArr = this.j;
            if (bVarArr[i].c.v != b.UNRESTRICTED && bVarArr[i].d < 0.0f) {
                obj = 1;
                break;
            }
            i++;
        }
        if (obj == null) {
            return 0;
        }
        obj = null;
        int i2 = 0;
        while (obj == null) {
            f fVar = d;
            if (fVar != null) {
                fVar.k++;
            }
            i2++;
            float f2 = Float.MAX_VALUE;
            int i3 = 0;
            int i4 = -1;
            int i5 = -1;
            int i6 = 0;
            while (i3 < this.n) {
                b bVar = this.j[i3];
                if (!(bVar.c.v == b.UNRESTRICTED || bVar.g || bVar.d >= r4)) {
                    int i7 = 1;
                    while (i7 < this.m) {
                        h hVar = this.p.c[i7];
                        float g = bVar.f.g(hVar);
                        if (g > f) {
                            int i8 = 0;
                            while (i8 < 7) {
                                float f3 = hVar.u[i8] / g;
                                if ((f3 < f2 && i8 == r13) || i8 > r13) {
                                    i5 = i7;
                                    i6 = i8;
                                    f2 = f3;
                                    i4 = i3;
                                }
                                i8++;
                            }
                        }
                        i7++;
                        f = 0.0f;
                    }
                }
                i3++;
                f = 0.0f;
            }
            if (i4 != -1) {
                b bVar2 = this.j[i4];
                bVar2.c.r = -1;
                f fVar2 = d;
                if (fVar2 != null) {
                    fVar2.j++;
                }
                bVar2.w(this.p.c[i5]);
                h hVar2 = bVar2.c;
                hVar2.r = i4;
                hVar2.k(bVar2);
            } else {
                obj = 1;
            }
            if (i2 > this.m / 2) {
                obj = 1;
            }
            f = 0.0f;
        }
        return i2;
    }

    private String L(int i) {
        i *= 4;
        int i2 = i / 1024;
        int i3 = i2 / 1024;
        String str = "";
        StringBuilder stringBuilder;
        if (i3 > 0) {
            stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append(i3);
            stringBuilder.append(" Mb");
            return stringBuilder.toString();
        } else if (i2 > 0) {
            stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append(i2);
            stringBuilder.append(" Kb");
            return stringBuilder.toString();
        } else {
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(str);
            stringBuilder2.append(i);
            stringBuilder2.append(" bytes");
            return stringBuilder2.toString();
        }
    }

    private String M(int i) {
        return i == 1 ? "LOW" : i == 2 ? "MEDIUM" : i == 3 ? "HIGH" : i == 4 ? "HIGHEST" : i == 5 ? "EQUALITY" : i == 6 ? "FIXED" : "NONE";
    }

    public static f P() {
        return d;
    }

    private void W() {
        int i = this.h * 2;
        this.h = i;
        this.j = (b[]) Arrays.copyOf(this.j, i);
        c cVar = this.p;
        cVar.c = (h[]) Arrays.copyOf(cVar.c, this.h);
        i = this.h;
        this.l = new boolean[i];
        this.i = i;
        this.o = i;
        f fVar = d;
        if (fVar != null) {
            fVar.d++;
            fVar.p = Math.max(fVar.p, (long) i);
            f fVar2 = d;
            fVar2.D = fVar2.p;
        }
    }

    private final int Z(a aVar, boolean z) {
        f fVar = d;
        if (fVar != null) {
            fVar.h++;
        }
        for (int i = 0; i < this.m; i++) {
            this.l[i] = false;
        }
        Object obj = null;
        int i2 = 0;
        while (obj == null) {
            f fVar2 = d;
            if (fVar2 != null) {
                fVar2.i++;
            }
            i2++;
            if (i2 >= this.m * 2) {
                return i2;
            }
            if (aVar.getKey() != null) {
                this.l[aVar.getKey().q] = true;
            }
            h b = aVar.b(this, this.l);
            if (b != null) {
                boolean[] zArr = this.l;
                int i3 = b.q;
                if (zArr[i3]) {
                    return i2;
                }
                zArr[i3] = true;
            }
            if (b != null) {
                float f = Float.MAX_VALUE;
                int i4 = -1;
                for (int i5 = 0; i5 < this.n; i5++) {
                    b bVar = this.j[i5];
                    if (!(bVar.c.v == b.UNRESTRICTED || bVar.g || !bVar.u(b))) {
                        float g = bVar.f.g(b);
                        if (g < 0.0f) {
                            float f2 = (-bVar.d) / g;
                            if (f2 < f) {
                                i4 = i5;
                                f = f2;
                            }
                        }
                    }
                }
                if (i4 > -1) {
                    b bVar2 = this.j[i4];
                    bVar2.c.r = -1;
                    f fVar3 = d;
                    if (fVar3 != null) {
                        fVar3.j++;
                    }
                    bVar2.w(b);
                    b = bVar2.c;
                    b.r = i4;
                    b.k(bVar2);
                }
            }
            obj = 1;
        }
        return i2;
    }

    private h a(b bVar, String str) {
        h hVar = (h) this.p.b.a();
        if (hVar == null) {
            hVar = new h(bVar, str);
            hVar.i(bVar, str);
        } else {
            hVar.g();
            hVar.i(bVar, str);
        }
        int i = this.r;
        int i2 = c;
        if (i >= i2) {
            i2 *= 2;
            c = i2;
            this.q = (h[]) Arrays.copyOf(this.q, i2);
        }
        h[] hVarArr = this.q;
        i2 = this.r;
        this.r = i2 + 1;
        hVarArr[i2] = hVar;
        return hVar;
    }

    private void a0() {
        int i = 0;
        while (true) {
            b[] bVarArr = this.j;
            if (i < bVarArr.length) {
                Object obj = bVarArr[i];
                if (obj != null) {
                    this.p.a.b(obj);
                }
                this.j[i] = null;
                i++;
            } else {
                return;
            }
        }
    }

    private final void c0(b bVar) {
        if (this.n > 0) {
            bVar.f.s(bVar, this.j);
            if (bVar.f.d == 0) {
                bVar.g = true;
            }
        }
    }

    private void h(b bVar) {
        bVar.d(this, 0);
    }

    private final void o(b bVar) {
        b[] bVarArr = this.j;
        int i = this.n;
        if (bVarArr[i] != null) {
            this.p.a.b(bVarArr[i]);
        }
        bVarArr = this.j;
        i = this.n;
        bVarArr[i] = bVar;
        h hVar = bVar.c;
        hVar.r = i;
        this.n = i + 1;
        hVar.k(bVar);
    }

    private void p(b bVar, int i) {
        q(bVar, i, 0);
    }

    private void r() {
        for (int i = 0; i < this.n; i++) {
            b bVar = this.j[i];
            bVar.c.t = bVar.d;
        }
    }

    public static b w(e eVar, h hVar, h hVar2, int i, float f, h hVar3, h hVar4, int i2, boolean z) {
        b v = eVar.v();
        v.g(hVar, hVar2, i, f, hVar3, hVar4, i2);
        if (z) {
            e eVar2 = eVar;
            v.d(eVar, 4);
        }
        return v;
    }

    public static b x(e eVar, h hVar, h hVar2, h hVar3, float f, boolean z) {
        b v = eVar.v();
        if (z) {
            eVar.h(v);
        }
        return v.i(hVar, hVar2, hVar3, f);
    }

    public static b y(e eVar, h hVar, h hVar2, int i, boolean z) {
        b v = eVar.v();
        v.n(hVar, hVar2, i);
        if (z) {
            eVar.p(v, 1);
        }
        return v;
    }

    public static b z(e eVar, h hVar, h hVar2, int i, boolean z) {
        h B = eVar.B();
        b v = eVar.v();
        v.p(hVar, hVar2, B, i);
        if (z) {
            eVar.p(v, (int) (v.f.g(B) * -1.0f));
        }
        return v;
    }

    public h B() {
        f fVar = d;
        if (fVar != null) {
            fVar.n++;
        }
        if (this.m + 1 >= this.i) {
            W();
        }
        h a = a(b.SLACK, null);
        int i = this.e + 1;
        this.e = i;
        this.m++;
        a.q = i;
        this.p.c[i] = a;
        return a;
    }

    void D() {
        F();
        String str = " #  ";
        for (int i = 0; i < this.n; i++) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append(this.j[i].z());
            str = stringBuilder.toString();
            stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append("\n #  ");
            str = stringBuilder.toString();
        }
        if (this.g != null) {
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(str);
            stringBuilder2.append(this.g);
            stringBuilder2.append("\n");
            str = stringBuilder2.toString();
        }
        System.out.println(str);
    }

    void G() {
        int i;
        int i2 = 0;
        for (i = 0; i < this.h; i++) {
            b[] bVarArr = this.j;
            if (bVarArr[i] != null) {
                i2 += bVarArr[i].y();
            }
        }
        int i3 = 0;
        for (i = 0; i < this.n; i++) {
            b[] bVarArr2 = this.j;
            if (bVarArr2[i] != null) {
                i3 += bVarArr2[i].y();
            }
        }
        PrintStream printStream = System.out;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Linear System -> Table size: ");
        stringBuilder.append(this.h);
        stringBuilder.append(" (");
        int i4 = this.h;
        stringBuilder.append(L(i4 * i4));
        stringBuilder.append(") -- row sizes: ");
        stringBuilder.append(L(i2));
        stringBuilder.append(", actual size: ");
        stringBuilder.append(L(i3));
        stringBuilder.append(" rows: ");
        stringBuilder.append(this.n);
        String str = "/";
        stringBuilder.append(str);
        stringBuilder.append(this.o);
        stringBuilder.append(" cols: ");
        stringBuilder.append(this.m);
        stringBuilder.append(str);
        stringBuilder.append(this.i);
        stringBuilder.append(" ");
        stringBuilder.append(0);
        stringBuilder.append(" occupied cells, ");
        stringBuilder.append(L(0));
        printStream.println(stringBuilder.toString());
    }

    public void H() {
        F();
        String str = "";
        int i = 0;
        while (true) {
            String str2 = "\n";
            if (i < this.n) {
                if (this.j[i].c.v == b.UNRESTRICTED) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(str);
                    stringBuilder.append(this.j[i].z());
                    str = stringBuilder.toString();
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(str);
                    stringBuilder.append(str2);
                    str = stringBuilder.toString();
                }
                i++;
            } else {
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append(str);
                stringBuilder2.append(this.g);
                stringBuilder2.append(str2);
                System.out.println(stringBuilder2.toString());
                return;
            }
        }
    }

    public void J(f fVar) {
        d = fVar;
    }

    public c K() {
        return this.p;
    }

    a N() {
        return this.g;
    }

    public int O() {
        int i = 0;
        for (int i2 = 0; i2 < this.n; i2++) {
            b[] bVarArr = this.j;
            if (bVarArr[i2] != null) {
                i += bVarArr[i2].y();
            }
        }
        return i;
    }

    public int Q() {
        return this.n;
    }

    public int R() {
        return this.e;
    }

    public int S(Object obj) {
        h m = ((b.f.a.i.e) obj).m();
        return m != null ? (int) (m.t + 0.5f) : 0;
    }

    b T(int i) {
        return this.j[i];
    }

    float U(String str) {
        h V = V(str, b.UNRESTRICTED);
        return V == null ? 0.0f : V.t;
    }

    h V(String str, b bVar) {
        if (this.f == null) {
            this.f = new HashMap();
        }
        h hVar = (h) this.f.get(str);
        return hVar == null ? C(str, bVar) : hVar;
    }

    public void X() throws Exception {
        f fVar = d;
        if (fVar != null) {
            fVar.e++;
        }
        if (this.k) {
            if (fVar != null) {
                fVar.r++;
            }
            Object obj = null;
            for (int i = 0; i < this.n; i++) {
                if (!this.j[i].g) {
                    break;
                }
            }
            obj = 1;
            if (obj == null) {
                Y(this.g);
                return;
            }
            fVar = d;
            if (fVar != null) {
                fVar.q++;
            }
            r();
            return;
        }
        Y(this.g);
    }

    void Y(a aVar) throws Exception {
        f fVar = d;
        if (fVar != null) {
            fVar.t++;
            fVar.u = Math.max(fVar.u, (long) this.m);
            fVar = d;
            fVar.v = Math.max(fVar.v, (long) this.n);
        }
        c0((b) aVar);
        I(aVar);
        Z(aVar, false);
        r();
    }

    public void b(h hVar, h hVar2, float f, int i) {
        h hVar3 = hVar;
        h hVar4 = hVar2;
        d dVar = d.LEFT;
        h u = u(hVar3.s(dVar));
        d dVar2 = d.TOP;
        h u2 = u(hVar3.s(dVar2));
        d dVar3 = d.RIGHT;
        h u3 = u(hVar3.s(dVar3));
        d dVar4 = d.BOTTOM;
        h u4 = u(hVar3.s(dVar4));
        h u5 = u(hVar4.s(dVar));
        h u6 = u(hVar4.s(dVar2));
        h u7 = u(hVar4.s(dVar3));
        h u8 = u(hVar4.s(dVar4));
        b v = v();
        double d = (double) f;
        double sin = Math.sin(d);
        h hVar5 = u7;
        double d2 = d;
        double d3 = (double) i;
        Double.isNaN(d3);
        v.r(u2, u4, u6, u8, (float) (sin * d3));
        d(v);
        v = v();
        double cos = Math.cos(d2);
        Double.isNaN(d3);
        v.r(u, u3, u5, hVar5, (float) (cos * d3));
        d(v);
    }

    public void b0() {
        c cVar;
        int i = 0;
        while (true) {
            cVar = this.p;
            h[] hVarArr = cVar.c;
            if (i >= hVarArr.length) {
                break;
            }
            h hVar = hVarArr[i];
            if (hVar != null) {
                hVar.g();
            }
            i++;
        }
        cVar.b.c(this.q, this.r);
        this.r = 0;
        Arrays.fill(this.p.c, null);
        HashMap hashMap = this.f;
        if (hashMap != null) {
            hashMap.clear();
        }
        this.e = 0;
        this.g.clear();
        this.m = 1;
        for (i = 0; i < this.n; i++) {
            this.j[i].e = false;
        }
        a0();
        this.n = 0;
    }

    public void c(h hVar, h hVar2, int i, float f, h hVar3, h hVar4, int i2, int i3) {
        int i4 = i3;
        b v = v();
        v.g(hVar, hVar2, i, f, hVar3, hVar4, i2);
        if (i4 != 6) {
            v.d(this, i4);
        }
        d(v);
    }

    public void d(b bVar) {
        if (bVar != null) {
            f fVar = d;
            if (fVar != null) {
                fVar.f++;
                if (bVar.g) {
                    fVar.g++;
                }
            }
            boolean z = true;
            if (this.n + 1 >= this.o || this.m + 1 >= this.i) {
                W();
            }
            boolean z2 = false;
            if (!bVar.g) {
                c0(bVar);
                if (!bVar.isEmpty()) {
                    bVar.s();
                    if (bVar.f(this)) {
                        h t = t();
                        bVar.c = t;
                        o(bVar);
                        this.t.c(bVar);
                        Z(this.t, true);
                        if (t.r == -1) {
                            if (bVar.c == t) {
                                t = bVar.v(t);
                                if (t != null) {
                                    f fVar2 = d;
                                    if (fVar2 != null) {
                                        fVar2.j++;
                                    }
                                    bVar.w(t);
                                }
                            }
                            if (!bVar.g) {
                                bVar.c.k(bVar);
                            }
                            this.n--;
                        }
                    } else {
                        z = false;
                    }
                    if (bVar.t()) {
                        z2 = z;
                    } else {
                        return;
                    }
                }
                return;
            }
            if (!z2) {
                o(bVar);
            }
        }
    }

    public b e(h hVar, h hVar2, int i, int i2) {
        b v = v();
        v.n(hVar, hVar2, i);
        if (i2 != 6) {
            v.d(this, i2);
        }
        d(v);
        return v;
    }

    public void f(h hVar, int i) {
        int i2 = hVar.r;
        b bVar;
        if (i2 != -1) {
            bVar = this.j[i2];
            if (bVar.g) {
                bVar.d = (float) i;
                return;
            } else if (bVar.f.d == 0) {
                bVar.g = true;
                bVar.d = (float) i;
                return;
            } else {
                bVar = v();
                bVar.m(hVar, i);
                d(bVar);
                return;
            }
        }
        bVar = v();
        bVar.h(hVar, i);
        d(bVar);
    }

    public void g(h hVar, int i, int i2) {
        int i3 = hVar.r;
        b bVar;
        if (i3 != -1) {
            bVar = this.j[i3];
            if (bVar.g) {
                bVar.d = (float) i;
                return;
            }
            bVar = v();
            bVar.m(hVar, i);
            bVar.d(this, i2);
            d(bVar);
            return;
        }
        bVar = v();
        bVar.h(hVar, i);
        bVar.d(this, i2);
        d(bVar);
    }

    public void i(h hVar, h hVar2, boolean z) {
        b v = v();
        h B = B();
        B.s = 0;
        v.p(hVar, hVar2, B, 0);
        if (z) {
            q(v, (int) (v.f.g(B) * -1.0f), 1);
        }
        d(v);
    }

    public void j(h hVar, int i) {
        b v = v();
        h B = B();
        B.s = 0;
        v.o(hVar, i, B);
        d(v);
    }

    public void k(h hVar, h hVar2, int i, int i2) {
        b v = v();
        h B = B();
        B.s = 0;
        v.p(hVar, hVar2, B, i);
        if (i2 != 6) {
            q(v, (int) (v.f.g(B) * -1.0f), i2);
        }
        d(v);
    }

    public void l(h hVar, h hVar2, boolean z) {
        b v = v();
        h B = B();
        B.s = 0;
        v.q(hVar, hVar2, B, 0);
        if (z) {
            q(v, (int) (v.f.g(B) * -1.0f), 1);
        }
        d(v);
    }

    public void m(h hVar, h hVar2, int i, int i2) {
        b v = v();
        h B = B();
        B.s = 0;
        v.q(hVar, hVar2, B, i);
        if (i2 != 6) {
            q(v, (int) (v.f.g(B) * -1.0f), i2);
        }
        d(v);
    }

    public void n(h hVar, h hVar2, h hVar3, h hVar4, float f, int i) {
        b v = v();
        v.j(hVar, hVar2, hVar3, hVar4, f);
        if (i != 6) {
            v.d(this, i);
        }
        d(v);
    }

    void q(b bVar, int i, int i2) {
        bVar.e(s(i2, null), i);
    }

    public h s(int i, String str) {
        f fVar = d;
        if (fVar != null) {
            fVar.m++;
        }
        if (this.m + 1 >= this.i) {
            W();
        }
        h a = a(b.ERROR, str);
        int i2 = this.e + 1;
        this.e = i2;
        this.m++;
        a.q = i2;
        a.s = i;
        this.p.c[i2] = a;
        this.g.a(a);
        return a;
    }

    public h t() {
        f fVar = d;
        if (fVar != null) {
            fVar.o++;
        }
        if (this.m + 1 >= this.i) {
            W();
        }
        h a = a(b.SLACK, null);
        int i = this.e + 1;
        this.e = i;
        this.m++;
        a.q = i;
        this.p.c[i] = a;
        return a;
    }

    public h u(Object obj) {
        h hVar = null;
        if (obj == null) {
            return null;
        }
        if (this.m + 1 >= this.i) {
            W();
        }
        if (obj instanceof b.f.a.i.e) {
            b.f.a.i.e eVar = (b.f.a.i.e) obj;
            hVar = eVar.m();
            if (hVar == null) {
                eVar.A(this.p);
                hVar = eVar.m();
            }
            int i = hVar.q;
            if (i == -1 || i > this.e || this.p.c[i] == null) {
                if (i != -1) {
                    hVar.g();
                }
                i = this.e + 1;
                this.e = i;
                this.m++;
                hVar.q = i;
                hVar.v = b.UNRESTRICTED;
                this.p.c[i] = hVar;
            }
        }
        return hVar;
    }

    public b v() {
        b bVar = (b) this.p.a.a();
        if (bVar == null) {
            bVar = new b(this.p);
        } else {
            bVar.x();
        }
        h.e();
        return bVar;
    }
}
