package b.f.a.i;

public class n {
    public int a;
    public int b;
    public int c;
    public int d;

    public boolean a(int i, int i2) {
        int i3 = this.a;
        if (i >= i3 && i < i3 + this.c) {
            i = this.b;
            if (i2 >= i && i2 < i + this.d) {
                return true;
            }
        }
        return false;
    }

    public int b() {
        return (this.a + this.c) / 2;
    }

    public int c() {
        return (this.b + this.d) / 2;
    }

    void d(int i, int i2) {
        this.a -= i;
        this.b -= i2;
        this.c += i * 2;
        this.d += i2 * 2;
    }

    boolean e(n nVar) {
        int i = this.a;
        int i2 = nVar.a;
        if (i >= i2 && i < i2 + nVar.c) {
            i = this.b;
            i2 = nVar.b;
            if (i >= i2 && i < i2 + nVar.d) {
                return true;
            }
        }
        return false;
    }

    public void f(int i, int i2, int i3, int i4) {
        this.a = i;
        this.b = i2;
        this.c = i3;
        this.d = i4;
    }
}
