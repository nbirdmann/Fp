package b.f.a.i;

import java.util.Arrays;

public class l extends h {
    protected h[] c1 = new h[4];
    protected int d1 = 0;

    public void P1(h hVar) {
        int i = this.d1 + 1;
        h[] hVarArr = this.c1;
        if (i > hVarArr.length) {
            this.c1 = (h[]) Arrays.copyOf(hVarArr, hVarArr.length * 2);
        }
        h[] hVarArr2 = this.c1;
        int i2 = this.d1;
        hVarArr2[i2] = hVar;
        this.d1 = i2 + 1;
    }

    public void Q1() {
        this.d1 = 0;
    }
}
