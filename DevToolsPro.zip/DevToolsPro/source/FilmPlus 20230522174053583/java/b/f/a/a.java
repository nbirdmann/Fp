package b.f.a;

import b.f.a.h.b;
import java.io.PrintStream;
import java.util.Arrays;

public class a {
    private static final boolean a = false;
    private static final int b = -1;
    private static final boolean c = false;
    int d = 0;
    private final b e;
    private final c f;
    private int g = 8;
    private h h = null;
    private int[] i = new int[8];
    private int[] j = new int[8];
    private float[] k = new float[8];
    private int l = -1;
    private int m = -1;
    private boolean n = false;

    a(b bVar, c cVar) {
        this.e = bVar;
        this.f = cVar;
    }

    private boolean n(h hVar, e eVar) {
        return hVar.y <= 1;
    }

    final void a(h hVar, float f, boolean z) {
        if (f != 0.0f) {
            int i = this.l;
            int i2;
            int[] iArr;
            if (i == -1) {
                this.l = 0;
                this.k[0] = f;
                this.i[0] = hVar.q;
                this.j[0] = -1;
                hVar.y++;
                hVar.a(this.e);
                this.d++;
                if (!this.n) {
                    i2 = this.m + 1;
                    this.m = i2;
                    iArr = this.i;
                    if (i2 >= iArr.length) {
                        this.n = true;
                        this.m = iArr.length - 1;
                    }
                }
                return;
            }
            int[] iArr2;
            int i3 = 0;
            int i4 = -1;
            while (i != -1 && i3 < this.d) {
                int[] iArr3 = this.i;
                int i5 = iArr3[i];
                int i6 = hVar.q;
                if (i5 == i6) {
                    float[] fArr = this.k;
                    fArr[i] = fArr[i] + f;
                    if (fArr[i] == 0.0f) {
                        if (i == this.l) {
                            this.l = this.j[i];
                        } else {
                            iArr = this.j;
                            iArr[i4] = iArr[i];
                        }
                        if (z) {
                            hVar.f(this.e);
                        }
                        if (this.n) {
                            this.m = i;
                        }
                        hVar.y--;
                        this.d--;
                    }
                    return;
                }
                if (iArr3[i] < i6) {
                    i4 = i;
                }
                i = this.j[i];
                i3++;
            }
            int i7 = this.m;
            int i8 = i7 + 1;
            if (this.n) {
                iArr2 = this.i;
                if (iArr2[i7] != -1) {
                    i7 = iArr2.length;
                }
            } else {
                i7 = i8;
            }
            iArr2 = this.i;
            if (i7 >= iArr2.length && this.d < iArr2.length) {
                i8 = 0;
                while (true) {
                    int[] iArr4 = this.i;
                    if (i8 >= iArr4.length) {
                        break;
                    } else if (iArr4[i8] == -1) {
                        i7 = i8;
                        break;
                    } else {
                        i8++;
                    }
                }
            }
            iArr2 = this.i;
            if (i7 >= iArr2.length) {
                i7 = iArr2.length;
                i8 = this.g * 2;
                this.g = i8;
                this.n = false;
                this.m = i7 - 1;
                this.k = Arrays.copyOf(this.k, i8);
                this.i = Arrays.copyOf(this.i, this.g);
                this.j = Arrays.copyOf(this.j, this.g);
            }
            this.i[i7] = hVar.q;
            this.k[i7] = f;
            if (i4 != -1) {
                iArr = this.j;
                iArr[i7] = iArr[i4];
                iArr[i4] = i7;
            } else {
                this.j[i7] = this.l;
                this.l = i7;
            }
            hVar.y++;
            hVar.a(this.e);
            this.d++;
            if (!this.n) {
                this.m++;
            }
            i2 = this.m;
            iArr = this.i;
            if (i2 >= iArr.length) {
                this.n = true;
                this.m = iArr.length - 1;
            }
        }
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:48:0x0090 A:{SYNTHETIC} */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:16:0x0047  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:48:0x0090 A:{SYNTHETIC} */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:16:0x0047  */
    b.f.a.h b(b.f.a.e r15) {
        /*
        r14 = this;
        r0 = r14.l;
        r1 = 0;
        r2 = 0;
        r3 = 0;
        r2 = r1;
        r4 = 0;
        r5 = 0;
        r6 = 0;
        r7 = 0;
        r8 = 0;
    L_0x000b:
        r9 = -1;
        if (r0 == r9) goto L_0x0098;
    L_0x000e:
        r9 = r14.d;
        if (r4 >= r9) goto L_0x0098;
    L_0x0012:
        r9 = r14.k;
        r10 = r9[r0];
        r11 = 981668463; // 0x3a83126f float:0.001 double:4.85008663E-315;
        r12 = r14.f;
        r12 = r12.c;
        r13 = r14.i;
        r13 = r13[r0];
        r12 = r12[r13];
        r13 = (r10 > r3 ? 1 : (r10 == r3 ? 0 : -1));
        if (r13 >= 0) goto L_0x0036;
    L_0x0027:
        r11 = -1165815185; // 0xffffffffba83126f float:-0.001 double:NaN;
        r11 = (r10 > r11 ? 1 : (r10 == r11 ? 0 : -1));
        if (r11 <= 0) goto L_0x0042;
    L_0x002e:
        r9[r0] = r3;
        r9 = r14.e;
        r12.f(r9);
        goto L_0x0041;
    L_0x0036:
        r11 = (r10 > r11 ? 1 : (r10 == r11 ? 0 : -1));
        if (r11 >= 0) goto L_0x0042;
    L_0x003a:
        r9[r0] = r3;
        r9 = r14.e;
        r12.f(r9);
    L_0x0041:
        r10 = 0;
    L_0x0042:
        r9 = 1;
        r11 = (r10 > r3 ? 1 : (r10 == r3 ? 0 : -1));
        if (r11 == 0) goto L_0x0090;
    L_0x0047:
        r11 = r12.v;
        r13 = b.f.a.h.b.UNRESTRICTED;
        if (r11 != r13) goto L_0x006c;
    L_0x004d:
        if (r2 != 0) goto L_0x0057;
    L_0x004f:
        r2 = r14.n(r12, r15);
    L_0x0053:
        r5 = r2;
        r7 = r10;
        r2 = r12;
        goto L_0x0090;
    L_0x0057:
        r11 = (r7 > r10 ? 1 : (r7 == r10 ? 0 : -1));
        if (r11 <= 0) goto L_0x0060;
    L_0x005b:
        r2 = r14.n(r12, r15);
        goto L_0x0053;
    L_0x0060:
        if (r5 != 0) goto L_0x0090;
    L_0x0062:
        r11 = r14.n(r12, r15);
        if (r11 == 0) goto L_0x0090;
    L_0x0068:
        r7 = r10;
        r2 = r12;
        r5 = 1;
        goto L_0x0090;
    L_0x006c:
        if (r2 != 0) goto L_0x0090;
    L_0x006e:
        r11 = (r10 > r3 ? 1 : (r10 == r3 ? 0 : -1));
        if (r11 >= 0) goto L_0x0090;
    L_0x0072:
        if (r1 != 0) goto L_0x007c;
    L_0x0074:
        r1 = r14.n(r12, r15);
    L_0x0078:
        r6 = r1;
        r8 = r10;
        r1 = r12;
        goto L_0x0090;
    L_0x007c:
        r11 = (r8 > r10 ? 1 : (r8 == r10 ? 0 : -1));
        if (r11 <= 0) goto L_0x0085;
    L_0x0080:
        r1 = r14.n(r12, r15);
        goto L_0x0078;
    L_0x0085:
        if (r6 != 0) goto L_0x0090;
    L_0x0087:
        r11 = r14.n(r12, r15);
        if (r11 == 0) goto L_0x0090;
    L_0x008d:
        r8 = r10;
        r1 = r12;
        r6 = 1;
    L_0x0090:
        r9 = r14.j;
        r0 = r9[r0];
        r4 = r4 + 1;
        goto L_0x000b;
    L_0x0098:
        if (r2 == 0) goto L_0x009b;
    L_0x009a:
        return r2;
    L_0x009b:
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.f.a.a.b(b.f.a.e):b.f.a.h");
    }

    public final void c() {
        int i = this.l;
        int i2 = 0;
        while (i != -1 && i2 < this.d) {
            h hVar = this.f.c[this.i[i]];
            if (hVar != null) {
                hVar.f(this.e);
            }
            i = this.j[i];
            i2++;
        }
        this.l = -1;
        this.m = -1;
        this.n = false;
        this.d = 0;
    }

    final boolean d(h hVar) {
        int i = this.l;
        if (i == -1) {
            return false;
        }
        int i2 = 0;
        while (i != -1 && i2 < this.d) {
            if (this.i[i] == hVar.q) {
                return true;
            }
            i = this.j[i];
            i2++;
        }
        return false;
    }

    public void e() {
        int i = this.d;
        System.out.print("{ ");
        for (int i2 = 0; i2 < i; i2++) {
            h j = j(i2);
            if (j != null) {
                PrintStream printStream = System.out;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(j);
                stringBuilder.append(" = ");
                stringBuilder.append(k(i2));
                stringBuilder.append(" ");
                printStream.print(stringBuilder.toString());
            }
        }
        System.out.println(" }");
    }

    void f(float f) {
        int i = this.l;
        int i2 = 0;
        while (i != -1 && i2 < this.d) {
            float[] fArr = this.k;
            fArr[i] = fArr[i] / f;
            i = this.j[i];
            i2++;
        }
    }

    public final float g(h hVar) {
        int i = this.l;
        int i2 = 0;
        while (i != -1 && i2 < this.d) {
            if (this.i[i] == hVar.q) {
                return this.k[i];
            }
            i = this.j[i];
            i2++;
        }
        return 0.0f;
    }

    h h() {
        h hVar = this.h;
        if (hVar != null) {
            return hVar;
        }
        int i = this.l;
        int i2 = 0;
        h hVar2 = null;
        while (i != -1 && i2 < this.d) {
            if (this.k[i] < 0.0f) {
                h hVar3 = this.f.c[this.i[i]];
                if (hVar2 == null || hVar2.s < hVar3.s) {
                    hVar2 = hVar3;
                }
            }
            i = this.j[i];
            i2++;
        }
        return hVar2;
    }

    h i(boolean[] zArr, h hVar) {
        int i = this.l;
        int i2 = 0;
        h hVar2 = null;
        float f = 0.0f;
        while (i != -1 && i2 < this.d) {
            float[] fArr = this.k;
            if (fArr[i] < 0.0f) {
                h hVar3 = this.f.c[this.i[i]];
                if ((zArr == null || !zArr[hVar3.q]) && hVar3 != hVar) {
                    b bVar = hVar3.v;
                    if (bVar == b.SLACK || bVar == b.ERROR) {
                        float f2 = fArr[i];
                        if (f2 < f) {
                            f = f2;
                            hVar2 = hVar3;
                        }
                    }
                }
            }
            i = this.j[i];
            i2++;
        }
        return hVar2;
    }

    final h j(int i) {
        int i2 = this.l;
        int i3 = 0;
        while (i2 != -1 && i3 < this.d) {
            if (i3 == i) {
                return this.f.c[this.i[i2]];
            }
            i2 = this.j[i2];
            i3++;
        }
        return null;
    }

    final float k(int i) {
        int i2 = this.l;
        int i3 = 0;
        while (i2 != -1 && i3 < this.d) {
            if (i3 == i) {
                return this.k[i2];
            }
            i2 = this.j[i2];
            i3++;
        }
        return 0.0f;
    }

    boolean l() {
        int i = this.l;
        int i2 = 0;
        while (i != -1 && i2 < this.d) {
            if (this.k[i] > 0.0f) {
                return true;
            }
            i = this.j[i];
            i2++;
        }
        return false;
    }

    void m() {
        int i = this.l;
        int i2 = 0;
        while (i != -1 && i2 < this.d) {
            float[] fArr = this.k;
            fArr[i] = fArr[i] * -1.0f;
            i = this.j[i];
            i2++;
        }
    }

    public final void o(h hVar, float f) {
        if (f == 0.0f) {
            p(hVar, true);
            return;
        }
        int i = this.l;
        int i2;
        int[] iArr;
        if (i == -1) {
            this.l = 0;
            this.k[0] = f;
            this.i[0] = hVar.q;
            this.j[0] = -1;
            hVar.y++;
            hVar.a(this.e);
            this.d++;
            if (!this.n) {
                i2 = this.m + 1;
                this.m = i2;
                iArr = this.i;
                if (i2 >= iArr.length) {
                    this.n = true;
                    this.m = iArr.length - 1;
                }
            }
            return;
        }
        int[] iArr2;
        int[] iArr3;
        int i3 = 0;
        int i4 = -1;
        while (i != -1 && i3 < this.d) {
            iArr2 = this.i;
            int i5 = iArr2[i];
            int i6 = hVar.q;
            if (i5 == i6) {
                this.k[i] = f;
                return;
            }
            if (iArr2[i] < i6) {
                i4 = i;
            }
            i = this.j[i];
            i3++;
        }
        i = this.m;
        i3 = i + 1;
        if (this.n) {
            iArr3 = this.i;
            if (iArr3[i] != -1) {
                i = iArr3.length;
            }
        } else {
            i = i3;
        }
        iArr3 = this.i;
        if (i >= iArr3.length && this.d < iArr3.length) {
            i3 = 0;
            while (true) {
                iArr2 = this.i;
                if (i3 >= iArr2.length) {
                    break;
                } else if (iArr2[i3] == -1) {
                    i = i3;
                    break;
                } else {
                    i3++;
                }
            }
        }
        iArr3 = this.i;
        if (i >= iArr3.length) {
            i = iArr3.length;
            i3 = this.g * 2;
            this.g = i3;
            this.n = false;
            this.m = i - 1;
            this.k = Arrays.copyOf(this.k, i3);
            this.i = Arrays.copyOf(this.i, this.g);
            this.j = Arrays.copyOf(this.j, this.g);
        }
        this.i[i] = hVar.q;
        this.k[i] = f;
        if (i4 != -1) {
            iArr = this.j;
            iArr[i] = iArr[i4];
            iArr[i4] = i;
        } else {
            this.j[i] = this.l;
            this.l = i;
        }
        hVar.y++;
        hVar.a(this.e);
        i2 = this.d + 1;
        this.d = i2;
        if (!this.n) {
            this.m++;
        }
        iArr = this.i;
        if (i2 >= iArr.length) {
            this.n = true;
        }
        if (this.m >= iArr.length) {
            this.n = true;
            this.m = iArr.length - 1;
        }
    }

    public final float p(h hVar, boolean z) {
        if (this.h == hVar) {
            this.h = null;
        }
        int i = this.l;
        if (i == -1) {
            return 0.0f;
        }
        int i2 = 0;
        int i3 = -1;
        while (i != -1 && i2 < this.d) {
            if (this.i[i] == hVar.q) {
                if (i == this.l) {
                    this.l = this.j[i];
                } else {
                    int[] iArr = this.j;
                    iArr[i3] = iArr[i];
                }
                if (z) {
                    hVar.f(this.e);
                }
                hVar.y--;
                this.d--;
                this.i[i] = -1;
                if (this.n) {
                    this.m = i;
                }
                return this.k[i];
            }
            i2++;
            i3 = i;
            i = this.j[i];
        }
        return 0.0f;
    }

    int q() {
        return (((this.i.length * 4) * 3) + 0) + 36;
    }

    final void r(b bVar, b bVar2, boolean z) {
        int i = this.l;
        while (true) {
            int i2 = 0;
            while (i != -1 && i2 < this.d) {
                int i3 = this.i[i];
                h hVar = bVar2.c;
                if (i3 == hVar.q) {
                    float f = this.k[i];
                    p(hVar, z);
                    a aVar = bVar2.f;
                    i3 = aVar.l;
                    int i4 = 0;
                    while (i3 != -1 && i4 < aVar.d) {
                        a(this.f.c[aVar.i[i3]], aVar.k[i3] * f, z);
                        i3 = aVar.j[i3];
                        i4++;
                    }
                    bVar.d += bVar2.d * f;
                    if (z) {
                        bVar2.c.f(bVar);
                    }
                    i = this.l;
                } else {
                    i = this.j[i];
                    i2++;
                }
            }
            return;
        }
    }

    void s(b bVar, b[] bVarArr) {
        int i = this.l;
        while (true) {
            int i2 = 0;
            while (i != -1 && i2 < this.d) {
                h hVar = this.f.c[this.i[i]];
                if (hVar.r != -1) {
                    float f = this.k[i];
                    p(hVar, true);
                    b bVar2 = bVarArr[hVar.r];
                    if (!bVar2.g) {
                        a aVar = bVar2.f;
                        int i3 = aVar.l;
                        int i4 = 0;
                        while (i3 != -1 && i4 < aVar.d) {
                            a(this.f.c[aVar.i[i3]], aVar.k[i3] * f, true);
                            i3 = aVar.j[i3];
                            i4++;
                        }
                    }
                    bVar.d += bVar2.d * f;
                    bVar2.c.f(bVar);
                    i = this.l;
                } else {
                    i = this.j[i];
                    i2++;
                }
            }
            return;
        }
    }

    public String toString() {
        int i = this.l;
        String str = "";
        int i2 = 0;
        while (i != -1 && i2 < this.d) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append(" -> ");
            str = stringBuilder.toString();
            stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append(this.k[i]);
            stringBuilder.append(" : ");
            str = stringBuilder.toString();
            stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append(this.f.c[this.i[i]]);
            str = stringBuilder.toString();
            i = this.j[i];
            i2++;
        }
        return str;
    }
}
