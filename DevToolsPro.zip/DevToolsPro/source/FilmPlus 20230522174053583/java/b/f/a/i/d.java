package b.f.a.i;

import b.f.a.i.h.c;
import java.util.ArrayList;

public class d {
    protected h a;
    protected h b;
    protected h c;
    protected h d;
    protected h e;
    protected h f;
    protected h g;
    protected ArrayList<h> h;
    protected int i;
    protected int j;
    protected float k = 0.0f;
    private int l;
    private boolean m = false;
    protected boolean n;
    protected boolean o;
    protected boolean p;
    private boolean q;

    public d(h hVar, int i, boolean z) {
        this.a = hVar;
        this.l = i;
        this.m = z;
    }

    private void b() {
        int i = this.l * 2;
        h hVar = this.a;
        boolean z = false;
        h hVar2 = hVar;
        Object obj = null;
        while (obj == null) {
            this.i++;
            h[] hVarArr = hVar.Z0;
            int i2 = this.l;
            h hVar3 = null;
            hVarArr[i2] = null;
            hVar.Y0[i2] = null;
            if (hVar.o0() != 8) {
                if (this.b == null) {
                    this.b = hVar;
                }
                this.d = hVar;
                c[] cVarArr = hVar.e0;
                i2 = this.l;
                if (cVarArr[i2] == c.MATCH_CONSTRAINT) {
                    int[] iArr = hVar.G;
                    if (iArr[i2] == 0 || iArr[i2] == 3 || iArr[i2] == 2) {
                        this.j++;
                        float[] fArr = hVar.X0;
                        float f = fArr[i2];
                        if (f > 0.0f) {
                            this.k += fArr[i2];
                        }
                        if (k(hVar, i2)) {
                            if (f < 0.0f) {
                                this.n = true;
                            } else {
                                this.o = true;
                            }
                            if (this.h == null) {
                                this.h = new ArrayList();
                            }
                            this.h.add(hVar);
                        }
                        if (this.f == null) {
                            this.f = hVar;
                        }
                        h hVar4 = this.g;
                        if (hVar4 != null) {
                            hVar4.Y0[this.l] = hVar;
                        }
                        this.g = hVar;
                    }
                }
            }
            if (hVar2 != hVar) {
                hVar2.Z0[this.l] = hVar;
            }
            e eVar = hVar.c0[i + 1].i;
            if (eVar != null) {
                hVar2 = eVar.g;
                e[] eVarArr = hVar2.c0;
                if (eVarArr[i].i != null && eVarArr[i].i.g == hVar) {
                    hVar3 = hVar2;
                }
            }
            if (hVar3 == null) {
                hVar3 = hVar;
                obj = 1;
            }
            hVar2 = hVar;
            hVar = hVar3;
        }
        this.c = hVar;
        if (this.l == 0 && this.m) {
            this.e = hVar;
        } else {
            this.e = this.a;
        }
        if (this.o && this.n) {
            z = true;
        }
        this.p = z;
    }

    private static boolean k(h hVar, int i) {
        if (hVar.o0() != 8 && hVar.e0[i] == c.MATCH_CONSTRAINT) {
            int[] iArr = hVar.G;
            if (iArr[i] == 0 || iArr[i] == 3) {
                return true;
            }
        }
        return false;
    }

    public void a() {
        if (!this.q) {
            b();
        }
        this.q = true;
    }

    public h c() {
        return this.a;
    }

    public h d() {
        return this.f;
    }

    public h e() {
        return this.b;
    }

    public h f() {
        return this.e;
    }

    public h g() {
        return this.c;
    }

    public h h() {
        return this.g;
    }

    public h i() {
        return this.d;
    }

    public float j() {
        return this.k;
    }
}
