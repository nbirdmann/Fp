package b.f.a.i;

import b.f.a.e;
import b.f.a.i.e.c;
import b.f.a.i.e.d;
import java.util.ArrayList;

public class g extends i {
    public static final int E1 = 0;
    public static final int F1 = 1;
    public static final int G1 = 2;
    private static final int H1 = 3;
    private boolean I1 = true;
    private int J1 = 0;
    private int K1 = 0;
    private int L1 = 8;
    private ArrayList<b> M1 = new ArrayList();
    private ArrayList<a> N1 = new ArrayList();
    private ArrayList<k> O1 = new ArrayList();
    private ArrayList<k> P1 = new ArrayList();
    private e Q1 = null;

    class a {
        h a;
        h b;
        int c;

        a() {
        }
    }

    class b {
        h a;
        h b;
        int c = 1;
        int d;

        b() {
        }
    }

    public g(int i, int i2) {
        super(i, i2);
    }

    public g(int i, int i2, int i3, int i4) {
        super(i, i2, i3, i4);
    }

    private void H2() {
        int size = this.c1.size();
        int i = 0;
        for (int i2 = 0; i2 < size; i2++) {
            h hVar = (h) this.c1.get(i2);
            i += hVar.y();
            int i3 = this.J1;
            int i4 = i % i3;
            a aVar = (a) this.N1.get(i / i3);
            b bVar = (b) this.M1.get(i4);
            h hVar2 = bVar.a;
            h hVar3 = bVar.b;
            h hVar4 = aVar.a;
            h hVar5 = aVar.b;
            d dVar = d.LEFT;
            hVar.s(dVar).a(hVar2.s(dVar), this.L1);
            if (hVar3 instanceof k) {
                hVar.s(d.RIGHT).a(hVar3.s(dVar), this.L1);
            } else {
                d dVar2 = d.RIGHT;
                hVar.s(dVar2).a(hVar3.s(dVar2), this.L1);
            }
            i4 = bVar.c;
            if (i4 == 1) {
                hVar.s(dVar).F(c.STRONG);
                hVar.s(d.RIGHT).F(c.WEAK);
            } else if (i4 == 2) {
                hVar.s(dVar).F(c.WEAK);
                hVar.s(d.RIGHT).F(c.STRONG);
            } else if (i4 == 3) {
                hVar.l1(h.c.MATCH_CONSTRAINT);
            }
            d dVar3 = d.TOP;
            hVar.s(dVar3).a(hVar4.s(dVar3), this.L1);
            if (hVar5 instanceof k) {
                hVar.s(d.BOTTOM).a(hVar5.s(dVar3), this.L1);
            } else {
                dVar3 = d.BOTTOM;
                hVar.s(dVar3).a(hVar5.s(dVar3), this.L1);
            }
            i++;
        }
    }

    private void K2() {
        this.N1.clear();
        float f = 100.0f / ((float) this.K1);
        h hVar = this;
        float f2 = f;
        for (int i = 0; i < this.K1; i++) {
            a aVar = new a();
            aVar.a = hVar;
            if (i < this.K1 - 1) {
                hVar = new k();
                hVar.f2(0);
                hVar.v1(this);
                hVar.d2((int) f2);
                f2 += f;
                aVar.b = hVar;
                this.P1.add(hVar);
            } else {
                aVar.b = this;
            }
            hVar = aVar.b;
            this.N1.add(aVar);
        }
        R2();
    }

    private void Q2() {
        this.M1.clear();
        float f = 100.0f / ((float) this.J1);
        h hVar = this;
        float f2 = f;
        for (int i = 0; i < this.J1; i++) {
            b bVar = new b();
            bVar.a = hVar;
            if (i < this.J1 - 1) {
                hVar = new k();
                hVar.f2(1);
                hVar.v1(this);
                hVar.d2((int) f2);
                f2 += f;
                bVar.b = hVar;
                this.O1.add(hVar);
            } else {
                bVar.b = this;
            }
            hVar = bVar.b;
            this.M1.add(bVar);
        }
        R2();
    }

    private void R2() {
        if (this.Q1 != null) {
            int size = this.O1.size();
            for (int i = 0; i < size; i++) {
                k kVar = (k) this.O1.get(i);
                e eVar = this.Q1;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(z());
                stringBuilder.append(".VG");
                stringBuilder.append(i);
                kVar.U0(eVar, stringBuilder.toString());
            }
            size = this.P1.size();
            for (int i2 = 0; i2 < size; i2++) {
                k kVar2 = (k) this.P1.get(i2);
                e eVar2 = this.Q1;
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append(z());
                stringBuilder2.append(".HG");
                stringBuilder2.append(i2);
                kVar2.U0(eVar2, stringBuilder2.toString());
            }
        }
    }

    public void A2(int i) {
        b bVar = (b) this.M1.get(i);
        int i2 = bVar.c;
        if (i2 == 0) {
            bVar.c = 2;
        } else if (i2 == 1) {
            bVar.c = 0;
        } else if (i2 == 2) {
            bVar.c = 1;
        }
        H2();
    }

    public String B2(int i) {
        i = ((b) this.M1.get(i)).c;
        return i == 1 ? "L" : i == 0 ? "C" : i == 3 ? "F" : i == 2 ? "R" : "!";
    }

    public String C2() {
        int size = this.M1.size();
        String str = "";
        for (int i = 0; i < size; i++) {
            int i2 = ((b) this.M1.get(i)).c;
            StringBuilder stringBuilder;
            if (i2 == 1) {
                stringBuilder = new StringBuilder();
                stringBuilder.append(str);
                stringBuilder.append("L");
                str = stringBuilder.toString();
            } else if (i2 == 0) {
                stringBuilder = new StringBuilder();
                stringBuilder.append(str);
                stringBuilder.append("C");
                str = stringBuilder.toString();
            } else if (i2 == 3) {
                stringBuilder = new StringBuilder();
                stringBuilder.append(str);
                stringBuilder.append("F");
                str = stringBuilder.toString();
            } else if (i2 == 2) {
                stringBuilder = new StringBuilder();
                stringBuilder.append(str);
                stringBuilder.append("R");
                str = stringBuilder.toString();
            }
        }
        return str;
    }

    public int D2() {
        return this.J1;
    }

    public int E2() {
        return this.K1;
    }

    public int F2() {
        return this.L1;
    }

    public boolean G2() {
        return this.I1;
    }

    public void I2(int i, int i2) {
        if (i < this.M1.size()) {
            ((b) this.M1.get(i)).c = i2;
            H2();
        }
    }

    public void J2(String str) {
        int length = str.length();
        for (int i = 0; i < length; i++) {
            char charAt = str.charAt(i);
            if (charAt == 'L') {
                I2(i, 1);
            } else if (charAt == 'C') {
                I2(i, 0);
            } else if (charAt == 'F') {
                I2(i, 3);
            } else if (charAt == 'R') {
                I2(i, 2);
            } else {
                I2(i, 0);
            }
        }
    }

    public void L2(int i) {
        if (this.I1 && this.J1 != i) {
            this.J1 = i;
            Q2();
            O2();
        }
    }

    public void M2(int i) {
        if (!this.I1 && this.J1 != i) {
            this.K1 = i;
            K2();
            O2();
        }
    }

    public void N1(e eVar) {
        super.N1(eVar);
        if (eVar == this.j1) {
            int size = this.O1.size();
            for (int i = 0; i < size; i++) {
                ((k) this.O1.get(i)).N1(eVar);
            }
            size = this.P1.size();
            for (int i2 = 0; i2 < size; i2++) {
                ((k) this.P1.get(i2)).N1(eVar);
            }
        }
    }

    public void N2(int i) {
        if (i > 1) {
            this.L1 = i;
        }
    }

    public void O2() {
        int i;
        int size = this.c1.size();
        int i2 = 0;
        for (i = 0; i < size; i++) {
            i2 += ((h) this.c1.get(i)).y();
        }
        size += i2;
        int i3;
        if (this.I1) {
            if (this.J1 == 0) {
                L2(1);
            }
            i = this.J1;
            i3 = size / i;
            if (i * i3 < size) {
                i3++;
            }
            if (this.K1 != i3 || this.O1.size() != this.J1 - 1) {
                this.K1 = i3;
                K2();
            } else {
                return;
            }
        }
        if (this.K1 == 0) {
            M2(1);
        }
        i = this.K1;
        i3 = size / i;
        if (i * i3 < size) {
            i3++;
        }
        if (this.J1 != i3 || this.P1.size() != this.K1 - 1) {
            this.J1 = i3;
            Q2();
        } else {
            return;
        }
        H2();
    }

    public void P2(boolean z) {
        this.I1 = z;
    }

    public void U0(e eVar, String str) {
        this.Q1 = eVar;
        super.U0(eVar, str);
        R2();
    }

    public void b(e eVar) {
        super.b(eVar);
        int size = this.c1.size();
        if (size != 0) {
            O2();
            if (eVar == this.j1) {
                k kVar;
                int size2 = this.O1.size();
                int i = 0;
                while (true) {
                    boolean z = true;
                    if (i >= size2) {
                        break;
                    }
                    kVar = (k) this.O1.get(i);
                    if (N() != h.c.WRAP_CONTENT) {
                        z = false;
                    }
                    kVar.g2(z);
                    kVar.b(eVar);
                    i++;
                }
                size2 = this.P1.size();
                for (i = 0; i < size2; i++) {
                    kVar = (k) this.P1.get(i);
                    kVar.g2(n0() == h.c.WRAP_CONTENT);
                    kVar.b(eVar);
                }
                for (int i2 = 0; i2 < size; i2++) {
                    ((h) this.c1.get(i2)).b(eVar);
                }
            }
        }
    }

    public ArrayList<k> e2() {
        return this.P1;
    }

    public ArrayList<k> h2() {
        return this.O1;
    }

    public String j0() {
        return "ConstraintTableLayout";
    }

    public boolean j2() {
        return true;
    }

    public void z2() {
        int size = this.O1.size();
        for (int i = 0; i < size; i++) {
            ((k) this.O1.get(i)).Z1();
        }
        size = this.P1.size();
        for (int i2 = 0; i2 < size; i2++) {
            ((k) this.P1.get(i2)).Z1();
        }
    }
}
