package b.d;

import com.guideplus.co.R;

public final class a {

    public static final class a {
        public static final int a = 2130968674;
        public static final int b = 2130968675;
        public static final int c = 2130968676;
        public static final int d = 2130968677;
        public static final int e = 2130968678;
        public static final int f = 2130968679;
        public static final int g = 2130968680;
        public static final int h = 2130968788;
        public static final int i = 2130968789;
        public static final int j = 2130968790;
        public static final int k = 2130968791;
        public static final int l = 2130968792;

        private a() {
        }
    }

    public static final class b {
        public static final int a = 2131099697;
        public static final int b = 2131099698;
        public static final int c = 2131099699;
        public static final int d = 2131099700;

        private b() {
        }
    }

    public static final class c {
        public static final int a = 2131165259;
        public static final int b = 2131165260;
        public static final int c = 2131165261;

        private c() {
        }
    }

    public static final class d {
        public static final int a = 2131951632;
        public static final int b = 2131951815;
        public static final int c = 2131951816;
        public static final int d = 2131951817;

        private d() {
        }
    }

    public static final class e {
        public static final int[] a = new int[]{16843071, 16843072, R.attr.cardBackgroundColor, R.attr.cardCornerRadius, R.attr.cardElevation, R.attr.cardMaxElevation, R.attr.cardPreventCornerOverlap, R.attr.cardUseCompatPadding, R.attr.contentPadding, R.attr.contentPaddingBottom, R.attr.contentPaddingLeft, R.attr.contentPaddingRight, R.attr.contentPaddingTop};
        public static final int b = 0;
        public static final int c = 1;
        public static final int d = 2;
        public static final int e = 3;
        public static final int f = 4;
        public static final int g = 5;
        public static final int h = 6;
        public static final int i = 7;
        public static final int j = 8;
        public static final int k = 9;
        public static final int l = 10;
        public static final int m = 11;
        public static final int n = 12;

        private e() {
        }
    }

    private a() {
    }
}
