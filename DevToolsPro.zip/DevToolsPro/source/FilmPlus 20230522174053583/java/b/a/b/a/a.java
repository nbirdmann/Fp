package b.a.b.a;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.util.Log;
import android.util.SparseArray;
import android.util.TypedValue;
import androidx.annotation.j0;
import androidx.annotation.k0;
import androidx.annotation.n;
import androidx.annotation.s;
import androidx.appcompat.widget.k;
import androidx.core.content.c;
import java.util.WeakHashMap;

public final class a {
    private static final String a = "AppCompatResources";
    private static final ThreadLocal<TypedValue> b = new ThreadLocal();
    private static final WeakHashMap<Context, SparseArray<a>> c = new WeakHashMap(0);
    private static final Object d = new Object();

    private static class a {
        final ColorStateList a;
        final Configuration b;

        a(@j0 ColorStateList colorStateList, @j0 Configuration configuration) {
            this.a = colorStateList;
            this.b = configuration;
        }
    }

    private a() {
    }

    private static void a(@j0 Context context, @n int i, @j0 ColorStateList colorStateList) {
        synchronized (d) {
            WeakHashMap weakHashMap = c;
            SparseArray sparseArray = (SparseArray) weakHashMap.get(context);
            if (sparseArray == null) {
                sparseArray = new SparseArray();
                weakHashMap.put(context, sparseArray);
            }
            sparseArray.append(i, new a(colorStateList, context.getResources().getConfiguration()));
        }
    }

    /* DevToolsApp WARNING: Missing block: B:17:0x0034, code:
            return null;
     */
    @androidx.annotation.k0
    private static android.content.res.ColorStateList b(@androidx.annotation.j0 android.content.Context r4, @androidx.annotation.n int r5) {
        /*
        r0 = d;
        monitor-enter(r0);
        r1 = c;	 Catch:{ all -> 0x0035 }
        r1 = r1.get(r4);	 Catch:{ all -> 0x0035 }
        r1 = (android.util.SparseArray) r1;	 Catch:{ all -> 0x0035 }
        if (r1 == 0) goto L_0x0032;
    L_0x000d:
        r2 = r1.size();	 Catch:{ all -> 0x0035 }
        if (r2 <= 0) goto L_0x0032;
    L_0x0013:
        r2 = r1.get(r5);	 Catch:{ all -> 0x0035 }
        r2 = (b.a.b.a.a.a) r2;	 Catch:{ all -> 0x0035 }
        if (r2 == 0) goto L_0x0032;
    L_0x001b:
        r3 = r2.b;	 Catch:{ all -> 0x0035 }
        r4 = r4.getResources();	 Catch:{ all -> 0x0035 }
        r4 = r4.getConfiguration();	 Catch:{ all -> 0x0035 }
        r4 = r3.equals(r4);	 Catch:{ all -> 0x0035 }
        if (r4 == 0) goto L_0x002f;
    L_0x002b:
        r4 = r2.a;	 Catch:{ all -> 0x0035 }
        monitor-exit(r0);	 Catch:{ all -> 0x0035 }
        return r4;
    L_0x002f:
        r1.remove(r5);	 Catch:{ all -> 0x0035 }
    L_0x0032:
        monitor-exit(r0);	 Catch:{ all -> 0x0035 }
        r4 = 0;
        return r4;
    L_0x0035:
        r4 = move-exception;
        monitor-exit(r0);	 Catch:{ all -> 0x0035 }
        throw r4;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.a.b.a.a.b(android.content.Context, int):android.content.res.ColorStateList");
    }

    public static ColorStateList c(@j0 Context context, @n int i) {
        if (VERSION.SDK_INT >= 23) {
            return context.getColorStateList(i);
        }
        ColorStateList b = b(context, i);
        if (b != null) {
            return b;
        }
        b = f(context, i);
        if (b == null) {
            return c.f(context, i);
        }
        a(context, i, b);
        return b;
    }

    @k0
    public static Drawable d(@j0 Context context, @s int i) {
        return k.n().p(context, i);
    }

    @j0
    private static TypedValue e() {
        ThreadLocal threadLocal = b;
        TypedValue typedValue = (TypedValue) threadLocal.get();
        if (typedValue != null) {
            return typedValue;
        }
        typedValue = new TypedValue();
        threadLocal.set(typedValue);
        return typedValue;
    }

    @k0
    private static ColorStateList f(Context context, int i) {
        if (g(context, i)) {
            return null;
        }
        Resources resources = context.getResources();
        try {
            return androidx.core.content.i.a.a(resources, resources.getXml(i), context.getTheme());
        } catch (Throwable e) {
            Log.e(a, "Failed to inflate ColorStateList, leaving it to the framework", e);
            return null;
        }
    }

    private static boolean g(@j0 Context context, @n int i) {
        Resources resources = context.getResources();
        TypedValue e = e();
        resources.getValue(i, e, true);
        int i2 = e.type;
        return i2 >= 28 && i2 <= 31;
    }
}
