package b.a.c.a;

import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.util.StateSet;
import androidx.annotation.j0;
import androidx.annotation.k0;
import androidx.core.content.i.h;
import b.a.a.l;
import b.a0.b.a.i;
import b.e.j;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class a extends e {
    private static final String E0 = a.class.getSimpleName();
    private static final String F0 = "transition";
    private static final String G0 = "item";
    private static final String H0 = ": <transition> tag requires a 'drawable' attribute or child tag defining a drawable";
    private static final String I0 = ": <transition> tag requires 'fromId' & 'toId' attributes";
    private static final String J0 = ": <item> tag requires a 'drawable' attribute or child tag defining a drawable";
    private c K0;
    private g L0;
    private int M0;
    private int N0;
    private boolean O0;

    private static abstract class g {
        private g() {
        }

        public boolean a() {
            return false;
        }

        public void b() {
        }

        public abstract void c();

        public abstract void d();
    }

    private static class b extends g {
        private final Animatable a;

        b(Animatable animatable) {
            super();
            this.a = animatable;
        }

        public void c() {
            this.a.start();
        }

        public void d() {
            this.a.stop();
        }
    }

    static class c extends a {
        private static final long K = 4294967296L;
        private static final long L = 8589934592L;
        b.e.f<Long> M;
        j<Integer> N;

        c(@k0 c cVar, @j0 a aVar, @k0 Resources resources) {
            super(cVar, aVar, resources);
            if (cVar != null) {
                this.M = cVar.M;
                this.N = cVar.N;
                return;
            }
            this.M = new b.e.f();
            this.N = new j();
        }

        private static long H(int i, int i2) {
            return ((long) i2) | (((long) i) << 32);
        }

        int F(@j0 int[] iArr, @j0 Drawable drawable, int i) {
            int D = super.D(iArr, drawable);
            this.N.q(D, Integer.valueOf(i));
            return D;
        }

        int G(int i, int i2, @j0 Drawable drawable, boolean z) {
            int a = super.a(drawable);
            long H = H(i, i2);
            long j = z ? L : 0;
            long j2 = (long) a;
            this.M.a(H, Long.valueOf(j2 | j));
            if (z) {
                this.M.a(H(i2, i), Long.valueOf((K | j2) | j));
            }
            return a;
        }

        int I(int i) {
            return i < 0 ? 0 : ((Integer) this.N.i(i, Integer.valueOf(0))).intValue();
        }

        int J(@j0 int[] iArr) {
            int E = super.E(iArr);
            return E >= 0 ? E : super.E(StateSet.WILD_CARD);
        }

        int K(int i, int i2) {
            return (int) ((Long) this.M.i(H(i, i2), Long.valueOf(-1))).longValue();
        }

        boolean L(int i, int i2) {
            return (((Long) this.M.i(H(i, i2), Long.valueOf(-1))).longValue() & K) != 0;
        }

        boolean M(int i, int i2) {
            return (((Long) this.M.i(H(i, i2), Long.valueOf(-1))).longValue() & L) != 0;
        }

        @j0
        public Drawable newDrawable() {
            return new a(this, null);
        }

        @j0
        public Drawable newDrawable(Resources resources) {
            return new a(this, resources);
        }

        void v() {
            this.M = this.M.clone();
            this.N = this.N.clone();
        }
    }

    private static class d extends g {
        private final b.a0.b.a.c a;

        d(b.a0.b.a.c cVar) {
            super();
            this.a = cVar;
        }

        public void c() {
            this.a.start();
        }

        public void d() {
            this.a.stop();
        }
    }

    private static class e extends g {
        private final ObjectAnimator a;
        private final boolean b;

        e(AnimationDrawable animationDrawable, boolean z, boolean z2) {
            super();
            int numberOfFrames = animationDrawable.getNumberOfFrames();
            int i = z ? numberOfFrames - 1 : 0;
            numberOfFrames = z ? 0 : numberOfFrames - 1;
            TimeInterpolator fVar = new f(animationDrawable, z);
            ObjectAnimator ofInt = ObjectAnimator.ofInt(animationDrawable, "currentIndex", new int[]{i, numberOfFrames});
            if (VERSION.SDK_INT >= 18) {
                ofInt.setAutoCancel(true);
            }
            ofInt.setDuration((long) fVar.a());
            ofInt.setInterpolator(fVar);
            this.b = z2;
            this.a = ofInt;
        }

        public boolean a() {
            return this.b;
        }

        public void b() {
            this.a.reverse();
        }

        public void c() {
            this.a.start();
        }

        public void d() {
            this.a.cancel();
        }
    }

    private static class f implements TimeInterpolator {
        private int[] a;
        private int b;
        private int c;

        f(AnimationDrawable animationDrawable, boolean z) {
            b(animationDrawable, z);
        }

        int a() {
            return this.c;
        }

        int b(AnimationDrawable animationDrawable, boolean z) {
            int numberOfFrames = animationDrawable.getNumberOfFrames();
            this.b = numberOfFrames;
            int[] iArr = this.a;
            if (iArr == null || iArr.length < numberOfFrames) {
                this.a = new int[numberOfFrames];
            }
            iArr = this.a;
            int i = 0;
            for (int i2 = 0; i2 < numberOfFrames; i2++) {
                int duration = animationDrawable.getDuration(z ? (numberOfFrames - i2) - 1 : i2);
                iArr[i2] = duration;
                i += duration;
            }
            this.c = i;
            return i;
        }

        public float getInterpolation(float f) {
            int i = (int) ((f * ((float) this.c)) + 0.5f);
            int i2 = this.b;
            int[] iArr = this.a;
            int i3 = 0;
            while (i3 < i2 && i >= iArr[i3]) {
                i -= iArr[i3];
                i3++;
            }
            return (((float) i3) / ((float) i2)) + (i3 < i2 ? ((float) i) / ((float) this.c) : 0.0f);
        }
    }

    public a() {
        this(null, null);
    }

    a(@k0 c cVar, @k0 Resources resources) {
        super(null);
        this.M0 = -1;
        this.N0 = -1;
        i(new c(cVar, this, resources));
        onStateChange(getState());
        jumpToCurrentState();
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:11:0x0020 A:{Catch:{ XmlPullParserException -> 0x002f, IOException -> 0x0028 }} */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:9:0x001b A:{Catch:{ XmlPullParserException -> 0x002f, IOException -> 0x0028 }} */
    @androidx.annotation.k0
    public static b.a.c.a.a B(@androidx.annotation.j0 android.content.Context r6, @androidx.annotation.s int r7, @androidx.annotation.k0 android.content.res.Resources.Theme r8) {
        /*
        r0 = "parser error";
        r1 = r6.getResources();	 Catch:{ XmlPullParserException -> 0x002f, IOException -> 0x0028 }
        r7 = r1.getXml(r7);	 Catch:{ XmlPullParserException -> 0x002f, IOException -> 0x0028 }
        r2 = android.util.Xml.asAttributeSet(r7);	 Catch:{ XmlPullParserException -> 0x002f, IOException -> 0x0028 }
    L_0x000e:
        r3 = r7.next();	 Catch:{ XmlPullParserException -> 0x002f, IOException -> 0x0028 }
        r4 = 2;
        if (r3 == r4) goto L_0x0019;
    L_0x0015:
        r5 = 1;
        if (r3 == r5) goto L_0x0019;
    L_0x0018:
        goto L_0x000e;
    L_0x0019:
        if (r3 != r4) goto L_0x0020;
    L_0x001b:
        r6 = C(r6, r1, r7, r2, r8);	 Catch:{ XmlPullParserException -> 0x002f, IOException -> 0x0028 }
        return r6;
    L_0x0020:
        r6 = new org.xmlpull.v1.XmlPullParserException;	 Catch:{ XmlPullParserException -> 0x002f, IOException -> 0x0028 }
        r7 = "No start tag found";
        r6.<init>(r7);	 Catch:{ XmlPullParserException -> 0x002f, IOException -> 0x0028 }
        throw r6;	 Catch:{ XmlPullParserException -> 0x002f, IOException -> 0x0028 }
    L_0x0028:
        r6 = move-exception;
        r7 = E0;
        android.util.Log.e(r7, r0, r6);
        goto L_0x0035;
    L_0x002f:
        r6 = move-exception;
        r7 = E0;
        android.util.Log.e(r7, r0, r6);
    L_0x0035:
        r6 = 0;
        return r6;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.a.c.a.a.B(android.content.Context, int, android.content.res.Resources$Theme):b.a.c.a.a");
    }

    public static a C(@j0 Context context, @j0 Resources resources, @j0 XmlPullParser xmlPullParser, @j0 AttributeSet attributeSet, @k0 Theme theme) throws IOException, XmlPullParserException {
        String name = xmlPullParser.getName();
        if (name.equals("animated-selector")) {
            a aVar = new a();
            aVar.v(context, resources, xmlPullParser, attributeSet, theme);
            return aVar;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(xmlPullParser.getPositionDescription());
        stringBuilder.append(": invalid animated-selector tag ");
        stringBuilder.append(name);
        throw new XmlPullParserException(stringBuilder.toString());
    }

    private void D() {
        onStateChange(getState());
    }

    private int E(@j0 Context context, @j0 Resources resources, @j0 XmlPullParser xmlPullParser, @j0 AttributeSet attributeSet, @k0 Theme theme) throws XmlPullParserException, IOException {
        StringBuilder stringBuilder;
        TypedArray s = h.s(resources, theme, attributeSet, l.j0);
        int resourceId = s.getResourceId(l.k0, 0);
        int resourceId2 = s.getResourceId(l.l0, -1);
        Drawable d = resourceId2 > 0 ? b.a.b.a.a.d(context, resourceId2) : null;
        s.recycle();
        int[] p = p(attributeSet);
        String str = J0;
        if (d == null) {
            int next;
            while (true) {
                next = xmlPullParser.next();
                if (next != 4) {
                    break;
                }
            }
            if (next == 2) {
                d = xmlPullParser.getName().equals("vector") ? i.f(resources, xmlPullParser, attributeSet, theme) : VERSION.SDK_INT >= 21 ? Drawable.createFromXmlInner(resources, xmlPullParser, attributeSet, theme) : Drawable.createFromXmlInner(resources, xmlPullParser, attributeSet);
            } else {
                stringBuilder = new StringBuilder();
                stringBuilder.append(xmlPullParser.getPositionDescription());
                stringBuilder.append(str);
                throw new XmlPullParserException(stringBuilder.toString());
            }
        }
        if (d != null) {
            return this.K0.F(p, d, resourceId);
        }
        stringBuilder = new StringBuilder();
        stringBuilder.append(xmlPullParser.getPositionDescription());
        stringBuilder.append(str);
        throw new XmlPullParserException(stringBuilder.toString());
    }

    private int F(@j0 Context context, @j0 Resources resources, @j0 XmlPullParser xmlPullParser, @j0 AttributeSet attributeSet, @k0 Theme theme) throws XmlPullParserException, IOException {
        StringBuilder stringBuilder;
        TypedArray s = h.s(resources, theme, attributeSet, l.m0);
        int resourceId = s.getResourceId(l.p0, -1);
        int resourceId2 = s.getResourceId(l.o0, -1);
        int resourceId3 = s.getResourceId(l.n0, -1);
        Drawable d = resourceId3 > 0 ? b.a.b.a.a.d(context, resourceId3) : null;
        boolean z = s.getBoolean(l.q0, false);
        s.recycle();
        String str = H0;
        if (d == null) {
            while (true) {
                resourceId3 = xmlPullParser.next();
                if (resourceId3 != 4) {
                    break;
                }
            }
            if (resourceId3 == 2) {
                d = xmlPullParser.getName().equals("animated-vector") ? b.a0.b.a.c.f(context, resources, xmlPullParser, attributeSet, theme) : VERSION.SDK_INT >= 21 ? Drawable.createFromXmlInner(resources, xmlPullParser, attributeSet, theme) : Drawable.createFromXmlInner(resources, xmlPullParser, attributeSet);
            } else {
                stringBuilder = new StringBuilder();
                stringBuilder.append(xmlPullParser.getPositionDescription());
                stringBuilder.append(str);
                throw new XmlPullParserException(stringBuilder.toString());
            }
        }
        if (d == null) {
            stringBuilder = new StringBuilder();
            stringBuilder.append(xmlPullParser.getPositionDescription());
            stringBuilder.append(str);
            throw new XmlPullParserException(stringBuilder.toString());
        } else if (resourceId != -1 && resourceId2 != -1) {
            return this.K0.G(resourceId, resourceId2, d, z);
        } else {
            stringBuilder = new StringBuilder();
            stringBuilder.append(xmlPullParser.getPositionDescription());
            stringBuilder.append(I0);
            throw new XmlPullParserException(stringBuilder.toString());
        }
    }

    private boolean G(int i) {
        int d;
        g gVar = this.L0;
        if (gVar == null) {
            d = d();
        } else if (i == this.M0) {
            return true;
        } else {
            if (i == this.N0 && gVar.a()) {
                gVar.b();
                this.M0 = this.N0;
                this.N0 = i;
                return true;
            }
            d = this.M0;
            gVar.d();
        }
        this.L0 = null;
        this.N0 = -1;
        this.M0 = -1;
        c cVar = this.K0;
        int I = cVar.I(d);
        int I2 = cVar.I(i);
        if (!(I2 == 0 || I == 0)) {
            int K = cVar.K(I, I2);
            if (K < 0) {
                return false;
            }
            g eVar;
            boolean M = cVar.M(I, I2);
            h(K);
            Drawable current = getCurrent();
            if (current instanceof AnimationDrawable) {
                eVar = new e((AnimationDrawable) current, cVar.L(I, I2), M);
            } else if (current instanceof b.a0.b.a.c) {
                eVar = new d((b.a0.b.a.c) current);
            } else if (current instanceof Animatable) {
                eVar = new b((Animatable) current);
            }
            eVar.c();
            this.L0 = eVar;
            this.N0 = d;
            this.M0 = i;
            return true;
        }
        return false;
    }

    private void w(@j0 Context context, @j0 Resources resources, @j0 XmlPullParser xmlPullParser, @j0 AttributeSet attributeSet, @k0 Theme theme) throws XmlPullParserException, IOException {
        int depth = xmlPullParser.getDepth() + 1;
        while (true) {
            int next = xmlPullParser.next();
            if (next != 1) {
                int depth2 = xmlPullParser.getDepth();
                if (depth2 < depth && next == 3) {
                    return;
                }
                if (next == 2) {
                    if (depth2 <= depth) {
                        if (xmlPullParser.getName().equals(G0)) {
                            E(context, resources, xmlPullParser, attributeSet, theme);
                        } else if (xmlPullParser.getName().equals(F0)) {
                            F(context, resources, xmlPullParser, attributeSet, theme);
                        }
                    }
                }
            } else {
                return;
            }
        }
    }

    private void x(TypedArray typedArray) {
        c cVar = this.K0;
        if (VERSION.SDK_INT >= 21) {
            cVar.d |= typedArray.getChangingConfigurations();
        }
        cVar.B(typedArray.getBoolean(l.f0, cVar.i));
        cVar.x(typedArray.getBoolean(l.g0, cVar.l));
        cVar.y(typedArray.getInt(l.h0, cVar.A));
        cVar.z(typedArray.getInt(l.i0, cVar.B));
        setDither(typedArray.getBoolean(l.d0, cVar.x));
    }

    /* renamed from: A */
    c o() {
        return new c(this.K0, this, null);
    }

    void b() {
        super.b();
        this.O0 = false;
    }

    protected void i(@j0 c cVar) {
        super.i(cVar);
        if (cVar instanceof c) {
            this.K0 = (c) cVar;
        }
    }

    public boolean isStateful() {
        return true;
    }

    public void jumpToCurrentState() {
        super.jumpToCurrentState();
        g gVar = this.L0;
        if (gVar != null) {
            gVar.d();
            this.L0 = null;
            h(this.M0);
            this.M0 = -1;
            this.N0 = -1;
        }
    }

    public Drawable mutate() {
        if (!this.O0 && super.mutate() == this) {
            this.K0.v();
            this.O0 = true;
        }
        return this;
    }

    protected boolean onStateChange(int[] iArr) {
        int J = this.K0.J(iArr);
        boolean z = J != d() && (G(J) || h(J));
        Drawable current = getCurrent();
        return current != null ? z | current.setState(iArr) : z;
    }

    public boolean setVisible(boolean z, boolean z2) {
        boolean visible = super.setVisible(z, z2);
        g gVar = this.L0;
        if (gVar != null && (visible || z2)) {
            if (z) {
                gVar.c();
            } else {
                jumpToCurrentState();
            }
        }
        return visible;
    }

    public void v(@j0 Context context, @j0 Resources resources, @j0 XmlPullParser xmlPullParser, @j0 AttributeSet attributeSet, @k0 Theme theme) throws XmlPullParserException, IOException {
        TypedArray s = h.s(resources, theme, attributeSet, l.c0);
        setVisible(s.getBoolean(l.e0, true), true);
        x(s);
        m(resources);
        s.recycle();
        w(context, resources, xmlPullParser, attributeSet, theme);
        D();
    }

    public void y(@j0 int[] iArr, @j0 Drawable drawable, int i) {
        if (drawable != null) {
            this.K0.F(iArr, drawable, i);
            onStateChange(getState());
            return;
        }
        throw new IllegalArgumentException("Drawable must not be null");
    }

    public <T extends Drawable & Animatable> void z(int i, int i2, @j0 T t, boolean z) {
        if (t != null) {
            this.K0.G(i, i2, t, z);
            return;
        }
        throw new IllegalArgumentException("Transition drawable must not be null");
    }
}
