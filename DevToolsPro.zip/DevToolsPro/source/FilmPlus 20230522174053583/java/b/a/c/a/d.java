package b.a.c.a;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Paint.Cap;
import android.graphics.Paint.Join;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import androidx.annotation.r0;
import androidx.annotation.t;
import b.a.a.b;
import b.a.a.k;
import b.a.a.l;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public class d extends Drawable {
    public static final int a = 0;
    public static final int b = 1;
    public static final int c = 2;
    public static final int d = 3;
    private static final float e = ((float) Math.toRadians(45.0d));
    private final Paint f;
    private float g;
    private float h;
    private float i;
    private float j;
    private boolean k;
    private final Path l = new Path();
    private final int m;
    private boolean n = false;
    private float o;
    private float p;
    private int q = 2;

    @r0({androidx.annotation.r0.a.b})
    @Retention(RetentionPolicy.SOURCE)
    public @interface a {
    }

    public d(Context context) {
        Paint paint = new Paint();
        this.f = paint;
        paint.setStyle(Style.STROKE);
        paint.setStrokeJoin(Join.MITER);
        paint.setStrokeCap(Cap.BUTT);
        paint.setAntiAlias(true);
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes(null, l.I3, b.c1, k.v1);
        p(obtainStyledAttributes.getColor(l.M3, 0));
        o(obtainStyledAttributes.getDimension(l.Q3, 0.0f));
        t(obtainStyledAttributes.getBoolean(l.P3, true));
        r((float) Math.round(obtainStyledAttributes.getDimension(l.O3, 0.0f)));
        this.m = obtainStyledAttributes.getDimensionPixelSize(l.N3, 0);
        this.h = (float) Math.round(obtainStyledAttributes.getDimension(l.L3, 0.0f));
        this.g = (float) Math.round(obtainStyledAttributes.getDimension(l.J3, 0.0f));
        this.i = obtainStyledAttributes.getDimension(l.K3, 0.0f);
        obtainStyledAttributes.recycle();
    }

    private static float k(float f, float f2, float f3) {
        return f + ((f2 - f) * f3);
    }

    public float a() {
        return this.g;
    }

    public float b() {
        return this.i;
    }

    public float c() {
        return this.h;
    }

    public float d() {
        return this.f.getStrokeWidth();
    }

    public void draw(Canvas canvas) {
        Canvas canvas2 = canvas;
        Rect bounds = getBounds();
        int i = this.q;
        int i2 = 0;
        if (i != 0 && (i == 1 || (i == 3 ? androidx.core.graphics.drawable.a.f(this) != 0 : androidx.core.graphics.drawable.a.f(this) != 1))) {
            i2 = 1;
        }
        float f = this.g;
        f = k(this.h, (float) Math.sqrt((double) ((f * f) * 2.0f)), this.o);
        float k = k(this.h, this.i, this.o);
        float round = (float) Math.round(k(0.0f, this.p, this.o));
        float k2 = k(0.0f, e, this.o);
        double d = (double) f;
        float k3 = k(i2 != 0 ? 0.0f : -180.0f, i2 != 0 ? 180.0f : 0.0f, this.o);
        double d2 = (double) k2;
        double cos = Math.cos(d2);
        Double.isNaN(d);
        int i3 = i2;
        f = (float) Math.round(cos * d);
        d2 = Math.sin(d2);
        Double.isNaN(d);
        float round2 = (float) Math.round(d * d2);
        this.l.rewind();
        float k4 = k(this.j + this.f.getStrokeWidth(), -this.p, this.o);
        float f2 = (-k) / 2.0f;
        this.l.moveTo(f2 + round, 0.0f);
        this.l.rLineTo(k - (round * 2.0f), 0.0f);
        this.l.moveTo(f2, k4);
        this.l.rLineTo(f, round2);
        this.l.moveTo(f2, -k4);
        this.l.rLineTo(f, -round2);
        this.l.close();
        canvas.save();
        f = this.f.getStrokeWidth();
        round2 = ((float) bounds.height()) - (3.0f * f);
        float f3 = this.j;
        canvas2.translate((float) bounds.centerX(), ((float) ((((int) (round2 - (2.0f * f3))) / 4) * 2)) + ((f * 1.5f) + f3));
        if (this.k) {
            canvas2.rotate(k3 * ((float) ((this.n ^ i3) != 0 ? -1 : 1)));
        } else if (i3 != 0) {
            canvas2.rotate(180.0f);
        }
        canvas2.drawPath(this.l, this.f);
        canvas.restore();
    }

    @androidx.annotation.l
    public int e() {
        return this.f.getColor();
    }

    public int f() {
        return this.q;
    }

    public float g() {
        return this.j;
    }

    public int getIntrinsicHeight() {
        return this.m;
    }

    public int getIntrinsicWidth() {
        return this.m;
    }

    public int getOpacity() {
        return -3;
    }

    public final Paint h() {
        return this.f;
    }

    @t(from = 0.0d, to = 1.0d)
    public float i() {
        return this.o;
    }

    public boolean j() {
        return this.k;
    }

    public void l(float f) {
        if (this.g != f) {
            this.g = f;
            invalidateSelf();
        }
    }

    public void m(float f) {
        if (this.i != f) {
            this.i = f;
            invalidateSelf();
        }
    }

    public void n(float f) {
        if (this.h != f) {
            this.h = f;
            invalidateSelf();
        }
    }

    public void o(float f) {
        if (this.f.getStrokeWidth() != f) {
            this.f.setStrokeWidth(f);
            double d = (double) (f / 2.0f);
            double cos = Math.cos((double) e);
            Double.isNaN(d);
            this.p = (float) (d * cos);
            invalidateSelf();
        }
    }

    public void p(@androidx.annotation.l int i) {
        if (i != this.f.getColor()) {
            this.f.setColor(i);
            invalidateSelf();
        }
    }

    public void q(int i) {
        if (i != this.q) {
            this.q = i;
            invalidateSelf();
        }
    }

    public void r(float f) {
        if (f != this.j) {
            this.j = f;
            invalidateSelf();
        }
    }

    public void s(@t(from = 0.0d, to = 1.0d) float f) {
        if (this.o != f) {
            this.o = f;
            invalidateSelf();
        }
    }

    public void setAlpha(int i) {
        if (i != this.f.getAlpha()) {
            this.f.setAlpha(i);
            invalidateSelf();
        }
    }

    public void setColorFilter(ColorFilter colorFilter) {
        this.f.setColorFilter(colorFilter);
        invalidateSelf();
    }

    public void t(boolean z) {
        if (this.k != z) {
            this.k = z;
            invalidateSelf();
        }
    }

    public void u(boolean z) {
        if (this.n != z) {
            this.n = z;
            invalidateSelf();
        }
    }
}
