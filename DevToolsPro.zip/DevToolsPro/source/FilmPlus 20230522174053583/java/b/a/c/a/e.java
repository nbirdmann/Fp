package b.a.c.a;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.util.StateSet;
import androidx.annotation.j0;
import androidx.annotation.k0;
import androidx.annotation.o0;
import androidx.annotation.r0;
import androidx.core.content.i.h;
import b.a.a.l;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

@r0({androidx.annotation.r0.a.b})
class e extends b {
    private static final String A0 = "StateListDrawable";
    private static final boolean B0 = false;
    private a C0;
    private boolean D0;

    static class a extends c {
        int[][] J;

        a(a aVar, e eVar, Resources resources) {
            super(aVar, eVar, resources);
            if (aVar != null) {
                this.J = aVar.J;
            } else {
                this.J = new int[g()][];
            }
        }

        int D(int[] iArr, Drawable drawable) {
            int a = a(drawable);
            this.J[a] = iArr;
            return a;
        }

        int E(int[] iArr) {
            int[][] iArr2 = this.J;
            int i = i();
            for (int i2 = 0; i2 < i; i2++) {
                if (StateSet.stateSetMatches(iArr2[i2], iArr)) {
                    return i2;
                }
            }
            return -1;
        }

        @j0
        public Drawable newDrawable() {
            return new e(this, null);
        }

        @j0
        public Drawable newDrawable(Resources resources) {
            return new e(this, resources);
        }

        public void r(int i, int i2) {
            super.r(i, i2);
            Object obj = new int[i2][];
            System.arraycopy(this.J, 0, obj, 0, i);
            this.J = obj;
        }

        void v() {
            int[][] iArr = this.J;
            int[][] iArr2 = new int[iArr.length][];
            for (int length = iArr.length - 1; length >= 0; length--) {
                int[][] iArr3 = this.J;
                iArr2[length] = iArr3[length] != null ? (int[]) iArr3[length].clone() : null;
            }
            this.J = iArr2;
        }
    }

    e() {
        this(null, null);
    }

    e(@k0 a aVar) {
        if (aVar != null) {
            i(aVar);
        }
    }

    e(a aVar, Resources resources) {
        i(new a(aVar, this, resources));
        onStateChange(getState());
    }

    private void w(Context context, Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Theme theme) throws XmlPullParserException, IOException {
        a aVar = this.C0;
        int depth = xmlPullParser.getDepth() + 1;
        while (true) {
            int next = xmlPullParser.next();
            if (next != 1) {
                int depth2 = xmlPullParser.getDepth();
                if (depth2 < depth && next == 3) {
                    return;
                }
                if (next == 2) {
                    if (depth2 > depth) {
                        continue;
                    } else if (xmlPullParser.getName().equals("item")) {
                        TypedArray s = h.s(resources, theme, attributeSet, l.u6);
                        Drawable drawable = null;
                        int resourceId = s.getResourceId(l.v6, -1);
                        if (resourceId > 0) {
                            drawable = b.a.b.a.a.d(context, resourceId);
                        }
                        s.recycle();
                        int[] p = p(attributeSet);
                        if (drawable == null) {
                            while (true) {
                                depth2 = xmlPullParser.next();
                                if (depth2 != 4) {
                                    break;
                                }
                            }
                            if (depth2 == 2) {
                                drawable = VERSION.SDK_INT >= 21 ? Drawable.createFromXmlInner(resources, xmlPullParser, attributeSet, theme) : Drawable.createFromXmlInner(resources, xmlPullParser, attributeSet);
                            } else {
                                StringBuilder stringBuilder = new StringBuilder();
                                stringBuilder.append(xmlPullParser.getPositionDescription());
                                stringBuilder.append(": <item> tag requires a 'drawable' attribute or ");
                                stringBuilder.append("child tag defining a drawable");
                                throw new XmlPullParserException(stringBuilder.toString());
                            }
                        }
                        aVar.D(p, drawable);
                    }
                }
            } else {
                return;
            }
        }
    }

    private void x(TypedArray typedArray) {
        c cVar = this.C0;
        if (VERSION.SDK_INT >= 21) {
            cVar.d |= typedArray.getChangingConfigurations();
        }
        cVar.i = typedArray.getBoolean(l.q6, cVar.i);
        cVar.l = typedArray.getBoolean(l.r6, cVar.l);
        cVar.A = typedArray.getInt(l.s6, cVar.A);
        cVar.B = typedArray.getInt(l.t6, cVar.B);
        cVar.x = typedArray.getBoolean(l.o6, cVar.x);
    }

    @o0(21)
    public void applyTheme(@j0 Theme theme) {
        super.applyTheme(theme);
        onStateChange(getState());
    }

    void b() {
        super.b();
        this.D0 = false;
    }

    protected void i(@j0 c cVar) {
        super.i(cVar);
        if (cVar instanceof a) {
            this.C0 = (a) cVar;
        }
    }

    public boolean isStateful() {
        return true;
    }

    @j0
    public Drawable mutate() {
        if (!this.D0 && super.mutate() == this) {
            this.C0.v();
            this.D0 = true;
        }
        return this;
    }

    public void n(int[] iArr, Drawable drawable) {
        if (drawable != null) {
            this.C0.D(iArr, drawable);
            onStateChange(getState());
        }
    }

    /* renamed from: o */
    a c() {
        return new a(this.C0, this, null);
    }

    protected boolean onStateChange(int[] iArr) {
        boolean onStateChange = super.onStateChange(iArr);
        int E = this.C0.E(iArr);
        if (E < 0) {
            E = this.C0.E(StateSet.WILD_CARD);
        }
        return h(E) || onStateChange;
    }

    int[] p(AttributeSet attributeSet) {
        int attributeCount = attributeSet.getAttributeCount();
        int[] iArr = new int[attributeCount];
        int i = 0;
        for (int i2 = 0; i2 < attributeCount; i2++) {
            int attributeNameResource = attributeSet.getAttributeNameResource(i2);
            if (!(attributeNameResource == 0 || attributeNameResource == 16842960 || attributeNameResource == 16843161)) {
                int i3 = i + 1;
                if (!attributeSet.getAttributeBooleanValue(i2, false)) {
                    attributeNameResource = -attributeNameResource;
                }
                iArr[i] = attributeNameResource;
                i = i3;
            }
        }
        return StateSet.trimStateSet(iArr, i);
    }

    int q() {
        return this.C0.i();
    }

    Drawable r(int i) {
        return this.C0.h(i);
    }

    int s(int[] iArr) {
        return this.C0.E(iArr);
    }

    a t() {
        return this.C0;
    }

    int[] u(int i) {
        return this.C0.J[i];
    }

    public void v(@j0 Context context, @j0 Resources resources, @j0 XmlPullParser xmlPullParser, @j0 AttributeSet attributeSet, @k0 Theme theme) throws XmlPullParserException, IOException {
        TypedArray s = h.s(resources, theme, attributeSet, l.n6);
        setVisible(s.getBoolean(l.p6, true), true);
        x(s);
        m(resources);
        s.recycle();
        w(context, resources, xmlPullParser, attributeSet, theme);
        onStateChange(getState());
    }
}
