package b.a.c.a;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.Callback;
import android.graphics.drawable.Drawable.ConstantState;
import android.os.Build.VERSION;
import android.util.SparseArray;
import androidx.annotation.j0;
import androidx.annotation.k0;
import androidx.annotation.o0;
import androidx.annotation.r0;

@r0({androidx.annotation.r0.a.b})
class b extends Drawable implements Callback {
    private static final boolean a = false;
    private static final String b = "DrawableContainer";
    private static final boolean c = true;
    private c d;
    private Rect f;
    private Drawable q0;
    private int r0 = 255;
    private Drawable s;
    private boolean s0;
    private int t0 = -1;
    private int u0 = -1;
    private boolean v0;
    private Runnable w0;
    private long x0;
    private long y0;
    private b z0;

    static abstract class c extends ConstantState {
        int A;
        int B;
        boolean C;
        ColorFilter D;
        boolean E;
        ColorStateList F;
        Mode G;
        boolean H;
        boolean I;
        final b a;
        Resources b;
        int c = 160;
        int d;
        int e;
        SparseArray<ConstantState> f;
        Drawable[] g;
        int h;
        boolean i;
        boolean j;
        Rect k;
        boolean l;
        boolean m;
        int n;
        int o;
        int p;
        int q;
        boolean r;
        int s;
        boolean t;
        boolean u;
        boolean v;
        boolean w;
        boolean x;
        boolean y;
        int z;

        c(c cVar, b bVar, Resources resources) {
            int i = 0;
            this.i = false;
            this.l = false;
            this.x = true;
            this.A = 0;
            this.B = 0;
            this.a = bVar;
            Resources resources2 = resources != null ? resources : cVar != null ? cVar.b : null;
            this.b = resources2;
            int g = b.g(resources, cVar != null ? cVar.c : 0);
            this.c = g;
            if (cVar != null) {
                this.d = cVar.d;
                this.e = cVar.e;
                this.v = true;
                this.w = true;
                this.i = cVar.i;
                this.l = cVar.l;
                this.x = cVar.x;
                this.y = cVar.y;
                this.z = cVar.z;
                this.A = cVar.A;
                this.B = cVar.B;
                this.C = cVar.C;
                this.D = cVar.D;
                this.E = cVar.E;
                this.F = cVar.F;
                this.G = cVar.G;
                this.H = cVar.H;
                this.I = cVar.I;
                if (cVar.c == g) {
                    if (cVar.j) {
                        this.k = new Rect(cVar.k);
                        this.j = true;
                    }
                    if (cVar.m) {
                        this.n = cVar.n;
                        this.o = cVar.o;
                        this.p = cVar.p;
                        this.q = cVar.q;
                        this.m = true;
                    }
                }
                if (cVar.r) {
                    this.s = cVar.s;
                    this.r = true;
                }
                if (cVar.t) {
                    this.u = cVar.u;
                    this.t = true;
                }
                Drawable[] drawableArr = cVar.g;
                this.g = new Drawable[drawableArr.length];
                this.h = cVar.h;
                SparseArray sparseArray = cVar.f;
                if (sparseArray != null) {
                    this.f = sparseArray.clone();
                } else {
                    this.f = new SparseArray(this.h);
                }
                int i2 = this.h;
                while (i < i2) {
                    if (drawableArr[i] != null) {
                        ConstantState constantState = drawableArr[i].getConstantState();
                        if (constantState != null) {
                            this.f.put(i, constantState);
                        } else {
                            this.g[i] = drawableArr[i];
                        }
                    }
                    i++;
                }
                return;
            }
            this.g = new Drawable[10];
            this.h = 0;
        }

        private void f() {
            SparseArray sparseArray = this.f;
            if (sparseArray != null) {
                int size = sparseArray.size();
                for (int i = 0; i < size; i++) {
                    this.g[this.f.keyAt(i)] = w(((ConstantState) this.f.valueAt(i)).newDrawable(this.b));
                }
                this.f = null;
            }
        }

        private Drawable w(Drawable drawable) {
            if (VERSION.SDK_INT >= 23) {
                drawable.setLayoutDirection(this.z);
            }
            drawable = drawable.mutate();
            drawable.setCallback(this.a);
            return drawable;
        }

        final boolean A(int i, int i2) {
            int i3 = this.h;
            Drawable[] drawableArr = this.g;
            boolean z = false;
            for (int i4 = 0; i4 < i3; i4++) {
                if (drawableArr[i4] != null) {
                    boolean layoutDirection = VERSION.SDK_INT >= 23 ? drawableArr[i4].setLayoutDirection(i) : false;
                    if (i4 == i2) {
                        z = layoutDirection;
                    }
                }
            }
            this.z = i;
            return z;
        }

        public final void B(boolean z) {
            this.i = z;
        }

        final void C(Resources resources) {
            if (resources != null) {
                this.b = resources;
                int g = b.g(resources, this.c);
                int i = this.c;
                this.c = g;
                if (i != g) {
                    this.m = false;
                    this.j = false;
                }
            }
        }

        public final int a(Drawable drawable) {
            int i = this.h;
            if (i >= this.g.length) {
                r(i, i + 10);
            }
            drawable.mutate();
            drawable.setVisible(false, true);
            drawable.setCallback(this.a);
            this.g[i] = drawable;
            this.h++;
            this.e = drawable.getChangingConfigurations() | this.e;
            s();
            this.k = null;
            this.j = false;
            this.m = false;
            this.v = false;
            return i;
        }

        @o0(21)
        final void b(Theme theme) {
            if (theme != null) {
                f();
                int i = this.h;
                Drawable[] drawableArr = this.g;
                int i2 = 0;
                while (i2 < i) {
                    if (drawableArr[i2] != null && drawableArr[i2].canApplyTheme()) {
                        drawableArr[i2].applyTheme(theme);
                        this.e |= drawableArr[i2].getChangingConfigurations();
                    }
                    i2++;
                }
                C(theme.getResources());
            }
        }

        public synchronized boolean c() {
            if (this.v) {
                return this.w;
            }
            f();
            this.v = true;
            int i = this.h;
            Drawable[] drawableArr = this.g;
            for (int i2 = 0; i2 < i; i2++) {
                if (drawableArr[i2].getConstantState() == null) {
                    this.w = false;
                    return false;
                }
            }
            this.w = true;
            return true;
        }

        @o0(21)
        public boolean canApplyTheme() {
            int i = this.h;
            Drawable[] drawableArr = this.g;
            for (int i2 = 0; i2 < i; i2++) {
                Drawable drawable = drawableArr[i2];
                if (drawable == null) {
                    ConstantState constantState = (ConstantState) this.f.get(i2);
                    if (constantState != null && constantState.canApplyTheme()) {
                        return true;
                    }
                } else if (drawable.canApplyTheme()) {
                    return true;
                }
            }
            return false;
        }

        final void d() {
            this.y = false;
        }

        protected void e() {
            this.m = true;
            f();
            int i = this.h;
            Drawable[] drawableArr = this.g;
            this.o = -1;
            this.n = -1;
            int i2 = 0;
            this.q = 0;
            this.p = 0;
            while (i2 < i) {
                Drawable drawable = drawableArr[i2];
                int intrinsicWidth = drawable.getIntrinsicWidth();
                if (intrinsicWidth > this.n) {
                    this.n = intrinsicWidth;
                }
                intrinsicWidth = drawable.getIntrinsicHeight();
                if (intrinsicWidth > this.o) {
                    this.o = intrinsicWidth;
                }
                intrinsicWidth = drawable.getMinimumWidth();
                if (intrinsicWidth > this.p) {
                    this.p = intrinsicWidth;
                }
                int minimumHeight = drawable.getMinimumHeight();
                if (minimumHeight > this.q) {
                    this.q = minimumHeight;
                }
                i2++;
            }
        }

        final int g() {
            return this.g.length;
        }

        public int getChangingConfigurations() {
            return this.d | this.e;
        }

        public final Drawable h(int i) {
            Drawable drawable = this.g[i];
            if (drawable != null) {
                return drawable;
            }
            SparseArray sparseArray = this.f;
            if (sparseArray != null) {
                int indexOfKey = sparseArray.indexOfKey(i);
                if (indexOfKey >= 0) {
                    Drawable w = w(((ConstantState) this.f.valueAt(indexOfKey)).newDrawable(this.b));
                    this.g[i] = w;
                    this.f.removeAt(indexOfKey);
                    if (this.f.size() == 0) {
                        this.f = null;
                    }
                    return w;
                }
            }
            return null;
        }

        public final int i() {
            return this.h;
        }

        public final int j() {
            if (!this.m) {
                e();
            }
            return this.o;
        }

        public final int k() {
            if (!this.m) {
                e();
            }
            return this.q;
        }

        public final int l() {
            if (!this.m) {
                e();
            }
            return this.p;
        }

        public final Rect m() {
            Rect rect = null;
            if (this.i) {
                return null;
            }
            Rect rect2 = this.k;
            if (rect2 != null || this.j) {
                return rect2;
            }
            f();
            rect2 = new Rect();
            int i = this.h;
            Drawable[] drawableArr = this.g;
            for (int i2 = 0; i2 < i; i2++) {
                if (drawableArr[i2].getPadding(rect2)) {
                    if (rect == null) {
                        rect = new Rect(0, 0, 0, 0);
                    }
                    int i3 = rect2.left;
                    if (i3 > rect.left) {
                        rect.left = i3;
                    }
                    i3 = rect2.top;
                    if (i3 > rect.top) {
                        rect.top = i3;
                    }
                    i3 = rect2.right;
                    if (i3 > rect.right) {
                        rect.right = i3;
                    }
                    i3 = rect2.bottom;
                    if (i3 > rect.bottom) {
                        rect.bottom = i3;
                    }
                }
            }
            this.j = true;
            this.k = rect;
            return rect;
        }

        public final int n() {
            if (!this.m) {
                e();
            }
            return this.n;
        }

        public final int o() {
            return this.A;
        }

        public final int p() {
            return this.B;
        }

        public final int q() {
            if (this.r) {
                return this.s;
            }
            f();
            int i = this.h;
            Drawable[] drawableArr = this.g;
            int opacity = i > 0 ? drawableArr[0].getOpacity() : -2;
            for (int i2 = 1; i2 < i; i2++) {
                opacity = Drawable.resolveOpacity(opacity, drawableArr[i2].getOpacity());
            }
            this.s = opacity;
            this.r = true;
            return opacity;
        }

        public void r(int i, int i2) {
            Object obj = new Drawable[i2];
            System.arraycopy(this.g, 0, obj, 0, i);
            this.g = obj;
        }

        void s() {
            this.r = false;
            this.t = false;
        }

        public final boolean t() {
            return this.l;
        }

        public final boolean u() {
            if (this.t) {
                return this.u;
            }
            f();
            int i = this.h;
            Drawable[] drawableArr = this.g;
            boolean z = false;
            for (int i2 = 0; i2 < i; i2++) {
                if (drawableArr[i2].isStateful()) {
                    z = true;
                    break;
                }
            }
            this.u = z;
            this.t = true;
            return z;
        }

        void v() {
            int i = this.h;
            Drawable[] drawableArr = this.g;
            for (int i2 = 0; i2 < i; i2++) {
                if (drawableArr[i2] != null) {
                    drawableArr[i2].mutate();
                }
            }
            this.y = true;
        }

        public final void x(boolean z) {
            this.l = z;
        }

        public final void y(int i) {
            this.A = i;
        }

        public final void z(int i) {
            this.B = i;
        }
    }

    class a implements Runnable {
        a() {
        }

        public void run() {
            b.this.a(true);
            b.this.invalidateSelf();
        }
    }

    static class b implements Callback {
        private Callback a;

        b() {
        }

        public Callback a() {
            Callback callback = this.a;
            this.a = null;
            return callback;
        }

        public b b(Callback callback) {
            this.a = callback;
            return this;
        }

        public void invalidateDrawable(@j0 Drawable drawable) {
        }

        public void scheduleDrawable(@j0 Drawable drawable, @j0 Runnable runnable, long j) {
            Callback callback = this.a;
            if (callback != null) {
                callback.scheduleDrawable(drawable, runnable, j);
            }
        }

        public void unscheduleDrawable(@j0 Drawable drawable, @j0 Runnable runnable) {
            Callback callback = this.a;
            if (callback != null) {
                callback.unscheduleDrawable(drawable, runnable);
            }
        }
    }

    b() {
    }

    private void e(Drawable drawable) {
        if (this.z0 == null) {
            this.z0 = new b();
        }
        drawable.setCallback(this.z0.b(drawable.getCallback()));
        try {
            if (this.d.A <= 0 && this.s0) {
                drawable.setAlpha(this.r0);
            }
            c cVar = this.d;
            if (cVar.E) {
                drawable.setColorFilter(cVar.D);
            } else {
                if (cVar.H) {
                    androidx.core.graphics.drawable.a.o(drawable, cVar.F);
                }
                cVar = this.d;
                if (cVar.I) {
                    androidx.core.graphics.drawable.a.p(drawable, cVar.G);
                }
            }
            drawable.setVisible(isVisible(), true);
            drawable.setDither(this.d.x);
            drawable.setState(getState());
            drawable.setLevel(getLevel());
            drawable.setBounds(getBounds());
            int i = VERSION.SDK_INT;
            if (i >= 23) {
                drawable.setLayoutDirection(getLayoutDirection());
            }
            if (i >= 19) {
                drawable.setAutoMirrored(this.d.C);
            }
            Rect rect = this.f;
            if (i >= 21 && rect != null) {
                drawable.setHotspotBounds(rect.left, rect.top, rect.right, rect.bottom);
            }
            drawable.setCallback(this.z0.a());
        } catch (Throwable th) {
            drawable.setCallback(this.z0.a());
        }
    }

    @SuppressLint({"WrongConstant"})
    @TargetApi(23)
    private boolean f() {
        return isAutoMirrored() && getLayoutDirection() == 1;
    }

    static int g(@k0 Resources resources, int i) {
        if (resources != null) {
            i = resources.getDisplayMetrics().densityDpi;
        }
        return i == 0 ? 160 : i;
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:18:0x0068  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:12:0x003f  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:24:? A:{SYNTHETIC, RETURN, SKIP} */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:21:0x006d A:{SKIP} */
    void a(boolean r14) {
        /*
        r13 = this;
        r0 = 1;
        r13.s0 = r0;
        r1 = android.os.SystemClock.uptimeMillis();
        r3 = r13.s;
        r4 = 255; // 0xff float:3.57E-43 double:1.26E-321;
        r6 = 0;
        r7 = 0;
        if (r3 == 0) goto L_0x0038;
    L_0x0010:
        r9 = r13.x0;
        r11 = (r9 > r7 ? 1 : (r9 == r7 ? 0 : -1));
        if (r11 == 0) goto L_0x003a;
    L_0x0016:
        r11 = (r9 > r1 ? 1 : (r9 == r1 ? 0 : -1));
        if (r11 > 0) goto L_0x0022;
    L_0x001a:
        r9 = r13.r0;
        r3.setAlpha(r9);
        r13.x0 = r7;
        goto L_0x003a;
    L_0x0022:
        r9 = r9 - r1;
        r9 = r9 * r4;
        r10 = (int) r9;
        r9 = r13.d;
        r9 = r9.A;
        r10 = r10 / r9;
        r9 = 255 - r10;
        r10 = r13.r0;
        r9 = r9 * r10;
        r9 = r9 / 255;
        r3.setAlpha(r9);
        r3 = 1;
        goto L_0x003b;
    L_0x0038:
        r13.x0 = r7;
    L_0x003a:
        r3 = 0;
    L_0x003b:
        r9 = r13.q0;
        if (r9 == 0) goto L_0x0068;
    L_0x003f:
        r10 = r13.y0;
        r12 = (r10 > r7 ? 1 : (r10 == r7 ? 0 : -1));
        if (r12 == 0) goto L_0x006a;
    L_0x0045:
        r12 = (r10 > r1 ? 1 : (r10 == r1 ? 0 : -1));
        if (r12 > 0) goto L_0x0055;
    L_0x0049:
        r9.setVisible(r6, r6);
        r0 = 0;
        r13.q0 = r0;
        r0 = -1;
        r13.u0 = r0;
        r13.y0 = r7;
        goto L_0x006a;
    L_0x0055:
        r10 = r10 - r1;
        r10 = r10 * r4;
        r3 = (int) r10;
        r4 = r13.d;
        r4 = r4.B;
        r3 = r3 / r4;
        r4 = r13.r0;
        r3 = r3 * r4;
        r3 = r3 / 255;
        r9.setAlpha(r3);
        goto L_0x006b;
    L_0x0068:
        r13.y0 = r7;
    L_0x006a:
        r0 = r3;
    L_0x006b:
        if (r14 == 0) goto L_0x0077;
    L_0x006d:
        if (r0 == 0) goto L_0x0077;
    L_0x006f:
        r14 = r13.w0;
        r3 = 16;
        r1 = r1 + r3;
        r13.scheduleSelf(r14, r1);
    L_0x0077:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.a.c.a.b.a(boolean):void");
    }

    @o0(21)
    public void applyTheme(@j0 Theme theme) {
        this.d.b(theme);
    }

    void b() {
        this.d.d();
        this.v0 = false;
    }

    c c() {
        return this.d;
    }

    @o0(21)
    public boolean canApplyTheme() {
        return this.d.canApplyTheme();
    }

    int d() {
        return this.t0;
    }

    public void draw(@j0 Canvas canvas) {
        Drawable drawable = this.s;
        if (drawable != null) {
            drawable.draw(canvas);
        }
        drawable = this.q0;
        if (drawable != null) {
            drawable.draw(canvas);
        }
    }

    public int getAlpha() {
        return this.r0;
    }

    public int getChangingConfigurations() {
        return super.getChangingConfigurations() | this.d.getChangingConfigurations();
    }

    public final ConstantState getConstantState() {
        if (!this.d.c()) {
            return null;
        }
        this.d.d = getChangingConfigurations();
        return this.d;
    }

    @j0
    public Drawable getCurrent() {
        return this.s;
    }

    public void getHotspotBounds(@j0 Rect rect) {
        Rect rect2 = this.f;
        if (rect2 != null) {
            rect.set(rect2);
        } else {
            super.getHotspotBounds(rect);
        }
    }

    public int getIntrinsicHeight() {
        if (this.d.t()) {
            return this.d.j();
        }
        Drawable drawable = this.s;
        return drawable != null ? drawable.getIntrinsicHeight() : -1;
    }

    public int getIntrinsicWidth() {
        if (this.d.t()) {
            return this.d.n();
        }
        Drawable drawable = this.s;
        return drawable != null ? drawable.getIntrinsicWidth() : -1;
    }

    public int getMinimumHeight() {
        if (this.d.t()) {
            return this.d.k();
        }
        Drawable drawable = this.s;
        return drawable != null ? drawable.getMinimumHeight() : 0;
    }

    public int getMinimumWidth() {
        if (this.d.t()) {
            return this.d.l();
        }
        Drawable drawable = this.s;
        return drawable != null ? drawable.getMinimumWidth() : 0;
    }

    public int getOpacity() {
        Drawable drawable = this.s;
        return (drawable == null || !drawable.isVisible()) ? -2 : this.d.q();
    }

    @o0(21)
    public void getOutline(@j0 Outline outline) {
        Drawable drawable = this.s;
        if (drawable != null) {
            drawable.getOutline(outline);
        }
    }

    public boolean getPadding(@j0 Rect rect) {
        boolean z;
        Rect m = this.d.m();
        if (m != null) {
            rect.set(m);
            z = (m.right | ((m.left | m.top) | m.bottom)) != 0;
        } else {
            Drawable drawable = this.s;
            z = drawable != null ? drawable.getPadding(rect) : super.getPadding(rect);
        }
        if (f()) {
            int i = rect.left;
            rect.left = rect.right;
            rect.right = i;
        }
        return z;
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:32:0x0079  */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:31:0x0071  */
    boolean h(int r9) {
        /*
        r8 = this;
        r0 = r8.t0;
        r1 = 0;
        if (r9 != r0) goto L_0x0006;
    L_0x0005:
        return r1;
    L_0x0006:
        r2 = android.os.SystemClock.uptimeMillis();
        r0 = r8.d;
        r0 = r0.B;
        r4 = -1;
        r5 = 0;
        r6 = 0;
        if (r0 <= 0) goto L_0x0035;
    L_0x0014:
        r0 = r8.q0;
        if (r0 == 0) goto L_0x001b;
    L_0x0018:
        r0.setVisible(r1, r1);
    L_0x001b:
        r0 = r8.s;
        if (r0 == 0) goto L_0x002e;
    L_0x001f:
        r8.q0 = r0;
        r0 = r8.t0;
        r8.u0 = r0;
        r0 = r8.d;
        r0 = r0.B;
        r0 = (long) r0;
        r0 = r0 + r2;
        r8.y0 = r0;
        goto L_0x003c;
    L_0x002e:
        r8.q0 = r5;
        r8.u0 = r4;
        r8.y0 = r6;
        goto L_0x003c;
    L_0x0035:
        r0 = r8.s;
        if (r0 == 0) goto L_0x003c;
    L_0x0039:
        r0.setVisible(r1, r1);
    L_0x003c:
        if (r9 < 0) goto L_0x005c;
    L_0x003e:
        r0 = r8.d;
        r1 = r0.h;
        if (r9 >= r1) goto L_0x005c;
    L_0x0044:
        r0 = r0.h(r9);
        r8.s = r0;
        r8.t0 = r9;
        if (r0 == 0) goto L_0x0060;
    L_0x004e:
        r9 = r8.d;
        r9 = r9.A;
        if (r9 <= 0) goto L_0x0058;
    L_0x0054:
        r4 = (long) r9;
        r2 = r2 + r4;
        r8.x0 = r2;
    L_0x0058:
        r8.e(r0);
        goto L_0x0060;
    L_0x005c:
        r8.s = r5;
        r8.t0 = r4;
    L_0x0060:
        r0 = r8.x0;
        r9 = 1;
        r2 = (r0 > r6 ? 1 : (r0 == r6 ? 0 : -1));
        if (r2 != 0) goto L_0x006d;
    L_0x0067:
        r0 = r8.y0;
        r2 = (r0 > r6 ? 1 : (r0 == r6 ? 0 : -1));
        if (r2 == 0) goto L_0x007f;
    L_0x006d:
        r0 = r8.w0;
        if (r0 != 0) goto L_0x0079;
    L_0x0071:
        r0 = new b.a.c.a.b$a;
        r0.<init>();
        r8.w0 = r0;
        goto L_0x007c;
    L_0x0079:
        r8.unscheduleSelf(r0);
    L_0x007c:
        r8.a(r9);
    L_0x007f:
        r8.invalidateSelf();
        return r9;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.a.c.a.b.h(int):boolean");
    }

    protected void i(c cVar) {
        this.d = cVar;
        int i = this.t0;
        if (i >= 0) {
            Drawable h = cVar.h(i);
            this.s = h;
            if (h != null) {
                e(h);
            }
        }
        this.u0 = -1;
        this.q0 = null;
    }

    public void invalidateDrawable(@j0 Drawable drawable) {
        c cVar = this.d;
        if (cVar != null) {
            cVar.s();
        }
        if (drawable == this.s && getCallback() != null) {
            getCallback().invalidateDrawable(this);
        }
    }

    public boolean isAutoMirrored() {
        return this.d.C;
    }

    public boolean isStateful() {
        return this.d.u();
    }

    void j(int i) {
        h(i);
    }

    public void jumpToCurrentState() {
        Object obj;
        Drawable drawable = this.q0;
        Object obj2 = 1;
        if (drawable != null) {
            drawable.jumpToCurrentState();
            this.q0 = null;
            this.u0 = -1;
            obj = 1;
        } else {
            obj = null;
        }
        Drawable drawable2 = this.s;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
            if (this.s0) {
                this.s.setAlpha(this.r0);
            }
        }
        if (this.y0 != 0) {
            this.y0 = 0;
            obj = 1;
        }
        if (this.x0 != 0) {
            this.x0 = 0;
        } else {
            obj2 = obj;
        }
        if (obj2 != null) {
            invalidateSelf();
        }
    }

    public void k(int i) {
        this.d.A = i;
    }

    public void l(int i) {
        this.d.B = i;
    }

    final void m(Resources resources) {
        this.d.C(resources);
    }

    @j0
    public Drawable mutate() {
        if (!this.v0 && super.mutate() == this) {
            c c = c();
            c.v();
            i(c);
            this.v0 = true;
        }
        return this;
    }

    protected void onBoundsChange(Rect rect) {
        Drawable drawable = this.q0;
        if (drawable != null) {
            drawable.setBounds(rect);
        }
        drawable = this.s;
        if (drawable != null) {
            drawable.setBounds(rect);
        }
    }

    public boolean onLayoutDirectionChanged(int i) {
        return this.d.A(i, d());
    }

    protected boolean onLevelChange(int i) {
        Drawable drawable = this.q0;
        if (drawable != null) {
            return drawable.setLevel(i);
        }
        drawable = this.s;
        return drawable != null ? drawable.setLevel(i) : false;
    }

    protected boolean onStateChange(int[] iArr) {
        Drawable drawable = this.q0;
        if (drawable != null) {
            return drawable.setState(iArr);
        }
        drawable = this.s;
        return drawable != null ? drawable.setState(iArr) : false;
    }

    public void scheduleDrawable(@j0 Drawable drawable, @j0 Runnable runnable, long j) {
        if (drawable == this.s && getCallback() != null) {
            getCallback().scheduleDrawable(this, runnable, j);
        }
    }

    public void setAlpha(int i) {
        if (!this.s0 || this.r0 != i) {
            this.s0 = true;
            this.r0 = i;
            Drawable drawable = this.s;
            if (drawable == null) {
                return;
            }
            if (this.x0 == 0) {
                drawable.setAlpha(i);
            } else {
                a(false);
            }
        }
    }

    public void setAutoMirrored(boolean z) {
        c cVar = this.d;
        if (cVar.C != z) {
            cVar.C = z;
            Drawable drawable = this.s;
            if (drawable != null) {
                androidx.core.graphics.drawable.a.j(drawable, z);
            }
        }
    }

    public void setColorFilter(ColorFilter colorFilter) {
        c cVar = this.d;
        cVar.E = true;
        if (cVar.D != colorFilter) {
            cVar.D = colorFilter;
            Drawable drawable = this.s;
            if (drawable != null) {
                drawable.setColorFilter(colorFilter);
            }
        }
    }

    public void setDither(boolean z) {
        c cVar = this.d;
        if (cVar.x != z) {
            cVar.x = z;
            Drawable drawable = this.s;
            if (drawable != null) {
                drawable.setDither(z);
            }
        }
    }

    public void setHotspot(float f, float f2) {
        Drawable drawable = this.s;
        if (drawable != null) {
            androidx.core.graphics.drawable.a.k(drawable, f, f2);
        }
    }

    public void setHotspotBounds(int i, int i2, int i3, int i4) {
        Rect rect = this.f;
        if (rect == null) {
            this.f = new Rect(i, i2, i3, i4);
        } else {
            rect.set(i, i2, i3, i4);
        }
        Drawable drawable = this.s;
        if (drawable != null) {
            androidx.core.graphics.drawable.a.l(drawable, i, i2, i3, i4);
        }
    }

    public void setTintList(ColorStateList colorStateList) {
        c cVar = this.d;
        cVar.H = true;
        if (cVar.F != colorStateList) {
            cVar.F = colorStateList;
            androidx.core.graphics.drawable.a.o(this.s, colorStateList);
        }
    }

    public void setTintMode(@j0 Mode mode) {
        c cVar = this.d;
        cVar.I = true;
        if (cVar.G != mode) {
            cVar.G = mode;
            androidx.core.graphics.drawable.a.p(this.s, mode);
        }
    }

    public boolean setVisible(boolean z, boolean z2) {
        boolean visible = super.setVisible(z, z2);
        Drawable drawable = this.q0;
        if (drawable != null) {
            drawable.setVisible(z, z2);
        }
        drawable = this.s;
        if (drawable != null) {
            drawable.setVisible(z, z2);
        }
        return visible;
    }

    public void unscheduleDrawable(@j0 Drawable drawable, @j0 Runnable runnable) {
        if (drawable == this.s && getCallback() != null) {
            getCallback().unscheduleDrawable(this, runnable);
        }
    }
}
