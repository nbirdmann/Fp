package b.a.e;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.annotation.r0;

public abstract class b {
    private Object a;
    private boolean b;

    public interface a {
        void a(b bVar);

        boolean b(b bVar, Menu menu);

        boolean c(b bVar, Menu menu);

        boolean d(b bVar, MenuItem menuItem);
    }

    public abstract void c();

    public abstract View d();

    public abstract Menu e();

    public abstract MenuInflater f();

    public abstract CharSequence g();

    public Object h() {
        return this.a;
    }

    public abstract CharSequence i();

    public boolean j() {
        return this.b;
    }

    public abstract void k();

    public boolean l() {
        return false;
    }

    @r0({androidx.annotation.r0.a.b})
    public boolean m() {
        return true;
    }

    public abstract void n(View view);

    public abstract void o(int i);

    public abstract void p(CharSequence charSequence);

    public void q(Object obj) {
        this.a = obj;
    }

    public abstract void r(int i);

    public abstract void s(CharSequence charSequence);

    public void t(boolean z) {
        this.b = z;
    }
}
