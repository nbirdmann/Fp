package b.a.e;

public interface c {
    void d();

    void h();
}
