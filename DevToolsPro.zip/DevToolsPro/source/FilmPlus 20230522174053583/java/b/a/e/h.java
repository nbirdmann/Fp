package b.a.e;

import android.view.View;
import android.view.animation.Interpolator;
import androidx.annotation.r0;
import b.h.o.j0;
import b.h.o.k0;
import b.h.o.l0;
import java.util.ArrayList;
import java.util.Iterator;

@r0({androidx.annotation.r0.a.b})
public class h {
    final ArrayList<j0> a = new ArrayList();
    private long b = -1;
    private Interpolator c;
    k0 d;
    private boolean e;
    private final l0 f = new a();

    class a extends l0 {
        private boolean a = false;
        private int b = 0;

        a() {
        }

        public void b(View view) {
            int i = this.b + 1;
            this.b = i;
            if (i == h.this.a.size()) {
                k0 k0Var = h.this.d;
                if (k0Var != null) {
                    k0Var.b(null);
                }
                d();
            }
        }

        public void c(View view) {
            if (!this.a) {
                this.a = true;
                k0 k0Var = h.this.d;
                if (k0Var != null) {
                    k0Var.c(null);
                }
            }
        }

        void d() {
            this.b = 0;
            this.a = false;
            h.this.b();
        }
    }

    public void a() {
        if (this.e) {
            Iterator it = this.a.iterator();
            while (it.hasNext()) {
                ((j0) it.next()).c();
            }
            this.e = false;
        }
    }

    void b() {
        this.e = false;
    }

    public h c(j0 j0Var) {
        if (!this.e) {
            this.a.add(j0Var);
        }
        return this;
    }

    public h d(j0 j0Var, j0 j0Var2) {
        this.a.add(j0Var);
        j0Var2.u(j0Var.d());
        this.a.add(j0Var2);
        return this;
    }

    public h e(long j) {
        if (!this.e) {
            this.b = j;
        }
        return this;
    }

    public h f(Interpolator interpolator) {
        if (!this.e) {
            this.c = interpolator;
        }
        return this;
    }

    public h g(k0 k0Var) {
        if (!this.e) {
            this.d = k0Var;
        }
        return this;
    }

    public void h() {
        if (!this.e) {
            Iterator it = this.a.iterator();
            while (it.hasNext()) {
                j0 j0Var = (j0) it.next();
                long j = this.b;
                if (j >= 0) {
                    j0Var.q(j);
                }
                Interpolator interpolator = this.c;
                if (interpolator != null) {
                    j0Var.r(interpolator);
                }
                if (this.d != null) {
                    j0Var.s(this.f);
                }
                j0Var.w();
            }
            this.e = true;
        }
    }
}
