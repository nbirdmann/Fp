package b.a.e;

import android.content.Context;
import android.view.ActionMode;
import android.view.ActionMode.Callback;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.annotation.r0;
import androidx.appcompat.view.menu.r;
import b.e.i;
import b.h.f.b.b;
import java.util.ArrayList;

@r0({androidx.annotation.r0.a.b})
public class f extends ActionMode {
    final Context a;
    final b b;

    @r0({androidx.annotation.r0.a.b})
    public static class a implements b.a.e.b.a {
        final Callback a;
        final Context b;
        final ArrayList<f> c = new ArrayList();
        final i<Menu, Menu> d = new i();

        public a(Context context, Callback callback) {
            this.b = context;
            this.a = callback;
        }

        private Menu f(Menu menu) {
            Menu menu2 = (Menu) this.d.get(menu);
            if (menu2 != null) {
                return menu2;
            }
            menu2 = r.a(this.b, (b.h.f.b.a) menu);
            this.d.put(menu, menu2);
            return menu2;
        }

        public void a(b bVar) {
            this.a.onDestroyActionMode(e(bVar));
        }

        public boolean b(b bVar, Menu menu) {
            return this.a.onCreateActionMode(e(bVar), f(menu));
        }

        public boolean c(b bVar, Menu menu) {
            return this.a.onPrepareActionMode(e(bVar), f(menu));
        }

        public boolean d(b bVar, MenuItem menuItem) {
            return this.a.onActionItemClicked(e(bVar), r.b(this.b, (b) menuItem));
        }

        public ActionMode e(b bVar) {
            int size = this.c.size();
            for (int i = 0; i < size; i++) {
                f fVar = (f) this.c.get(i);
                if (fVar != null && fVar.b == bVar) {
                    return fVar;
                }
            }
            ActionMode fVar2 = new f(this.b, bVar);
            this.c.add(fVar2);
            return fVar2;
        }
    }

    public f(Context context, b bVar) {
        this.a = context;
        this.b = bVar;
    }

    public void finish() {
        this.b.c();
    }

    public View getCustomView() {
        return this.b.d();
    }

    public Menu getMenu() {
        return r.a(this.a, (b.h.f.b.a) this.b.e());
    }

    public MenuInflater getMenuInflater() {
        return this.b.f();
    }

    public CharSequence getSubtitle() {
        return this.b.g();
    }

    public Object getTag() {
        return this.b.h();
    }

    public CharSequence getTitle() {
        return this.b.i();
    }

    public boolean getTitleOptionalHint() {
        return this.b.j();
    }

    public void invalidate() {
        this.b.k();
    }

    public boolean isTitleOptional() {
        return this.b.l();
    }

    public void setCustomView(View view) {
        this.b.n(view);
    }

    public void setSubtitle(int i) {
        this.b.o(i);
    }

    public void setSubtitle(CharSequence charSequence) {
        this.b.p(charSequence);
    }

    public void setTag(Object obj) {
        this.b.q(obj);
    }

    public void setTitle(int i) {
        this.b.r(i);
    }

    public void setTitle(CharSequence charSequence) {
        this.b.s(charSequence);
    }

    public void setTitleOptionalHint(boolean z) {
        this.b.t(z);
    }
}
