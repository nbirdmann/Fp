package b.a.e;

import android.content.Context;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.annotation.r0;
import androidx.annotation.r0.a;
import androidx.appcompat.view.menu.h;
import androidx.appcompat.view.menu.o;
import androidx.appcompat.view.menu.v;
import androidx.appcompat.widget.ActionBarContextView;
import java.lang.ref.WeakReference;

@r0({a.b})
public class e extends b implements h.a {
    private Context c;
    private ActionBarContextView d;
    private b.a f;
    private boolean q0;
    private boolean r0;
    private WeakReference<View> s;
    private h s0;

    public e(Context context, ActionBarContextView actionBarContextView, b.a aVar, boolean z) {
        this.c = context;
        this.d = actionBarContextView;
        this.f = aVar;
        h Z = new h(actionBarContextView.getContext()).Z(1);
        this.s0 = Z;
        Z.X(this);
        this.r0 = z;
    }

    public boolean a(h hVar, MenuItem menuItem) {
        return this.f.d(this, menuItem);
    }

    public void b(h hVar) {
        k();
        this.d.o();
    }

    public void c() {
        if (!this.q0) {
            this.q0 = true;
            this.d.sendAccessibilityEvent(32);
            this.f.a(this);
        }
    }

    public View d() {
        WeakReference weakReference = this.s;
        return weakReference != null ? (View) weakReference.get() : null;
    }

    public Menu e() {
        return this.s0;
    }

    public MenuInflater f() {
        return new g(this.d.getContext());
    }

    public CharSequence g() {
        return this.d.getSubtitle();
    }

    public CharSequence i() {
        return this.d.getTitle();
    }

    public void k() {
        this.f.c(this, this.s0);
    }

    public boolean l() {
        return this.d.s();
    }

    public boolean m() {
        return this.r0;
    }

    public void n(View view) {
        this.d.setCustomView(view);
        this.s = view != null ? new WeakReference(view) : null;
    }

    public void o(int i) {
        p(this.c.getString(i));
    }

    public void p(CharSequence charSequence) {
        this.d.setSubtitle(charSequence);
    }

    public void r(int i) {
        s(this.c.getString(i));
    }

    public void s(CharSequence charSequence) {
        this.d.setTitle(charSequence);
    }

    public void t(boolean z) {
        super.t(z);
        this.d.setTitleOptional(z);
    }

    public void u(h hVar, boolean z) {
    }

    public void v(v vVar) {
    }

    public boolean w(v vVar) {
        if (!vVar.hasVisibleItems()) {
            return true;
        }
        new o(this.d.getContext(), vVar).l();
        return true;
    }
}
