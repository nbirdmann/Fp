package b.a.e;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.PorterDuff.Mode;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import android.view.InflateException;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MenuItem.OnMenuItemClickListener;
import android.view.SubMenu;
import android.view.View;
import androidx.annotation.e0;
import androidx.annotation.r0;
import androidx.appcompat.view.menu.k;
import androidx.appcompat.view.menu.l;
import androidx.appcompat.widget.d0;
import b.h.o.o;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

@r0({androidx.annotation.r0.a.b})
public class g extends MenuInflater {
    static final String a = "SupportMenuInflater";
    private static final String b = "menu";
    private static final String c = "group";
    private static final String d = "item";
    static final int e = 0;
    static final Class<?>[] f;
    static final Class<?>[] g;
    final Object[] h;
    final Object[] i;
    Context j;
    private Object k;

    private static class a implements OnMenuItemClickListener {
        private static final Class<?>[] l = new Class[]{MenuItem.class};
        private Object m;
        private Method n;

        public a(Object obj, String str) {
            this.m = obj;
            Class cls = obj.getClass();
            try {
                this.n = cls.getMethod(str, l);
            } catch (Throwable e) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Couldn't resolve menu item onClick handler ");
                stringBuilder.append(str);
                stringBuilder.append(" in class ");
                stringBuilder.append(cls.getName());
                InflateException inflateException = new InflateException(stringBuilder.toString());
                inflateException.initCause(e);
                throw inflateException;
            }
        }

        public boolean onMenuItemClick(MenuItem menuItem) {
            try {
                if (this.n.getReturnType() == Boolean.TYPE) {
                    return ((Boolean) this.n.invoke(this.m, new Object[]{menuItem})).booleanValue();
                }
                this.n.invoke(this.m, new Object[]{menuItem});
                return true;
            } catch (Throwable e) {
                throw new RuntimeException(e);
            }
        }
    }

    private class b {
        private static final int a = 0;
        private static final int b = 0;
        private static final int c = 0;
        private static final int d = 0;
        private static final int e = 0;
        private static final boolean f = false;
        private static final boolean g = true;
        private static final boolean h = true;
        private boolean A;
        private boolean B;
        private boolean C;
        private int D;
        private int E;
        private String F;
        private String G;
        private String H;
        b.h.o.b I;
        private CharSequence J;
        private CharSequence K;
        private ColorStateList L = null;
        private Mode M = null;
        private Menu i;
        private int j;
        private int k;
        private int l;
        private int m;
        private boolean n;
        private boolean o;
        private boolean p;
        private int q;
        private int r;
        private CharSequence s;
        private CharSequence t;
        private int u;
        private char v;
        private int w;
        private char x;
        private int y;
        private int z;

        public b(Menu menu) {
            this.i = menu;
            h();
        }

        private char c(String str) {
            return str == null ? 0 : str.charAt(0);
        }

        private <T> T e(String str, Class<?>[] clsArr, Object[] objArr) {
            try {
                Constructor constructor = g.this.j.getClassLoader().loadClass(str).getConstructor(clsArr);
                constructor.setAccessible(true);
                str = constructor.newInstance(objArr);
                return str;
            } catch (Throwable e) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Cannot instantiate class: ");
                stringBuilder.append(str);
                Log.w(g.a, stringBuilder.toString(), e);
                return null;
            }
        }

        private void i(MenuItem menuItem) {
            Object obj = null;
            menuItem.setChecked(this.A).setVisible(this.B).setEnabled(this.C).setCheckable(this.z >= 1).setTitleCondensed(this.t).setIcon(this.u);
            int i = this.D;
            if (i >= 0) {
                menuItem.setShowAsAction(i);
            }
            if (this.H != null) {
                if (g.this.j.isRestricted()) {
                    throw new IllegalStateException("The android:onClick attribute cannot be used within a restricted context");
                }
                menuItem.setOnMenuItemClickListener(new a(g.this.b(), this.H));
            }
            boolean z = menuItem instanceof k;
            if (z) {
                k kVar = (k) menuItem;
            }
            if (this.z >= 2) {
                if (z) {
                    ((k) menuItem).w(true);
                } else if (menuItem instanceof l) {
                    ((l) menuItem).l(true);
                }
            }
            String str = this.F;
            if (str != null) {
                menuItem.setActionView((View) e(str, g.f, g.this.h));
                obj = 1;
            }
            i = this.E;
            if (i > 0) {
                if (obj == null) {
                    menuItem.setActionView(i);
                } else {
                    Log.w(g.a, "Ignoring attribute 'itemActionViewLayout'. Action view already specified.");
                }
            }
            b.h.o.b bVar = this.I;
            if (bVar != null) {
                o.l(menuItem, bVar);
            }
            o.p(menuItem, this.J);
            o.w(menuItem, this.K);
            o.o(menuItem, this.v, this.w);
            o.s(menuItem, this.x, this.y);
            Mode mode = this.M;
            if (mode != null) {
                o.r(menuItem, mode);
            }
            ColorStateList colorStateList = this.L;
            if (colorStateList != null) {
                o.q(menuItem, colorStateList);
            }
        }

        public void a() {
            this.p = true;
            i(this.i.add(this.j, this.q, this.r, this.s));
        }

        public SubMenu b() {
            this.p = true;
            SubMenu addSubMenu = this.i.addSubMenu(this.j, this.q, this.r, this.s);
            i(addSubMenu.getItem());
            return addSubMenu;
        }

        public boolean d() {
            return this.p;
        }

        public void f(AttributeSet attributeSet) {
            TypedArray obtainStyledAttributes = g.this.j.obtainStyledAttributes(attributeSet, b.a.a.l.R4);
            this.j = obtainStyledAttributes.getResourceId(b.a.a.l.T4, 0);
            this.k = obtainStyledAttributes.getInt(b.a.a.l.V4, 0);
            this.l = obtainStyledAttributes.getInt(b.a.a.l.W4, 0);
            this.m = obtainStyledAttributes.getInt(b.a.a.l.X4, 0);
            this.n = obtainStyledAttributes.getBoolean(b.a.a.l.U4, true);
            this.o = obtainStyledAttributes.getBoolean(b.a.a.l.S4, true);
            obtainStyledAttributes.recycle();
        }

        public void g(AttributeSet attributeSet) {
            TypedArray obtainStyledAttributes = g.this.j.obtainStyledAttributes(attributeSet, b.a.a.l.Y4);
            this.q = obtainStyledAttributes.getResourceId(b.a.a.l.b5, 0);
            this.r = (obtainStyledAttributes.getInt(b.a.a.l.e5, this.k) & b.h.f.b.a.c) | (obtainStyledAttributes.getInt(b.a.a.l.f5, this.l) & 65535);
            this.s = obtainStyledAttributes.getText(b.a.a.l.g5);
            this.t = obtainStyledAttributes.getText(b.a.a.l.h5);
            this.u = obtainStyledAttributes.getResourceId(b.a.a.l.Z4, 0);
            this.v = c(obtainStyledAttributes.getString(b.a.a.l.i5));
            this.w = obtainStyledAttributes.getInt(b.a.a.l.p5, 4096);
            this.x = c(obtainStyledAttributes.getString(b.a.a.l.j5));
            this.y = obtainStyledAttributes.getInt(b.a.a.l.t5, 4096);
            int i = b.a.a.l.k5;
            if (obtainStyledAttributes.hasValue(i)) {
                this.z = obtainStyledAttributes.getBoolean(i, false);
            } else {
                this.z = this.m;
            }
            this.A = obtainStyledAttributes.getBoolean(b.a.a.l.c5, false);
            this.B = obtainStyledAttributes.getBoolean(b.a.a.l.d5, this.n);
            this.C = obtainStyledAttributes.getBoolean(b.a.a.l.a5, this.o);
            this.D = obtainStyledAttributes.getInt(b.a.a.l.u5, -1);
            this.H = obtainStyledAttributes.getString(b.a.a.l.l5);
            this.E = obtainStyledAttributes.getResourceId(b.a.a.l.m5, 0);
            this.F = obtainStyledAttributes.getString(b.a.a.l.o5);
            String string = obtainStyledAttributes.getString(b.a.a.l.n5);
            this.G = string;
            Object obj = string != null ? 1 : null;
            if (obj != null && this.E == 0 && this.F == null) {
                this.I = (b.h.o.b) e(string, g.g, g.this.i);
            } else {
                if (obj != null) {
                    Log.w(g.a, "Ignoring attribute 'actionProviderClass'. Action view already specified.");
                }
                this.I = null;
            }
            this.J = obtainStyledAttributes.getText(b.a.a.l.q5);
            this.K = obtainStyledAttributes.getText(b.a.a.l.v5);
            i = b.a.a.l.s5;
            if (obtainStyledAttributes.hasValue(i)) {
                this.M = d0.e(obtainStyledAttributes.getInt(i, -1), this.M);
            } else {
                this.M = null;
            }
            i = b.a.a.l.r5;
            if (obtainStyledAttributes.hasValue(i)) {
                this.L = obtainStyledAttributes.getColorStateList(i);
            } else {
                this.L = null;
            }
            obtainStyledAttributes.recycle();
            this.p = false;
        }

        public void h() {
            this.j = 0;
            this.k = 0;
            this.l = 0;
            this.m = 0;
            this.n = true;
            this.o = true;
        }
    }

    static {
        Class[] clsArr = new Class[]{Context.class};
        f = clsArr;
        g = clsArr;
    }

    public g(Context context) {
        super(context);
        this.j = context;
        Object[] objArr = new Object[]{context};
        this.h = objArr;
        this.i = objArr;
    }

    private Object a(Object obj) {
        if (obj instanceof Activity) {
            return obj;
        }
        if (obj instanceof ContextWrapper) {
            obj = a(((ContextWrapper) obj).getBaseContext());
        }
        return obj;
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:12:0x0042  */
    private void c(org.xmlpull.v1.XmlPullParser r13, android.util.AttributeSet r14, android.view.Menu r15) throws org.xmlpull.v1.XmlPullParserException, java.io.IOException {
        /*
        r12 = this;
        r0 = new b.a.e.g$b;
        r0.<init>(r15);
        r15 = r13.getEventType();
    L_0x0009:
        r1 = 2;
        r2 = "menu";
        r3 = 1;
        if (r15 != r1) goto L_0x0035;
    L_0x000f:
        r15 = r13.getName();
        r4 = r15.equals(r2);
        if (r4 == 0) goto L_0x001e;
    L_0x0019:
        r15 = r13.next();
        goto L_0x003b;
    L_0x001e:
        r13 = new java.lang.RuntimeException;
        r14 = new java.lang.StringBuilder;
        r14.<init>();
        r0 = "Expecting menu, got ";
        r14.append(r0);
        r14.append(r15);
        r14 = r14.toString();
        r13.<init>(r14);
        throw r13;
    L_0x0035:
        r15 = r13.next();
        if (r15 != r3) goto L_0x0009;
    L_0x003b:
        r4 = 0;
        r5 = 0;
        r8 = r4;
        r6 = 0;
        r7 = 0;
    L_0x0040:
        if (r6 != 0) goto L_0x00c6;
    L_0x0042:
        if (r15 == r3) goto L_0x00be;
    L_0x0044:
        r9 = "item";
        r10 = "group";
        if (r15 == r1) goto L_0x008e;
    L_0x004a:
        r11 = 3;
        if (r15 == r11) goto L_0x004f;
    L_0x004d:
        goto L_0x00b9;
    L_0x004f:
        r15 = r13.getName();
        if (r7 == 0) goto L_0x005e;
    L_0x0055:
        r11 = r15.equals(r8);
        if (r11 == 0) goto L_0x005e;
    L_0x005b:
        r8 = r4;
        r7 = 0;
        goto L_0x00b9;
    L_0x005e:
        r10 = r15.equals(r10);
        if (r10 == 0) goto L_0x0068;
    L_0x0064:
        r0.h();
        goto L_0x00b9;
    L_0x0068:
        r9 = r15.equals(r9);
        if (r9 == 0) goto L_0x0086;
    L_0x006e:
        r15 = r0.d();
        if (r15 != 0) goto L_0x00b9;
    L_0x0074:
        r15 = r0.I;
        if (r15 == 0) goto L_0x0082;
    L_0x0078:
        r15 = r15.hasSubMenu();
        if (r15 == 0) goto L_0x0082;
    L_0x007e:
        r0.b();
        goto L_0x00b9;
    L_0x0082:
        r0.a();
        goto L_0x00b9;
    L_0x0086:
        r15 = r15.equals(r2);
        if (r15 == 0) goto L_0x00b9;
    L_0x008c:
        r6 = 1;
        goto L_0x00b9;
    L_0x008e:
        if (r7 == 0) goto L_0x0091;
    L_0x0090:
        goto L_0x00b9;
    L_0x0091:
        r15 = r13.getName();
        r10 = r15.equals(r10);
        if (r10 == 0) goto L_0x009f;
    L_0x009b:
        r0.f(r14);
        goto L_0x00b9;
    L_0x009f:
        r9 = r15.equals(r9);
        if (r9 == 0) goto L_0x00a9;
    L_0x00a5:
        r0.g(r14);
        goto L_0x00b9;
    L_0x00a9:
        r9 = r15.equals(r2);
        if (r9 == 0) goto L_0x00b7;
    L_0x00af:
        r15 = r0.b();
        r12.c(r13, r14, r15);
        goto L_0x00b9;
    L_0x00b7:
        r8 = r15;
        r7 = 1;
    L_0x00b9:
        r15 = r13.next();
        goto L_0x0040;
    L_0x00be:
        r13 = new java.lang.RuntimeException;
        r14 = "Unexpected end of document";
        r13.<init>(r14);
        throw r13;
    L_0x00c6:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.a.e.g.c(org.xmlpull.v1.XmlPullParser, android.util.AttributeSet, android.view.Menu):void");
    }

    Object b() {
        if (this.k == null) {
            this.k = a(this.j);
        }
        return this.k;
    }

    public void inflate(@e0 int i, Menu menu) {
        String str = "Error inflating menu XML";
        if (menu instanceof b.h.f.b.a) {
            XmlResourceParser xmlResourceParser = null;
            try {
                xmlResourceParser = this.j.getResources().getLayout(i);
                c(xmlResourceParser, Xml.asAttributeSet(xmlResourceParser), menu);
                if (xmlResourceParser != null) {
                    xmlResourceParser.close();
                }
            } catch (Throwable e) {
                throw new InflateException(str, e);
            } catch (Throwable e2) {
                throw new InflateException(str, e2);
            } catch (Throwable th) {
                if (xmlResourceParser != null) {
                    xmlResourceParser.close();
                }
            }
        } else {
            super.inflate(i, menu);
        }
    }
}
