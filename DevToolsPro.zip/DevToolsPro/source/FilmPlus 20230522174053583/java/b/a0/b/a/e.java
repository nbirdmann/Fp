package b.a0.b.a;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.Keyframe;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.TypeEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.util.Xml;
import android.view.InflateException;
import androidx.annotation.r0;
import b.h.d.h;
import b.h.d.h.b;
import com.ironsource.mediationsdk.utils.IronSourceConstants;
import java.io.IOException;
import java.util.ArrayList;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

@r0({androidx.annotation.r0.a.b})
public class e {
    private static final String a = "AnimatorInflater";
    private static final int b = 0;
    private static final int c = 100;
    private static final int d = 0;
    private static final int e = 1;
    private static final int f = 2;
    private static final int g = 3;
    private static final int h = 4;
    private static final boolean i = false;

    private static class a implements TypeEvaluator<b[]> {
        private b[] a;

        a() {
        }

        a(b[] bVarArr) {
            this.a = bVarArr;
        }

        /* renamed from: a */
        public b[] evaluate(float f, b[] bVarArr, b[] bVarArr2) {
            if (h.b(bVarArr, bVarArr2)) {
                b[] bVarArr3 = this.a;
                if (bVarArr3 == null || !h.b(bVarArr3, bVarArr)) {
                    this.a = h.f(bVarArr);
                }
                for (int i = 0; i < bVarArr.length; i++) {
                    this.a[i].d(bVarArr[i], bVarArr2[i], f);
                }
                return this.a;
            }
            throw new IllegalArgumentException("Can't interpolate between two incompatible pathData");
        }
    }

    private e() {
    }

    private static Animator a(Context context, Resources resources, Theme theme, XmlPullParser xmlPullParser, float f) throws XmlPullParserException, IOException {
        return b(context, resources, theme, xmlPullParser, Xml.asAttributeSet(xmlPullParser), null, 0, f);
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:32:0x00ba  */
    private static android.animation.Animator b(android.content.Context r18, android.content.res.Resources r19, android.content.res.Resources.Theme r20, org.xmlpull.v1.XmlPullParser r21, android.util.AttributeSet r22, android.animation.AnimatorSet r23, int r24, float r25) throws org.xmlpull.v1.XmlPullParserException, java.io.IOException {
        /*
        r8 = r19;
        r9 = r20;
        r10 = r21;
        r11 = r23;
        r12 = r21.getDepth();
        r0 = 0;
        r13 = r0;
    L_0x000e:
        r1 = r21.next();
        r2 = 3;
        r14 = 0;
        if (r1 != r2) goto L_0x001c;
    L_0x0016:
        r2 = r21.getDepth();
        if (r2 <= r12) goto L_0x00df;
    L_0x001c:
        r2 = 1;
        if (r1 == r2) goto L_0x00df;
    L_0x001f:
        r3 = 2;
        if (r1 == r3) goto L_0x0023;
    L_0x0022:
        goto L_0x000e;
    L_0x0023:
        r1 = r21.getName();
        r3 = "objectAnimator";
        r3 = r1.equals(r3);
        if (r3 == 0) goto L_0x0043;
    L_0x002f:
        r0 = r18;
        r1 = r19;
        r2 = r20;
        r3 = r22;
        r4 = r25;
        r5 = r21;
        r0 = o(r0, r1, r2, r3, r4, r5);
    L_0x003f:
        r3 = r18;
        goto L_0x00b4;
    L_0x0043:
        r3 = "animator";
        r3 = r1.equals(r3);
        if (r3 == 0) goto L_0x005d;
    L_0x004b:
        r4 = 0;
        r0 = r18;
        r1 = r19;
        r2 = r20;
        r3 = r22;
        r5 = r25;
        r6 = r21;
        r0 = m(r0, r1, r2, r3, r4, r5, r6);
        goto L_0x003f;
    L_0x005d:
        r3 = "set";
        r3 = r1.equals(r3);
        if (r3 == 0) goto L_0x0093;
    L_0x0065:
        r15 = new android.animation.AnimatorSet;
        r15.<init>();
        r0 = b.a0.b.a.a.Z;
        r7 = r22;
        r6 = androidx.core.content.i.h.s(r8, r9, r7, r0);
        r0 = "ordering";
        r16 = androidx.core.content.i.h.k(r6, r10, r0, r14, r14);
        r0 = r18;
        r1 = r19;
        r2 = r20;
        r3 = r21;
        r4 = r22;
        r5 = r15;
        r17 = r6;
        r6 = r16;
        r7 = r25;
        b(r0, r1, r2, r3, r4, r5, r6, r7);
        r17.recycle();
        r3 = r18;
        r0 = r15;
        goto L_0x00b4;
    L_0x0093:
        r3 = "propertyValuesHolder";
        r1 = r1.equals(r3);
        if (r1 == 0) goto L_0x00c4;
    L_0x009b:
        r1 = android.util.Xml.asAttributeSet(r21);
        r3 = r18;
        r1 = q(r3, r8, r9, r10, r1);
        if (r1 == 0) goto L_0x00b3;
    L_0x00a7:
        if (r0 == 0) goto L_0x00b3;
    L_0x00a9:
        r4 = r0 instanceof android.animation.ValueAnimator;
        if (r4 == 0) goto L_0x00b3;
    L_0x00ad:
        r4 = r0;
        r4 = (android.animation.ValueAnimator) r4;
        r4.setValues(r1);
    L_0x00b3:
        r14 = 1;
    L_0x00b4:
        if (r11 == 0) goto L_0x000e;
    L_0x00b6:
        if (r14 != 0) goto L_0x000e;
    L_0x00b8:
        if (r13 != 0) goto L_0x00bf;
    L_0x00ba:
        r13 = new java.util.ArrayList;
        r13.<init>();
    L_0x00bf:
        r13.add(r0);
        goto L_0x000e;
    L_0x00c4:
        r0 = new java.lang.RuntimeException;
        r1 = new java.lang.StringBuilder;
        r1.<init>();
        r2 = "Unknown animator name: ";
        r1.append(r2);
        r2 = r21.getName();
        r1.append(r2);
        r1 = r1.toString();
        r0.<init>(r1);
        throw r0;
    L_0x00df:
        if (r11 == 0) goto L_0x0108;
    L_0x00e1:
        if (r13 == 0) goto L_0x0108;
    L_0x00e3:
        r1 = r13.size();
        r1 = new android.animation.Animator[r1];
        r2 = r13.iterator();
    L_0x00ed:
        r3 = r2.hasNext();
        if (r3 == 0) goto L_0x00ff;
    L_0x00f3:
        r3 = r2.next();
        r3 = (android.animation.Animator) r3;
        r4 = r14 + 1;
        r1[r14] = r3;
        r14 = r4;
        goto L_0x00ed;
    L_0x00ff:
        if (r24 != 0) goto L_0x0105;
    L_0x0101:
        r11.playTogether(r1);
        goto L_0x0108;
    L_0x0105:
        r11.playSequentially(r1);
    L_0x0108:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.a0.b.a.e.b(android.content.Context, android.content.res.Resources, android.content.res.Resources$Theme, org.xmlpull.v1.XmlPullParser, android.util.AttributeSet, android.animation.AnimatorSet, int, float):android.animation.Animator");
    }

    private static Keyframe c(Keyframe keyframe, float f) {
        return keyframe.getType() == Float.TYPE ? Keyframe.ofFloat(f) : keyframe.getType() == Integer.TYPE ? Keyframe.ofInt(f) : Keyframe.ofObject(f);
    }

    private static void d(Keyframe[] keyframeArr, float f, int i, int i2) {
        f /= (float) ((i2 - i) + 2);
        while (i <= i2) {
            keyframeArr[i].setFraction(keyframeArr[i - 1].getFraction() + f);
            i++;
        }
    }

    private static void e(Object[] objArr, String str) {
        if (objArr != null && objArr.length != 0) {
            String str2 = a;
            Log.d(str2, str);
            int length = objArr.length;
            for (int i = 0; i < length; i++) {
                Keyframe keyframe = (Keyframe) objArr[i];
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Keyframe ");
                stringBuilder.append(i);
                stringBuilder.append(": fraction ");
                Object obj = "null";
                stringBuilder.append(keyframe.getFraction() < 0.0f ? obj : Float.valueOf(keyframe.getFraction()));
                stringBuilder.append(", ");
                stringBuilder.append(", value : ");
                if (keyframe.hasValue()) {
                    obj = keyframe.getValue();
                }
                stringBuilder.append(obj);
                Log.d(str2, stringBuilder.toString());
            }
        }
    }

    private static PropertyValuesHolder f(TypedArray typedArray, int i, int i2, int i3, String str) {
        TypedValue peekValue = typedArray.peekValue(i2);
        Object obj = peekValue != null ? 1 : null;
        int i4 = obj != null ? peekValue.type : 0;
        TypedValue peekValue2 = typedArray.peekValue(i3);
        Object obj2 = peekValue2 != null ? 1 : null;
        int i5 = obj2 != null ? peekValue2.type : 0;
        if (i == 4) {
            i = ((obj == null || !i(i4)) && (obj2 == null || !i(i5))) ? 0 : 3;
        }
        Object obj3 = i == 0 ? 1 : null;
        PropertyValuesHolder propertyValuesHolder = null;
        PropertyValuesHolder ofObject;
        if (i == 2) {
            String string = typedArray.getString(i2);
            String string2 = typedArray.getString(i3);
            b[] d = h.d(string);
            b[] d2 = h.d(string2);
            if (d == null && d2 == null) {
                return null;
            }
            if (d != null) {
                TypeEvaluator aVar = new a();
                if (d2 == null) {
                    ofObject = PropertyValuesHolder.ofObject(str, aVar, new Object[]{d});
                } else if (h.b(d, d2)) {
                    ofObject = PropertyValuesHolder.ofObject(str, aVar, new Object[]{d, d2});
                } else {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(" Can't morph from ");
                    stringBuilder.append(string);
                    stringBuilder.append(" to ");
                    stringBuilder.append(string2);
                    throw new InflateException(stringBuilder.toString());
                }
                return ofObject;
            } else if (d2 == null) {
                return null;
            } else {
                return PropertyValuesHolder.ofObject(str, new a(), new Object[]{d2});
            }
        }
        TypeEvaluator a = i == 3 ? f.a() : null;
        int dimension;
        if (obj3 != null) {
            float dimension2;
            if (obj != null) {
                float dimension3 = i4 == 5 ? typedArray.getDimension(i2, 0.0f) : typedArray.getFloat(i2, 0.0f);
                if (obj2 != null) {
                    dimension2 = i5 == 5 ? typedArray.getDimension(i3, 0.0f) : typedArray.getFloat(i3, 0.0f);
                    ofObject = PropertyValuesHolder.ofFloat(str, new float[]{dimension3, dimension2});
                } else {
                    ofObject = PropertyValuesHolder.ofFloat(str, new float[]{dimension3});
                }
            } else {
                dimension2 = i5 == 5 ? typedArray.getDimension(i3, 0.0f) : typedArray.getFloat(i3, 0.0f);
                ofObject = PropertyValuesHolder.ofFloat(str, new float[]{dimension2});
            }
            propertyValuesHolder = ofObject;
        } else if (obj != null) {
            i2 = i4 == 5 ? (int) typedArray.getDimension(i2, 0.0f) : i(i4) ? typedArray.getColor(i2, 0) : typedArray.getInt(i2, 0);
            if (obj2 != null) {
                dimension = i5 == 5 ? (int) typedArray.getDimension(i3, 0.0f) : i(i5) ? typedArray.getColor(i3, 0) : typedArray.getInt(i3, 0);
                propertyValuesHolder = PropertyValuesHolder.ofInt(str, new int[]{i2, dimension});
            } else {
                propertyValuesHolder = PropertyValuesHolder.ofInt(str, new int[]{i2});
            }
        } else if (obj2 != null) {
            dimension = i5 == 5 ? (int) typedArray.getDimension(i3, 0.0f) : i(i5) ? typedArray.getColor(i3, 0) : typedArray.getInt(i3, 0);
            propertyValuesHolder = PropertyValuesHolder.ofInt(str, new int[]{dimension});
        }
        if (propertyValuesHolder == null || a == null) {
            return propertyValuesHolder;
        }
        propertyValuesHolder.setEvaluator(a);
        return propertyValuesHolder;
    }

    private static int g(TypedArray typedArray, int i, int i2) {
        TypedValue peekValue = typedArray.peekValue(i);
        Object obj = 1;
        Object obj2 = peekValue != null ? 1 : null;
        i = obj2 != null ? peekValue.type : 0;
        TypedValue peekValue2 = typedArray.peekValue(i2);
        if (peekValue2 == null) {
            obj = null;
        }
        return ((obj2 == null || !i(i)) && (obj == null || !i(obj != null ? peekValue2.type : 0))) ? 0 : 3;
    }

    private static int h(Resources resources, Theme theme, AttributeSet attributeSet, XmlPullParser xmlPullParser) {
        TypedArray s = androidx.core.content.i.h.s(resources, theme, attributeSet, a.g0);
        int i = 0;
        TypedValue t = androidx.core.content.i.h.t(s, xmlPullParser, "value", 0);
        if ((t != null ? 1 : null) != null && i(t.type)) {
            i = 3;
        }
        s.recycle();
        return i;
    }

    private static boolean i(int i) {
        return i >= 28 && i <= 31;
    }

    public static Animator j(Context context, @androidx.annotation.b int i) throws NotFoundException {
        return VERSION.SDK_INT >= 24 ? AnimatorInflater.loadAnimator(context, i) : k(context, context.getResources(), context.getTheme(), i);
    }

    public static Animator k(Context context, Resources resources, Theme theme, @androidx.annotation.b int i) throws NotFoundException {
        return l(context, resources, theme, i, 1.0f);
    }

    public static Animator l(Context context, Resources resources, Theme theme, @androidx.annotation.b int i, float f) throws NotFoundException {
        StringBuilder stringBuilder;
        NotFoundException notFoundException;
        String str = "Can't load animation resource ID #0x";
        XmlResourceParser xmlResourceParser = null;
        try {
            xmlResourceParser = resources.getAnimation(i);
            Animator a = a(context, resources, theme, xmlResourceParser, f);
            if (xmlResourceParser != null) {
                xmlResourceParser.close();
            }
            return a;
        } catch (Throwable e) {
            stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append(Integer.toHexString(i));
            notFoundException = new NotFoundException(stringBuilder.toString());
            notFoundException.initCause(e);
            throw notFoundException;
        } catch (Throwable e2) {
            stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append(Integer.toHexString(i));
            notFoundException = new NotFoundException(stringBuilder.toString());
            notFoundException.initCause(e2);
            throw notFoundException;
        } catch (Throwable th) {
            if (xmlResourceParser != null) {
                xmlResourceParser.close();
            }
        }
    }

    private static ValueAnimator m(Context context, Resources resources, Theme theme, AttributeSet attributeSet, ValueAnimator valueAnimator, float f, XmlPullParser xmlPullParser) throws NotFoundException {
        TypedArray s = androidx.core.content.i.h.s(resources, theme, attributeSet, a.Q);
        TypedArray s2 = androidx.core.content.i.h.s(resources, theme, attributeSet, a.l0);
        if (valueAnimator == null) {
            valueAnimator = new ValueAnimator();
        }
        r(valueAnimator, s, s2, f, xmlPullParser);
        int l = androidx.core.content.i.h.l(s, xmlPullParser, "interpolator", 0, 0);
        if (l > 0) {
            valueAnimator.setInterpolator(d.b(context, l));
        }
        s.recycle();
        if (s2 != null) {
            s2.recycle();
        }
        return valueAnimator;
    }

    private static Keyframe n(Context context, Resources resources, Theme theme, AttributeSet attributeSet, int i, XmlPullParser xmlPullParser) throws XmlPullParserException, IOException {
        TypedArray s = androidx.core.content.i.h.s(resources, theme, attributeSet, a.g0);
        float j = androidx.core.content.i.h.j(s, xmlPullParser, "fraction", 3, -1.0f);
        String str = "value";
        TypedValue t = androidx.core.content.i.h.t(s, xmlPullParser, str, 0);
        Object obj = t != null ? 1 : null;
        if (i == 4) {
            i = (obj == null || !i(t.type)) ? 0 : 3;
        }
        Keyframe ofInt = obj != null ? i != 0 ? (i == 1 || i == 3) ? Keyframe.ofInt(j, androidx.core.content.i.h.k(s, xmlPullParser, str, 0, 0)) : null : Keyframe.ofFloat(j, androidx.core.content.i.h.j(s, xmlPullParser, str, 0, 0.0f)) : i == 0 ? Keyframe.ofFloat(j) : Keyframe.ofInt(j);
        int l = androidx.core.content.i.h.l(s, xmlPullParser, "interpolator", 1, 0);
        if (l > 0) {
            ofInt.setInterpolator(d.b(context, l));
        }
        s.recycle();
        return ofInt;
    }

    private static ObjectAnimator o(Context context, Resources resources, Theme theme, AttributeSet attributeSet, float f, XmlPullParser xmlPullParser) throws NotFoundException {
        ValueAnimator objectAnimator = new ObjectAnimator();
        m(context, resources, theme, attributeSet, objectAnimator, f, xmlPullParser);
        return objectAnimator;
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:17:0x0042  */
    private static android.animation.PropertyValuesHolder p(android.content.Context r9, android.content.res.Resources r10, android.content.res.Resources.Theme r11, org.xmlpull.v1.XmlPullParser r12, java.lang.String r13, int r14) throws org.xmlpull.v1.XmlPullParserException, java.io.IOException {
        /*
        r0 = 0;
        r1 = r0;
    L_0x0002:
        r2 = r12.next();
        r3 = 3;
        if (r2 == r3) goto L_0x0040;
    L_0x0009:
        r4 = 1;
        if (r2 == r4) goto L_0x0040;
    L_0x000c:
        r2 = r12.getName();
        r3 = "keyframe";
        r2 = r2.equals(r3);
        if (r2 == 0) goto L_0x0002;
    L_0x0018:
        r2 = 4;
        if (r14 != r2) goto L_0x0023;
    L_0x001b:
        r14 = android.util.Xml.asAttributeSet(r12);
        r14 = h(r10, r11, r14, r12);
    L_0x0023:
        r5 = android.util.Xml.asAttributeSet(r12);
        r2 = r9;
        r3 = r10;
        r4 = r11;
        r6 = r14;
        r7 = r12;
        r2 = n(r2, r3, r4, r5, r6, r7);
        if (r2 == 0) goto L_0x003c;
    L_0x0032:
        if (r1 != 0) goto L_0x0039;
    L_0x0034:
        r1 = new java.util.ArrayList;
        r1.<init>();
    L_0x0039:
        r1.add(r2);
    L_0x003c:
        r12.next();
        goto L_0x0002;
    L_0x0040:
        if (r1 == 0) goto L_0x00e9;
    L_0x0042:
        r9 = r1.size();
        if (r9 <= 0) goto L_0x00e9;
    L_0x0048:
        r10 = 0;
        r11 = r1.get(r10);
        r11 = (android.animation.Keyframe) r11;
        r12 = r9 + -1;
        r12 = r1.get(r12);
        r12 = (android.animation.Keyframe) r12;
        r0 = r12.getFraction();
        r2 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r4 = 0;
        r5 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1));
        if (r5 >= 0) goto L_0x0077;
    L_0x0062:
        r0 = (r0 > r4 ? 1 : (r0 == r4 ? 0 : -1));
        if (r0 >= 0) goto L_0x006a;
    L_0x0066:
        r12.setFraction(r2);
        goto L_0x0077;
    L_0x006a:
        r0 = r1.size();
        r12 = c(r12, r2);
        r1.add(r0, r12);
        r9 = r9 + 1;
    L_0x0077:
        r12 = r11.getFraction();
        r0 = (r12 > r4 ? 1 : (r12 == r4 ? 0 : -1));
        if (r0 == 0) goto L_0x0090;
    L_0x007f:
        r12 = (r12 > r4 ? 1 : (r12 == r4 ? 0 : -1));
        if (r12 >= 0) goto L_0x0087;
    L_0x0083:
        r11.setFraction(r4);
        goto L_0x0090;
    L_0x0087:
        r11 = c(r11, r4);
        r1.add(r10, r11);
        r9 = r9 + 1;
    L_0x0090:
        r11 = new android.animation.Keyframe[r9];
        r1.toArray(r11);
    L_0x0095:
        if (r10 >= r9) goto L_0x00dc;
    L_0x0097:
        r12 = r11[r10];
        r0 = r12.getFraction();
        r0 = (r0 > r4 ? 1 : (r0 == r4 ? 0 : -1));
        if (r0 >= 0) goto L_0x00d9;
    L_0x00a1:
        if (r10 != 0) goto L_0x00a7;
    L_0x00a3:
        r12.setFraction(r4);
        goto L_0x00d9;
    L_0x00a7:
        r0 = r9 + -1;
        if (r10 != r0) goto L_0x00af;
    L_0x00ab:
        r12.setFraction(r2);
        goto L_0x00d9;
    L_0x00af:
        r12 = r10 + 1;
        r1 = r10;
    L_0x00b2:
        if (r12 >= r0) goto L_0x00c5;
    L_0x00b4:
        r5 = r11[r12];
        r5 = r5.getFraction();
        r5 = (r5 > r4 ? 1 : (r5 == r4 ? 0 : -1));
        if (r5 < 0) goto L_0x00bf;
    L_0x00be:
        goto L_0x00c5;
    L_0x00bf:
        r1 = r12 + 1;
        r8 = r1;
        r1 = r12;
        r12 = r8;
        goto L_0x00b2;
    L_0x00c5:
        r12 = r1 + 1;
        r12 = r11[r12];
        r12 = r12.getFraction();
        r0 = r10 + -1;
        r0 = r11[r0];
        r0 = r0.getFraction();
        r12 = r12 - r0;
        d(r11, r12, r10, r1);
    L_0x00d9:
        r10 = r10 + 1;
        goto L_0x0095;
    L_0x00dc:
        r0 = android.animation.PropertyValuesHolder.ofKeyframe(r13, r11);
        if (r14 != r3) goto L_0x00e9;
    L_0x00e2:
        r9 = b.a0.b.a.f.a();
        r0.setEvaluator(r9);
    L_0x00e9:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.a0.b.a.e.p(android.content.Context, android.content.res.Resources, android.content.res.Resources$Theme, org.xmlpull.v1.XmlPullParser, java.lang.String, int):android.animation.PropertyValuesHolder");
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:21:0x006f  */
    private static android.animation.PropertyValuesHolder[] q(android.content.Context r17, android.content.res.Resources r18, android.content.res.Resources.Theme r19, org.xmlpull.v1.XmlPullParser r20, android.util.AttributeSet r21) throws org.xmlpull.v1.XmlPullParserException, java.io.IOException {
        /*
        r6 = r20;
        r7 = 0;
        r8 = r7;
    L_0x0004:
        r0 = r20.getEventType();
        r9 = 0;
        r1 = 3;
        if (r0 == r1) goto L_0x006d;
    L_0x000c:
        r10 = 1;
        if (r0 == r10) goto L_0x006d;
    L_0x000f:
        r2 = 2;
        if (r0 == r2) goto L_0x0016;
    L_0x0012:
        r20.next();
        goto L_0x0004;
    L_0x0016:
        r0 = r20.getName();
        r3 = "propertyValuesHolder";
        r0 = r0.equals(r3);
        if (r0 == 0) goto L_0x0063;
    L_0x0022:
        r0 = b.a0.b.a.a.b0;
        r11 = r18;
        r12 = r19;
        r13 = r21;
        r14 = androidx.core.content.i.h.s(r11, r12, r13, r0);
        r0 = "propertyName";
        r15 = androidx.core.content.i.h.m(r14, r6, r0, r1);
        r0 = 4;
        r1 = "valueType";
        r5 = androidx.core.content.i.h.k(r14, r6, r1, r2, r0);
        r0 = r17;
        r1 = r18;
        r2 = r19;
        r3 = r20;
        r4 = r15;
        r16 = r5;
        r0 = p(r0, r1, r2, r3, r4, r5);
        if (r0 != 0) goto L_0x0052;
    L_0x004c:
        r1 = r16;
        r0 = f(r14, r1, r9, r10, r15);
    L_0x0052:
        if (r0 == 0) goto L_0x005f;
    L_0x0054:
        if (r8 != 0) goto L_0x005c;
    L_0x0056:
        r1 = new java.util.ArrayList;
        r1.<init>();
        r8 = r1;
    L_0x005c:
        r8.add(r0);
    L_0x005f:
        r14.recycle();
        goto L_0x0069;
    L_0x0063:
        r11 = r18;
        r12 = r19;
        r13 = r21;
    L_0x0069:
        r20.next();
        goto L_0x0004;
    L_0x006d:
        if (r8 == 0) goto L_0x0082;
    L_0x006f:
        r0 = r8.size();
        r7 = new android.animation.PropertyValuesHolder[r0];
    L_0x0075:
        if (r9 >= r0) goto L_0x0082;
    L_0x0077:
        r1 = r8.get(r9);
        r1 = (android.animation.PropertyValuesHolder) r1;
        r7[r9] = r1;
        r9 = r9 + 1;
        goto L_0x0075;
    L_0x0082:
        return r7;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.a0.b.a.e.q(android.content.Context, android.content.res.Resources, android.content.res.Resources$Theme, org.xmlpull.v1.XmlPullParser, android.util.AttributeSet):android.animation.PropertyValuesHolder[]");
    }

    private static void r(ValueAnimator valueAnimator, TypedArray typedArray, TypedArray typedArray2, float f, XmlPullParser xmlPullParser) {
        long k = (long) androidx.core.content.i.h.k(typedArray, xmlPullParser, IronSourceConstants.EVENTS_DURATION, 1, 300);
        long k2 = (long) androidx.core.content.i.h.k(typedArray, xmlPullParser, "startOffset", 2, 0);
        int k3 = androidx.core.content.i.h.k(typedArray, xmlPullParser, "valueType", 7, 4);
        if (androidx.core.content.i.h.r(xmlPullParser, "valueFrom") && androidx.core.content.i.h.r(xmlPullParser, "valueTo")) {
            if (k3 == 4) {
                k3 = g(typedArray, 5, 6);
            }
            if (f(typedArray, k3, 5, 6, "") != null) {
                valueAnimator.setValues(new PropertyValuesHolder[]{f(typedArray, k3, 5, 6, "")});
            }
        }
        valueAnimator.setDuration(k);
        valueAnimator.setStartDelay(k2);
        valueAnimator.setRepeatCount(androidx.core.content.i.h.k(typedArray, xmlPullParser, "repeatCount", 3, 0));
        valueAnimator.setRepeatMode(androidx.core.content.i.h.k(typedArray, xmlPullParser, "repeatMode", 4, 1));
        if (typedArray2 != null) {
            s(valueAnimator, typedArray2, k3, f, xmlPullParser);
        }
    }

    private static void s(ValueAnimator valueAnimator, TypedArray typedArray, int i, float f, XmlPullParser xmlPullParser) {
        ObjectAnimator objectAnimator = (ObjectAnimator) valueAnimator;
        String m = androidx.core.content.i.h.m(typedArray, xmlPullParser, "pathData", 1);
        if (m != null) {
            String m2 = androidx.core.content.i.h.m(typedArray, xmlPullParser, "propertyXName", 2);
            String m3 = androidx.core.content.i.h.m(typedArray, xmlPullParser, "propertyYName", 3);
            if (i != 2) {
            }
            if (m2 == null && m3 == null) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(typedArray.getPositionDescription());
                stringBuilder.append(" propertyXName or propertyYName is needed for PathData");
                throw new InflateException(stringBuilder.toString());
            }
            t(h.e(m), objectAnimator, f * 0.5f, m2, m3);
            return;
        }
        objectAnimator.setPropertyName(androidx.core.content.i.h.m(typedArray, xmlPullParser, "propertyName", 0));
    }

    private static void t(Path path, ObjectAnimator objectAnimator, float f, String str, String str2) {
        float[] fArr;
        Path path2 = path;
        ObjectAnimator objectAnimator2 = objectAnimator;
        String str3 = str;
        String str4 = str2;
        PathMeasure pathMeasure = new PathMeasure(path2, false);
        ArrayList arrayList = new ArrayList();
        float f2 = 0.0f;
        arrayList.add(Float.valueOf(0.0f));
        float f3 = 0.0f;
        do {
            f3 += pathMeasure.getLength();
            arrayList.add(Float.valueOf(f3));
        } while (pathMeasure.nextContour());
        pathMeasure = new PathMeasure(path2, false);
        int min = Math.min(100, ((int) (f3 / f)) + 1);
        float[] fArr2 = new float[min];
        float[] fArr3 = new float[min];
        float[] fArr4 = new float[2];
        f3 /= (float) (min - 1);
        int i = 0;
        int i2 = 0;
        while (true) {
            fArr = null;
            if (i >= min) {
                break;
            }
            pathMeasure.getPosTan(f2 - ((Float) arrayList.get(i2)).floatValue(), fArr4, null);
            fArr2[i] = fArr4[0];
            fArr3[i] = fArr4[1];
            f2 += f3;
            int i3 = i2 + 1;
            if (i3 < arrayList.size() && f2 > ((Float) arrayList.get(i3)).floatValue()) {
                pathMeasure.nextContour();
                i2 = i3;
            }
            i++;
        }
        PropertyValuesHolder ofFloat = str3 != null ? PropertyValuesHolder.ofFloat(str3, fArr2) : null;
        if (str4 != null) {
            fArr = PropertyValuesHolder.ofFloat(str4, fArr3);
        }
        if (ofFloat == null) {
            objectAnimator2.setValues(new PropertyValuesHolder[]{fArr});
        } else if (fArr == null) {
            objectAnimator2.setValues(new PropertyValuesHolder[]{ofFloat});
        } else {
            objectAnimator2.setValues(new PropertyValuesHolder[]{ofFloat, fArr});
        }
    }
}
