package b.a0.b.a;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.AnimatedVectorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.Callback;
import android.graphics.drawable.Drawable.ConstantState;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import androidx.annotation.j0;
import androidx.annotation.k0;
import androidx.annotation.o0;
import androidx.core.content.i.h;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class c extends h implements b {
    private static final String b = "AnimatedVDCompat";
    private static final String c = "animated-vector";
    private static final String d = "target";
    private static final boolean f = false;
    private Context q0;
    private ArgbEvaluator r0;
    private c s;
    d s0;
    private AnimatorListener t0;
    ArrayList<b.a0.b.a.b.a> u0;
    final Callback v0;

    class a implements Callback {
        a() {
        }

        public void invalidateDrawable(Drawable drawable) {
            c.this.invalidateSelf();
        }

        public void scheduleDrawable(Drawable drawable, Runnable runnable, long j) {
            c.this.scheduleSelf(runnable, j);
        }

        public void unscheduleDrawable(Drawable drawable, Runnable runnable) {
            c.this.unscheduleSelf(runnable);
        }
    }

    class b extends AnimatorListenerAdapter {
        b() {
        }

        public void onAnimationEnd(Animator animator) {
            ArrayList arrayList = new ArrayList(c.this.u0);
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                ((b.a0.b.a.b.a) arrayList.get(i)).b(c.this);
            }
        }

        public void onAnimationStart(Animator animator) {
            ArrayList arrayList = new ArrayList(c.this.u0);
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                ((b.a0.b.a.b.a) arrayList.get(i)).c(c.this);
            }
        }
    }

    private static class c extends ConstantState {
        int a;
        i b;
        AnimatorSet c;
        ArrayList<Animator> d;
        b.e.a<Animator, String> e;

        public c(Context context, c cVar, Callback callback, Resources resources) {
            if (cVar != null) {
                this.a = cVar.a;
                i iVar = cVar.b;
                int i = 0;
                if (iVar != null) {
                    ConstantState constantState = iVar.getConstantState();
                    if (resources != null) {
                        this.b = (i) constantState.newDrawable(resources);
                    } else {
                        this.b = (i) constantState.newDrawable();
                    }
                    iVar = (i) this.b.mutate();
                    this.b = iVar;
                    iVar.setCallback(callback);
                    this.b.setBounds(cVar.b.getBounds());
                    this.b.m(false);
                }
                ArrayList arrayList = cVar.d;
                if (arrayList != null) {
                    int size = arrayList.size();
                    this.d = new ArrayList(size);
                    this.e = new b.e.a(size);
                    while (i < size) {
                        Animator animator = (Animator) cVar.d.get(i);
                        Animator clone = animator.clone();
                        String str = (String) cVar.e.get(animator);
                        clone.setTarget(this.b.h(str));
                        this.d.add(clone);
                        this.e.put(clone, str);
                        i++;
                    }
                    a();
                }
            }
        }

        public void a() {
            if (this.c == null) {
                this.c = new AnimatorSet();
            }
            this.c.playTogether(this.d);
        }

        public int getChangingConfigurations() {
            return this.a;
        }

        public Drawable newDrawable() {
            throw new IllegalStateException("No constant state support for SDK < 24.");
        }

        public Drawable newDrawable(Resources resources) {
            throw new IllegalStateException("No constant state support for SDK < 24.");
        }
    }

    @o0(24)
    private static class d extends ConstantState {
        private final ConstantState a;

        public d(ConstantState constantState) {
            this.a = constantState;
        }

        public boolean canApplyTheme() {
            return this.a.canApplyTheme();
        }

        public int getChangingConfigurations() {
            return this.a.getChangingConfigurations();
        }

        public Drawable newDrawable() {
            Drawable cVar = new c();
            Drawable newDrawable = this.a.newDrawable();
            cVar.a = newDrawable;
            newDrawable.setCallback(cVar.v0);
            return cVar;
        }

        public Drawable newDrawable(Resources resources) {
            Drawable cVar = new c();
            Drawable newDrawable = this.a.newDrawable(resources);
            cVar.a = newDrawable;
            newDrawable.setCallback(cVar.v0);
            return cVar;
        }

        public Drawable newDrawable(Resources resources, Theme theme) {
            Drawable cVar = new c();
            Drawable newDrawable = this.a.newDrawable(resources, theme);
            cVar.a = newDrawable;
            newDrawable.setCallback(cVar.v0);
            return cVar;
        }
    }

    c() {
        this(null, null, null);
    }

    private c(@k0 Context context) {
        this(context, null, null);
    }

    private c(@k0 Context context, @k0 c cVar, @k0 Resources resources) {
        this.r0 = null;
        this.t0 = null;
        this.u0 = null;
        Callback aVar = new a();
        this.v0 = aVar;
        this.q0 = context;
        if (cVar != null) {
            this.s = cVar;
        } else {
            this.s = new c(context, cVar, aVar, resources);
        }
    }

    public static void a(Drawable drawable) {
        if (drawable != null && (drawable instanceof Animatable)) {
            if (VERSION.SDK_INT >= 24) {
                ((AnimatedVectorDrawable) drawable).clearAnimationCallbacks();
            } else {
                ((c) drawable).c();
            }
        }
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:15:0x0056 A:{Catch:{ XmlPullParserException -> 0x0063, IOException -> 0x005e }} */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:13:0x0049 A:{Catch:{ XmlPullParserException -> 0x0063, IOException -> 0x005e }} */
    @androidx.annotation.k0
    public static b.a0.b.a.c e(@androidx.annotation.j0 android.content.Context r6, @androidx.annotation.s int r7) {
        /*
        r0 = "parser error";
        r1 = "AnimatedVDCompat";
        r2 = android.os.Build.VERSION.SDK_INT;
        r3 = 24;
        if (r2 < r3) goto L_0x0030;
    L_0x000a:
        r0 = new b.a0.b.a.c;
        r0.<init>(r6);
        r1 = r6.getResources();
        r6 = r6.getTheme();
        r6 = androidx.core.content.i.g.c(r1, r7, r6);
        r0.a = r6;
        r7 = r0.v0;
        r6.setCallback(r7);
        r6 = new b.a0.b.a.c$d;
        r7 = r0.a;
        r7 = r7.getConstantState();
        r6.<init>(r7);
        r0.s0 = r6;
        return r0;
    L_0x0030:
        r2 = r6.getResources();
        r7 = r2.getXml(r7);	 Catch:{ XmlPullParserException -> 0x0063, IOException -> 0x005e }
        r2 = android.util.Xml.asAttributeSet(r7);	 Catch:{ XmlPullParserException -> 0x0063, IOException -> 0x005e }
    L_0x003c:
        r3 = r7.next();	 Catch:{ XmlPullParserException -> 0x0063, IOException -> 0x005e }
        r4 = 2;
        if (r3 == r4) goto L_0x0047;
    L_0x0043:
        r5 = 1;
        if (r3 == r5) goto L_0x0047;
    L_0x0046:
        goto L_0x003c;
    L_0x0047:
        if (r3 != r4) goto L_0x0056;
    L_0x0049:
        r3 = r6.getResources();	 Catch:{ XmlPullParserException -> 0x0063, IOException -> 0x005e }
        r4 = r6.getTheme();	 Catch:{ XmlPullParserException -> 0x0063, IOException -> 0x005e }
        r6 = f(r6, r3, r7, r2, r4);	 Catch:{ XmlPullParserException -> 0x0063, IOException -> 0x005e }
        return r6;
    L_0x0056:
        r6 = new org.xmlpull.v1.XmlPullParserException;	 Catch:{ XmlPullParserException -> 0x0063, IOException -> 0x005e }
        r7 = "No start tag found";
        r6.<init>(r7);	 Catch:{ XmlPullParserException -> 0x0063, IOException -> 0x005e }
        throw r6;	 Catch:{ XmlPullParserException -> 0x0063, IOException -> 0x005e }
    L_0x005e:
        r6 = move-exception;
        android.util.Log.e(r1, r0, r6);
        goto L_0x0067;
    L_0x0063:
        r6 = move-exception;
        android.util.Log.e(r1, r0, r6);
    L_0x0067:
        r6 = 0;
        return r6;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.a0.b.a.c.e(android.content.Context, int):b.a0.b.a.c");
    }

    public static c f(Context context, Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Theme theme) throws XmlPullParserException, IOException {
        c cVar = new c(context);
        cVar.inflate(resources, xmlPullParser, attributeSet, theme);
        return cVar;
    }

    public static void g(Drawable drawable, b.a0.b.a.b.a aVar) {
        if (drawable != null && aVar != null && (drawable instanceof Animatable)) {
            if (VERSION.SDK_INT >= 24) {
                h((AnimatedVectorDrawable) drawable, aVar);
            } else {
                ((c) drawable).b(aVar);
            }
        }
    }

    @o0(23)
    private static void h(@j0 AnimatedVectorDrawable animatedVectorDrawable, @j0 b.a0.b.a.b.a aVar) {
        animatedVectorDrawable.registerAnimationCallback(aVar.a());
    }

    private void i() {
        AnimatorListener animatorListener = this.t0;
        if (animatorListener != null) {
            this.s.c.removeListener(animatorListener);
            this.t0 = null;
        }
    }

    private void j(String str, Animator animator) {
        animator.setTarget(this.s.b.h(str));
        if (VERSION.SDK_INT < 21) {
            k(animator);
        }
        c cVar = this.s;
        if (cVar.d == null) {
            cVar.d = new ArrayList();
            this.s.e = new b.e.a();
        }
        this.s.d.add(animator);
        this.s.e.put(animator, str);
    }

    private void k(Animator animator) {
        if (animator instanceof AnimatorSet) {
            List childAnimations = ((AnimatorSet) animator).getChildAnimations();
            if (childAnimations != null) {
                for (int i = 0; i < childAnimations.size(); i++) {
                    k((Animator) childAnimations.get(i));
                }
            }
        }
        if (animator instanceof ObjectAnimator) {
            ObjectAnimator objectAnimator = (ObjectAnimator) animator;
            String propertyName = objectAnimator.getPropertyName();
            if ("fillColor".equals(propertyName) || "strokeColor".equals(propertyName)) {
                if (this.r0 == null) {
                    this.r0 = new ArgbEvaluator();
                }
                objectAnimator.setEvaluator(this.r0);
            }
        }
    }

    /* DevToolsApp WARNING: Missing block: B:12:0x001f, code:
            return false;
     */
    public static boolean l(android.graphics.drawable.Drawable r2, b.a0.b.a.b.a r3) {
        /*
        r0 = 0;
        if (r2 == 0) goto L_0x001f;
    L_0x0003:
        if (r3 != 0) goto L_0x0006;
    L_0x0005:
        goto L_0x001f;
    L_0x0006:
        r1 = r2 instanceof android.graphics.drawable.Animatable;
        if (r1 != 0) goto L_0x000b;
    L_0x000a:
        return r0;
    L_0x000b:
        r0 = android.os.Build.VERSION.SDK_INT;
        r1 = 24;
        if (r0 < r1) goto L_0x0018;
    L_0x0011:
        r2 = (android.graphics.drawable.AnimatedVectorDrawable) r2;
        r2 = m(r2, r3);
        return r2;
    L_0x0018:
        r2 = (b.a0.b.a.c) r2;
        r2 = r2.d(r3);
        return r2;
    L_0x001f:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.a0.b.a.c.l(android.graphics.drawable.Drawable, b.a0.b.a.b$a):boolean");
    }

    @o0(23)
    private static boolean m(AnimatedVectorDrawable animatedVectorDrawable, b.a0.b.a.b.a aVar) {
        return animatedVectorDrawable.unregisterAnimationCallback(aVar.a());
    }

    public void applyTheme(Theme theme) {
        Drawable drawable = this.a;
        if (drawable != null) {
            androidx.core.graphics.drawable.a.a(drawable, theme);
        }
    }

    public void b(@j0 b.a0.b.a.b.a aVar) {
        Drawable drawable = this.a;
        if (drawable != null) {
            h((AnimatedVectorDrawable) drawable, aVar);
        } else if (aVar != null) {
            if (this.u0 == null) {
                this.u0 = new ArrayList();
            }
            if (!this.u0.contains(aVar)) {
                this.u0.add(aVar);
                if (this.t0 == null) {
                    this.t0 = new b();
                }
                this.s.c.addListener(this.t0);
            }
        }
    }

    public void c() {
        Drawable drawable = this.a;
        if (drawable != null) {
            ((AnimatedVectorDrawable) drawable).clearAnimationCallbacks();
            return;
        }
        i();
        ArrayList arrayList = this.u0;
        if (arrayList != null) {
            arrayList.clear();
        }
    }

    public boolean canApplyTheme() {
        Drawable drawable = this.a;
        return drawable != null ? androidx.core.graphics.drawable.a.b(drawable) : false;
    }

    public boolean d(@j0 b.a0.b.a.b.a aVar) {
        Drawable drawable = this.a;
        if (drawable != null) {
            m((AnimatedVectorDrawable) drawable, aVar);
        }
        ArrayList arrayList = this.u0;
        if (arrayList == null || aVar == null) {
            return false;
        }
        boolean remove = arrayList.remove(aVar);
        if (this.u0.size() == 0) {
            i();
        }
        return remove;
    }

    public void draw(Canvas canvas) {
        Drawable drawable = this.a;
        if (drawable != null) {
            drawable.draw(canvas);
            return;
        }
        this.s.b.draw(canvas);
        if (this.s.c.isStarted()) {
            invalidateSelf();
        }
    }

    public int getAlpha() {
        Drawable drawable = this.a;
        return drawable != null ? androidx.core.graphics.drawable.a.d(drawable) : this.s.b.getAlpha();
    }

    public int getChangingConfigurations() {
        Drawable drawable = this.a;
        return drawable != null ? drawable.getChangingConfigurations() : super.getChangingConfigurations() | this.s.a;
    }

    public ConstantState getConstantState() {
        return (this.a == null || VERSION.SDK_INT < 24) ? null : new d(this.a.getConstantState());
    }

    public int getIntrinsicHeight() {
        Drawable drawable = this.a;
        return drawable != null ? drawable.getIntrinsicHeight() : this.s.b.getIntrinsicHeight();
    }

    public int getIntrinsicWidth() {
        Drawable drawable = this.a;
        return drawable != null ? drawable.getIntrinsicWidth() : this.s.b.getIntrinsicWidth();
    }

    public int getOpacity() {
        Drawable drawable = this.a;
        return drawable != null ? drawable.getOpacity() : this.s.b.getOpacity();
    }

    public void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet) throws XmlPullParserException, IOException {
        inflate(resources, xmlPullParser, attributeSet, null);
    }

    public void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Theme theme) throws XmlPullParserException, IOException {
        Drawable drawable = this.a;
        if (drawable != null) {
            androidx.core.graphics.drawable.a.g(drawable, resources, xmlPullParser, attributeSet, theme);
            return;
        }
        int eventType = xmlPullParser.getEventType();
        int depth = xmlPullParser.getDepth() + 1;
        while (eventType != 1 && (xmlPullParser.getDepth() >= depth || eventType != 3)) {
            if (eventType == 2) {
                String name = xmlPullParser.getName();
                TypedArray s;
                if (c.equals(name)) {
                    s = h.s(resources, theme, attributeSet, a.L);
                    int resourceId = s.getResourceId(0, 0);
                    if (resourceId != 0) {
                        Drawable e = i.e(resources, resourceId, theme);
                        e.m(false);
                        e.setCallback(this.v0);
                        Drawable drawable2 = this.s.b;
                        if (drawable2 != null) {
                            drawable2.setCallback(null);
                        }
                        this.s.b = e;
                    }
                    s.recycle();
                } else if (d.equals(name)) {
                    s = resources.obtainAttributes(attributeSet, a.N);
                    String string = s.getString(0);
                    int resourceId2 = s.getResourceId(1, 0);
                    if (resourceId2 != 0) {
                        Context context = this.q0;
                        if (context != null) {
                            j(string, e.j(context, resourceId2));
                        } else {
                            s.recycle();
                            throw new IllegalStateException("Context can't be null when inflating animators");
                        }
                    }
                    s.recycle();
                } else {
                    continue;
                }
            }
            eventType = xmlPullParser.next();
        }
        this.s.a();
    }

    public boolean isAutoMirrored() {
        Drawable drawable = this.a;
        return drawable != null ? androidx.core.graphics.drawable.a.h(drawable) : this.s.b.isAutoMirrored();
    }

    public boolean isRunning() {
        Drawable drawable = this.a;
        return drawable != null ? ((AnimatedVectorDrawable) drawable).isRunning() : this.s.c.isRunning();
    }

    public boolean isStateful() {
        Drawable drawable = this.a;
        return drawable != null ? drawable.isStateful() : this.s.b.isStateful();
    }

    public Drawable mutate() {
        Drawable drawable = this.a;
        if (drawable != null) {
            drawable.mutate();
        }
        return this;
    }

    protected void onBoundsChange(Rect rect) {
        Drawable drawable = this.a;
        if (drawable != null) {
            drawable.setBounds(rect);
        } else {
            this.s.b.setBounds(rect);
        }
    }

    protected boolean onLevelChange(int i) {
        Drawable drawable = this.a;
        return drawable != null ? drawable.setLevel(i) : this.s.b.setLevel(i);
    }

    protected boolean onStateChange(int[] iArr) {
        Drawable drawable = this.a;
        return drawable != null ? drawable.setState(iArr) : this.s.b.setState(iArr);
    }

    public void setAlpha(int i) {
        Drawable drawable = this.a;
        if (drawable != null) {
            drawable.setAlpha(i);
        } else {
            this.s.b.setAlpha(i);
        }
    }

    public void setAutoMirrored(boolean z) {
        Drawable drawable = this.a;
        if (drawable != null) {
            androidx.core.graphics.drawable.a.j(drawable, z);
        } else {
            this.s.b.setAutoMirrored(z);
        }
    }

    public void setColorFilter(ColorFilter colorFilter) {
        Drawable drawable = this.a;
        if (drawable != null) {
            drawable.setColorFilter(colorFilter);
        } else {
            this.s.b.setColorFilter(colorFilter);
        }
    }

    public void setTint(int i) {
        Drawable drawable = this.a;
        if (drawable != null) {
            androidx.core.graphics.drawable.a.n(drawable, i);
        } else {
            this.s.b.setTint(i);
        }
    }

    public void setTintList(ColorStateList colorStateList) {
        Drawable drawable = this.a;
        if (drawable != null) {
            androidx.core.graphics.drawable.a.o(drawable, colorStateList);
        } else {
            this.s.b.setTintList(colorStateList);
        }
    }

    public void setTintMode(Mode mode) {
        Drawable drawable = this.a;
        if (drawable != null) {
            androidx.core.graphics.drawable.a.p(drawable, mode);
        } else {
            this.s.b.setTintMode(mode);
        }
    }

    public boolean setVisible(boolean z, boolean z2) {
        Drawable drawable = this.a;
        if (drawable != null) {
            return drawable.setVisible(z, z2);
        }
        this.s.b.setVisible(z, z2);
        return super.setVisible(z, z2);
    }

    public void start() {
        Drawable drawable = this.a;
        if (drawable != null) {
            ((AnimatedVectorDrawable) drawable).start();
        } else if (!this.s.c.isStarted()) {
            this.s.c.start();
            invalidateSelf();
        }
    }

    public void stop() {
        Drawable drawable = this.a;
        if (drawable != null) {
            ((AnimatedVectorDrawable) drawable).stop();
        } else {
            this.s.c.end();
        }
    }
}
