package b.a0.b.a;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.util.AttributeSet;
import android.view.InflateException;
import android.view.animation.Interpolator;
import androidx.annotation.r0;
import androidx.annotation.r0.a;
import androidx.core.content.i.h;
import org.xmlpull.v1.XmlPullParser;

@r0({a.b})
public class g implements Interpolator {
    private static final float a = 0.002f;
    public static final int b = 3000;
    public static final double c = 1.0E-5d;
    private float[] d;
    private float[] e;

    public g(Context context, AttributeSet attributeSet, XmlPullParser xmlPullParser) {
        this(context.getResources(), context.getTheme(), attributeSet, xmlPullParser);
    }

    public g(Resources resources, Theme theme, AttributeSet attributeSet, XmlPullParser xmlPullParser) {
        TypedArray s = h.s(resources, theme, attributeSet, a.q0);
        d(s, xmlPullParser);
        s.recycle();
    }

    private void a(float f, float f2, float f3, float f4) {
        Path path = new Path();
        path.moveTo(0.0f, 0.0f);
        path.cubicTo(f, f2, f3, f4, 1.0f, 1.0f);
        b(path);
    }

    private void b(Path path) {
        int i = 0;
        PathMeasure pathMeasure = new PathMeasure(path, false);
        float length = pathMeasure.getLength();
        int min = Math.min(b, ((int) (length / a)) + 1);
        if (min > 0) {
            int i2;
            StringBuilder stringBuilder;
            this.d = new float[min];
            this.e = new float[min];
            float[] fArr = new float[2];
            for (i2 = 0; i2 < min; i2++) {
                pathMeasure.getPosTan((((float) i2) * length) / ((float) (min - 1)), fArr, null);
                this.d[i2] = fArr[0];
                this.e[i2] = fArr[1];
            }
            if (((double) Math.abs(this.d[0])) <= 1.0E-5d && ((double) Math.abs(this.e[0])) <= 1.0E-5d) {
                int i3 = min - 1;
                if (((double) Math.abs(this.d[i3] - 1.0f)) <= 1.0E-5d && ((double) Math.abs(this.e[i3] - 1.0f)) <= 1.0E-5d) {
                    length = 0.0f;
                    int i4 = 0;
                    while (i < min) {
                        fArr = this.d;
                        i2 = i4 + 1;
                        float f = fArr[i4];
                        if (f >= length) {
                            fArr[i] = f;
                            i++;
                            length = f;
                            i4 = i2;
                        } else {
                            stringBuilder = new StringBuilder();
                            stringBuilder.append("The Path cannot loop back on itself, x :");
                            stringBuilder.append(f);
                            throw new IllegalArgumentException(stringBuilder.toString());
                        }
                    }
                    if (pathMeasure.nextContour()) {
                        throw new IllegalArgumentException("The Path should be continuous, can't have 2+ contours");
                    }
                    return;
                }
            }
            stringBuilder = new StringBuilder();
            stringBuilder.append("The Path must start at (0,0) and end at (1,1) start: ");
            stringBuilder.append(this.d[0]);
            String str = ",";
            stringBuilder.append(str);
            stringBuilder.append(this.e[0]);
            stringBuilder.append(" end:");
            min--;
            stringBuilder.append(this.d[min]);
            stringBuilder.append(str);
            stringBuilder.append(this.e[min]);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("The Path has a invalid length ");
        stringBuilder2.append(length);
        throw new IllegalArgumentException(stringBuilder2.toString());
    }

    private void c(float f, float f2) {
        Path path = new Path();
        path.moveTo(0.0f, 0.0f);
        path.quadTo(f, f2, 1.0f, 1.0f);
        b(path);
    }

    private void d(TypedArray typedArray, XmlPullParser xmlPullParser) {
        String str = "pathData";
        if (h.r(xmlPullParser, str)) {
            String m = h.m(typedArray, xmlPullParser, str, 4);
            Path e = b.h.d.h.e(m);
            if (e != null) {
                b(e);
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("The path is null, which is created from ");
            stringBuilder.append(m);
            throw new InflateException(stringBuilder.toString());
        }
        str = "controlX1";
        if (h.r(xmlPullParser, str)) {
            String str2 = "controlY1";
            if (h.r(xmlPullParser, str2)) {
                float j = h.j(typedArray, xmlPullParser, str, 0, 0.0f);
                float j2 = h.j(typedArray, xmlPullParser, str2, 1, 0.0f);
                String str3 = "controlX2";
                boolean r = h.r(xmlPullParser, str3);
                String str4 = "controlY2";
                if (r != h.r(xmlPullParser, str4)) {
                    throw new InflateException("pathInterpolator requires both controlX2 and controlY2 for cubic Beziers.");
                } else if (r) {
                    a(j, j2, h.j(typedArray, xmlPullParser, str3, 2, 0.0f), h.j(typedArray, xmlPullParser, str4, 3, 0.0f));
                    return;
                } else {
                    c(j, j2);
                    return;
                }
            }
            throw new InflateException("pathInterpolator requires the controlY1 attribute");
        }
        throw new InflateException("pathInterpolator requires the controlX1 attribute");
    }

    public float getInterpolation(float f) {
        if (f <= 0.0f) {
            return 0.0f;
        }
        if (f >= 1.0f) {
            return 1.0f;
        }
        int i = 0;
        int length = this.d.length - 1;
        while (length - i > 1) {
            int i2 = (i + length) / 2;
            if (f < this.d[i2]) {
                length = i2;
            } else {
                i = i2;
            }
        }
        float[] fArr = this.d;
        float f2 = fArr[length] - fArr[i];
        if (f2 == 0.0f) {
            return this.e[i];
        }
        f = (f - fArr[i]) / f2;
        float[] fArr2 = this.e;
        float f3 = fArr2[i];
        return f3 + (f * (fArr2[length] - f3));
    }
}
