package b.a0.b.a;

import android.graphics.drawable.Animatable;
import android.graphics.drawable.Animatable2.AnimationCallback;
import android.graphics.drawable.Drawable;
import androidx.annotation.j0;
import androidx.annotation.o0;

public interface b extends Animatable {

    public static abstract class a {
        AnimationCallback a;

        class a extends AnimationCallback {
            a() {
            }

            public void onAnimationEnd(Drawable drawable) {
                a.this.b(drawable);
            }

            public void onAnimationStart(Drawable drawable) {
                a.this.c(drawable);
            }
        }

        @o0(23)
        AnimationCallback a() {
            if (this.a == null) {
                this.a = new a();
            }
            return this.a;
        }

        public void b(Drawable drawable) {
        }

        public void c(Drawable drawable) {
        }
    }

    void b(@j0 a aVar);

    void c();

    boolean d(@j0 a aVar);
}
