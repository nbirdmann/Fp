package b.a0.b.a;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Paint.Cap;
import android.graphics.Paint.Join;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.Path.FillType;
import android.graphics.PathMeasure;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.ConstantState;
import android.graphics.drawable.VectorDrawable;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.util.Log;
import androidx.annotation.j0;
import androidx.annotation.l;
import androidx.annotation.o0;
import androidx.annotation.r0;
import b.h.o.f0;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class i extends h {
    static final String b = "VectorDrawableCompat";
    static final Mode c = Mode.SRC_IN;
    private static final String d = "clip-path";
    private static final String f = "group";
    private static final String q0 = "vector";
    private static final int r0 = 0;
    private static final String s = "path";
    private static final int s0 = 1;
    private static final int t0 = 2;
    private static final int u0 = 0;
    private static final int v0 = 1;
    private static final int w0 = 2;
    private static final int x0 = 2048;
    private static final boolean y0 = false;
    private PorterDuffColorFilter A0;
    private ColorFilter B0;
    private boolean C0;
    private boolean D0;
    private ConstantState E0;
    private final float[] F0;
    private final Matrix G0;
    private final Rect H0;
    private h z0;

    private static abstract class e {
        private e() {
        }

        public boolean a() {
            return false;
        }

        public boolean b(int[] iArr) {
            return false;
        }
    }

    private static abstract class f extends e {
        protected b.h.d.h.b[] a = null;
        String b;
        int c;

        public f() {
            super();
        }

        public f(f fVar) {
            super();
            this.b = fVar.b;
            this.c = fVar.c;
            this.a = b.h.d.h.f(fVar.a);
        }

        public void c(Theme theme) {
        }

        public boolean d() {
            return false;
        }

        public boolean e() {
            return false;
        }

        public String f(b.h.d.h.b[] bVarArr) {
            String str = " ";
            for (int i = 0; i < bVarArr.length; i++) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(str);
                stringBuilder.append(bVarArr[i].a);
                stringBuilder.append(":");
                str = stringBuilder.toString();
                float[] fArr = bVarArr[i].b;
                for (float append : fArr) {
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(str);
                    stringBuilder2.append(append);
                    stringBuilder2.append(",");
                    str = stringBuilder2.toString();
                }
            }
            return str;
        }

        public void g(int i) {
            String str = "";
            for (int i2 = 0; i2 < i; i2++) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(str);
                stringBuilder.append("    ");
                str = stringBuilder.toString();
            }
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(str);
            stringBuilder2.append("current path is :");
            stringBuilder2.append(this.b);
            stringBuilder2.append(" pathData is ");
            stringBuilder2.append(f(this.a));
            Log.v(i.b, stringBuilder2.toString());
        }

        public b.h.d.h.b[] getPathData() {
            return this.a;
        }

        public String getPathName() {
            return this.b;
        }

        public void h(Path path) {
            path.reset();
            b.h.d.h.b[] bVarArr = this.a;
            if (bVarArr != null) {
                b.h.d.h.b.e(bVarArr, path);
            }
        }

        public void setPathData(b.h.d.h.b[] bVarArr) {
            if (b.h.d.h.b(this.a, bVarArr)) {
                b.h.d.h.k(this.a, bVarArr);
            } else {
                this.a = b.h.d.h.f(bVarArr);
            }
        }
    }

    private static class b extends f {
        public b(b bVar) {
            super(bVar);
        }

        private void j(TypedArray typedArray) {
            String string = typedArray.getString(0);
            if (string != null) {
                this.b = string;
            }
            String string2 = typedArray.getString(1);
            if (string2 != null) {
                this.a = b.h.d.h.d(string2);
            }
        }

        public boolean e() {
            return true;
        }

        public void i(Resources resources, AttributeSet attributeSet, Theme theme, XmlPullParser xmlPullParser) {
            if (androidx.core.content.i.h.r(xmlPullParser, "pathData")) {
                TypedArray s = androidx.core.content.i.h.s(resources, theme, attributeSet, a.I);
                j(s);
                s.recycle();
            }
        }
    }

    private static class c extends f {
        private static final int d = 0;
        private int[] e;
        androidx.core.content.i.b f;
        float g = 0.0f;
        androidx.core.content.i.b h;
        float i = 1.0f;
        int j = 0;
        float k = 1.0f;
        float l = 0.0f;
        float m = 1.0f;
        float n = 0.0f;
        Cap o = Cap.BUTT;
        Join p = Join.MITER;
        float q = 4.0f;

        public c(c cVar) {
            super(cVar);
            this.e = cVar.e;
            this.f = cVar.f;
            this.g = cVar.g;
            this.i = cVar.i;
            this.h = cVar.h;
            this.j = cVar.j;
            this.k = cVar.k;
            this.l = cVar.l;
            this.m = cVar.m;
            this.n = cVar.n;
            this.o = cVar.o;
            this.p = cVar.p;
            this.q = cVar.q;
        }

        private Cap i(int i, Cap cap) {
            return i != 0 ? i != 1 ? i != 2 ? cap : Cap.SQUARE : Cap.ROUND : Cap.BUTT;
        }

        private Join j(int i, Join join) {
            return i != 0 ? i != 1 ? i != 2 ? join : Join.BEVEL : Join.ROUND : Join.MITER;
        }

        private void l(TypedArray typedArray, XmlPullParser xmlPullParser, Theme theme) {
            this.e = null;
            if (androidx.core.content.i.h.r(xmlPullParser, "pathData")) {
                String string = typedArray.getString(0);
                if (string != null) {
                    this.b = string;
                }
                string = typedArray.getString(2);
                if (string != null) {
                    this.a = b.h.d.h.d(string);
                }
                Theme theme2 = theme;
                this.h = androidx.core.content.i.h.i(typedArray, xmlPullParser, theme2, "fillColor", 1, 0);
                this.k = androidx.core.content.i.h.j(typedArray, xmlPullParser, "fillAlpha", 12, this.k);
                this.o = i(androidx.core.content.i.h.k(typedArray, xmlPullParser, "strokeLineCap", 8, -1), this.o);
                this.p = j(androidx.core.content.i.h.k(typedArray, xmlPullParser, "strokeLineJoin", 9, -1), this.p);
                this.q = androidx.core.content.i.h.j(typedArray, xmlPullParser, "strokeMiterLimit", 10, this.q);
                this.f = androidx.core.content.i.h.i(typedArray, xmlPullParser, theme2, "strokeColor", 3, 0);
                this.i = androidx.core.content.i.h.j(typedArray, xmlPullParser, "strokeAlpha", 11, this.i);
                this.g = androidx.core.content.i.h.j(typedArray, xmlPullParser, "strokeWidth", 4, this.g);
                this.m = androidx.core.content.i.h.j(typedArray, xmlPullParser, "trimPathEnd", 6, this.m);
                this.n = androidx.core.content.i.h.j(typedArray, xmlPullParser, "trimPathOffset", 7, this.n);
                this.l = androidx.core.content.i.h.j(typedArray, xmlPullParser, "trimPathStart", 5, this.l);
                this.j = androidx.core.content.i.h.k(typedArray, xmlPullParser, "fillType", 13, this.j);
            }
        }

        public boolean a() {
            return this.h.i() || this.f.i();
        }

        public boolean b(int[] iArr) {
            return this.f.j(iArr) | this.h.j(iArr);
        }

        public void c(Theme theme) {
            if (this.e == null) {
            }
        }

        public boolean d() {
            return this.e != null;
        }

        float getFillAlpha() {
            return this.k;
        }

        @l
        int getFillColor() {
            return this.h.e();
        }

        float getStrokeAlpha() {
            return this.i;
        }

        @l
        int getStrokeColor() {
            return this.f.e();
        }

        float getStrokeWidth() {
            return this.g;
        }

        float getTrimPathEnd() {
            return this.m;
        }

        float getTrimPathOffset() {
            return this.n;
        }

        float getTrimPathStart() {
            return this.l;
        }

        public void k(Resources resources, AttributeSet attributeSet, Theme theme, XmlPullParser xmlPullParser) {
            TypedArray s = androidx.core.content.i.h.s(resources, theme, attributeSet, a.t);
            l(s, xmlPullParser, theme);
            s.recycle();
        }

        void setFillAlpha(float f) {
            this.k = f;
        }

        void setFillColor(int i) {
            this.h.k(i);
        }

        void setStrokeAlpha(float f) {
            this.i = f;
        }

        void setStrokeColor(int i) {
            this.f.k(i);
        }

        void setStrokeWidth(float f) {
            this.g = f;
        }

        void setTrimPathEnd(float f) {
            this.m = f;
        }

        void setTrimPathOffset(float f) {
            this.n = f;
        }

        void setTrimPathStart(float f) {
            this.l = f;
        }
    }

    private static class d extends e {
        final Matrix a;
        final ArrayList<e> b;
        float c;
        private float d;
        private float e;
        private float f;
        private float g;
        private float h;
        private float i;
        final Matrix j;
        int k;
        private int[] l;
        private String m;

        public d() {
            super();
            this.a = new Matrix();
            this.b = new ArrayList();
            this.c = 0.0f;
            this.d = 0.0f;
            this.e = 0.0f;
            this.f = 1.0f;
            this.g = 1.0f;
            this.h = 0.0f;
            this.i = 0.0f;
            this.j = new Matrix();
            this.m = null;
        }

        public d(d dVar, b.e.a<String, Object> aVar) {
            super();
            this.a = new Matrix();
            this.b = new ArrayList();
            this.c = 0.0f;
            this.d = 0.0f;
            this.e = 0.0f;
            this.f = 1.0f;
            this.g = 1.0f;
            this.h = 0.0f;
            this.i = 0.0f;
            Matrix matrix = new Matrix();
            this.j = matrix;
            this.m = null;
            this.c = dVar.c;
            this.d = dVar.d;
            this.e = dVar.e;
            this.f = dVar.f;
            this.g = dVar.g;
            this.h = dVar.h;
            this.i = dVar.i;
            this.l = dVar.l;
            String str = dVar.m;
            this.m = str;
            this.k = dVar.k;
            if (str != null) {
                aVar.put(str, this);
            }
            matrix.set(dVar.j);
            ArrayList arrayList = dVar.b;
            for (int i = 0; i < arrayList.size(); i++) {
                Object obj = arrayList.get(i);
                if (obj instanceof d) {
                    this.b.add(new d((d) obj, aVar));
                } else {
                    f cVar;
                    if (obj instanceof c) {
                        cVar = new c((c) obj);
                    } else if (obj instanceof b) {
                        cVar = new b((b) obj);
                    } else {
                        throw new IllegalStateException("Unknown object in the tree!");
                    }
                    this.b.add(cVar);
                    String str2 = cVar.b;
                    if (str2 != null) {
                        aVar.put(str2, cVar);
                    }
                }
            }
        }

        private void d() {
            this.j.reset();
            this.j.postTranslate(-this.d, -this.e);
            this.j.postScale(this.f, this.g);
            this.j.postRotate(this.c, 0.0f, 0.0f);
            this.j.postTranslate(this.h + this.d, this.i + this.e);
        }

        private void e(TypedArray typedArray, XmlPullParser xmlPullParser) {
            this.l = null;
            this.c = androidx.core.content.i.h.j(typedArray, xmlPullParser, "rotation", 5, this.c);
            this.d = typedArray.getFloat(1, this.d);
            this.e = typedArray.getFloat(2, this.e);
            this.f = androidx.core.content.i.h.j(typedArray, xmlPullParser, "scaleX", 3, this.f);
            this.g = androidx.core.content.i.h.j(typedArray, xmlPullParser, "scaleY", 4, this.g);
            this.h = androidx.core.content.i.h.j(typedArray, xmlPullParser, "translateX", 6, this.h);
            this.i = androidx.core.content.i.h.j(typedArray, xmlPullParser, "translateY", 7, this.i);
            String string = typedArray.getString(0);
            if (string != null) {
                this.m = string;
            }
            d();
        }

        public boolean a() {
            for (int i = 0; i < this.b.size(); i++) {
                if (((e) this.b.get(i)).a()) {
                    return true;
                }
            }
            return false;
        }

        public boolean b(int[] iArr) {
            boolean z = false;
            for (int i = 0; i < this.b.size(); i++) {
                z |= ((e) this.b.get(i)).b(iArr);
            }
            return z;
        }

        public void c(Resources resources, AttributeSet attributeSet, Theme theme, XmlPullParser xmlPullParser) {
            TypedArray s = androidx.core.content.i.h.s(resources, theme, attributeSet, a.k);
            e(s, xmlPullParser);
            s.recycle();
        }

        public String getGroupName() {
            return this.m;
        }

        public Matrix getLocalMatrix() {
            return this.j;
        }

        public float getPivotX() {
            return this.d;
        }

        public float getPivotY() {
            return this.e;
        }

        public float getRotation() {
            return this.c;
        }

        public float getScaleX() {
            return this.f;
        }

        public float getScaleY() {
            return this.g;
        }

        public float getTranslateX() {
            return this.h;
        }

        public float getTranslateY() {
            return this.i;
        }

        public void setPivotX(float f) {
            if (f != this.d) {
                this.d = f;
                d();
            }
        }

        public void setPivotY(float f) {
            if (f != this.e) {
                this.e = f;
                d();
            }
        }

        public void setRotation(float f) {
            if (f != this.c) {
                this.c = f;
                d();
            }
        }

        public void setScaleX(float f) {
            if (f != this.f) {
                this.f = f;
                d();
            }
        }

        public void setScaleY(float f) {
            if (f != this.g) {
                this.g = f;
                d();
            }
        }

        public void setTranslateX(float f) {
            if (f != this.h) {
                this.h = f;
                d();
            }
        }

        public void setTranslateY(float f) {
            if (f != this.i) {
                this.i = f;
                d();
            }
        }
    }

    private static class g {
        private static final Matrix a = new Matrix();
        private final Path b;
        private final Path c;
        private final Matrix d;
        Paint e;
        Paint f;
        private PathMeasure g;
        private int h;
        final d i;
        float j;
        float k;
        float l;
        float m;
        int n;
        String o;
        Boolean p;
        final b.e.a<String, Object> q;

        public g() {
            this.d = new Matrix();
            this.j = 0.0f;
            this.k = 0.0f;
            this.l = 0.0f;
            this.m = 0.0f;
            this.n = 255;
            this.o = null;
            this.p = null;
            this.q = new b.e.a();
            this.i = new d();
            this.b = new Path();
            this.c = new Path();
        }

        public g(g gVar) {
            this.d = new Matrix();
            this.j = 0.0f;
            this.k = 0.0f;
            this.l = 0.0f;
            this.m = 0.0f;
            this.n = 255;
            this.o = null;
            this.p = null;
            b.e.i aVar = new b.e.a();
            this.q = aVar;
            this.i = new d(gVar.i, aVar);
            this.b = new Path(gVar.b);
            this.c = new Path(gVar.c);
            this.j = gVar.j;
            this.k = gVar.k;
            this.l = gVar.l;
            this.m = gVar.m;
            this.h = gVar.h;
            this.n = gVar.n;
            this.o = gVar.o;
            String str = gVar.o;
            if (str != null) {
                aVar.put(str, this);
            }
            this.p = gVar.p;
        }

        private static float a(float f, float f2, float f3, float f4) {
            return (f * f4) - (f2 * f3);
        }

        private void c(d dVar, Matrix matrix, Canvas canvas, int i, int i2, ColorFilter colorFilter) {
            dVar.a.set(matrix);
            dVar.a.preConcat(dVar.j);
            canvas.save();
            for (int i3 = 0; i3 < dVar.b.size(); i3++) {
                e eVar = (e) dVar.b.get(i3);
                if (eVar instanceof d) {
                    c((d) eVar, dVar.a, canvas, i, i2, colorFilter);
                } else if (eVar instanceof f) {
                    d(dVar, (f) eVar, canvas, i, i2, colorFilter);
                }
            }
            canvas.restore();
        }

        private void d(d dVar, f fVar, Canvas canvas, int i, int i2, ColorFilter colorFilter) {
            float f = ((float) i) / this.l;
            float f2 = ((float) i2) / this.m;
            float min = Math.min(f, f2);
            Matrix matrix = dVar.a;
            this.d.set(matrix);
            this.d.postScale(f, f2);
            float e = e(matrix);
            if (e != 0.0f) {
                fVar.h(this.b);
                Path path = this.b;
                this.c.reset();
                if (fVar.e()) {
                    this.c.addPath(path, this.d);
                    canvas.clipPath(this.c);
                } else {
                    androidx.core.content.i.b bVar;
                    Paint paint;
                    Shader f3;
                    c cVar = (c) fVar;
                    float f4 = cVar.l;
                    if (!(f4 == 0.0f && cVar.m == 1.0f)) {
                        float f5 = cVar.n;
                        f4 = (f4 + f5) % 1.0f;
                        float f6 = (cVar.m + f5) % 1.0f;
                        if (this.g == null) {
                            this.g = new PathMeasure();
                        }
                        this.g.setPath(this.b, false);
                        float length = this.g.getLength();
                        f4 *= length;
                        f6 *= length;
                        path.reset();
                        if (f4 > f6) {
                            this.g.getSegment(f4, length, path, true);
                            this.g.getSegment(0.0f, f6, path, true);
                        } else {
                            this.g.getSegment(f4, f6, path, true);
                        }
                        path.rLineTo(0.0f, 0.0f);
                    }
                    this.c.addPath(path, this.d);
                    if (cVar.h.l()) {
                        bVar = cVar.h;
                        if (this.f == null) {
                            paint = new Paint(1);
                            this.f = paint;
                            paint.setStyle(Style.FILL);
                        }
                        paint = this.f;
                        if (bVar.h()) {
                            f3 = bVar.f();
                            f3.setLocalMatrix(this.d);
                            paint.setShader(f3);
                            paint.setAlpha(Math.round(cVar.k * 255.0f));
                        } else {
                            paint.setShader(null);
                            paint.setAlpha(255);
                            paint.setColor(i.a(bVar.e(), cVar.k));
                        }
                        paint.setColorFilter(colorFilter);
                        this.c.setFillType(cVar.j == 0 ? FillType.WINDING : FillType.EVEN_ODD);
                        canvas.drawPath(this.c, paint);
                    }
                    if (cVar.f.l()) {
                        bVar = cVar.f;
                        if (this.e == null) {
                            paint = new Paint(1);
                            this.e = paint;
                            paint.setStyle(Style.STROKE);
                        }
                        Paint paint2 = this.e;
                        Join join = cVar.p;
                        if (join != null) {
                            paint2.setStrokeJoin(join);
                        }
                        Cap cap = cVar.o;
                        if (cap != null) {
                            paint2.setStrokeCap(cap);
                        }
                        paint2.setStrokeMiter(cVar.q);
                        if (bVar.h()) {
                            f3 = bVar.f();
                            f3.setLocalMatrix(this.d);
                            paint2.setShader(f3);
                            paint2.setAlpha(Math.round(cVar.i * 255.0f));
                        } else {
                            paint2.setShader(null);
                            paint2.setAlpha(255);
                            paint2.setColor(i.a(bVar.e(), cVar.i));
                        }
                        paint2.setColorFilter(colorFilter);
                        paint2.setStrokeWidth(cVar.g * (min * e));
                        canvas.drawPath(this.c, paint2);
                    }
                }
            }
        }

        private float e(Matrix matrix) {
            float[] fArr = new float[]{0.0f, 1.0f, 1.0f, 0.0f};
            matrix.mapVectors(fArr);
            float hypot = (float) Math.hypot((double) fArr[0], (double) fArr[1]);
            float hypot2 = (float) Math.hypot((double) fArr[2], (double) fArr[3]);
            float a = a(fArr[0], fArr[1], fArr[2], fArr[3]);
            float max = Math.max(hypot, hypot2);
            return max > 0.0f ? Math.abs(a) / max : 0.0f;
        }

        public void b(Canvas canvas, int i, int i2, ColorFilter colorFilter) {
            c(this.i, a, canvas, i, i2, colorFilter);
        }

        public boolean f() {
            if (this.p == null) {
                this.p = Boolean.valueOf(this.i.a());
            }
            return this.p.booleanValue();
        }

        public boolean g(int[] iArr) {
            return this.i.b(iArr);
        }

        public float getAlpha() {
            return ((float) getRootAlpha()) / 255.0f;
        }

        public int getRootAlpha() {
            return this.n;
        }

        public void setAlpha(float f) {
            setRootAlpha((int) (f * 255.0f));
        }

        public void setRootAlpha(int i) {
            this.n = i;
        }
    }

    private static class h extends ConstantState {
        int a;
        g b;
        ColorStateList c;
        Mode d;
        boolean e;
        Bitmap f;
        int[] g;
        ColorStateList h;
        Mode i;
        int j;
        boolean k;
        boolean l;
        Paint m;

        public h() {
            this.c = null;
            this.d = i.c;
            this.b = new g();
        }

        public h(h hVar) {
            this.c = null;
            this.d = i.c;
            if (hVar != null) {
                this.a = hVar.a;
                g gVar = new g(hVar.b);
                this.b = gVar;
                if (hVar.b.f != null) {
                    gVar.f = new Paint(hVar.b.f);
                }
                if (hVar.b.e != null) {
                    this.b.e = new Paint(hVar.b.e);
                }
                this.c = hVar.c;
                this.d = hVar.d;
                this.e = hVar.e;
            }
        }

        public boolean a(int i, int i2) {
            return i == this.f.getWidth() && i2 == this.f.getHeight();
        }

        public boolean b() {
            return !this.l && this.h == this.c && this.i == this.d && this.k == this.e && this.j == this.b.getRootAlpha();
        }

        public void c(int i, int i2) {
            if (this.f == null || !a(i, i2)) {
                this.f = Bitmap.createBitmap(i, i2, Config.ARGB_8888);
                this.l = true;
            }
        }

        public void d(Canvas canvas, ColorFilter colorFilter, Rect rect) {
            canvas.drawBitmap(this.f, null, rect, e(colorFilter));
        }

        public Paint e(ColorFilter colorFilter) {
            if (!f() && colorFilter == null) {
                return null;
            }
            if (this.m == null) {
                Paint paint = new Paint();
                this.m = paint;
                paint.setFilterBitmap(true);
            }
            this.m.setAlpha(this.b.getRootAlpha());
            this.m.setColorFilter(colorFilter);
            return this.m;
        }

        public boolean f() {
            return this.b.getRootAlpha() < 255;
        }

        public boolean g() {
            return this.b.f();
        }

        public int getChangingConfigurations() {
            return this.a;
        }

        public boolean h(int[] iArr) {
            boolean g = this.b.g(iArr);
            this.l |= g;
            return g;
        }

        public void i() {
            this.h = this.c;
            this.i = this.d;
            this.j = this.b.getRootAlpha();
            this.k = this.e;
            this.l = false;
        }

        public void j(int i, int i2) {
            this.f.eraseColor(0);
            this.b.b(new Canvas(this.f), i, i2, null);
        }

        @j0
        public Drawable newDrawable() {
            return new i(this);
        }

        @j0
        public Drawable newDrawable(Resources resources) {
            return new i(this);
        }
    }

    @o0(24)
    private static class i extends ConstantState {
        private final ConstantState a;

        public i(ConstantState constantState) {
            this.a = constantState;
        }

        public boolean canApplyTheme() {
            return this.a.canApplyTheme();
        }

        public int getChangingConfigurations() {
            return this.a.getChangingConfigurations();
        }

        public Drawable newDrawable() {
            Drawable iVar = new i();
            iVar.a = (VectorDrawable) this.a.newDrawable();
            return iVar;
        }

        public Drawable newDrawable(Resources resources) {
            Drawable iVar = new i();
            iVar.a = (VectorDrawable) this.a.newDrawable(resources);
            return iVar;
        }

        public Drawable newDrawable(Resources resources, Theme theme) {
            Drawable iVar = new i();
            iVar.a = (VectorDrawable) this.a.newDrawable(resources, theme);
            return iVar;
        }
    }

    i() {
        this.D0 = true;
        this.F0 = new float[9];
        this.G0 = new Matrix();
        this.H0 = new Rect();
        this.z0 = new h();
    }

    i(@j0 h hVar) {
        this.D0 = true;
        this.F0 = new float[9];
        this.G0 = new Matrix();
        this.H0 = new Rect();
        this.z0 = hVar;
        this.A0 = o(this.A0, hVar.c, hVar.d);
    }

    static int a(int i, float f) {
        return (i & f0.s) | (((int) (((float) Color.alpha(i)) * f)) << 24);
    }

    /* DevToolsApp WARNING: Removed duplicated region for block: B:14:0x003d A:{Catch:{ XmlPullParserException -> 0x004a, IOException -> 0x0045 }} */
    /* DevToolsApp WARNING: Removed duplicated region for block: B:12:0x0038 A:{Catch:{ XmlPullParserException -> 0x004a, IOException -> 0x0045 }} */
    @androidx.annotation.k0
    public static b.a0.b.a.i e(@androidx.annotation.j0 android.content.res.Resources r6, @androidx.annotation.s int r7, @androidx.annotation.k0 android.content.res.Resources.Theme r8) {
        /*
        r0 = "parser error";
        r1 = "VectorDrawableCompat";
        r2 = android.os.Build.VERSION.SDK_INT;
        r3 = 24;
        if (r2 < r3) goto L_0x0023;
    L_0x000a:
        r0 = new b.a0.b.a.i;
        r0.<init>();
        r6 = androidx.core.content.i.g.c(r6, r7, r8);
        r0.a = r6;
        r6 = new b.a0.b.a.i$i;
        r7 = r0.a;
        r7 = r7.getConstantState();
        r6.<init>(r7);
        r0.E0 = r6;
        return r0;
    L_0x0023:
        r7 = r6.getXml(r7);	 Catch:{ XmlPullParserException -> 0x004a, IOException -> 0x0045 }
        r2 = android.util.Xml.asAttributeSet(r7);	 Catch:{ XmlPullParserException -> 0x004a, IOException -> 0x0045 }
    L_0x002b:
        r3 = r7.next();	 Catch:{ XmlPullParserException -> 0x004a, IOException -> 0x0045 }
        r4 = 2;
        if (r3 == r4) goto L_0x0036;
    L_0x0032:
        r5 = 1;
        if (r3 == r5) goto L_0x0036;
    L_0x0035:
        goto L_0x002b;
    L_0x0036:
        if (r3 != r4) goto L_0x003d;
    L_0x0038:
        r6 = f(r6, r7, r2, r8);	 Catch:{ XmlPullParserException -> 0x004a, IOException -> 0x0045 }
        return r6;
    L_0x003d:
        r6 = new org.xmlpull.v1.XmlPullParserException;	 Catch:{ XmlPullParserException -> 0x004a, IOException -> 0x0045 }
        r7 = "No start tag found";
        r6.<init>(r7);	 Catch:{ XmlPullParserException -> 0x004a, IOException -> 0x0045 }
        throw r6;	 Catch:{ XmlPullParserException -> 0x004a, IOException -> 0x0045 }
    L_0x0045:
        r6 = move-exception;
        android.util.Log.e(r1, r0, r6);
        goto L_0x004e;
    L_0x004a:
        r6 = move-exception;
        android.util.Log.e(r1, r0, r6);
    L_0x004e:
        r6 = 0;
        return r6;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.a0.b.a.i.e(android.content.res.Resources, int, android.content.res.Resources$Theme):b.a0.b.a.i");
    }

    public static i f(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Theme theme) throws XmlPullParserException, IOException {
        i iVar = new i();
        iVar.inflate(resources, xmlPullParser, attributeSet, theme);
        return iVar;
    }

    private void i(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Theme theme) throws XmlPullParserException, IOException {
        h hVar = this.z0;
        g gVar = hVar.b;
        ArrayDeque arrayDeque = new ArrayDeque();
        arrayDeque.push(gVar.i);
        int eventType = xmlPullParser.getEventType();
        int depth = xmlPullParser.getDepth() + 1;
        Object obj = 1;
        while (eventType != 1 && (xmlPullParser.getDepth() >= depth || eventType != 3)) {
            String str = "group";
            if (eventType == 2) {
                String name = xmlPullParser.getName();
                d dVar = (d) arrayDeque.peek();
                f cVar;
                if (s.equals(name)) {
                    cVar = new c();
                    cVar.k(resources, attributeSet, theme, xmlPullParser);
                    dVar.b.add(cVar);
                    if (cVar.getPathName() != null) {
                        gVar.q.put(cVar.getPathName(), cVar);
                    }
                    obj = null;
                    hVar.a = cVar.c | hVar.a;
                } else if (d.equals(name)) {
                    cVar = new b();
                    cVar.i(resources, attributeSet, theme, xmlPullParser);
                    dVar.b.add(cVar);
                    if (cVar.getPathName() != null) {
                        gVar.q.put(cVar.getPathName(), cVar);
                    }
                    hVar.a = cVar.c | hVar.a;
                } else if (str.equals(name)) {
                    d dVar2 = new d();
                    dVar2.c(resources, attributeSet, theme, xmlPullParser);
                    dVar.b.add(dVar2);
                    arrayDeque.push(dVar2);
                    if (dVar2.getGroupName() != null) {
                        gVar.q.put(dVar2.getGroupName(), dVar2);
                    }
                    hVar.a = dVar2.k | hVar.a;
                }
            } else if (eventType == 3 && str.equals(xmlPullParser.getName())) {
                arrayDeque.pop();
            }
            eventType = xmlPullParser.next();
        }
        if (obj != null) {
            throw new XmlPullParserException("no path defined");
        }
    }

    private boolean j() {
        return VERSION.SDK_INT >= 17 && isAutoMirrored() && androidx.core.graphics.drawable.a.f(this) == 1;
    }

    private static Mode k(int i, Mode mode) {
        if (i == 3) {
            return Mode.SRC_OVER;
        }
        if (i == 5) {
            return Mode.SRC_IN;
        }
        if (i == 9) {
            return Mode.SRC_ATOP;
        }
        switch (i) {
            case 14:
                return Mode.MULTIPLY;
            case 15:
                return Mode.SCREEN;
            case 16:
                return Mode.ADD;
            default:
                return mode;
        }
    }

    private void l(d dVar, int i) {
        String str = "";
        for (int i2 = 0; i2 < i; i2++) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append("    ");
            str = stringBuilder.toString();
        }
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(str);
        stringBuilder2.append("current group is :");
        stringBuilder2.append(dVar.getGroupName());
        stringBuilder2.append(" rotation is ");
        stringBuilder2.append(dVar.c);
        String stringBuilder3 = stringBuilder2.toString();
        String str2 = b;
        Log.v(str2, stringBuilder3);
        stringBuilder2 = new StringBuilder();
        stringBuilder2.append(str);
        stringBuilder2.append("matrix is :");
        stringBuilder2.append(dVar.getLocalMatrix().toString());
        Log.v(str2, stringBuilder2.toString());
        for (int i3 = 0; i3 < dVar.b.size(); i3++) {
            e eVar = (e) dVar.b.get(i3);
            if (eVar instanceof d) {
                l((d) eVar, i + 1);
            } else {
                ((f) eVar).g(i + 1);
            }
        }
    }

    private void n(TypedArray typedArray, XmlPullParser xmlPullParser) throws XmlPullParserException {
        h hVar = this.z0;
        g gVar = hVar.b;
        hVar.d = k(androidx.core.content.i.h.k(typedArray, xmlPullParser, "tintMode", 6, -1), Mode.SRC_IN);
        ColorStateList colorStateList = typedArray.getColorStateList(1);
        if (colorStateList != null) {
            hVar.c = colorStateList;
        }
        hVar.e = androidx.core.content.i.h.e(typedArray, xmlPullParser, "autoMirrored", 5, hVar.e);
        gVar.l = androidx.core.content.i.h.j(typedArray, xmlPullParser, "viewportWidth", 7, gVar.l);
        float j = androidx.core.content.i.h.j(typedArray, xmlPullParser, "viewportHeight", 8, gVar.m);
        gVar.m = j;
        StringBuilder stringBuilder;
        if (gVar.l <= 0.0f) {
            stringBuilder = new StringBuilder();
            stringBuilder.append(typedArray.getPositionDescription());
            stringBuilder.append("<vector> tag requires viewportWidth > 0");
            throw new XmlPullParserException(stringBuilder.toString());
        } else if (j > 0.0f) {
            gVar.j = typedArray.getDimension(3, gVar.j);
            j = typedArray.getDimension(2, gVar.k);
            gVar.k = j;
            if (gVar.j <= 0.0f) {
                stringBuilder = new StringBuilder();
                stringBuilder.append(typedArray.getPositionDescription());
                stringBuilder.append("<vector> tag requires width > 0");
                throw new XmlPullParserException(stringBuilder.toString());
            } else if (j > 0.0f) {
                gVar.setAlpha(androidx.core.content.i.h.j(typedArray, xmlPullParser, "alpha", 4, gVar.getAlpha()));
                String string = typedArray.getString(0);
                if (string != null) {
                    gVar.o = string;
                    gVar.q.put(string, gVar);
                }
            } else {
                stringBuilder = new StringBuilder();
                stringBuilder.append(typedArray.getPositionDescription());
                stringBuilder.append("<vector> tag requires height > 0");
                throw new XmlPullParserException(stringBuilder.toString());
            }
        } else {
            stringBuilder = new StringBuilder();
            stringBuilder.append(typedArray.getPositionDescription());
            stringBuilder.append("<vector> tag requires viewportHeight > 0");
            throw new XmlPullParserException(stringBuilder.toString());
        }
    }

    public boolean canApplyTheme() {
        Drawable drawable = this.a;
        if (drawable != null) {
            androidx.core.graphics.drawable.a.b(drawable);
        }
        return false;
    }

    public void draw(Canvas canvas) {
        Drawable drawable = this.a;
        if (drawable != null) {
            drawable.draw(canvas);
            return;
        }
        copyBounds(this.H0);
        if (this.H0.width() > 0 && this.H0.height() > 0) {
            ColorFilter colorFilter = this.B0;
            if (colorFilter == null) {
                colorFilter = this.A0;
            }
            canvas.getMatrix(this.G0);
            this.G0.getValues(this.F0);
            float abs = Math.abs(this.F0[0]);
            float abs2 = Math.abs(this.F0[4]);
            float abs3 = Math.abs(this.F0[1]);
            float abs4 = Math.abs(this.F0[3]);
            if (!(abs3 == 0.0f && abs4 == 0.0f)) {
                abs = 1.0f;
                abs2 = 1.0f;
            }
            int height = (int) (((float) this.H0.height()) * abs2);
            int min = Math.min(2048, (int) (((float) this.H0.width()) * abs));
            height = Math.min(2048, height);
            if (min > 0 && height > 0) {
                int save = canvas.save();
                Rect rect = this.H0;
                canvas.translate((float) rect.left, (float) rect.top);
                if (j()) {
                    canvas.translate((float) this.H0.width(), 0.0f);
                    canvas.scale(-1.0f, 1.0f);
                }
                this.H0.offsetTo(0, 0);
                this.z0.c(min, height);
                if (!this.D0) {
                    this.z0.j(min, height);
                } else if (!this.z0.b()) {
                    this.z0.j(min, height);
                    this.z0.i();
                }
                this.z0.d(canvas, colorFilter, this.H0);
                canvas.restoreToCount(save);
            }
        }
    }

    @r0({androidx.annotation.r0.a.b})
    public float g() {
        h hVar = this.z0;
        if (hVar != null) {
            g gVar = hVar.b;
            if (gVar != null) {
                float f = gVar.j;
                if (f != 0.0f) {
                    float f2 = gVar.k;
                    if (f2 != 0.0f) {
                        float f3 = gVar.m;
                        if (f3 != 0.0f) {
                            float f4 = gVar.l;
                            if (f4 != 0.0f) {
                                return Math.min(f4 / f, f3 / f2);
                            }
                        }
                    }
                }
            }
        }
        return 1.0f;
    }

    public int getAlpha() {
        Drawable drawable = this.a;
        return drawable != null ? androidx.core.graphics.drawable.a.d(drawable) : this.z0.b.getRootAlpha();
    }

    public int getChangingConfigurations() {
        Drawable drawable = this.a;
        return drawable != null ? drawable.getChangingConfigurations() : super.getChangingConfigurations() | this.z0.getChangingConfigurations();
    }

    public ConstantState getConstantState() {
        if (this.a != null && VERSION.SDK_INT >= 24) {
            return new i(this.a.getConstantState());
        }
        this.z0.a = getChangingConfigurations();
        return this.z0;
    }

    public int getIntrinsicHeight() {
        Drawable drawable = this.a;
        return drawable != null ? drawable.getIntrinsicHeight() : (int) this.z0.b.k;
    }

    public int getIntrinsicWidth() {
        Drawable drawable = this.a;
        return drawable != null ? drawable.getIntrinsicWidth() : (int) this.z0.b.j;
    }

    public int getOpacity() {
        Drawable drawable = this.a;
        return drawable != null ? drawable.getOpacity() : -3;
    }

    Object h(String str) {
        return this.z0.b.q.get(str);
    }

    public void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet) throws XmlPullParserException, IOException {
        Drawable drawable = this.a;
        if (drawable != null) {
            drawable.inflate(resources, xmlPullParser, attributeSet);
        } else {
            inflate(resources, xmlPullParser, attributeSet, null);
        }
    }

    public void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Theme theme) throws XmlPullParserException, IOException {
        Drawable drawable = this.a;
        if (drawable != null) {
            androidx.core.graphics.drawable.a.g(drawable, resources, xmlPullParser, attributeSet, theme);
            return;
        }
        h hVar = this.z0;
        hVar.b = new g();
        TypedArray s = androidx.core.content.i.h.s(resources, theme, attributeSet, a.a);
        n(s, xmlPullParser);
        s.recycle();
        hVar.a = getChangingConfigurations();
        hVar.l = true;
        i(resources, xmlPullParser, attributeSet, theme);
        this.A0 = o(this.A0, hVar.c, hVar.d);
    }

    public void invalidateSelf() {
        Drawable drawable = this.a;
        if (drawable != null) {
            drawable.invalidateSelf();
        } else {
            super.invalidateSelf();
        }
    }

    public boolean isAutoMirrored() {
        Drawable drawable = this.a;
        return drawable != null ? androidx.core.graphics.drawable.a.h(drawable) : this.z0.e;
    }

    /* DevToolsApp WARNING: Missing block: B:13:0x0023, code:
            if (r0.isStateful() != false) goto L_0x0028;
     */
    public boolean isStateful() {
        /*
        r1 = this;
        r0 = r1.a;
        if (r0 == 0) goto L_0x0009;
    L_0x0004:
        r0 = r0.isStateful();
        return r0;
    L_0x0009:
        r0 = super.isStateful();
        if (r0 != 0) goto L_0x0028;
    L_0x000f:
        r0 = r1.z0;
        if (r0 == 0) goto L_0x0026;
    L_0x0013:
        r0 = r0.g();
        if (r0 != 0) goto L_0x0028;
    L_0x0019:
        r0 = r1.z0;
        r0 = r0.c;
        if (r0 == 0) goto L_0x0026;
    L_0x001f:
        r0 = r0.isStateful();
        if (r0 == 0) goto L_0x0026;
    L_0x0025:
        goto L_0x0028;
    L_0x0026:
        r0 = 0;
        goto L_0x0029;
    L_0x0028:
        r0 = 1;
    L_0x0029:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: b.a0.b.a.i.isStateful():boolean");
    }

    void m(boolean z) {
        this.D0 = z;
    }

    public Drawable mutate() {
        Drawable drawable = this.a;
        if (drawable != null) {
            drawable.mutate();
            return this;
        }
        if (!this.C0 && super.mutate() == this) {
            this.z0 = new h(this.z0);
            this.C0 = true;
        }
        return this;
    }

    PorterDuffColorFilter o(PorterDuffColorFilter porterDuffColorFilter, ColorStateList colorStateList, Mode mode) {
        return (colorStateList == null || mode == null) ? null : new PorterDuffColorFilter(colorStateList.getColorForState(getState(), 0), mode);
    }

    protected void onBoundsChange(Rect rect) {
        Drawable drawable = this.a;
        if (drawable != null) {
            drawable.setBounds(rect);
        }
    }

    protected boolean onStateChange(int[] iArr) {
        Drawable drawable = this.a;
        if (drawable != null) {
            return drawable.setState(iArr);
        }
        boolean z = false;
        h hVar = this.z0;
        ColorStateList colorStateList = hVar.c;
        boolean z2 = true;
        if (colorStateList != null) {
            Mode mode = hVar.d;
            if (mode != null) {
                this.A0 = o(this.A0, colorStateList, mode);
                invalidateSelf();
                z = true;
            }
        }
        if (hVar.g() && hVar.h(iArr)) {
            invalidateSelf();
        } else {
            z2 = z;
        }
        return z2;
    }

    public void scheduleSelf(Runnable runnable, long j) {
        Drawable drawable = this.a;
        if (drawable != null) {
            drawable.scheduleSelf(runnable, j);
        } else {
            super.scheduleSelf(runnable, j);
        }
    }

    public void setAlpha(int i) {
        Drawable drawable = this.a;
        if (drawable != null) {
            drawable.setAlpha(i);
            return;
        }
        if (this.z0.b.getRootAlpha() != i) {
            this.z0.b.setRootAlpha(i);
            invalidateSelf();
        }
    }

    public void setAutoMirrored(boolean z) {
        Drawable drawable = this.a;
        if (drawable != null) {
            androidx.core.graphics.drawable.a.j(drawable, z);
        } else {
            this.z0.e = z;
        }
    }

    public void setColorFilter(ColorFilter colorFilter) {
        Drawable drawable = this.a;
        if (drawable != null) {
            drawable.setColorFilter(colorFilter);
            return;
        }
        this.B0 = colorFilter;
        invalidateSelf();
    }

    public void setTint(int i) {
        Drawable drawable = this.a;
        if (drawable != null) {
            androidx.core.graphics.drawable.a.n(drawable, i);
        } else {
            setTintList(ColorStateList.valueOf(i));
        }
    }

    public void setTintList(ColorStateList colorStateList) {
        Drawable drawable = this.a;
        if (drawable != null) {
            androidx.core.graphics.drawable.a.o(drawable, colorStateList);
            return;
        }
        h hVar = this.z0;
        if (hVar.c != colorStateList) {
            hVar.c = colorStateList;
            this.A0 = o(this.A0, colorStateList, hVar.d);
            invalidateSelf();
        }
    }

    public void setTintMode(Mode mode) {
        Drawable drawable = this.a;
        if (drawable != null) {
            androidx.core.graphics.drawable.a.p(drawable, mode);
            return;
        }
        h hVar = this.z0;
        if (hVar.d != mode) {
            hVar.d = mode;
            this.A0 = o(this.A0, hVar.c, mode);
            invalidateSelf();
        }
    }

    public boolean setVisible(boolean z, boolean z2) {
        Drawable drawable = this.a;
        return drawable != null ? drawable.setVisible(z, z2) : super.setVisible(z, z2);
    }

    public void unscheduleSelf(Runnable runnable) {
        Drawable drawable = this.a;
        if (drawable != null) {
            drawable.unscheduleSelf(runnable);
        } else {
            super.unscheduleSelf(runnable);
        }
    }
}
