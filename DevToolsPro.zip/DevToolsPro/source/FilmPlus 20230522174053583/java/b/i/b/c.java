package b.i.b;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public abstract class c extends a {
    private int v0;
    private int w0;
    private LayoutInflater x0;

    @Deprecated
    public c(Context context, int i, Cursor cursor) {
        super(context, cursor);
        this.w0 = i;
        this.v0 = i;
        this.x0 = (LayoutInflater) context.getSystemService("layout_inflater");
    }

    public c(Context context, int i, Cursor cursor, int i2) {
        super(context, cursor, i2);
        this.w0 = i;
        this.v0 = i;
        this.x0 = (LayoutInflater) context.getSystemService("layout_inflater");
    }

    @Deprecated
    public c(Context context, int i, Cursor cursor, boolean z) {
        super(context, cursor, z);
        this.w0 = i;
        this.v0 = i;
        this.x0 = (LayoutInflater) context.getSystemService("layout_inflater");
    }

    public View i(Context context, Cursor cursor, ViewGroup viewGroup) {
        return this.x0.inflate(this.w0, viewGroup, false);
    }

    public View j(Context context, Cursor cursor, ViewGroup viewGroup) {
        return this.x0.inflate(this.v0, viewGroup, false);
    }

    public void n(int i) {
        this.w0 = i;
    }

    public void o(int i) {
        this.v0 = i;
    }
}
