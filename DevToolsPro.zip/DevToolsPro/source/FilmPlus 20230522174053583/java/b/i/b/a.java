package b.i.b;

import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.os.Handler;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.FilterQueryProvider;
import android.widget.Filterable;
import androidx.annotation.r0;

public abstract class a extends BaseAdapter implements Filterable, a {
    @Deprecated
    public static final int a = 1;
    public static final int b = 2;
    @r0({androidx.annotation.r0.a.b})
    protected boolean c;
    @r0({androidx.annotation.r0.a.b})
    protected boolean d;
    @r0({androidx.annotation.r0.a.b})
    protected Cursor f;
    @r0({androidx.annotation.r0.a.b})
    protected int q0;
    @r0({androidx.annotation.r0.a.b})
    protected a r0;
    @r0({androidx.annotation.r0.a.b})
    protected Context s;
    @r0({androidx.annotation.r0.a.b})
    protected DataSetObserver s0;
    @r0({androidx.annotation.r0.a.b})
    protected b t0;
    @r0({androidx.annotation.r0.a.b})
    protected FilterQueryProvider u0;

    private class a extends ContentObserver {
        a() {
            super(new Handler());
        }

        public boolean deliverSelfNotifications() {
            return true;
        }

        public void onChange(boolean z) {
            a.this.k();
        }
    }

    private class b extends DataSetObserver {
        b() {
        }

        public void onChanged() {
            BaseAdapter baseAdapter = a.this;
            baseAdapter.c = true;
            baseAdapter.notifyDataSetChanged();
        }

        public void onInvalidated() {
            BaseAdapter baseAdapter = a.this;
            baseAdapter.c = false;
            baseAdapter.notifyDataSetInvalidated();
        }
    }

    @Deprecated
    public a(Context context, Cursor cursor) {
        g(context, cursor, 1);
    }

    public a(Context context, Cursor cursor, int i) {
        g(context, cursor, i);
    }

    public a(Context context, Cursor cursor, boolean z) {
        g(context, cursor, z ? 1 : 2);
    }

    public CharSequence a(Cursor cursor) {
        return cursor == null ? "" : cursor.toString();
    }

    public void b(Cursor cursor) {
        cursor = m(cursor);
        if (cursor != null) {
            cursor.close();
        }
    }

    public Cursor c() {
        return this.f;
    }

    public Cursor d(CharSequence charSequence) {
        FilterQueryProvider filterQueryProvider = this.u0;
        return filterQueryProvider != null ? filterQueryProvider.runQuery(charSequence) : this.f;
    }

    public abstract void e(View view, Context context, Cursor cursor);

    public FilterQueryProvider f() {
        return this.u0;
    }

    void g(Context context, Cursor cursor, int i) {
        boolean z = false;
        if ((i & 1) == 1) {
            i |= 2;
            this.d = true;
        } else {
            this.d = false;
        }
        if (cursor != null) {
            z = true;
        }
        this.f = cursor;
        this.c = z;
        this.s = context;
        this.q0 = z ? cursor.getColumnIndexOrThrow("_id") : -1;
        if ((i & 2) == 2) {
            this.r0 = new a();
            this.s0 = new b();
        } else {
            this.r0 = null;
            this.s0 = null;
        }
        if (z) {
            ContentObserver contentObserver = this.r0;
            if (contentObserver != null) {
                cursor.registerContentObserver(contentObserver);
            }
            DataSetObserver dataSetObserver = this.s0;
            if (dataSetObserver != null) {
                cursor.registerDataSetObserver(dataSetObserver);
            }
        }
    }

    public int getCount() {
        if (this.c) {
            Cursor cursor = this.f;
            if (cursor != null) {
                return cursor.getCount();
            }
        }
        return 0;
    }

    public View getDropDownView(int i, View view, ViewGroup viewGroup) {
        if (!this.c) {
            return null;
        }
        this.f.moveToPosition(i);
        if (view == null) {
            view = i(this.s, this.f, viewGroup);
        }
        e(view, this.s, this.f);
        return view;
    }

    public Filter getFilter() {
        if (this.t0 == null) {
            this.t0 = new b(this);
        }
        return this.t0;
    }

    public Object getItem(int i) {
        if (this.c) {
            Cursor cursor = this.f;
            if (cursor != null) {
                cursor.moveToPosition(i);
                return this.f;
            }
        }
        return null;
    }

    public long getItemId(int i) {
        if (this.c) {
            Cursor cursor = this.f;
            if (cursor != null && cursor.moveToPosition(i)) {
                return this.f.getLong(this.q0);
            }
        }
        return 0;
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        if (!this.c) {
            throw new IllegalStateException("this should only be called when the cursor is valid");
        } else if (this.f.moveToPosition(i)) {
            if (view == null) {
                view = j(this.s, this.f, viewGroup);
            }
            e(view, this.s, this.f);
            return view;
        } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("couldn't move cursor to position ");
            stringBuilder.append(i);
            throw new IllegalStateException(stringBuilder.toString());
        }
    }

    @Deprecated
    protected void h(Context context, Cursor cursor, boolean z) {
        g(context, cursor, z ? 1 : 2);
    }

    public boolean hasStableIds() {
        return true;
    }

    public View i(Context context, Cursor cursor, ViewGroup viewGroup) {
        return j(context, cursor, viewGroup);
    }

    public abstract View j(Context context, Cursor cursor, ViewGroup viewGroup);

    protected void k() {
        if (this.d) {
            Cursor cursor = this.f;
            if (cursor != null && !cursor.isClosed()) {
                this.c = this.f.requery();
            }
        }
    }

    public void l(FilterQueryProvider filterQueryProvider) {
        this.u0 = filterQueryProvider;
    }

    public Cursor m(Cursor cursor) {
        Cursor cursor2 = this.f;
        if (cursor == cursor2) {
            return null;
        }
        ContentObserver contentObserver;
        DataSetObserver dataSetObserver;
        if (cursor2 != null) {
            contentObserver = this.r0;
            if (contentObserver != null) {
                cursor2.unregisterContentObserver(contentObserver);
            }
            dataSetObserver = this.s0;
            if (dataSetObserver != null) {
                cursor2.unregisterDataSetObserver(dataSetObserver);
            }
        }
        this.f = cursor;
        if (cursor != null) {
            contentObserver = this.r0;
            if (contentObserver != null) {
                cursor.registerContentObserver(contentObserver);
            }
            dataSetObserver = this.s0;
            if (dataSetObserver != null) {
                cursor.registerDataSetObserver(dataSetObserver);
            }
            this.q0 = cursor.getColumnIndexOrThrow("_id");
            this.c = true;
            notifyDataSetChanged();
        } else {
            this.q0 = -1;
            this.c = false;
            notifyDataSetInvalidated();
        }
        return cursor2;
    }
}
